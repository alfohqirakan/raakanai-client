import { BrowserRouter, Routes, Route } from "react-router-dom";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { RTLWrapper, DirectionToggle } from "@/components/RTLWrapper";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import Dashboard from "@/pages/Dashboard";
import CreativeHub from "@/pages/CreativeHub";
import CommandCenter from "@/pages/CommandCenter";
import ProjectExport from "@/pages/ProjectExport";
import EntityMonitor from "@/pages/EntityMonitor";
import Plans from "@/pages/Plans";
import MonitoringDashboard from "@/pages/MonitoringDashboard";
import CodePlayground from "@/pages/CodePlayground";
import FalconEvolution from "@/pages/FalconEvolution";
import { FalconIntelligence } from "@/pages/FalconIntelligence";
import { FalconEvolutionCenter } from "@/pages/FalconEvolutionCenter";
import { NeuralNetworkCenter } from "@/pages/NeuralNetworkCenter";
import AvatarCustomization from "@/pages/AvatarCustomization";
import SovereignTerminal from "@/pages/SovereignTerminal";
import SystemDashboard from "@/pages/SystemDashboard";
import RakanDashboard from "@/pages/RakanDashboard";
import SystemArchitecture from "@/pages/SystemArchitecture";
import ConsciousnessTracker from "@/pages/ConsciousnessTracker";
import GovernanceDashboard from "@/pages/GovernanceDashboard";
import GovernmentIntegration from "@/pages/GovernmentIntegration";
import SaudiNationalMemory from "@/pages/SaudiNationalMemory";
import NEOMFuture from "@/pages/NEOMFuture";
import Login from "@/pages/Login";
import GoogleLogin from "@/pages/GoogleLogin";
import NotFoundPage from "@/pages/not-found";

function Router() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/google-login" element={<GoogleLogin />} />
      <Route path="/" element={<RakanDashboard />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/rakan" element={<RakanDashboard />} />
      <Route path="/creative-hub" element={<CreativeHub />} />
      <Route path="/command-center" element={<CommandCenter />} />
      <Route path="/project-export" element={<ProjectExport />} />
      <Route path="/entity-monitor" element={<EntityMonitor />} />
      <Route path="/monitoring" element={<MonitoringDashboard />} />
      <Route path="/plans" element={<Plans />} />
      <Route path="/code-playground" element={<CodePlayground />} />
      <Route path="/falcon-evolution" element={<FalconEvolution />} />
      <Route path="/falcon-intelligence" element={<FalconIntelligence />} />
      <Route path="/falcon-center" element={<FalconEvolutionCenter />} />
      <Route path="/neural-network" element={<NeuralNetworkCenter />} />
      <Route path="/avatar-customization" element={<AvatarCustomization />} />
      <Route path="/sovereign-terminal" element={<SovereignTerminal />} />
      <Route path="/system-dashboard" element={<SystemDashboard />} />
      <Route path="/system-architecture" element={<SystemArchitecture />} />
      <Route path="/consciousness-tracker" element={<ConsciousnessTracker />} />
      <Route path="/evolution" element={<FalconEvolution />} />
      <Route path="/governance" element={<GovernanceDashboard />} />
      <Route path="/integration" element={<GovernmentIntegration />} />
      <Route path="/memory" element={<SaudiNationalMemory />} />
      <Route path="/neom" element={<NEOMFuture />} />
      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <RTLWrapper>
        <TooltipProvider>
          <AuthProvider>
            <BrowserRouter>
              <div className="min-h-screen bg-background text-foreground">
                {/* Direction Toggle - Fixed positioned for easy access */}
                <div className="fixed top-4 left-4 z-50">
                  <DirectionToggle className="bg-gray-800/90 text-white hover:bg-gray-700/90 backdrop-blur-sm" />
                </div>
                
                <Toaster />
                <Router />
              </div>
            </BrowserRouter>
          </AuthProvider>
        </TooltipProvider>
      </RTLWrapper>
    </QueryClientProvider>
  );
}

export default App;
