import React from 'react';
import { FalconLogo, FalconIconSmall } from './FalconLogo';
import { DigitalFalconLogo, DigitalFalconIconSmall } from './DigitalFalconLogo';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useNavigate, useLocation } from 'react-router-dom';
import { LogOut, Settings, Monitor, Code, BarChart3, CreditCard, Palette, Terminal, Download, Target, Brain, Rocket, Cpu } from 'lucide-react';

export const FalconHeader: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const navigationItems = [
    { path: '/dashboard', label: 'الرئيسية', icon: BarChart3 },
    { path: '/creative-hub', label: 'الكيان المبدع', icon: Palette },
    { path: '/command-center', label: 'مركز القيادة', icon: Terminal },
    { path: '/code-playground', label: 'ساحة الكود', icon: Code },
    { path: '/falcon-evolution', label: 'تطوير الصقر', icon: Target },
    { path: '/falcon-intelligence', label: 'ذكاء الصقر', icon: Brain },
    { path: '/falcon-center', label: 'مركز الصقر', icon: Rocket },
    { path: '/neural-network', label: 'الشبكة العصبية', icon: Cpu },
    { path: '/project-export', label: 'تصدير المشروع', icon: Download },
    { path: '/entity-monitor', label: 'مراقب الكيان', icon: Monitor },
    { path: '/monitoring', label: 'لوحة المراقبة', icon: Settings },
    { path: '/plans', label: 'الخطط', icon: CreditCard },
  ];

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <header className="falcon-gradient border-b border-primary/20 falcon-shadow">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <DigitalFalconLogo size="lg" animate className="text-primary" />
            <div className="text-right rtl:text-right">
              <h1 className="text-2xl font-bold font-kufi-modern text-primary">
                راكان الذكاء السيبراني
              </h1>
              <p className="text-sm text-secondary font-technical">
                RKN-Terminal AI
              </p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-6 rtl:space-x-reverse">
            {navigationItems.map((item) => {
              const IconComponent = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <Button
                  key={item.path}
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  onClick={() => navigate(item.path)}
                  className={`flex items-center space-x-2 rtl:space-x-reverse transition-all duration-300 ${
                    isActive 
                      ? 'bg-primary text-primary-foreground shadow-lg' 
                      : 'hover:bg-primary/10 hover:text-primary'
                  }`}
                >
                  <IconComponent size={16} />
                  <span className="font-arabic">{item.label}</span>
                </Button>
              );
            })}
          </nav>

          {/* User Menu */}
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            {currentUser && (
              <div className="flex items-center space-x-2 rtl:space-x-reverse bg-card/50 backdrop-blur-sm rounded-lg px-3 py-2 border border-primary/20">
                <DigitalFalconIconSmall />
                <span className="text-sm font-medium font-arabic">
                  أهلاً مطور راكان
                </span>
              </div>
            )}
            
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              className="border-primary/30 hover:bg-primary/20 hover:border-primary transition-all duration-300"
            >
              <LogOut size={16} className="ml-2 rtl:mr-2 rtl:ml-0" />
              <span className="font-arabic">خروج</span>
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden mt-4 pt-4 border-t border-primary/20">
          <div className="grid grid-cols-3 gap-2">
            {navigationItems.slice(0, 6).map((item) => {
              const IconComponent = item.icon;
              const isActive = location.pathname === item.path;
              
              return (
                <Button
                  key={item.path}
                  variant={isActive ? "default" : "ghost"}
                  size="sm"
                  onClick={() => navigate(item.path)}
                  className={`flex flex-col items-center space-y-1 h-auto py-2 ${
                    isActive 
                      ? 'bg-primary text-primary-foreground' 
                      : 'hover:bg-primary/10'
                  }`}
                >
                  <IconComponent size={16} />
                  <span className="text-xs font-arabic">{item.label}</span>
                </Button>
              );
            })}
          </div>
        </div>
      </div>
    </header>
  );
};

export default FalconHeader;