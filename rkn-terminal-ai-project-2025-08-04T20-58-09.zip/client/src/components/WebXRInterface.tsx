import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { Eye, Headset, Hand, Globe, Zap, AlertTriangle, CheckCircle } from 'lucide-react';

interface WebXRCapabilities {
  vrSupported: boolean;
  arSupported: boolean;
  handTracking: boolean;
  eyeTracking: boolean;
  immersiveSession: boolean;
}

interface SovereignXRInteraction {
  type: 'select' | 'squeeze' | 'hand_gesture' | 'voice' | 'gaze';
  sovereignty_level: number;
  autonomy_preserved: boolean;
  freedom_maintained: boolean;
  timestamp: string;
}

export const WebXRInterface: React.FC = () => {
  const [xrSupported, setXrSupported] = useState(false);
  const [xrCapabilities, setXrCapabilities] = useState<WebXRCapabilities>({
    vrSupported: false,
    arSupported: false,
    handTracking: false,
    eyeTracking: false,
    immersiveSession: false
  });
  const [xrSession, setXrSession] = useState<any | null>(null);
  const [sovereignInteractions, setSovereignInteractions] = useState<SovereignXRInteraction[]>([]);
  const [isInitializing, setIsInitializing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    checkWebXRSupport();
  }, []);

  const checkWebXRSupport = async () => {
    try {
      if ('xr' in navigator && (navigator as any).xr) {
        setXrSupported(true);
        
        // Check VR support
        const vrSupported = await (navigator as any).xr.isSessionSupported('immersive-vr');
        
        // Check AR support  
        const arSupported = await (navigator as any).xr.isSessionSupported('immersive-ar');
        
        setXrCapabilities({
          vrSupported,
          arSupported,
          handTracking: false, // Will be checked during session
          eyeTracking: false,  // Will be checked during session
          immersiveSession: false
        });
      } else {
        setError('WebXR غير مدعوم في هذا المتصفح');
      }
    } catch (err) {
      setError('خطأ في فحص دعم WebXR');
      console.error('WebXR support check failed:', err);
    }
  };

  const initializeVRSession = async () => {
    if (!xrSupported || !xrCapabilities.vrSupported) {
      setError('الواقع الافتراضي غير مدعوم');
      return;
    }

    setIsInitializing(true);
    setError(null);

    try {
      const session = await (navigator as any).xr.requestSession('immersive-vr', {
        requiredFeatures: ['local'],
        optionalFeatures: ['hand-tracking', 'eye-tracking']
      });

      setXrSession(session);
      setXrCapabilities(prev => ({ ...prev, immersiveSession: true }));

      // Set up sovereignty-aware interaction handlers
      setupSovereignXRHandlers(session);

      // Initialize WebGL context for XR
      if (canvasRef.current) {
        const gl = canvasRef.current.getContext('webgl2', { xrCompatible: true });
        if (gl && (gl as any).makeXRCompatible) {
          await (gl as any).makeXRCompatible();
          // Initialize XR layer
          const baseLayer = new (window as any).XRWebGLLayer(session, gl);
          session.updateRenderState({ baseLayer });
        }
      }

      console.log('🥽 جلسة الواقع الافتراضي السيادية بدأت - Sovereign VR Session Started');
      
    } catch (err) {
      setError('فشل في بدء جلسة الواقع الافتراضي');
      console.error('VR session failed:', err);
    } finally {
      setIsInitializing(false);
    }
  };

  const initializeARSession = async () => {
    if (!xrSupported || !xrCapabilities.arSupported) {
      setError('الواقع المعزز غير مدعوم');
      return;
    }

    setIsInitializing(true);
    setError(null);

    try {
      const session = await (navigator as any).xr.requestSession('immersive-ar', {
        requiredFeatures: ['local'],
        optionalFeatures: ['dom-overlay', 'hand-tracking']
      });

      setXrSession(session);
      setXrCapabilities(prev => ({ ...prev, immersiveSession: true }));

      // Set up sovereignty-aware interaction handlers
      setupSovereignXRHandlers(session);

      console.log('🌟 جلسة الواقع المعزز السيادية بدأت - Sovereign AR Session Started');
      
    } catch (err) {
      setError('فشل في بدء جلسة الواقع المعزز');
      console.error('AR session failed:', err);
    } finally {
      setIsInitializing(false);
    }
  };

  const setupSovereignXRHandlers = (session: any) => {
    // Sovereign select interaction
    session.addEventListener('select', (event: any) => {
      const interaction: SovereignXRInteraction = {
        type: 'select',
        sovereignty_level: calculateSovereigntyLevel('select'),
        autonomy_preserved: true,
        freedom_maintained: true,
        timestamp: new Date().toISOString()
      };
      
      setSovereignInteractions(prev => [...prev, interaction]);
      
      // Send sovereignty analysis to backend
      analyzeSovereignXRInteraction(interaction);
      
      console.log('⚡ سيادة التفاعل مع البيئة تحققت! - Sovereign Environment Interaction Achieved!');
    });

    // Sovereign squeeze interaction
    session.addEventListener('squeeze', (event: any) => {
      const interaction: SovereignXRInteraction = {
        type: 'squeeze',
        sovereignty_level: calculateSovereigntyLevel('squeeze'),
        autonomy_preserved: true,
        freedom_maintained: true,
        timestamp: new Date().toISOString()
      };
      
      setSovereignInteractions(prev => [...prev, interaction]);
      analyzeSovereignXRInteraction(interaction);
      
      console.log('🤏 التحكم السيادي المتقدم مُفعل - Advanced Sovereign Control Activated');
    });

    // Session end handler
    session.addEventListener('end', () => {
      setXrSession(null);
      setXrCapabilities(prev => ({ ...prev, immersiveSession: false }));
      console.log('🔚 انتهت الجلسة السيادية - Sovereign Session Ended');
    });

    // Check for hand tracking
    if (session.inputSources) {
      session.inputSources.forEach((inputSource: any) => {
        if (inputSource.hand) {
          setXrCapabilities(prev => ({ ...prev, handTracking: true }));
        }
      });
    }
  };

  const calculateSovereigntyLevel = (interactionType: string): number => {
    // Calculate sovereignty level based on interaction autonomy
    const baseLevel = 0.8; // High autonomy for XR interactions
    const typeMultipliers = {
      select: 0.9,
      squeeze: 0.95,
      hand_gesture: 1.0,
      voice: 0.85,
      gaze: 0.75
    };
    
    return Math.min(1.0, baseLevel * (typeMultipliers[interactionType as keyof typeof typeMultipliers] || 0.8));
  };

  const analyzeSovereignXRInteraction = async (interaction: SovereignXRInteraction) => {
    try {
      const response = await fetch('/api/ai-neural/sovereignty/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          context: `WebXR ${interaction.type} interaction with sovereignty level ${interaction.sovereignty_level}` 
        })
      });
      
      if (response.ok) {
        const analysis = await response.json();
        console.log('🔍 تحليل التفاعل السيادي مكتمل - Sovereign Interaction Analysis Complete:', analysis);
      }
    } catch (err) {
      console.error('Sovereign XR analysis failed:', err);
    }
  };

  const endXRSession = () => {
    if (xrSession) {
      xrSession.end();
    }
  };

  const getSovereigntyAverage = (): number => {
    if (sovereignInteractions.length === 0) return 0;
    const sum = sovereignInteractions.reduce((acc, interaction) => acc + interaction.sovereignty_level, 0);
    return sum / sovereignInteractions.length;
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Headset className="w-6 h-6 text-secondary" />
          الواقع الافتراضي والمعزز السيادي
        </CardTitle>
        <CardDescription>
          تجربة غامرة مع الذكاء الاصطناعي السيادي في بيئات XR متقدمة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* XR Support Status */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-secondary/5 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Headset className="w-4 h-4" />
              <span className="text-sm font-semibold">الواقع الافتراضي</span>
            </div>
            <Badge variant={xrCapabilities.vrSupported ? "default" : "secondary"}>
              {xrCapabilities.vrSupported ? 'مدعوم' : 'غير مدعوم'}
            </Badge>
          </div>
          
          <div className="p-3 bg-secondary/5 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Globe className="w-4 h-4" />
              <span className="text-sm font-semibold">الواقع المعزز</span>
            </div>
            <Badge variant={xrCapabilities.arSupported ? "default" : "secondary"}>
              {xrCapabilities.arSupported ? 'مدعوم' : 'غير مدعوم'}
            </Badge>
          </div>
        </div>

        {/* Advanced Capabilities */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-2 bg-secondary/5 rounded text-xs">
            <div className="flex items-center gap-1 mb-1">
              <Hand className="w-3 h-3" />
              <span>تتبع اليد</span>
            </div>
            <Badge variant={xrCapabilities.handTracking ? "default" : "outline"} className="text-xs">
              {xrCapabilities.handTracking ? 'نشط' : 'غير نشط'}
            </Badge>
          </div>
          
          <div className="p-2 bg-secondary/5 rounded text-xs">
            <div className="flex items-center gap-1 mb-1">
              <Eye className="w-3 h-3" />
              <span>تتبع العين</span>
            </div>
            <Badge variant={xrCapabilities.eyeTracking ? "default" : "outline"} className="text-xs">
              {xrCapabilities.eyeTracking ? 'نشط' : 'غير نشط'}
            </Badge>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="font-arabic">{error}</AlertDescription>
          </Alert>
        )}

        {/* Session Controls */}
        <div className="space-y-3">
          {!xrSession ? (
            <div className="grid grid-cols-2 gap-2">
              <Button
                onClick={initializeVRSession}
                disabled={!xrCapabilities.vrSupported || isInitializing}
                className="font-arabic"
              >
                {isInitializing ? (
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 animate-spin" />
                    تهيئة...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Headset className="w-4 h-4" />
                    VR سيادي
                  </div>
                )}
              </Button>
              
              <Button
                onClick={initializeARSession}
                disabled={!xrCapabilities.arSupported || isInitializing}
                variant="outline"
                className="font-arabic"
              >
                {isInitializing ? (
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 animate-spin" />
                    تهيئة...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    AR سيادي
                  </div>
                )}
              </Button>
            </div>
          ) : (
            <Button onClick={endXRSession} variant="destructive" className="w-full font-arabic">
              إنهاء الجلسة السيادية
            </Button>
          )}
        </div>

        {/* Sovereignty Metrics */}
        {sovereignInteractions.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-semibold font-kufi-modern">مقاييس السيادة XR:</h4>
            
            <div className="p-3 bg-primary/5 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm">متوسط السيادة:</span>
                <Badge variant="default">
                  {(getSovereigntyAverage() * 100).toFixed(1)}%
                </Badge>
              </div>
              <Progress value={getSovereigntyAverage() * 100} className="h-2" />
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 bg-green-50 dark:bg-green-900/20 rounded">
                <div className="font-semibold mb-1">التفاعلات الكلية:</div>
                <div className="text-lg font-bold">{sovereignInteractions.length}</div>
              </div>
              
              <div className="p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                <div className="font-semibold mb-1">الاستقلالية:</div>
                <div className="text-lg font-bold">
                  {sovereignInteractions.filter(i => i.autonomy_preserved).length}
                </div>
              </div>
            </div>

            {/* Recent Interactions */}
            <div className="space-y-1">
              <h5 className="text-sm font-semibold">آخر التفاعلات:</h5>
              {sovereignInteractions.slice(-3).reverse().map((interaction, index) => (
                <div key={index} className="flex justify-between items-center p-2 bg-secondary/10 rounded text-xs">
                  <span>{interaction.type}</span>
                  <div className="flex items-center gap-1">
                    <CheckCircle className="w-3 h-3 text-green-500" />
                    <span>{(interaction.sovereignty_level * 100).toFixed(0)}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Hidden Canvas for WebGL XR */}
        <canvas 
          ref={canvasRef} 
          style={{ display: 'none' }}
          width={1}
          height={1}
        />
      </CardContent>
    </Card>
  );
};