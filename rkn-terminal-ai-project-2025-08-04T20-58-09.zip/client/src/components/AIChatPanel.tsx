import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { ChatMessage } from "@shared/schema";

interface AIChatPanelProps {
  isOpen: boolean;
  onClose: () => void;
  selectedFileId: string | null;
}

export default function AIChatPanel({ isOpen, onClose, selectedFileId }: AIChatPanelProps) {
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: messages = [], isLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/chat/messages", selectedFileId],
    enabled: !!selectedFileId,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      return await apiRequest('POST', '/api/chat/messages', {
        userId: 'default-user',
        fileId: selectedFileId,
        role: 'user',
        content
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat/messages'] });
      setMessage("");
    },
    onError: (error) => {
      toast({
        title: "فشل في إرسال الرسالة",
        description: (error as Error).message,
        variant: "destructive",
      });
    },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate(message.trim());
    }
  };

  if (!isOpen) return null;

  return (
    <div className="w-80 bg-charcoal border-r border-gray-700 flex flex-col">
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-br from-electric-blue to-ai-purple rounded-lg flex items-center justify-center">
              <i className="fas fa-robot text-white text-sm"></i>
            </div>
            <div>
              <h3 className="font-semibold">مساعد راكان AI</h3>
              <p className="text-xs text-gray-400">متصل ونشط</p>
            </div>
          </div>
          <button 
            className="text-gray-400 hover:text-white transition-colors"
            onClick={onClose}
          >
            <i className="fas fa-times"></i>
          </button>
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="w-8 h-8 border-2 border-electric-blue border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 bg-electric-blue rounded-full flex items-center justify-center flex-shrink-0">
              <i className="fas fa-robot text-white text-xs"></i>
            </div>
            <div className="flex-1">
              <div className="bg-gray-800 rounded-xl p-3 text-sm">
                مرحباً! أنا مساعدك الذكي راكان. يمكنني مساعدتك في تحليل الملفات، استخراج المعلومات، والإجابة على أسئلتك حول محتوى الملفات المرفوعة.
              </div>
              <p className="text-xs text-gray-500 mt-1">الآن</p>
            </div>
          </div>
        ) : (
          messages.map((msg) => (
            <div key={msg.id} className={`flex items-start gap-3 ${msg.role === 'user' ? 'justify-end' : ''}`}>
              {msg.role === 'assistant' && (
                <div className="w-6 h-6 bg-electric-blue rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-robot text-white text-xs"></i>
                </div>
              )}
              <div className={`flex-1 ${msg.role === 'user' ? 'text-left' : ''}`}>
                <div className={`rounded-xl p-3 text-sm ${
                  msg.role === 'user' 
                    ? 'bg-electric-blue ml-8' 
                    : 'bg-gray-800'
                }`}>
                  {msg.content}
                </div>
                <p className={`text-xs text-gray-500 mt-1 ${msg.role === 'user' ? 'text-left' : ''}`}>
                  {new Date(msg.timestamp || '').toLocaleString('ar-EG')}
                </p>
              </div>
              {msg.role === 'user' && (
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-electric-blue to-ai-purple flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-user text-white text-xs"></i>
                </div>
              )}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input */}
      <div className="p-4 border-t border-gray-700">
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <input 
            type="text" 
            placeholder="اكتب رسالتك هنا..." 
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            disabled={sendMessageMutation.isPending}
            className="flex-1 bg-gray-800 border border-gray-600 rounded-xl px-4 py-2 text-white placeholder-gray-400 focus:border-electric-blue focus:ring-1 focus:ring-electric-blue transition-all text-sm"
          />
          <button 
            type="submit"
            disabled={!message.trim() || sendMessageMutation.isPending}
            className="w-10 h-10 bg-electric-blue hover:bg-electric-blue/80 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl flex items-center justify-center transition-colors"
          >
            {sendMessageMutation.isPending ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <i className="fas fa-paper-plane text-white text-sm"></i>
            )}
          </button>
        </form>
        <div className="flex items-center gap-2 mt-2">
          <button className="text-xs text-gray-400 hover:text-electric-blue transition-colors">
            <i className="fas fa-paperclip mr-1"></i>إرفاق ملف
          </button>
          <button className="text-xs text-gray-400 hover:text-electric-blue transition-colors">
            <i className="fas fa-microphone mr-1"></i>رسالة صوتية
          </button>
        </div>
      </div>
    </div>
  );
}
