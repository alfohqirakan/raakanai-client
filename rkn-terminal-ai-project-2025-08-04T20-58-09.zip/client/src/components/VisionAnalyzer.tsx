import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Eye, Image, FileText, Scan, Zap, CheckCircle, AlertCircle, Camera, Download, Brain } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useDirection } from '@/lib/direction';
import { useAIStore, useVisionResult, useProcessingStatus, type VisionAnalysisResult } from '@/store/aiStore';

interface FileState {
  id: string;
  file: File;
  preview: string;
}

interface AnalysisState {
  isAnalyzing: boolean;
  progress: number;
  results: VisionAnalysisResult | null;
  error: string | null;
  imagePreview: string | null;
  fileName: string | null;
}

export function VisionAnalyzer() {
  const [currentFile, setCurrentFile] = useState<FileState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);

  const { toast } = useToast();
  const { dir } = useDirection();
  
  // AI Store hooks
  const { setVisionResult, setProcessing, updateMetrics, updateAISettings } = useAIStore();
  const isProcessing = useProcessingStatus(currentFile?.id || '');
  const visionResult = useVisionResult(currentFile?.id || '');

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    const fileId = `vision_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const previewUrl = URL.createObjectURL(file);
    
    setCurrentFile({
      id: fileId,
      file,
      preview: previewUrl
    });
    setError(null);
    setProgress(10);
    setProcessing(fileId, true);

    const startTime = Date.now();

    try {
      const formData = new FormData();
      formData.append('image', file);

      // محاكاة تقدم التحليل
      const progressInterval = setInterval(() => {
        setProgress(prev => Math.min(prev + 15, 85));
      }, 500);

      const response = await axios.post('/api/vision/analyze', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });

      clearInterval(progressInterval);

      if (response.data.status === '✅ success') {
        const result = response.data.data.analysis;
        setVisionResult(fileId, result);
        setProgress(100);
        setProcessing(fileId, false);
        
        // Update metrics
        const processingTime = Date.now() - startTime;
        updateMetrics('vision', processingTime, true);

        toast({
          title: "تم تحليل الصورة بنجاح",
          description: `تم تحليل ${file.name} بواسطة RKN Vision AI`,
          variant: "default"
        });
      } else {
        throw new Error(response.data.message || 'فشل في تحليل الصورة');
      }

    } catch (error: any) {
      const processingTime = Date.now() - startTime;
      updateMetrics('vision', processingTime, false);
      
      setError(error.response?.data?.message || error.message || 'حدث خطأ أثناء التحليل');
      setProgress(0);
      setProcessing(fileId, false);

      toast({
        title: "فشل في تحليل الصورة",
        description: error.response?.data?.message || 'حدث خطأ غير متوقع',
        variant: "destructive"
      });
    }
  }, [toast, setVisionResult, setProcessing, updateMetrics]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp', '.tiff']
    },
    maxFiles: 1,
    maxSize: 10 * 1024 * 1024 // 10MB
  });

  const resetAnalysis = () => {
    if (currentFile?.preview) {
      URL.revokeObjectURL(currentFile.preview);
    }
    setCurrentFile(null);
    setError(null);
    setProgress(0);
  };

  const downloadReport = () => {
    if (!visionResult || !currentFile) return;

    const report = {
      fileName: currentFile.file.name,
      timestamp: new Date().toISOString(),
      analysis: visionResult,
      service: 'RKN-Terminal AI Vision',
      fileId: currentFile.id
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { 
      type: 'application/json' 
    });
    
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `vision-analysis-${currentFile.file.name}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className={`w-full max-w-6xl mx-auto space-y-6 ${dir === 'rtl' ? 'rtl' : 'ltr'}`} dir={dir}>
      <Card className="border-royal-blue bg-royal-blue/5 royal-glow">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 font-kufi text-royal-blue">
            <Eye className="h-8 w-8" />
            RKN Vision AI - محلل الصور المتقدم
          </CardTitle>
          <p className="text-sm text-muted-foreground font-cairo">
            تحليل ذكي شامل للصور باستخدام تقنيات الذكاء الاصطناعي المتقدمة
          </p>
        </CardHeader>
        <CardContent>
          {!currentFile ? (
            <div
              {...getRootProps()}
              className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all duration-300 ${
                isDragActive 
                  ? 'border-bright-gold bg-bright-gold/10' 
                  : 'border-royal-blue/30 hover:border-royal-blue/50 hover:bg-royal-blue/5'
              }`}
            >
              <input {...getInputProps()} />
              <Camera className="h-16 w-16 mx-auto mb-4 text-royal-blue opacity-60" />
              <h3 className="text-lg font-semibold mb-2 font-cairo text-royal-blue">
                {isDragActive ? 'أفلت الصورة هنا' : 'اسحب وأفلت صورة أو انقر للاختيار'}
              </h3>
              <p className="text-sm text-muted-foreground">
                يدعم: PNG, JPG, GIF, WebP, TIFF (حد أقصى 10 ميجابايت)
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* معاينة الصورة */}
              <div className="relative">
                <img
                  src={currentFile.preview}
                  alt="معاينة الصورة"
                  className="w-full max-h-96 object-contain rounded-lg border"
                />
                <Badge className="absolute top-2 right-2 bg-royal-blue text-white">
                  {currentFile.file.name}
                </Badge>
              </div>

              {/* شريط التقدم */}
              {isProcessing && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-cairo">جارِ التحليل بـ RKN Vision AI</span>
                    <span className="font-space-grotesk">{progress}%</span>
                  </div>
                  <Progress value={progress} className="h-3" />
                  <div className="text-center">
                    <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
                      <Brain className="w-4 h-4 text-royal-blue animate-pulse" />
                      تحليل الأشياء والنصوص والمشاهد...
                    </div>
                  </div>
                </div>
              )}

              {/* رسالة الخطأ */}
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="font-cairo">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              {/* نتائج التحليل */}
              {visionResult && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span className="font-semibold text-green-700 font-cairo">
                        تم التحليل بنجاح
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={downloadReport}
                        variant="outline"
                        size="sm"
                        className="text-royal-blue border-royal-blue hover:bg-royal-blue/10"
                      >
                        <Download className="h-4 w-4 mr-2" />
                        تحميل التقرير
                      </Button>
                      <Button
                        onClick={resetAnalysis}
                        variant="outline"
                        size="sm"
                        className="text-bright-gold border-bright-gold hover:bg-bright-gold/10"
                      >
                        تحليل صورة أخرى
                      </Button>
                    </div>
                  </div>

                  <Tabs defaultValue="objects" className="w-full">
                    <TabsList className="grid w-full grid-cols-4">
                      <TabsTrigger value="objects" className="flex items-center gap-2">
                        <Scan className="h-4 w-4" />
                        الأشياء
                      </TabsTrigger>
                      <TabsTrigger value="text" className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        النصوص
                      </TabsTrigger>
                      <TabsTrigger value="scene" className="flex items-center gap-2">
                        <Image className="h-4 w-4" />
                        المشهد
                      </TabsTrigger>
                      <TabsTrigger value="details" className="flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        التفاصيل
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="objects" className="space-y-3">
                      <h4 className="font-semibold text-royal-blue font-cairo">الأشياء المكتشفة</h4>
                      {visionResult.objects.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {visionResult.objects.map((object, index) => (
                            <Badge key={index} variant="secondary" className="bg-royal-blue/10 text-royal-blue">
                              {object}
                            </Badge>
                          ))}
                        </div>
                      ) : (
                        <p className="text-muted-foreground font-cairo">لم يتم اكتشاف أشياء محددة</p>
                      )}
                    </TabsContent>

                    <TabsContent value="text" className="space-y-3">
                      <h4 className="font-semibold text-royal-blue font-cairo">النصوص المستخرجة</h4>
                      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                        <p className="whitespace-pre-wrap font-cairo">
                          {visionResult.text || 'لا توجد نصوص مقروءة في الصورة'}
                        </p>
                      </div>
                    </TabsContent>

                    <TabsContent value="scene" className="space-y-3">
                      <h4 className="font-semibold text-royal-blue font-cairo">تحليل المشهد</h4>
                      <div className="space-y-3">
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">نوع المشهد:</label>
                          <p className="font-semibold text-bright-gold font-cairo">{visionResult.scene}</p>
                        </div>
                        <div>
                          <label className="text-sm font-medium text-muted-foreground">الوصف الشامل:</label>
                          <p className="text-sm leading-relaxed font-cairo">{visionResult.description}</p>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="details" className="space-y-3">
                      <h4 className="font-semibold text-royal-blue font-cairo">تفاصيل التحليل</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-muted-foreground">دقة التحليل:</label>
                          <div className="flex items-center gap-2">
                            <Progress value={visionResult.confidence * 100} className="flex-1" />
                            <span className="text-sm font-medium">
                              {Math.round(visionResult.confidence * 100)}%
                            </span>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-muted-foreground">أبعاد الصورة:</label>
                          <p className="text-sm font-mono">
                            {visionResult.metadata.imageSize.width} × {visionResult.metadata.imageSize.height}
                          </p>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-muted-foreground">التنسيق:</label>
                          <Badge variant="outline">{visionResult.metadata.format.toUpperCase()}</Badge>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-muted-foreground">جودة المعالجة:</label>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {visionResult.metadata.quality}
                          </Badge>
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>
                </div>
              )}

              {/* أزرار العمليات */}
              {!isProcessing && !visionResult && !error && currentFile && (
                <div className="flex gap-3 justify-center">
                  <Button
                    onClick={resetAnalysis}
                    variant="outline"
                    className="border-bright-gold text-bright-gold hover:bg-bright-gold/10"
                  >
                    اختيار صورة أخرى
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* معلومات الخدمة */}
      <Card className="border-bright-gold/30 bg-bright-gold/5">
        <CardHeader>
          <CardTitle className="text-bright-gold font-kufi">قدرات RKN Vision AI</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Scan className="h-4 w-4 text-bright-gold" />
              <span className="font-cairo">كشف وتصنيف الأشياء</span>
            </div>
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-bright-gold" />
              <span className="font-cairo">استخراج النصوص (OCR)</span>
            </div>
            <div className="flex items-center gap-2">
              <Image className="h-4 w-4 text-bright-gold" />
              <span className="font-cairo">تحليل المشاهد والسياق</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}