import React from 'react';
import { FalconHeader } from './FalconHeader';
import { FalconIconSmall } from './FalconLogo';

interface FalconLayoutProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
}

export const FalconLayout: React.FC<FalconLayoutProps> = ({ 
  children, 
  title = "راكان الذكاء السيادي",
  subtitle = "صقر الكود المنقض"
}) => {
  return (
    <div className="min-h-screen bg-background desert-pattern">
      <FalconHeader />
      
      <main className="container mx-auto px-4 py-8">
        {/* Page Title */}
        <div className="mb-8 text-center">
          <div className="flex items-center justify-center space-x-3 rtl:space-x-reverse mb-4">
            <FalconIconSmall size={32} className="desert-shimmer" />
            <h1 className="text-4xl font-bold font-amiri text-primary falcon-soar">
              {title}
            </h1>
          </div>
          <p className="text-lg text-muted-foreground font-scheherazade">
            {subtitle}
          </p>
          
          {/* Decorative Arabic Pattern */}
          <div className="mt-6 flex justify-center">
            <div className="w-32 h-1 bg-gradient-to-r from-transparent via-primary to-transparent rounded-full"></div>
          </div>
        </div>

        {/* Main Content */}
        <div className="space-y-6">
          {children}
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-primary/20 falcon-gradient">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-3 rtl:space-x-reverse">
              <FalconIconSmall size={24} />
              <div className="text-right rtl:text-right">
                <p className="font-bold font-amiri text-primary">
                  راكان الذكاء السيادي
                </p>
                <p className="text-xs text-muted-foreground font-scheherazade">
                  المهندس راكان قاسم الفهيقي
                </p>
              </div>
            </div>
            
            <div className="text-center text-sm text-muted-foreground font-arabic">
              <p>© 2025 - جميع الحقوق محفوظة</p>
              <p className="mt-1">صقر الكود في حالة انقضاض دائمة</p>
            </div>
            
            <div className="flex items-center space-x-2 rtl:space-x-reverse">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-xs text-muted-foreground font-arabic">
                النظام نشط ومستعد
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default FalconLayout;