import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import FileDrop from "./FileDrop";

interface UploadProgress {
  [key: string]: number;
}

export default function FileUploadZone() {
  const [uploadProgress, setUploadProgress] = useState<UploadProgress>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('files', file);

      const response = await apiRequest('POST', '/api/files/upload', formData);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "تم رفع الملف بنجاح",
        description: `تم رفع الملف وبدء التحليل بواسطة راكان`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
      setUploadProgress({});
    },
    onError: (error) => {
      toast({
        title: "فشل في رفع الملف",
        description: (error as Error).message,
        variant: "destructive",
      });
      setUploadProgress({});
    },
  });

  const handleFileUpload = (file: File) => {
    uploadMutation.mutate(file);
  };

  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold">منطقة رفع الملفات المتطورة</h3>
        <div className="flex items-center gap-2 text-sm text-gray-400">
          <i className="fas fa-robot text-electric-blue"></i>
          <span>معالجة بواسطة راكان AI</span>
        </div>
      </div>
      
      <FileDrop 
        onFile={handleFileUpload} 
        disabled={uploadMutation.isPending}
        className="bg-charcoal"
      />
      
      {uploadMutation.isPending && (
        <div className="mt-4 p-4 bg-electric-blue/10 rounded-lg border border-electric-blue/20">
          <div className="flex items-center gap-3">
            <div className="w-5 h-5 border-2 border-electric-blue border-t-transparent rounded-full animate-spin"></div>
            <div className="text-electric-blue font-medium">
              جاري رفع الملف وبدء التحليل بواسطة راكان...
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
