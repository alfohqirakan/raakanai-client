import React from 'react';

interface DigitalFalconLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  className?: string;
  animate?: boolean;
  variant?: 'full' | 'head' | 'minimal';
}

const sizeMap = {
  sm: 'w-8 h-8',
  md: 'w-12 h-12',
  lg: 'w-16 h-16',
  xl: 'w-24 h-24',
  full: 'w-full h-full'
};

export const DigitalFalconLogo: React.FC<DigitalFalconLogoProps> = ({ 
  size = 'md', 
  className = '', 
  animate = false,
  variant = 'full'
}) => {
  if (variant === 'head') {
    return (
      <div className={`${sizeMap[size]} ${className} ${animate ? 'falcon-soar' : ''}`}>
        <svg viewBox="0 0 100 100" className="w-full h-full">
          <defs>
            <linearGradient id="digitalFalconHeadGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: 'hsl(210, 100%, 18%)', stopOpacity: 1 }} />
              <stop offset="50%" style={{ stopColor: 'hsl(47, 90%, 61%)', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: 'hsl(0, 0%, 5%)', stopOpacity: 1 }} />
            </linearGradient>
            <filter id="digitalGlow" x="-50%" y="-50%" width="200%" height="200%">
              <feDropShadow dx="0" dy="0" stdDeviation="2" floodColor="hsl(47, 90%, 61%)" floodOpacity="0.5"/>
            </filter>
          </defs>
          
          {/* Digital Falcon Head in Circle - الصقر الرقمي */}
          <circle cx="50" cy="50" r="40" fill="url(#digitalFalconHeadGradient)" filter="url(#digitalGlow)" />
          <circle cx="50" cy="50" r="35" fill="transparent" stroke="hsl(47, 90%, 61%)" strokeWidth="2" opacity="0.7" />
          
          {/* Falcon Head */}
          <ellipse cx="50" cy="45" rx="12" ry="15" fill="hsl(0, 0%, 5%)" />
          
          {/* Digital Pattern Wings */}
          <path d="M30 40 L25 45 L30 50 L35 45 Z" fill="hsl(47, 90%, 61%)" opacity="0.8" />
          <path d="M70 40 L75 45 L70 50 L65 45 Z" fill="hsl(47, 90%, 61%)" opacity="0.8" />
          
          {/* Eyes with digital glow - عيون ذكية */}
          <circle cx="46" cy="42" r="2" fill="hsl(47, 90%, 61%)" />
          <circle cx="54" cy="42" r="2" fill="hsl(47, 90%, 61%)" />
          
          {/* Beak */}
          <path d="M50 35 L47 32 L53 32 Z" fill="hsl(210, 100%, 18%)" />
          
          {/* RKN Text */}
          <text x="50" y="75" textAnchor="middle" fontSize="8" fill="hsl(47, 90%, 61%)" className="font-technical">RKN</text>
        </svg>
      </div>
    );
  }

  return (
    <div className={`${sizeMap[size]} ${className} ${animate ? 'falcon-soar' : ''}`}>
      <svg viewBox="0 0 100 100" className="w-full h-full">
        <defs>
          <linearGradient id="rkn-digital-falcon" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{ stopColor: 'hsl(210, 100%, 18%)', stopOpacity: 1 }} />
            <stop offset="30%" style={{ stopColor: 'hsl(47, 90%, 61%)', stopOpacity: 1 }} />
            <stop offset="70%" style={{ stopColor: 'hsl(0, 0%, 5%)', stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: 'hsl(210, 100%, 18%)', stopOpacity: 1 }} />
          </linearGradient>
          <filter id="digital-shadow" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="2" dy="2" stdDeviation="3" floodColor="hsl(47, 90%, 61%)" floodOpacity="0.4"/>
          </filter>
          
          {/* Digital Pattern Definition */}
          <pattern id="digitalPattern" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
            <rect width="10" height="10" fill="transparent" />
            <rect width="2" height="2" x="2" y="2" fill="hsl(47, 90%, 61%)" opacity="0.3" />
            <rect width="2" height="2" x="6" y="6" fill="hsl(210, 100%, 18%)" opacity="0.3" />
          </pattern>
        </defs>
        
        {/* Digital Falcon Body - في وضعية الهجوم */}
        <ellipse cx="50" cy="55" rx="10" ry="22" fill="url(#rkn-digital-falcon)" filter="url(#digital-shadow)" />
        <ellipse cx="50" cy="55" rx="8" ry="20" fill="url(#digitalPattern)" opacity="0.5" />
        
        {/* Wings - Digital Geometric Patterns */}
        <path 
          d="M25 45 Q15 35 8 40 Q12 50 25 55 L35 50 Z" 
          fill="url(#rkn-digital-falcon)" 
          filter="url(#digital-shadow)"
          className={animate ? 'desert-shimmer' : ''}
        />
        <path 
          d="M75 45 Q85 35 92 40 Q88 50 75 55 L65 50 Z" 
          fill="url(#rkn-digital-falcon)" 
          filter="url(#digital-shadow)"
          className={animate ? 'desert-shimmer' : ''}
        />
        
        {/* Digital Wing Patterns */}
        <path d="M20 42 L28 42 L28 48 L20 48 Z" fill="url(#digitalPattern)" opacity="0.7" />
        <path d="M72 42 L80 42 L80 48 L72 48 Z" fill="url(#digitalPattern)" opacity="0.7" />
        
        {/* Head - Digital Sovereignty */}
        <circle cx="50" cy="35" r="8" fill="url(#rkn-digital-falcon)" filter="url(#digital-shadow)" />
        <circle cx="50" cy="35" r="6" fill="url(#digitalPattern)" opacity="0.4" />
        
        {/* Beak - Sharp and precise */}
        <path d="M50 27 L46 24 L54 24 Z" fill="hsl(0, 0%, 5%)" />
        
        {/* Eyes - Golden Digital Intelligence */}
        <circle cx="46" cy="33" r="2" fill="hsl(47, 90%, 61%)" />
        <circle cx="54" cy="33" r="2" fill="hsl(47, 90%, 61%)" />
        <circle cx="46" cy="33" r="1" fill="hsl(210, 100%, 18%)" />
        <circle cx="54" cy="33" r="1" fill="hsl(210, 100%, 18%)" />
        
        {/* Digital Tail Feathers */}
        <path 
          d="M45 75 Q40 85 35 92 M50 75 Q50 85 50 92 M55 75 Q60 85 65 92" 
          stroke="url(#rkn-digital-falcon)" 
          strokeWidth="3" 
          fill="none"
          strokeLinecap="round"
        />
        
        {/* Digital Enhancement Lines - الخطوط الرقمية */}
        <line x1="20" y1="50" x2="80" y2="50" stroke="hsl(47, 90%, 61%)" strokeWidth="0.5" opacity="0.3" />
        <line x1="50" y1="20" x2="50" y2="80" stroke="hsl(210, 100%, 18%)" strokeWidth="0.5" opacity="0.3" />
      </svg>
    </div>
  );
};

export const DigitalFalconIconSmall = () => (
  <DigitalFalconLogo size="sm" className="inline-block" variant="head" />
);

export const DigitalFalconMini = () => (
  <DigitalFalconLogo size="sm" className="inline-block" variant="minimal" />
);