import { useState, useRef } from 'react';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useTranslation } from '@/hooks/useTranslation';
import { Upload, X, CheckCircle, AlertCircle, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FileUploadProgressProps {
  onUpload: (files: File[]) => Promise<void>;
  maxFiles?: number;
  disabled?: boolean;
  acceptedTypes?: string[];
}

interface UploadingFile {
  file: File;
  progress: number;
  status: 'uploading' | 'analyzing' | 'completed' | 'error';
  error?: string;
  id: string;
}

export function FileUploadProgress({ 
  onUpload, 
  maxFiles = 10, 
  disabled = false,
  acceptedTypes 
}: FileUploadProgressProps) {
  const { t, isRTL } = useTranslation();
  const [uploadingFiles, setUploadingFiles] = useState<UploadingFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (files: FileList | null) => {
    if (!files || files.length === 0) return;
    
    const fileArray = Array.from(files).slice(0, maxFiles);
    const uploadFiles: UploadingFile[] = fileArray.map(file => ({
      file,
      progress: 0,
      status: 'uploading',
      id: Math.random().toString(36).substr(2, 9)
    }));

    setUploadingFiles(uploadFiles);
    setIsUploading(true);

    try {
      // Simulate upload progress for each file
      uploadFiles.forEach((uploadFile, index) => {
        const interval = setInterval(() => {
          setUploadingFiles(prev => prev.map(f => 
            f.id === uploadFile.id && f.status === 'uploading'
              ? { ...f, progress: Math.min(f.progress + Math.random() * 15, 85) }
              : f
          ));
        }, 200 + index * 100); // Stagger progress updates

        // Mark as analyzing after upload simulation
        setTimeout(() => {
          clearInterval(interval);
          setUploadingFiles(prev => prev.map(f => 
            f.id === uploadFile.id 
              ? { ...f, status: 'analyzing', progress: 95 }
              : f
          ));
        }, 2000 + index * 500);
      });

      // Perform actual upload
      await onUpload(fileArray);

      // Mark all as completed
      setUploadingFiles(prev => prev.map(f => ({
        ...f,
        status: 'completed',
        progress: 100
      })));

      // Clear after delay
      setTimeout(() => {
        setUploadingFiles([]);
      }, 3000);

    } catch (error) {
      console.error('Upload failed:', error);
      setUploadingFiles(prev => prev.map(f => ({
        ...f,
        status: 'error',
        error: (error as Error).message
      })));
    } finally {
      setIsUploading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFileSelect(e.target.files);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (disabled || isUploading) return;
    handleFileSelect(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const removeFile = (fileId: string) => {
    setUploadingFiles(prev => prev.filter(f => f.id !== fileId));
  };

  const getStatusIcon = (status: UploadingFile['status']) => {
    switch (status) {
      case 'uploading':
        return <Upload className="h-4 w-4 text-blue-500" />;
      case 'analyzing':
        return <Clock className="h-4 w-4 text-orange-500 animate-pulse" />;
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
    }
  };

  const getStatusText = (status: UploadingFile['status']) => {
    switch (status) {
      case 'uploading':
        return t('uploading');
      case 'analyzing':
        return t('analyzing');
      case 'completed':
        return t('uploadSuccess');
      case 'error':
        return t('uploadFailed');
    }
  };

  const getStatusColor = (status: UploadingFile['status']) => {
    switch (status) {
      case 'uploading':
        return 'bg-blue-500';
      case 'analyzing':
        return 'bg-orange-500';
      case 'completed':
        return 'bg-green-500';
      case 'error':
        return 'bg-red-500';
    }
  };

  return (
    <div className={cn("w-full max-w-2xl mx-auto space-y-4", isRTL && "rtl")}>
      {/* Upload Area */}
      <Card 
        className={cn(
          "border-2 border-dashed transition-colors cursor-pointer",
          disabled || isUploading 
            ? "border-gray-300 bg-gray-50 cursor-not-allowed" 
            : "border-blue-300 hover:border-blue-400 hover:bg-blue-50"
        )}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onClick={() => !disabled && !isUploading && fileInputRef.current?.click()}
      >
        <CardContent className="flex flex-col items-center justify-center py-8 px-6 text-center">
          <Upload className={cn(
            "h-12 w-12 mb-4",
            disabled || isUploading ? "text-gray-400" : "text-blue-500"
          )} />
          
          <h3 className={cn(
            "text-lg font-medium mb-2",
            disabled || isUploading ? "text-gray-500" : "text-gray-900"
          )}>
            {t('dragDropFiles')}
          </h3>
          
          <p className="text-sm text-gray-500 mb-4">
            {t('clickToSelect')}
          </p>
          
          <Button 
            variant="outline" 
            disabled={disabled || isUploading}
            size="sm"
          >
            {t('selectFiles')}
          </Button>

          {acceptedTypes && (
            <p className="text-xs text-gray-400 mt-2">
              {t('supportedTypes')}: {acceptedTypes.join(', ')}
            </p>
          )}
        </CardContent>
      </Card>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={acceptedTypes?.join(',')}
        onChange={handleFileChange}
        disabled={disabled || isUploading}
        className="hidden"
      />

      {/* Upload Progress */}
      {uploadingFiles.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-medium text-gray-900">
            {t('uploadProgress')} ({uploadingFiles.length} {t('filesCount')})
          </h4>
          
          {uploadingFiles.map((uploadFile) => (
            <Card key={uploadFile.id} className="overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3 flex-1 min-w-0">
                    {getStatusIcon(uploadFile.status)}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {uploadFile.file.name}
                      </p>
                      <p className="text-xs text-gray-500">
                        {(uploadFile.file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge 
                      variant="secondary" 
                      className={cn("text-white", getStatusColor(uploadFile.status))}
                    >
                      {getStatusText(uploadFile.status)}
                    </Badge>
                    
                    {uploadFile.status !== 'uploading' && uploadFile.status !== 'analyzing' && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFile(uploadFile.id)}
                        className="h-6 w-6 p-0"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>

                {/* Progress Bar */}
                {(uploadFile.status === 'uploading' || uploadFile.status === 'analyzing') && (
                  <div className="space-y-2">
                    <Progress 
                      value={uploadFile.progress} 
                      className="h-2"
                    />
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>{Math.round(uploadFile.progress)}%</span>
                      <span>
                        {uploadFile.status === 'analyzing' 
                          ? t('analyzingWithAI') 
                          : t('uploading')
                        }
                      </span>
                    </div>
                  </div>
                )}

                {/* Error Message */}
                {uploadFile.status === 'error' && uploadFile.error && (
                  <div className="mt-2 p-2 bg-red-50 rounded text-sm text-red-700">
                    {uploadFile.error}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Upload Statistics */}
      {uploadingFiles.length > 0 && (
        <Card className="bg-gray-50">
          <CardContent className="p-4">
            <div className="flex justify-between text-sm">
              <span>{t('totalFiles')}: {uploadingFiles.length}</span>
              <span>
                {t('completed')}: {uploadingFiles.filter(f => f.status === 'completed').length}
              </span>
              <span>
                {t('failed')}: {uploadingFiles.filter(f => f.status === 'error').length}
              </span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}