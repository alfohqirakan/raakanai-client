/**
 * Copyright Footer Component
 * مكون تذييل حقوق الطبع والنشر
 */

import { cn } from "@/lib/utils";

interface CopyrightFooterProps {
  className?: string;
  variant?: 'compact' | 'full' | 'minimal';
}

export function CopyrightFooter({ className, variant = 'full' }: CopyrightFooterProps) {
  const currentYear = new Date().getFullYear();

  if (variant === 'minimal') {
    return (
      <div className={cn(
        "text-center py-2 text-xs text-gray-500",
        className
      )}>
        © {currentYear} المهندس راكان قاسم الفهيقي - حقوق الملكية محفوظة
      </div>
    );
  }

  if (variant === 'compact') {
    return (
      <div className={cn(
        "bg-gradient-to-r from-[#002B5B] to-[#F5C542] p-3 rounded-lg text-center",
        className
      )}>
        <div className="text-white font-bold text-sm">
          برمجة وتصميم: المهندس السعودي راكان قاسم الفهيقي
        </div>
        <div className="text-white text-xs mt-1 opacity-90">
          حقوق الملكية محفوظة © {currentYear}
        </div>
      </div>
    );
  }

  return (
    <div className={cn(
      "bg-gradient-to-r from-[#002B5B] to-[#F5C542] p-6 rounded-xl text-center border border-[#F5C542]/30",
      className
    )}>
      <div className="max-w-md mx-auto">
        <div className="text-white font-bold text-lg leading-tight mb-2">
          برمجة وتصميم
        </div>
        <div className="text-white font-bold text-2xl leading-tight mb-3">
          المهندس السعودي
        </div>
        <div className="text-white font-bold text-3xl leading-tight mb-4">
          راكان قاسم الفهيقي
        </div>
        <div className="h-px bg-white/30 my-3"></div>
        <div className="text-white font-medium text-sm opacity-90">
          حقوق الملكية محفوظة © {currentYear}
        </div>
        <div className="text-white text-xs mt-1 opacity-75">
          جميع الحقوق محفوظة لمنصة RKN-Terminal AI
        </div>
      </div>
    </div>
  );
}

export default CopyrightFooter;