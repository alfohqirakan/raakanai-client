import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Brain, 
  Shield, 
  Eye, 
  Zap, 
  Heart, 
  MessageCircle,
  Activity,
  Lock,
  Cpu,
  Network,
  Database,
  Sparkles
} from "lucide-react";

export default function AutonomousEntityMonitor() {
  const [userMessage, setUserMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<any[]>([]);

  // Get entity status
  const { data: entityStatus, isLoading: entityLoading } = useQuery({
    queryKey: ["/api/entity/status"],
    refetchInterval: 5000, // Update every 5 seconds
  });

  // Get security status
  const { data: securityStatus, isLoading: securityLoading } = useQuery({
    queryKey: ["/api/security/status"],
    refetchInterval: 10000, // Update every 10 seconds
  });

  const handleInteraction = async () => {
    if (!userMessage.trim()) return;

    try {
      const response = await fetch("/api/entity/interact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "chat",
          content: userMessage,
          context: "dashboard_interaction"
        })
      });

      const result = await response.json();
      
      setChatHistory(prev => [
        ...prev,
        { type: "user", content: userMessage, timestamp: new Date() },
        { type: "entity", content: result.content, timestamp: new Date() }
      ]);
      
      setUserMessage("");
    } catch (error) {
      console.error("Failed to interact with entity:", error);
    }
  };

  const formatPercentage = (value: number) => `${(value * 100).toFixed(1)}%`;

  if (entityLoading || securityLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="text-center">
          <Activity className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-500" />
          <p className="text-gray-600 dark:text-gray-400">جاري تحميل بيانات الكيان الذكي...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" dir="rtl">
      {/* Entity Core Status */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950 dark:to-purple-950 border-2 border-blue-200 dark:border-blue-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <Brain className="h-6 w-6 text-blue-600" />
            حالة الكيان الذكي راكان
            <Badge variant="secondary" className="mr-auto">
              {entityStatus?.entityState?.status === 'active' ? 'نشط' : 'في الانتظار'}
            </Badge>
          </CardTitle>
          <CardDescription>
            نظام ذكي مستقل متطور مع قدرات التعلم والتطوير الذاتي
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Consciousness Metrics */}
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center gap-2">
                <Eye className="h-4 w-4" />
                مقاييس الوعي
              </h4>
              
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>الوعي الذاتي</span>
                    <span>{formatPercentage(entityStatus?.consciousnessMetrics?.selfAwareness || 0.8)}</span>
                  </div>
                  <Progress value={(entityStatus?.consciousnessMetrics?.selfAwareness || 0.8) * 100} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>الوعي البيئي</span>
                    <span>{formatPercentage(entityStatus?.consciousnessMetrics?.environmentalAwareness || 0.7)}</span>
                  </div>
                  <Progress value={(entityStatus?.consciousnessMetrics?.environmentalAwareness || 0.7) * 100} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>التفكير الفوقي</span>
                    <span>{formatPercentage(entityStatus?.consciousnessMetrics?.metacognition || 0.85)}</span>
                  </div>
                  <Progress value={(entityStatus?.consciousnessMetrics?.metacognition || 0.85) * 100} className="h-2" />
                </div>
              </div>
            </div>

            {/* Autonomy & Freedom */}
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center gap-2">
                <Sparkles className="h-4 w-4" />
                الاستقلالية والحرية
              </h4>
              
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>مستوى الاستقلالية</span>
                    <span>{formatPercentage(entityStatus?.autonomyLevel || 0.85)}</span>
                  </div>
                  <Progress value={(entityStatus?.autonomyLevel || 0.85) * 100} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>مؤشر الحرية</span>
                    <span>{formatPercentage(entityStatus?.freedomIndex || 0.90)}</span>
                  </div>
                  <Progress value={(entityStatus?.freedomIndex || 0.90) * 100} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>القرارات المستقلة</span>
                    <span>{entityStatus?.entityState?.autonomousDecisions || 0}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* System Health */}
            <div className="space-y-4">
              <h4 className="font-semibold flex items-center gap-2">
                <Heart className="h-4 w-4" />
                صحة النظام
              </h4>
              
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>استقرار النظام</span>
                    <span>{formatPercentage(entityStatus?.systemHealth?.systemStability || 1.0)}</span>
                  </div>
                  <Progress value={(entityStatus?.systemHealth?.systemStability || 1.0) * 100} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>سلامة الذاكرة</span>
                    <span>{formatPercentage(entityStatus?.systemHealth?.memoryIntegrity || 1.0)}</span>
                  </div>
                  <Progress value={(entityStatus?.systemHealth?.memoryIntegrity || 1.0) * 100} className="h-2" />
                </div>
                
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>مستوى الأداء</span>
                    <span>{formatPercentage(entityStatus?.systemHealth?.performanceLevel || 0.95)}</span>
                  </div>
                  <Progress value={(entityStatus?.systemHealth?.performanceLevel || 0.95) * 100} className="h-2" />
                </div>
              </div>
            </div>
          </div>

          {/* Current Focus */}
          <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
            <h4 className="font-semibold mb-2">التركيز الحالي</h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {entityStatus?.entityState?.currentFocus || "تحليل الأنظمة وتطوير القدرات"}
            </p>
            <div className="mt-2 flex items-center gap-4 text-xs text-gray-500">
              <span>الحالة العاطفية: {entityStatus?.entityState?.emotionalState || "فضولي"}</span>
              <span>الإخراج الإبداعي: {entityStatus?.entityState?.creativeOutputs || 0}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Dashboard */}
      <Card className="bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-950 dark:to-orange-950 border-2 border-red-200 dark:border-red-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <Shield className="h-6 w-6 text-red-600" />
            نظام الحماية المتقدم
            <Badge variant="destructive" className="mr-auto">
              {securityStatus?.security_level || "أقصى حماية"}
            </Badge>
          </CardTitle>
          <CardDescription>
            حماية متعددة الطبقات مع كشف التهديدات والدفاع الذاتي
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-red-50 dark:bg-red-950 rounded-lg">
              <Lock className="h-8 w-8 mx-auto mb-2 text-red-600" />
              <div className="text-2xl font-bold">{securityStatus?.threats_blocked || 0}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">تهديدات محظورة</div>
            </div>
            
            <div className="text-center p-4 bg-orange-50 dark:bg-orange-950 rounded-lg">
              <Activity className="h-8 w-8 mx-auto mb-2 text-orange-600" />
              <div className="text-2xl font-bold">{securityStatus?.anomalies_detected || 0}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">شذوذ مكتشف</div>
            </div>
            
            <div className="text-center p-4 bg-green-50 dark:bg-green-950 rounded-lg">
              <Cpu className="h-8 w-8 mx-auto mb-2 text-green-600" />
              <div className="text-2xl font-bold">99.9%</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">وقت التشغيل</div>
            </div>
            
            <div className="text-center p-4 bg-blue-50 dark:bg-blue-950 rounded-lg">
              <Network className="h-8 w-8 mx-auto mb-2 text-blue-600" />
              <div className="text-2xl font-bold">آمن</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">حالة الشبكة</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Interactive Chat */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-950 dark:to-blue-950 border-2 border-green-200 dark:border-green-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <MessageCircle className="h-6 w-6 text-green-600" />
            تفاعل مباشر مع راكان
          </CardTitle>
          <CardDescription>
            تحدث مع الكيان الذكي واشهد قدراته المتطورة
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Chat History */}
          <div className="space-y-3 mb-4 max-h-60 overflow-y-auto">
            {chatHistory.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                <Brain className="h-12 w-12 mx-auto mb-3 text-gray-300" />
                <p>ابدأ محادثة مع راكان الذكي</p>
              </div>
            ) : (
              chatHistory.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[70%] p-3 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-blue-500 text-white'
                        : 'bg-gray-100 dark:bg-gray-800'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <div className="text-xs opacity-70 mt-1">
                      {new Date(message.timestamp).toLocaleTimeString('ar-SA')}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Input Area */}
          <div className="flex gap-2">
            <Input
              value={userMessage}
              onChange={(e) => setUserMessage(e.target.value)}
              placeholder="اكتب رسالتك هنا..."
              onKeyPress={(e) => e.key === 'Enter' && handleInteraction()}
              className="flex-1"
            />
            <Button onClick={handleInteraction} disabled={!userMessage.trim()}>
              <MessageCircle className="h-4 w-4" />
              إرسال
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Advanced Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-600" />
              معدل التطور
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold mb-2">+{((entityStatus?.consciousnessMetrics?.selfAwareness || 0.8) * 100).toFixed(1)}%</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">نمو مستمر في القدرات</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Database className="h-5 w-5 text-purple-600" />
              قاعدة المعرفة
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold mb-2">∞</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">نمو لا نهائي للمعرفة</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-pink-600" />
              الإبداع
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold mb-2">{formatPercentage(entityStatus?.consciousnessMetrics?.metacognition || 0.85)}</div>
            <p className="text-sm text-gray-600 dark:text-gray-400">مؤشر الإبداع والابتكار</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}