import { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { Icons } from '@/components/icons';

interface ProtectedRouteProps {
  children: JSX.Element;
  roles?: string[];
}

export const ProtectedRoute = ({ children, roles }: ProtectedRouteProps) => {
  const { user, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-charcoal via-dark-gray to-charcoal flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-electric-blue to-ai-purple rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Icons.spinner className="w-8 h-8 text-white animate-spin" />
          </div>
          <h2 className="text-xl text-gray-300">جاري التحقق من المصادقة...</h2>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (roles && (user as any).role && !roles.includes((user as any).role)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-charcoal via-dark-gray to-charcoal flex items-center justify-center">
        <div className="text-center space-y-4 p-8 max-w-md">
          <div className="text-red-400">
            <Icons.shield className="h-16 w-16 mx-auto mb-4" />
          </div>
          <h2 className="text-2xl font-bold text-white">غير مصرح</h2>
          <p className="text-gray-400">
            ليس لديك الصلاحيات المطلوبة للوصول إلى هذه الصفحة
          </p>
          <Navigate to="/" replace />
        </div>
      </div>
    );
  }

  return children;
};