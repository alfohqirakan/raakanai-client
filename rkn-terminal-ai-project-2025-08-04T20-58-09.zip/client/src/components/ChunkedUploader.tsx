import { useCallback, useState } from 'react';
import axios from 'axios';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, CheckCircle, AlertCircle, FileText } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useDirection } from '@/lib/direction';

const CHUNK_SIZE = 5 * 1024 * 1024; // 5MB chunks for optimal performance

interface UploadStatus {
  isUploading: boolean;
  progress: number;
  fileName: string;
  fileSize: number;
  uploadedChunks: number;
  totalChunks: number;
  error?: string;
  completed: boolean;
}

export function ChunkedUploader() {
  const [uploadStatus, setUploadStatus] = useState<UploadStatus | null>(null);
  const { toast } = useToast();
  const { dir } = useDirection();

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const uploadFile = useCallback(async (file: File) => {
    const totalChunks = Math.ceil(file.size / CHUNK_SIZE);
    const fileId = `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    setUploadStatus({
      isUploading: true,
      progress: 0,
      fileName: file.name,
      fileSize: file.size,
      uploadedChunks: 0,
      totalChunks,
      completed: false
    });

    try {
      for (let i = 0; i < totalChunks; i++) {
        const start = i * CHUNK_SIZE;
        const end = Math.min(start + CHUNK_SIZE, file.size);
        const chunk = file.slice(start, end);
        
        const formData = new FormData();
        formData.append('chunk', chunk);
        formData.append('fileId', fileId);
        formData.append('chunkIndex', i.toString());
        formData.append('totalChunks', totalChunks.toString());
        formData.append('fileName', file.name);
        formData.append('fileSize', file.size.toString());
        
        await axios.post('/api/upload/chunk', formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          },
          timeout: 30000 // 30 second timeout per chunk
        });
        
        const progress = Math.round(((i + 1) / totalChunks) * 100);
        setUploadStatus(prev => prev ? {
          ...prev,
          progress,
          uploadedChunks: i + 1
        } : null);
      }
      
      // إخطار الخادم باكتمال التحميل
      const response = await axios.post('/api/upload/complete', { 
        fileId, 
        fileName: file.name,
        totalChunks,
        fileSize: file.size
      });
      
      setUploadStatus(prev => prev ? {
        ...prev,
        completed: true,
        isUploading: false
      } : null);

      toast({
        title: "تم رفع الملف بنجاح",
        description: `تم رفع ${file.name} وتحليله بالذكاء الاصطناعي`,
        variant: "default"
      });

    } catch (error: any) {
      const errorMessage = error.response?.data?.message || error.message || 'خطأ غير معروف';
      
      setUploadStatus(prev => prev ? {
        ...prev,
        error: errorMessage,
        isUploading: false
      } : null);

      toast({
        title: "فشل في رفع الملف",
        description: errorMessage,
        variant: "destructive"
      });
      
      console.error('خطأ في رفع الملف:', error);
    }
  }, [toast]);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Reset previous upload status
      setUploadStatus(null);
      uploadFile(file);
    }
  };

  const resetUpload = () => {
    setUploadStatus(null);
  };

  return (
    <div className={`w-full max-w-2xl mx-auto ${dir === 'rtl' ? 'rtl' : 'ltr'}`} dir={dir}>
      <Card className="border-royal-blue bg-royal-blue/5 royal-glow">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 font-kufi text-royal-blue">
            <Upload className="h-6 w-6" />
            رفع ملفات كبيرة - RKN Chunked Upload
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!uploadStatus && (
            <div className="text-center">
              <input
                type="file"
                id="file-upload"
                className="hidden"
                onChange={handleFileSelect}
                accept=".pdf,.txt,.docx,.png,.jpg,.jpeg,.mp4,.mp3,.zip,.json,.csv,.md"
              />
              <label
                htmlFor="file-upload"
                className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-royal-blue to-bright-gold text-white rounded-lg cursor-pointer hover:shadow-lg transition-all duration-300 falcon-animate"
              >
                <Upload className="h-5 w-5" />
                اختيار ملف للرفع
              </label>
              <p className="text-sm text-muted-foreground mt-2 font-cairo">
                يدعم الملفات الكبيرة حتى 100 ميجابايت مع تحميل متقطع آمن
              </p>
            </div>
          )}

          {uploadStatus && (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <FileText className="h-8 w-8 text-royal-blue" />
                <div className="flex-1">
                  <h3 className="font-semibold text-royal-blue font-cairo">
                    {uploadStatus.fileName}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {formatFileSize(uploadStatus.fileSize)} • 
                    {uploadStatus.uploadedChunks}/{uploadStatus.totalChunks} أجزاء
                  </p>
                </div>
                {uploadStatus.completed && (
                  <CheckCircle className="h-6 w-6 text-green-500" />
                )}
                {uploadStatus.error && (
                  <AlertCircle className="h-6 w-6 text-red-500" />
                )}
              </div>

              {uploadStatus.isUploading && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-cairo">تقدم الرفع</span>
                    <span className="font-space-grotesk">{uploadStatus.progress}%</span>
                  </div>
                  <Progress 
                    value={uploadStatus.progress} 
                    className="w-full h-3 bg-royal-blue/20"
                  />
                  <div className="text-center">
                    <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="w-4 h-4 border-2 border-royal-blue border-t-transparent rounded-full animate-spin"></div>
                      جارِ رفع الجزء {uploadStatus.uploadedChunks + 1} من {uploadStatus.totalChunks}
                    </div>
                  </div>
                </div>
              )}

              {uploadStatus.completed && (
                <div className="text-center space-y-3">
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
                    <p className="text-green-700 font-semibold font-cairo">
                      تم رفع الملف بنجاح
                    </p>
                    <p className="text-sm text-green-600">
                      الملف جاهز للتحليل بالذكاء الاصطناعي
                    </p>
                  </div>
                  <Button 
                    onClick={resetUpload}
                    className="bg-royal-blue hover:bg-royal-blue/90 text-bright-gold"
                  >
                    رفع ملف آخر
                  </Button>
                </div>
              )}

              {uploadStatus.error && (
                <div className="text-center space-y-3">
                  <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                    <AlertCircle className="h-8 w-8 text-red-500 mx-auto mb-2" />
                    <p className="text-red-700 font-semibold font-cairo">
                      فشل في رفع الملف
                    </p>
                    <p className="text-sm text-red-600">
                      {uploadStatus.error}
                    </p>
                  </div>
                  <Button 
                    onClick={resetUpload}
                    variant="outline"
                    className="border-royal-blue text-royal-blue hover:bg-royal-blue/10"
                  >
                    المحاولة مرة أخرى
                  </Button>
                </div>
              )}
            </div>
          )}

          <div className="mt-6 p-4 bg-bright-gold/10 border border-bright-gold/30 rounded-lg">
            <h4 className="font-semibold text-bright-gold mb-2 font-kufi">
              ميزات الرفع المتقدم
            </h4>
            <ul className="text-sm space-y-1 font-cairo">
              <li>• رفع متقطع آمن للملفات الكبيرة</li>
              <li>• استئناف الرفع في حالة انقطاع الاتصال</li>
              <li>• تشفير وحماية البيانات أثناء النقل</li>
              <li>• تحليل فوري بالذكاء الاصطناعي RKN</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}