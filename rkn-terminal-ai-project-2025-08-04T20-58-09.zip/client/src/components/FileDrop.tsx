import { useDropzone } from "react-dropzone";
import { cn } from "@/lib/utils";

interface FileDropProps {
  onFile: (file: File) => void;
  className?: string;
  disabled?: boolean;
}

export default function FileDrop({ onFile, className, disabled }: FileDropProps) {
  const { getRootProps, getInputProps, isDragActive, isDragReject } = useDropzone({
    onDrop: (acceptedFiles) => {
      if (acceptedFiles[0]) {
        onFile(acceptedFiles[0]);
      }
    },
    maxSize: 50 * 1024 * 1024, // 50MB limit
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp'],
      'application/pdf': ['.pdf'],
      'text/*': ['.txt', '.csv'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/json': ['.json']
    },
    disabled,
    multiple: false
  });

  return (
    <div 
      {...getRootProps()} 
      className={cn(
        "border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all",
        isDragActive && !isDragReject && "border-electric-blue bg-electric-blue/5",
        isDragReject && "border-red-400 bg-red-400/5",
        disabled && "opacity-50 cursor-not-allowed",
        !isDragActive && !isDragReject && "border-gray-600 hover:border-electric-blue/50",
        className
      )}
    >
      <input {...getInputProps()} />
      <div className="flex flex-col items-center gap-3">
        <div className="w-16 h-16 bg-electric-blue/10 rounded-full flex items-center justify-center">
          <i className="fas fa-cloud-upload-alt text-electric-blue text-2xl"></i>
        </div>
        {isDragActive ? (
          isDragReject ? (
            <p className="text-red-400 font-medium">نوع الملف غير مدعوم</p>
          ) : (
            <p className="text-electric-blue font-medium">أفلت الملف هنا...</p>
          )
        ) : (
          <>
            <p className="text-gray-300 font-medium">📂 اسحب الملف هنا أو اضغط لاختياره</p>
            <p className="text-sm text-gray-500">
              يدعم: الصور، PDF، النصوص، Word، JSON (حتى 50 ميغابايت)
            </p>
          </>
        )}
      </div>
    </div>
  );
}