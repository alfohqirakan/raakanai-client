/**
 * Notification Center Component
 * مركز الإشعارات المتقدم
 */

import { useState, useEffect } from 'react';
import { useWebSocket } from '../hooks/useWebSocket';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Bell, 
  Mail, 
  Send, 
  Settings, 
  CheckCircle, 
  AlertCircle, 
  Info, 
  Clock,
  User,
  FileText,
  Activity
} from 'lucide-react';

interface NotificationTemplate {
  name: string;
  info: {
    subject: string;
    text: string;
    websocketEvent?: string;
    priority?: 'low' | 'normal' | 'high' | 'urgent';
  };
}

interface NotificationHistory {
  id: string;
  type: string;
  title: string;
  message: string;
  read: boolean;
  timestamp: string;
}

interface EmailStatus {
  isConfigured: boolean;
  transporter: boolean;
  configuration: {
    host?: string;
    port?: number;
    secure?: boolean;
  };
}

export function NotificationCenter() {
  const webSocket = useWebSocket();
  const [templates, setTemplates] = useState<NotificationTemplate[]>([]);
  const [history, setHistory] = useState<NotificationHistory[]>([]);
  const [emailStatus, setEmailStatus] = useState<EmailStatus | null>(null);
  const [notifications, setNotifications] = useState<any[]>([]);
  
  // Form states
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [notificationContext, setNotificationContext] = useState<string>('{}');
  const [testEmail, setTestEmail] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Load notification data
  useEffect(() => {
    loadTemplates();
    loadHistory();
    loadEmailStatus();
  }, []);

  // WebSocket notifications listener
  useEffect(() => {
    if (!webSocket.state.isConnected) return;

    const unsubscribe = webSocket.onNotification((notification: any) => {
      setNotifications(prev => [notification, ...prev.slice(0, 19)]);
    });

    return unsubscribe;
  }, [webSocket]);

  const loadTemplates = async () => {
    try {
      const response = await fetch('/api/notifications/templates', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setTemplates(data.data || []);
      }
    } catch (error) {
      console.error('خطأ في جلب القوالب:', error);
    }
  };

  const loadHistory = async () => {
    try {
      const response = await fetch('/api/notifications/history?limit=20', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setHistory(data.data || []);
      }
    } catch (error) {
      console.error('خطأ في جلب التاريخ:', error);
    }
  };

  const loadEmailStatus = async () => {
    try {
      const response = await fetch('/api/email/status', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setEmailStatus(data.data);
      }
    } catch (error) {
      console.error('خطأ في جلب حالة البريد:', error);
    }
  };

  const sendTestNotification = async () => {
    if (!selectedTemplate) return;

    setIsLoading(true);
    setMessage(null);

    try {
      let context = {};
      try {
        context = JSON.parse(notificationContext);
      } catch {
        context = {
          fileName: 'test-file.pdf',
          fileUrl: '/files/test',
          summary: 'هذا إشعار تجريبي'
        };
      }

      const response = await fetch('/api/notifications/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          type: selectedTemplate,
          context,
          options: {
            sendEmail: emailStatus?.isConfigured,
            sendWebSocket: true
          }
        })
      });

      if (response.ok) {
        setMessage({ type: 'success', text: 'تم إرسال الإشعار التجريبي بنجاح' });
        loadHistory();
      } else {
        const error = await response.json();
        setMessage({ type: 'error', text: error.message || 'فشل في الإرسال' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'خطأ في الاتصال' });
    } finally {
      setIsLoading(false);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch(`/api/notifications/${notificationId}/read`, {
        method: 'POST',
        credentials: 'include'
      });
      if (response.ok) {
        setHistory(prev => 
          prev.map(n => n.id === notificationId ? { ...n, read: true } : n)
        );
      }
    } catch (error) {
      console.error('خطأ في تحديث الإشعار:', error);
    }
  };

  const getPriorityIcon = (priority?: string) => {
    switch (priority) {
      case 'urgent': return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'high': return <AlertCircle className="h-4 w-4 text-orange-500" />;
      case 'normal': return <Info className="h-4 w-4 text-blue-500" />;
      case 'low': return <Clock className="h-4 w-4 text-gray-500" />;
      default: return <Bell className="h-4 w-4 text-gray-500" />;
    }
  };

  const getNotificationTypeIcon = (type: string) => {
    switch (type) {
      case 'analysisComplete': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'analysisProgress': return <Activity className="h-4 w-4 text-blue-500" />;
      case 'newMessage': return <User className="h-4 w-4 text-purple-500" />;
      case 'analysisError': return <AlertCircle className="h-4 w-4 text-red-500" />;
      default: return <FileText className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-[#002B5B] mb-2">
          🔔 مركز الإشعارات المتقدم
        </h1>
        <p className="text-gray-600">
          إدارة الإشعارات والبريد الإلكتروني لـ RKN-Terminal AI
        </p>
      </div>

      <Tabs defaultValue="live" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="live">الإشعارات المباشرة</TabsTrigger>
          <TabsTrigger value="history">التاريخ</TabsTrigger>
          <TabsTrigger value="test">إرسال تجريبي</TabsTrigger>
          <TabsTrigger value="settings">الإعدادات</TabsTrigger>
        </TabsList>

        {/* Live Notifications */}
        <TabsContent value="live">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="h-5 w-5" />
                الإشعارات المباشرة
                <Badge variant="outline" className="mr-auto">
                  {notifications.length}
                </Badge>
              </CardTitle>
              <CardDescription>
                الإشعارات الواردة عبر WebSocket في الوقت الفعلي
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {notifications.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    لا توجد إشعارات مباشرة حتى الآن
                  </div>
                ) : (
                  <div className="space-y-3">
                    {notifications.map((notification, index) => (
                      <div
                        key={index}
                        className={`p-3 rounded-lg border-r-4 ${
                          notification.type === 'error'
                            ? 'border-red-500 bg-red-50'
                            : notification.type === 'success'
                            ? 'border-green-500 bg-green-50'
                            : notification.type === 'warning'
                            ? 'border-yellow-500 bg-yellow-50'
                            : 'border-blue-500 bg-blue-50'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-2">
                            {getNotificationTypeIcon(notification.type)}
                            <div>
                              <p className="font-medium text-sm">{notification.title}</p>
                              <p className="text-xs text-gray-600 mt-1">
                                {notification.message}
                              </p>
                            </div>
                          </div>
                          <span className="text-xs text-gray-400">
                            {new Date(notification.timestamp).toLocaleTimeString('ar-SA')}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notification History */}
        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                تاريخ الإشعارات
                <Badge variant="outline" className="mr-auto">
                  {history.length}
                </Badge>
              </CardTitle>
              <CardDescription>
                جميع الإشعارات المرسلة سابقاً
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {history.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    لا يوجد تاريخ إشعارات
                  </div>
                ) : (
                  <div className="space-y-3">
                    {history.map((notification) => (
                      <div
                        key={notification.id}
                        className={`p-3 rounded-lg border ${
                          notification.read ? 'bg-gray-50' : 'bg-white border-[#F5C542]'
                        }`}
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-2">
                            {getNotificationTypeIcon(notification.type)}
                            <div className="flex-1">
                              <p className={`font-medium text-sm ${
                                notification.read ? 'text-gray-600' : 'text-gray-900'
                              }`}>
                                {notification.title}
                              </p>
                              <p className="text-xs text-gray-500 mt-1">
                                {notification.message.substring(0, 100)}...
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {!notification.read && (
                              <Button
                                onClick={() => markAsRead(notification.id)}
                                size="sm"
                                variant="outline"
                              >
                                تحديد كمقروء
                              </Button>
                            )}
                            <span className="text-xs text-gray-400">
                              {new Date(notification.timestamp).toLocaleDateString('ar-SA')}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Test Notifications */}
        <TabsContent value="test">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Send className="h-5 w-5" />
                إرسال إشعار تجريبي
              </CardTitle>
              <CardDescription>
                اختبار نظام الإشعارات بإرسال إشعار تجريبي
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">نوع الإشعار</label>
                <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                  <SelectTrigger>
                    <SelectValue placeholder="اختر نوع الإشعار" />
                  </SelectTrigger>
                  <SelectContent>
                    {templates.map((template) => (
                      <SelectItem key={template.name} value={template.name}>
                        <div className="flex items-center gap-2">
                          {getPriorityIcon(template.info.priority)}
                          {template.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium mb-2 block">البيانات (JSON)</label>
                <Textarea
                  value={notificationContext}
                  onChange={(e) => setNotificationContext(e.target.value)}
                  placeholder='{"fileName": "test.pdf", "fileUrl": "/files/123", "summary": "ملخص التحليل"}'
                  rows={4}
                />
                <p className="text-xs text-gray-500 mt-1">
                  بيانات إضافية لتخصيص الإشعار (اختياري)
                </p>
              </div>

              {message && (
                <Alert className={message.type === 'error' ? 'border-red-500' : 'border-green-500'}>
                  <AlertDescription>{message.text}</AlertDescription>
                </Alert>
              )}

              <Button
                onClick={sendTestNotification}
                disabled={!selectedTemplate || isLoading}
                className="w-full"
              >
                {isLoading ? 'جارٍ الإرسال...' : 'إرسال إشعار تجريبي'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Settings */}
        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                إعدادات الإشعارات
              </CardTitle>
              <CardDescription>
                حالة وإعدادات نظام الإشعارات والبريد الإلكتروني
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Email Status */}
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Mail className="h-5 w-5" />
                  حالة البريد الإلكتروني
                </h3>
                {emailStatus ? (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-center gap-2">
                      <span className={`w-3 h-3 rounded-full ${
                        emailStatus.isConfigured ? 'bg-green-500' : 'bg-red-500'
                      }`} />
                      <span>تكوين الخدمة: {emailStatus.isConfigured ? 'مفعل' : 'غير مفعل'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`w-3 h-3 rounded-full ${
                        emailStatus.transporter ? 'bg-green-500' : 'bg-red-500'
                      }`} />
                      <span>ناقل البريد: {emailStatus.transporter ? 'متصل' : 'غير متصل'}</span>
                    </div>
                    {emailStatus.configuration.host && (
                      <div className="col-span-2 text-sm text-gray-600">
                        <p>الخادم: {emailStatus.configuration.host}:{emailStatus.configuration.port}</p>
                        <p>آمن: {emailStatus.configuration.secure ? 'نعم' : 'لا'}</p>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-gray-500">جارٍ جلب حالة البريد الإلكتروني...</p>
                )}
              </div>

              {/* WebSocket Status */}
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  حالة WebSocket
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <span className={`w-3 h-3 rounded-full ${
                      webSocket.state.isConnected ? 'bg-green-500' : 'bg-red-500'
                    }`} />
                    <span>الاتصال: {webSocket.state.isConnected ? 'متصل' : 'غير متصل'}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`w-3 h-3 rounded-full ${
                      webSocket.state.connectionId ? 'bg-green-500' : 'bg-gray-500'
                    }`} />
                    <span>معرف الجلسة: {webSocket.state.connectionId ? 'متاح' : 'غير متاح'}</span>
                  </div>
                </div>
              </div>

              {/* Available Templates */}
              <div>
                <h3 className="text-lg font-semibold mb-3">القوالب المتاحة</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {templates.map((template) => (
                    <div key={template.name} className="p-3 border rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        {getPriorityIcon(template.info.priority)}
                        <span className="font-medium text-sm">{template.name}</span>
                        <Badge variant="outline" size="sm">
                          {template.info.priority || 'normal'}
                        </Badge>
                      </div>
                      <p className="text-xs text-gray-600">
                        {template.info.subject.substring(0, 50)}...
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}