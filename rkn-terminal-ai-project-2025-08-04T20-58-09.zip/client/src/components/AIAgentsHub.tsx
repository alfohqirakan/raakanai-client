/**
 * AI Agents Hub Component
 * مركز الوكلاء الذكيين
 */

import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Alert, AlertDescription } from './ui/alert';
import CopyrightFooter from './CopyrightFooter';
import { 
  Bot, 
  Shield, 
  Code, 
  BarChart3, 
  Settings, 
  Play, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  User,
  Zap,
  Activity,
  TrendingUp
} from 'lucide-react';

interface AIAgent {
  id: string;
  name: string;
  nameAr: string;
  role: string;
  roleAr: string;
  specialization: 'security' | 'development' | 'analysis' | 'optimization' | 'testing';
  capabilities: string[];
  tools: AITool[];
  isActive: boolean;
  version: string;
  metadata: {
    created: string;
    lastUpdated: string;
    author: string;
    tags: string[];
  };
}

interface AITool {
  name: string;
  description: string;
  parameters?: Record<string, any>;
}

interface AgentExecution {
  agentId: string;
  taskId: string;
  userId: number;
  input: any;
  output?: any;
  status: 'pending' | 'running' | 'completed' | 'failed';
  startTime: string;
  endTime?: string;
  duration?: number;
  error?: string;
  toolsUsed: string[];
}

interface AgentStats {
  totalAgents: number;
  activeAgents: number;
  totalTasks: number;
  completedTasks: number;
  failedTasks: number;
  agentUsage: Record<string, number>;
  averageExecutionTime: number;
}

export function AIAgentsHub() {
  const [agents, setAgents] = useState<AIAgent[]>([]);
  const [tasks, setTasks] = useState<AgentExecution[]>([]);
  const [stats, setStats] = useState<AgentStats | null>(null);
  const [selectedAgent, setSelectedAgent] = useState<AIAgent | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Form states
  const [executionInput, setExecutionInput] = useState('');
  const [selectedTool, setSelectedTool] = useState('');
  const [testInput, setTestInput] = useState('');

  useEffect(() => {
    loadAgents();
    loadTasks();
    loadStats();
  }, []);

  const loadAgents = async () => {
    try {
      const response = await fetch('/api/agents?active=true', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setAgents(data.data || []);
      }
    } catch (error) {
      console.error('خطأ في جلب الوكلاء:', error);
    }
  };

  const loadTasks = async () => {
    try {
      const response = await fetch('/api/agents/tasks?limit=20', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setTasks(data.data || []);
      }
    } catch (error) {
      console.error('خطأ في جلب المهام:', error);
    }
  };

  const loadStats = async () => {
    try {
      const response = await fetch('/api/agents/stats', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setStats(data.data);
      }
    } catch (error) {
      console.error('خطأ في جلب الإحصائيات:', error);
    }
  };

  const executeAgent = async () => {
    if (!selectedAgent || !executionInput.trim()) return;

    setIsLoading(true);
    setMessage(null);

    try {
      let input = {};
      try {
        input = JSON.parse(executionInput);
      } catch {
        // If not valid JSON, treat as simple code input
        input = {
          code: executionInput,
          tool: selectedTool || selectedAgent.tools[0]?.name
        };
      }

      const response = await fetch(`/api/agents/${selectedAgent.id}/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ input })
      });

      if (response.ok) {
        const data = await response.json();
        setMessage({ type: 'success', text: 'تم تنفيذ الوكيل بنجاح' });
        loadTasks();
        setExecutionInput('');
      } else {
        const error = await response.json();
        setMessage({ type: 'error', text: error.message || 'فشل في التنفيذ' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'خطأ في الاتصال' });
    } finally {
      setIsLoading(false);
    }
  };

  const testAgent = async () => {
    if (!selectedAgent || !testInput.trim()) return;

    setIsLoading(true);
    setMessage(null);

    try {
      let input = {};
      try {
        input = JSON.parse(testInput);
      } catch {
        input = { code: testInput };
      }

      const response = await fetch(`/api/agents/${selectedAgent.id}/test`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ testInput: input })
      });

      if (response.ok) {
        const data = await response.json();
        setMessage({ 
          type: data.data.success ? 'success' : 'error', 
          text: data.data.message 
        });
      } else {
        const error = await response.json();
        setMessage({ type: 'error', text: error.message || 'فشل في الاختبار' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'خطأ في الاتصال' });
    } finally {
      setIsLoading(false);
    }
  };

  const getSpecializationIcon = (specialization: string) => {
    switch (specialization) {
      case 'security': return <Shield className="h-5 w-5 text-red-500" />;
      case 'development': return <Code className="h-5 w-5 text-blue-500" />;
      case 'analysis': return <BarChart3 className="h-5 w-5 text-green-500" />;
      case 'optimization': return <Zap className="h-5 w-5 text-yellow-500" />;
      case 'testing': return <CheckCircle className="h-5 w-5 text-purple-500" />;
      default: return <Bot className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed': return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'running': return <Activity className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'pending': return <Clock className="h-4 w-4 text-yellow-500" />;
      default: return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const formatDuration = (duration?: number): string => {
    if (!duration) return 'غير محدد';
    if (duration < 1000) return `${duration}ms`;
    return `${(duration / 1000).toFixed(1)}s`;
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-[#002B5B] mb-2">
          🤖 مركز الوكلاء الذكيين
        </h1>
        <p className="text-gray-600">
          الوكلاء المتخصصون لـ RKN-Terminal AI
        </p>
      </div>

      {/* Statistics Overview */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <Bot className="h-8 w-8 mx-auto mb-2 text-[#002B5B]" />
              <div className="text-2xl font-bold text-[#002B5B]">{stats.totalAgents}</div>
              <div className="text-sm text-gray-600">إجمالي الوكلاء</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Activity className="h-8 w-8 mx-auto mb-2 text-green-500" />
              <div className="text-2xl font-bold text-green-600">{stats.activeAgents}</div>
              <div className="text-sm text-gray-600">الوكلاء النشطين</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 mx-auto mb-2 text-[#F5C542]" />
              <div className="text-2xl font-bold text-[#F5C542]">{stats.completedTasks}</div>
              <div className="text-sm text-gray-600">المهام المكتملة</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Clock className="h-8 w-8 mx-auto mb-2 text-purple-500" />
              <div className="text-2xl font-bold text-purple-600">
                {formatDuration(stats.averageExecutionTime)}
              </div>
              <div className="text-sm text-gray-600">متوسط وقت التنفيذ</div>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs defaultValue="agents" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="agents">الوكلاء المتاحون</TabsTrigger>
          <TabsTrigger value="execute">تنفيذ مهمة</TabsTrigger>
          <TabsTrigger value="tasks">المهام السابقة</TabsTrigger>
        </TabsList>

        {/* Available Agents */}
        <TabsContent value="agents">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {agents.map((agent) => (
              <Card 
                key={agent.id} 
                className={`cursor-pointer transition-colors ${
                  selectedAgent?.id === agent.id ? 'border-[#F5C542] bg-yellow-50' : ''
                }`}
                onClick={() => setSelectedAgent(agent)}
              >
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getSpecializationIcon(agent.specialization)}
                    <div>
                      <div className="text-sm font-bold">{agent.nameAr}</div>
                      <div className="text-xs text-gray-500">{agent.name}</div>
                    </div>
                    <Badge variant={agent.isActive ? 'default' : 'secondary'} className="mr-auto">
                      {agent.isActive ? 'نشط' : 'غير نشط'}
                    </Badge>
                  </CardTitle>
                  <CardDescription>{agent.roleAr}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <div className="text-sm font-medium mb-1">القدرات:</div>
                      <div className="flex flex-wrap gap-1">
                        {agent.capabilities.slice(0, 3).map((capability, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {capability}
                          </Badge>
                        ))}
                        {agent.capabilities.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{agent.capabilities.length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm font-medium mb-1">الأدوات:</div>
                      <div className="text-xs text-gray-600">
                        {agent.tools.map(tool => tool.name).join(', ')}
                      </div>
                    </div>
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>الإصدار: {agent.version}</span>
                      <span>{agent.metadata.created}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Execute Agent */}
        <TabsContent value="execute">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Play className="h-5 w-5" />
                تنفيذ وكيل ذكي
              </CardTitle>
              <CardDescription>
                اختر وكيلاً وقدم المدخلات لتنفيذ المهمة
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">الوكيل المحدد</label>
                {selectedAgent ? (
                  <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg">
                    {getSpecializationIcon(selectedAgent.specialization)}
                    <div>
                      <div className="font-medium">{selectedAgent.nameAr}</div>
                      <div className="text-sm text-gray-600">{selectedAgent.roleAr}</div>
                    </div>
                  </div>
                ) : (
                  <div className="text-sm text-gray-500 p-3 bg-gray-50 rounded-lg">
                    لم يتم اختيار وكيل. اختر وكيلاً من التبويب الأول.
                  </div>
                )}
              </div>

              {selectedAgent && (
                <>
                  <div>
                    <label className="text-sm font-medium mb-2 block">الأداة (اختياري)</label>
                    <Select value={selectedTool} onValueChange={setSelectedTool}>
                      <SelectTrigger>
                        <SelectValue placeholder="اختر أداة أو اتركها فارغة للاختيار التلقائي" />
                      </SelectTrigger>
                      <SelectContent>
                        {selectedAgent.tools.map((tool) => (
                          <SelectItem key={tool.name} value={tool.name}>
                            {tool.name} - {tool.description}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">المدخل</label>
                    <Textarea
                      value={executionInput}
                      onChange={(e) => setExecutionInput(e.target.value)}
                      placeholder={
                        selectedAgent.specialization === 'security' 
                          ? 'أدخل الشفرة للفحص الأمني أو JSON: {"code": "SELECT * FROM users", "tool": "code-scanner"}'
                          : selectedAgent.specialization === 'development'
                          ? 'أدخل الشفرة للتحسين أو JSON: {"code": "for(var i=0; i<arr.length; i++)", "tool": "code-optimizer"}'
                          : 'أدخل البيانات للتحليل أو تنسيق JSON'
                      }
                      rows={6}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      يمكنك إدخال نص عادي أو JSON. للنص العادي سيتم معاملته كشفرة برمجية.
                    </p>
                  </div>

                  {message && (
                    <Alert className={message.type === 'error' ? 'border-red-500' : 'border-green-500'}>
                      <AlertDescription>{message.text}</AlertDescription>
                    </Alert>
                  )}

                  <div className="flex gap-2">
                    <Button
                      onClick={executeAgent}
                      disabled={!executionInput.trim() || isLoading}
                      className="flex-1"
                    >
                      {isLoading ? 'جارٍ التنفيذ...' : 'تنفيذ المهمة'}
                    </Button>
                    <Button
                      onClick={testAgent}
                      disabled={!executionInput.trim() || isLoading}
                      variant="outline"
                      className="flex-1"
                    >
                      اختبار فقط
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Previous Tasks */}
        <TabsContent value="tasks">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                المهام السابقة
                <Badge variant="outline" className="mr-auto">
                  {tasks.length}
                </Badge>
              </CardTitle>
              <CardDescription>
                سجل المهام التي تم تنفيذها بواسطة الوكلاء الذكيين
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {tasks.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    لا توجد مهام سابقة
                  </div>
                ) : (
                  <div className="space-y-3">
                    {tasks.map((task) => {
                      const agent = agents.find(a => a.id === task.agentId);
                      return (
                        <div
                          key={task.taskId}
                          className="p-3 border rounded-lg hover:bg-gray-50"
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {getStatusIcon(task.status)}
                              <div>
                                <div className="font-medium text-sm">
                                  {agent?.nameAr || task.agentId}
                                </div>
                                <div className="text-xs text-gray-500">
                                  {task.taskId}
                                </div>
                              </div>
                            </div>
                            <div className="text-left">
                              <div className="text-xs text-gray-500">
                                {new Date(task.startTime).toLocaleString('ar-SA')}
                              </div>
                              {task.duration && (
                                <div className="text-xs text-gray-400">
                                  المدة: {formatDuration(task.duration)}
                                </div>
                              )}
                            </div>
                          </div>
                          
                          {task.toolsUsed.length > 0 && (
                            <div className="flex flex-wrap gap-1 mb-2">
                              {task.toolsUsed.map((tool, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {tool}
                                </Badge>
                              ))}
                            </div>
                          )}
                          
                          {task.error && (
                            <div className="text-xs text-red-600 bg-red-50 p-2 rounded">
                              {task.error}
                            </div>
                          )}
                          
                          {task.output && task.status === 'completed' && (
                            <div className="text-xs text-green-600 bg-green-50 p-2 rounded">
                              ✅ تم التنفيذ بنجاح
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Copyright Footer */}
      <div className="mt-8">
        <CopyrightFooter variant="compact" />
      </div>
    </div>
  );
}