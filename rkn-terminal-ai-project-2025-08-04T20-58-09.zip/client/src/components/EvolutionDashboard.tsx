/**
 * Evolution Dashboard Component
 * لوحة تحكم التطور الذاتي
 */

import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import CopyrightFooter from './CopyrightFooter';
import { 
  Brain, 
  TrendingUp, 
  Lightbulb, 
  BookOpen, 
  Activity, 
  Target,
  AlertTriangle,
  CheckCircle,
  Clock,
  BarChart3,
  Zap
} from 'lucide-react';

interface EvolutionMetrics {
  agentId: string;
  successRate: number;
  averageExecutionTime: number;
  errorRate: number;
  userSatisfaction: number;
  improvementAreas: string[];
  strengths: string[];
  lastAnalyzed: string;
}

interface LearningPattern {
  id: string;
  pattern: string;
  frequency: number;
  successRate: number;
  context: string;
  recommendations: string[];
  createdAt: string;
  updatedAt: string;
}

interface EvolutionSuggestion {
  agentId: string;
  type: 'capability' | 'tool' | 'prompt' | 'parameter';
  description: string;
  descriptionAr: string;
  impact: 'low' | 'medium' | 'high';
  implementation: string;
  reasoning: string;
  confidence: number;
  createdAt: string;
}

interface EvolutionStats {
  totalAgentsAnalyzed: number;
  averageSuccessRate: number;
  totalPatternsIdentified: number;
  totalSuggestionsGenerated: number;
  knowledgeBaseDomains: string[];
  lastEvolutionCycle: string;
  evolutionTrends: {
    improvingAgents: number;
    stableAgents: number;
    decliningAgents: number;
  };
}

export function EvolutionDashboard() {
  const [metrics, setMetrics] = useState<Record<string, EvolutionMetrics>>({});
  const [patterns, setPatterns] = useState<LearningPattern[]>([]);
  const [suggestions, setSuggestions] = useState<Record<string, EvolutionSuggestion[]>>({});
  const [stats, setStats] = useState<EvolutionStats | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState<string>('');

  useEffect(() => {
    loadEvolutionData();
  }, []);

  const loadEvolutionData = async () => {
    setIsLoading(true);
    try {
      await Promise.all([
        loadMetrics(),
        loadPatterns(),
        loadSuggestions(),
        loadStats()
      ]);
    } catch (error) {
      console.error('خطأ في تحميل بيانات التطور:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadMetrics = async () => {
    try {
      const response = await fetch('/api/evolution/metrics', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setMetrics(data.data || {});
      }
    } catch (error) {
      console.error('خطأ في جلب المقاييس:', error);
    }
  };

  const loadPatterns = async () => {
    try {
      const response = await fetch('/api/evolution/patterns', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setPatterns(data.data || []);
      }
    } catch (error) {
      console.error('خطأ في جلب الأنماط:', error);
    }
  };

  const loadSuggestions = async () => {
    try {
      const response = await fetch('/api/evolution/suggestions', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setSuggestions(data.data || {});
      }
    } catch (error) {
      console.error('خطأ في جلب الاقتراحات:', error);
    }
  };

  const loadStats = async () => {
    try {
      const response = await fetch('/api/evolution/stats', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        setStats(data.data);
      }
    } catch (error) {
      console.error('خطأ في جلب الإحصائيات:', error);
    }
  };

  const analyzeAgent = async (agentId: string) => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/evolution/analyze/${agentId}`, {
        method: 'POST',
        credentials: 'include'
      });
      if (response.ok) {
        await loadEvolutionData();
      }
    } catch (error) {
      console.error('خطأ في تحليل الوكيل:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'capability': return <Zap className="h-4 w-4" />;
      case 'tool': return <Target className="h-4 w-4" />;
      case 'prompt': return <Brain className="h-4 w-4" />;
      case 'parameter': return <Activity className="h-4 w-4" />;
      default: return <Lightbulb className="h-4 w-4" />;
    }
  };

  const formatPercentage = (value: number) => `${(value * 100).toFixed(1)}%`;
  const formatTime = (ms: number) => ms < 1000 ? `${ms}ms` : `${(ms / 1000).toFixed(1)}s`;

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-[#002B5B] mb-2">
          🧠 لوحة التطور الذاتي
        </h1>
        <p className="text-gray-600">
          نظام التعلم والتطور المستمر لوكلاء RKN-Terminal AI
        </p>
      </div>

      {/* Statistics Overview */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <Brain className="h-8 w-8 mx-auto mb-2 text-[#002B5B]" />
              <div className="text-2xl font-bold text-[#002B5B]">{stats.totalAgentsAnalyzed}</div>
              <div className="text-sm text-gray-600">وكلاء محللين</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 mx-auto mb-2 text-green-500" />
              <div className="text-2xl font-bold text-green-600">
                {formatPercentage(stats.averageSuccessRate)}
              </div>
              <div className="text-sm text-gray-600">متوسط النجاح</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <BookOpen className="h-8 w-8 mx-auto mb-2 text-[#F5C542]" />
              <div className="text-2xl font-bold text-[#F5C542]">{stats.totalPatternsIdentified}</div>
              <div className="text-sm text-gray-600">أنماط مكتشفة</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Lightbulb className="h-8 w-8 mx-auto mb-2 text-purple-500" />
              <div className="text-2xl font-bold text-purple-600">{stats.totalSuggestionsGenerated}</div>
              <div className="text-sm text-gray-600">اقتراحات مُولدة</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Evolution Trends */}
      {stats && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              اتجاهات التطور
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{stats.evolutionTrends.improvingAgents}</div>
                <div className="text-sm text-green-700">وكلاء متحسنين</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{stats.evolutionTrends.stableAgents}</div>
                <div className="text-sm text-blue-700">وكلاء مستقرين</div>
              </div>
              <div className="text-center p-4 bg-red-50 rounded-lg">
                <div className="text-2xl font-bold text-red-600">{stats.evolutionTrends.decliningAgents}</div>
                <div className="text-sm text-red-700">وكلاء يحتاجون تحسين</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="metrics" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="metrics">مقاييس الأداء</TabsTrigger>
          <TabsTrigger value="patterns">أنماط التعلم</TabsTrigger>
          <TabsTrigger value="suggestions">اقتراحات التطوير</TabsTrigger>
          <TabsTrigger value="analysis">التحليل المخصص</TabsTrigger>
        </TabsList>

        {/* Performance Metrics */}
        <TabsContent value="metrics">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Object.entries(metrics).map(([agentId, metric]) => (
              <Card key={agentId}>
                <CardHeader>
                  <CardTitle className="text-lg">{agentId}</CardTitle>
                  <CardDescription>
                    آخر تحليل: {new Date(metric.lastAnalyzed).toLocaleDateString('ar-SA')}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">معدل النجاح</span>
                      <span className="text-sm font-bold">{formatPercentage(metric.successRate)}</span>
                    </div>
                    <Progress value={metric.successRate * 100} className="h-2" />
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm">رضا المستخدم</span>
                      <span className="text-sm font-bold">{formatPercentage(metric.userSatisfaction)}</span>
                    </div>
                    <Progress value={metric.userSatisfaction * 100} className="h-2" />
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="text-gray-600">متوسط الوقت:</span>
                      <div className="font-medium">{formatTime(metric.averageExecutionTime)}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">معدل الأخطاء:</span>
                      <div className="font-medium">{formatPercentage(metric.errorRate)}</div>
                    </div>
                  </div>

                  {metric.strengths.length > 0 && (
                    <div>
                      <div className="text-sm font-medium text-green-600 mb-1">نقاط القوة:</div>
                      <div className="flex flex-wrap gap-1">
                        {metric.strengths.slice(0, 2).map((strength, index) => (
                          <Badge key={index} variant="outline" className="text-xs text-green-700">
                            {strength}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {metric.improvementAreas.length > 0 && (
                    <div>
                      <div className="text-sm font-medium text-orange-600 mb-1">مجالات التحسين:</div>
                      <div className="flex flex-wrap gap-1">
                        {metric.improvementAreas.slice(0, 2).map((area, index) => (
                          <Badge key={index} variant="outline" className="text-xs text-orange-700">
                            {area}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Learning Patterns */}
        <TabsContent value="patterns">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                أنماط التعلم المكتشفة
                <Badge variant="outline" className="mr-auto">
                  {patterns.length}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {patterns.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    لم يتم اكتشاف أنماط تعلم حتى الآن
                  </div>
                ) : (
                  <div className="space-y-3">
                    {patterns.map((pattern) => (
                      <div key={pattern.id} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <div className="font-medium text-sm">{pattern.pattern}</div>
                            <div className="text-xs text-gray-600 mt-1">{pattern.context}</div>
                          </div>
                          <div className="text-left">
                            <div className="text-xs text-gray-500">
                              تكرار: {pattern.frequency}
                            </div>
                            <div className="text-xs text-gray-500">
                              نجاح: {formatPercentage(pattern.successRate)}
                            </div>
                          </div>
                        </div>
                        
                        {pattern.recommendations.length > 0 && (
                          <div className="mt-2">
                            <div className="text-xs font-medium text-blue-600 mb-1">التوصيات:</div>
                            <div className="flex flex-wrap gap-1">
                              {pattern.recommendations.map((rec, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {rec}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Evolution Suggestions */}
        <TabsContent value="suggestions">
          <div className="space-y-4">
            {Object.entries(suggestions).map(([agentId, agentSuggestions]) => (
              <Card key={agentId}>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5" />
                    اقتراحات تطوير {agentId}
                    <Badge variant="outline" className="mr-auto">
                      {agentSuggestions.length}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {agentSuggestions.length === 0 ? (
                    <div className="text-center text-gray-500 py-4">
                      لا توجد اقتراحات حالياً
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {agentSuggestions.map((suggestion, index) => (
                        <div key={index} className="p-3 border rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              {getTypeIcon(suggestion.type)}
                              <div>
                                <div className="font-medium text-sm">{suggestion.descriptionAr}</div>
                                <div className="text-xs text-gray-600 mt-1">{suggestion.description}</div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge className={getImpactColor(suggestion.impact)}>
                                {suggestion.impact}
                              </Badge>
                              <span className="text-xs text-gray-500">
                                {(suggestion.confidence * 100).toFixed(0)}%
                              </span>
                            </div>
                          </div>
                          
                          <div className="text-xs text-gray-600 mb-2">
                            <strong>التنفيذ:</strong> {suggestion.implementation}
                          </div>
                          
                          <div className="text-xs text-gray-600">
                            <strong>التبرير:</strong> {suggestion.reasoning}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Custom Analysis */}
        <TabsContent value="analysis">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                التحليل المخصص
              </CardTitle>
              <CardDescription>
                تحليل مفصل لوكيل محدد وإنشاء اقتراحات مخصصة
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {Object.keys(metrics).map((agentId) => (
                  <Button
                    key={agentId}
                    onClick={() => analyzeAgent(agentId)}
                    disabled={isLoading}
                    variant={selectedAgent === agentId ? 'default' : 'outline'}
                    className="justify-start"
                  >
                    {agentId}
                  </Button>
                ))}
              </div>
              
              {isLoading && (
                <div className="text-center py-8">
                  <Activity className="h-8 w-8 animate-spin mx-auto mb-2 text-[#002B5B]" />
                  <div className="text-sm text-gray-600">جارٍ تحليل الوكيل...</div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Copyright Footer */}
      <div className="mt-8">
        <CopyrightFooter variant="compact" />
      </div>
    </div>
  );
}