import React from 'react';

interface FalconLogoProps {
  size?: number;
  className?: string;
  animated?: boolean;
}

export const FalconLogo: React.FC<FalconLogoProps> = ({ 
  size = 60, 
  className = '', 
  animated = true 
}) => {
  return (
    <div className={`${className} ${animated ? 'hover:scale-110 transition-transform duration-300' : ''}`}>
      <svg 
        width={size} 
        height={size} 
        viewBox="0 0 120 120" 
        xmlns="http://www.w3.org/2000/svg"
        className="drop-shadow-lg"
      >
        {/* Background Circle - Arabic Desert Gold */}
        <circle 
          cx="60" 
          cy="60" 
          r="58" 
          fill="url(#falconGradient)"
          stroke="url(#strokeGradient)"
          strokeWidth="2"
        />
        
        {/* Falcon Silhouette - Attacking Pose */}
        <g transform="translate(60,60)">
          {/* Body */}
          <path
            d="M-5,-20 C-8,-15 -10,-5 -8,5 C-5,15 0,20 5,15 C8,10 10,0 8,-10 C5,-18 0,-22 -5,-20 Z"
            fill="#1a1a2e"
            className={animated ? "animate-pulse" : ""}
          />
          
          {/* Wings - Spread for Attack */}
          <path
            d="M-8,-15 C-25,-20 -35,-15 -30,-5 C-25,0 -15,-2 -8,-8 Z"
            fill="#0f3460"
            className={animated ? "animate-bounce" : ""}
            style={{ animationDuration: '3s' }}
          />
          <path
            d="M8,-15 C25,-20 35,-15 30,-5 C25,0 15,-2 8,-8 Z"
            fill="#0f3460"
            className={animated ? "animate-bounce" : ""}
            style={{ animationDuration: '3s', animationDelay: '0.2s' }}
          />
          
          {/* Head and Beak - Sharp and Focused */}
          <circle cx="0" cy="-18" r="6" fill="#1a1a2e" />
          <path
            d="M0,-24 L6,-28 L3,-22 Z"
            fill="#c9a876"
            className={animated ? "animate-ping" : ""}
            style={{ animationDuration: '2s' }}
          />
          
          {/* Eye - Fierce and Alert */}
          <circle cx="2" cy="-20" r="2" fill="#c9a876" />
          <circle cx="3" cy="-21" r="1" fill="#1a1a2e" />
          
          {/* Tail Feathers */}
          <path
            d="M0,15 C-3,25 0,30 3,25 C5,20 3,15 0,15 Z"
            fill="#0f3460"
          />
          
          {/* Talons - Sharp and Ready */}
          <g transform="translate(-3,12)">
            <path d="M0,0 L-2,8 M2,0 L0,8 M4,0 L6,8" 
                  stroke="#c9a876" 
                  strokeWidth="2" 
                  strokeLinecap="round" />
          </g>
          <g transform="translate(3,12)">
            <path d="M0,0 L-2,8 M2,0 L0,8 M4,0 L6,8" 
                  stroke="#c9a876" 
                  strokeWidth="2" 
                  strokeLinecap="round" />
          </g>
        </g>
        
        {/* Gradients */}
        <defs>
          <radialGradient id="falconGradient" cx="50%" cy="30%">
            <stop offset="0%" stopColor="#c9a876" />
            <stop offset="50%" stopColor="#8b7355" />
            <stop offset="100%" stopColor="#5d4e37" />
          </radialGradient>
          <linearGradient id="strokeGradient">
            <stop offset="0%" stopColor="#c9a876" />
            <stop offset="100%" stopColor="#1a1a2e" />
          </linearGradient>
        </defs>
        
        {/* Arabic Pattern Elements */}
        <g opacity="0.3">
          <path d="M20,20 Q30,15 40,20 T60,20" stroke="#c9a876" strokeWidth="1" fill="none" />
          <path d="M60,100 Q70,95 80,100 T100,100" stroke="#c9a876" strokeWidth="1" fill="none" />
          <circle cx="100" cy="20" r="2" fill="#c9a876" opacity="0.5" />
          <circle cx="20" cy="100" r="2" fill="#c9a876" opacity="0.5" />
        </g>
      </svg>
    </div>
  );
};

export const FalconIconSmall: React.FC<{ size?: number; className?: string }> = ({ 
  size = 24, 
  className = '' 
}) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 40 40" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <circle cx="20" cy="20" r="18" fill="url(#smallFalconGradient)" />
      <g transform="translate(20,20) scale(0.6)">
        <path d="M-3,-12 C-5,-8 -6,-2 -5,3 C-3,8 0,10 3,8 C5,5 6,-2 5,-6 C3,-10 0,-12 -3,-12 Z" fill="#1a1a2e" />
        <path d="M-5,-8 C-12,-10 -16,-8 -14,-3 C-12,0 -8,-1 -5,-4 Z" fill="#0f3460" />
        <path d="M5,-8 C12,-10 16,-8 14,-3 C12,0 8,-1 5,-4 Z" fill="#0f3460" />
        <circle cx="0" cy="-10" r="3" fill="#1a1a2e" />
        <path d="M0,-13 L3,-15 L1,-12 Z" fill="#c9a876" />
        <circle cx="1" cy="-11" r="1" fill="#c9a876" />
      </g>
      <defs>
        <radialGradient id="smallFalconGradient">
          <stop offset="0%" stopColor="#c9a876" />
          <stop offset="100%" stopColor="#5d4e37" />
        </radialGradient>
      </defs>
    </svg>
  );
};