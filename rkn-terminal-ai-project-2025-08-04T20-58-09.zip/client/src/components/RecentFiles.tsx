import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatFileSize, getFileIcon, formatTimeAgo } from "@/lib/fileUtils";
import type { File } from "@shared/schema";

interface RecentFilesProps {
  onFileSelect: (fileId: string) => void;
}

export default function RecentFiles({ onFileSelect }: RecentFilesProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: files = [], isLoading } = useQuery<File[]>({
    queryKey: ["/api/files"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (fileId: string) => {
      await apiRequest('DELETE', `/api/files/${fileId}`);
    },
    onSuccess: () => {
      toast({
        title: "تم حذف الملف بنجاح",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: (error) => {
      toast({
        title: "فشل في حذف الملف",
        description: (error as Error).message,
        variant: "destructive",
      });
    },
  });

  const downloadReport = async (fileId: string, fileName: string) => {
    try {
      const response = await apiRequest('GET', `/api/files/${fileId}/report`) as any;
      const { downloadURL, fileName: reportFileName } = response;
      
      // Create download link
      const link = document.createElement('a');
      link.href = downloadURL;
      link.download = reportFileName || `تقرير_${fileName}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      toast({
        title: "تم تحميل التقرير بنجاح",
        description: "تم تحميل تقرير التحليل بنجاح",
      });
    } catch (error) {
      toast({
        title: "فشل في تحميل التقرير",
        description: (error as Error).message,
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'analyzed':
        return <span className="bg-success/20 text-success px-2 py-1 rounded-full text-xs">مُحلل</span>;
      case 'processing':
        return <span className="bg-warning/20 text-warning px-2 py-1 rounded-full text-xs">قيد المعالجة</span>;
      case 'error':
        return <span className="bg-destructive/20 text-destructive px-2 py-1 rounded-full text-xs">خطأ</span>;
      default:
        return <span className="bg-gray-600/20 text-gray-400 px-2 py-1 rounded-full text-xs">مرفوع</span>;
    }
  };

  if (isLoading) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-semibold mb-4">الملفات الحديثة</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="bg-charcoal border border-gray-600 rounded-xl p-4 animate-pulse">
              <div className="w-10 h-10 bg-gray-700 rounded-lg mb-3"></div>
              <div className="h-4 bg-gray-700 rounded mb-2"></div>
              <div className="h-3 bg-gray-700 rounded w-20"></div>
            </div>
          ))}
        </div>
      </section>
    );
  }

  return (
    <section className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-semibold">الملفات الحديثة</h3>
        <button className="text-electric-blue hover:text-electric-blue/80 transition-colors">
          <span className="text-sm">عرض الكل</span>
          <i className="fas fa-arrow-left mr-2"></i>
        </button>
      </div>

      {files.length === 0 ? (
        <div className="bg-charcoal border border-gray-600 rounded-xl p-8 text-center">
          <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-folder-open text-gray-400 text-2xl"></i>
          </div>
          <h4 className="text-lg font-semibold mb-2">لا توجد ملفات</h4>
          <p className="text-gray-400">ابدأ برفع ملفاتك لتحليلها بالذكاء الاصطناعي</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {files.slice(0, 6).map((file) => (
            <div 
              key={file.id} 
              className="bg-charcoal border border-gray-600 hover:border-electric-blue rounded-xl p-4 transition-all group cursor-pointer"
              onClick={() => onFileSelect(file.id)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getFileIcon(file.mimeType).bg}`}>
                  <i className={`${getFileIcon(file.mimeType).icon} ${getFileIcon(file.mimeType).color}`}></i>
                </div>
                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                  <button 
                    className="text-electric-blue hover:text-electric-blue/80 transition-colors"
                    onClick={(e) => {
                      e.stopPropagation();
                      onFileSelect(file.id);
                    }}
                    title="عرض الملف"
                  >
                    <i className="fas fa-eye"></i>
                  </button>
                  {file.status === 'analyzed' && (
                    <button 
                      className="text-green-400 hover:text-green-300 transition-colors"
                      onClick={(e) => {
                        e.stopPropagation();
                        downloadReport(file.id, file.originalName);
                      }}
                      title="تحميل التقرير"
                    >
                      <i className="fas fa-download"></i>
                    </button>
                  )}
                  <button 
                    className="text-red-400 hover:text-red-300 transition-colors"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteMutation.mutate(file.id);
                    }}
                    disabled={deleteMutation.isPending}
                    title="حذف الملف"
                  >
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>
              <h4 className="font-medium mb-1 truncate" title={file.originalName}>
                {file.originalName}
              </h4>
              <p className="text-sm text-gray-400 mb-2">
                {formatFileSize(file.size)}
              </p>
              <div className="flex items-center justify-between text-xs">
                <span className="text-gray-500">
                  {formatTimeAgo(file.uploadedAt || undefined)}
                </span>
                {getStatusBadge(file.status)}
              </div>
              {file.summary && (
                <p className="text-xs text-gray-400 mt-2 line-clamp-2">
                  {file.summary}
                </p>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
