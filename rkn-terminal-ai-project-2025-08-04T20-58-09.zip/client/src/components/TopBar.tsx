import { useAuth } from "@/hooks/useAuth";

export default function TopBar() {
  const { user, logout, isLoggingOut } = useAuth();
  return (
    <header className="bg-charcoal/90 backdrop-blur-sm border-b border-gray-700 px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Mobile Menu Toggle */}
        <button className="lg:hidden text-gray-300 hover:text-white transition-colors">
          <i className="fas fa-bars text-xl"></i>
        </button>

        {/* Search Bar */}
        <div className="flex-1 max-w-md mx-6">
          <div className="relative">
            <input 
              type="text" 
              placeholder="البحث في الملفات والمحادثات..." 
              className="w-full bg-gray-800 border border-gray-600 rounded-xl px-4 py-2 pr-10 text-white placeholder-gray-400 focus:border-electric-blue focus:ring-1 focus:ring-electric-blue transition-all"
            />
            <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
          </div>
        </div>

        {/* User Actions */}
        <div className="flex items-center gap-4">
          {/* Plans Link */}
          <a 
            href="/plans"
            className="flex items-center gap-2 px-3 py-2 text-electric-blue hover:bg-electric-blue/10 rounded-lg transition-all text-sm font-medium"
          >
            <i className="fas fa-crown"></i>
            <span className="hidden md:inline">الخطط</span>
          </a>

          {/* Entity Monitor Link */}
          <a 
            href="/entity-monitor"
            className="flex items-center gap-2 px-3 py-2 text-gray-300 hover:bg-gray-700/50 rounded-lg transition-all text-sm"
          >
            <i className="fas fa-robot"></i>
            <span className="hidden md:inline">مراقب راكان</span>
          </a>

          {/* Notifications */}
          <button className="relative p-2 text-gray-300 hover:text-white transition-colors">
            <i className="fas fa-bell text-lg"></i>
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-warning rounded-full text-xs flex items-center justify-center">3</span>
          </button>

          {/* User Profile */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-electric-blue to-ai-purple flex items-center justify-center">
              <i className="fas fa-user text-white text-sm"></i>
            </div>
            <div className="hidden md:block">
              <p className="text-sm font-medium">{user?.username || "مستخدم"}</p>
              <p className="text-xs text-gray-400">
                {user?.plan === 'pro' ? 'خطة احترافية' : 'خطة مجانية'} • {user?.uploadCount || 0} ملف
              </p>
            </div>
            
            {/* Logout Button */}
            <button
              onClick={logout}
              disabled={isLoggingOut}
              className="p-2 text-gray-300 hover:text-red-400 transition-colors disabled:opacity-50"
              title="تسجيل الخروج"
            >
              {isLoggingOut ? (
                <div className="w-4 h-4 border-2 border-gray-300 border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <i className="fas fa-sign-out-alt text-lg"></i>
              )}
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
