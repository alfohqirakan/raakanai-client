import { useQuery } from '@tanstack/react-query';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { FileImage, FileText, Code, Archive, Volume2, Video, File } from 'lucide-react';

interface SupportedTypes {
  images: string[];
  documents: string[];
  text: string[];
  code: string[];
  archives: string[];
  audio: string[];
  video: string[];
  maxSize: string;
  maxFiles: string;
}

export function FileTypeInfo() {
  const { t } = useTranslation();
  
  const { data: supportedTypes, isLoading } = useQuery<{ data: SupportedTypes }>({
    queryKey: ['/api/files/supported-types'],
    enabled: true,
  });

  if (isLoading) {
    return <div className="text-center py-4">{t('loading')}</div>;
  }

  if (!supportedTypes?.data) {
    return null;
  }

  const typeIcons = {
    images: FileImage,
    documents: FileText,
    text: FileText,
    code: Code,
    archives: Archive,
    audio: Volume2,
    video: Video,
  };

  const typeLabels = {
    images: t('images'),
    documents: t('documents'),
    text: t('textFiles'),
    code: t('codeFiles'),
    archives: t('archiveFiles'),
    audio: t('audioFiles'),
    video: t('videoFiles'),
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <File className="h-5 w-5" />
          {t('supportedFileTypes')}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* File Type Categories */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.entries(supportedTypes.data).map(([category, types]) => {
            if (['maxSize', 'maxFiles'].includes(category) || !Array.isArray(types)) {
              return null;
            }

            const Icon = typeIcons[category as keyof typeof typeIcons] || File;
            const label = typeLabels[category as keyof typeof typeLabels] || category;

            return (
              <div key={category} className="space-y-3">
                <div className="flex items-center gap-2 font-medium">
                  <Icon className="h-4 w-4 text-blue-500" />
                  {label}
                </div>
                <div className="flex flex-wrap gap-1">
                  {types.map((type: string) => (
                    <Badge key={type} variant="secondary" className="text-xs">
                      .{type}
                    </Badge>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Limits Information */}
        <div className="border-t pt-4 space-y-2">
          <div className="flex justify-between items-center">
            <span className="font-medium">{t('maxSize')}:</span>
            <Badge variant="outline">{supportedTypes.data.maxSize}</Badge>
          </div>
          <div className="flex justify-between items-center">
            <span className="font-medium">{t('totalFiles')}:</span>
            <Badge variant="outline">{supportedTypes.data.maxFiles}</Badge>
          </div>
        </div>

        {/* Security Note */}
        <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
          <p className="text-sm text-blue-700 dark:text-blue-300">
            {t('securityNote')}: {t('securityNoteText')}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}