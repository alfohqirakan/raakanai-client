import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { FileUploadProgress } from '@/components/FileUploadProgress';
import { FileTypeInfo } from '@/components/FileTypeInfo';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { 
  Upload, 
  CheckCircle, 
  AlertTriangle, 
  BarChart3, 
  RefreshCw,
  Info,
  Shield,
  Zap
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';

interface ProcessingStats {
  circuitBreaker: {
    state: 'closed' | 'open' | 'half-open';
    failures: number;
    lastFailureTime: number;
  };
  timestamp: string;
  version: string;
}

interface UploadResult {
  id: string;
  status: 'success' | 'failed';
  summary: string;
  keyPoints: string[];
  categories: string[];
  confidence: number;
  language: string;
  fileSize: number;
  processingTime: number;
  retryAttempts: number;
  error?: string;
}

interface UploadResponse {
  results: UploadResult[];
  summary: {
    total: number;
    successful: number;
    failed: number;
    processingStats: ProcessingStats;
  };
}

export function AdvancedFileUploader() {
  const { t, isRTL } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showStats, setShowStats] = useState(false);
  const [showFileTypes, setShowFileTypes] = useState(false);

  // Get processing statistics
  const { data: processingStats, refetch: refetchStats } = useQuery<{ data: ProcessingStats }>({
    queryKey: ['/api/ai/processing-stats'],
    enabled: showStats,
    refetchInterval: showStats ? 5000 : false, // Refresh every 5 seconds when visible
  });

  // Get cache statistics
  const { data: cacheStats } = useQuery<{ data: any }>({
    queryKey: ['/api/ai/cache-stats'],
    enabled: showStats,
    refetchInterval: showStats ? 5000 : false,
  });

  // Get system health
  const { data: systemHealth } = useQuery<{ data: any }>({
    queryKey: ['/api/ai/system-health'],
    enabled: showStats,
    refetchInterval: showStats ? 10000 : false,
  });

  // Upload with progress mutation
  const uploadMutation = useMutation({
    mutationFn: async (files: File[]) => {
      const formData = new FormData();
      files.forEach((file, index) => {
        formData.append(`files`, file);
      });

      const response = await fetch('/api/files/upload-with-progress', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error(`Upload failed: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.status?.includes('❌')) {
        throw new Error(data.message || 'Upload failed');
      }

      return data.data as UploadResponse;
    },
    onSuccess: (data) => {
      toast({
        title: t('uploadSuccess'),
        description: `${data.summary.successful} ${t('filesCount')} ${t('successfully')} ${t('uploaded')}`,
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats'] });
    },
    onError: (error: Error) => {
      toast({
        title: t('uploadFailed'),
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Reset circuit breaker mutation
  const resetCircuitBreakerMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/ai/reset-circuit-breaker', {
        method: 'POST',
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error(`Reset failed: ${response.statusText}`);
      }

      const data = await response.json();
      if (data.status?.includes('❌')) {
        throw new Error(data.message || 'Reset failed');
      }

      return data.data;
    },
    onSuccess: () => {
      toast({
        title: t('success'),
        description: 'تم إعادة تعيين قاطع الدائرة بنجاح',
      });
      refetchStats();
    },
    onError: (error: Error) => {
      toast({
        title: t('error'),
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleFileUpload = async (files: File[]) => {
    if (!user) {
      toast({
        title: t('error'),
        description: t('mustLoginToUpload'),
        variant: 'destructive',
      });
      return;
    }

    await uploadMutation.mutateAsync(files);
  };

  const getCircuitBreakerStatus = () => {
    const state = processingStats?.data?.circuitBreaker?.state;
    switch (state) {
      case 'closed':
        return { text: 'طبيعي', color: 'bg-green-500', icon: CheckCircle };
      case 'open':
        return { text: 'مفتوح', color: 'bg-red-500', icon: AlertTriangle };
      case 'half-open':
        return { text: 'تجريبي', color: 'bg-yellow-500', icon: RefreshCw };
      default:
        return { text: 'غير معروف', color: 'bg-gray-500', icon: Info };
    }
  };

  const formatProcessingTime = (ms: number) => {
    if (ms < 1000) return `${ms}ms`;
    return `${(ms / 1000).toFixed(1)}s`;
  };

  return (
    <div className={cn("w-full max-w-4xl mx-auto space-y-6", isRTL && "rtl")}>
      {/* Header */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Upload className="h-6 w-6 text-blue-600" />
            {t('uploadFiles')}
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              {t('enhanced')} AI
            </Badge>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button
          variant="outline"
          onClick={() => setShowFileTypes(!showFileTypes)}
          className="flex items-center gap-2"
        >
          <Info className="h-4 w-4" />
          {t('supportedFileTypes')}
        </Button>
        
        <Button
          variant="outline"
          onClick={() => setShowStats(!showStats)}
          className="flex items-center gap-2"
        >
          <BarChart3 className="h-4 w-4" />
          {t('processingStats')}
        </Button>

        {processingStats?.data?.circuitBreaker?.state === 'open' && (
          <Button
            variant="outline"
            onClick={() => resetCircuitBreakerMutation.mutate()}
            disabled={resetCircuitBreakerMutation.isPending}
            className="flex items-center gap-2 text-red-600 border-red-300 hover:bg-red-50"
          >
            <RefreshCw className="h-4 w-4" />
            {t('resetCircuitBreaker')}
          </Button>
        )}
      </div>

      {/* File Types Information */}
      {showFileTypes && (
        <Card>
          <CardContent className="p-6">
            <FileTypeInfo />
          </CardContent>
        </Card>
      )}

      {/* Processing Statistics */}
      {showStats && processingStats?.data && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-500" />
              {t('aiProcessingStats')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{t('circuitBreakerStatus')}:</span>
                  <div className="flex items-center gap-2">
                    {(() => {
                      const status = getCircuitBreakerStatus();
                      const Icon = status.icon;
                      return (
                        <>
                          <Icon className="h-4 w-4" />
                          <Badge className={cn("text-white", status.color)}>
                            {status.text}
                          </Badge>
                        </>
                      );
                    })()}
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="font-medium">{t('failureCount')}:</span>
                  <Badge variant="outline">
                    {processingStats.data.circuitBreaker.failures}
                  </Badge>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-medium">{t('systemVersion')}:</span>
                  <Badge variant="secondary">
                    {processingStats.data.version}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="font-medium">{t('lastUpdate')}:</span>
                  <span className="text-sm text-gray-500">
                    {new Date(processingStats.data.timestamp).toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            {processingStats.data.circuitBreaker.state !== 'closed' && (
              <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
                <p className="text-sm text-yellow-700 dark:text-yellow-300">
                  <Shield className="h-4 w-4 inline mr-2" />
                  {t('circuitBreakerWarning')}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* File Upload Component */}
      <Card>
        <CardContent className="p-6">
          <FileUploadProgress
            onUpload={handleFileUpload}
            maxFiles={user?.plan === 'pro' ? 100 : 5}
            disabled={uploadMutation.isPending}
          />
        </CardContent>
      </Card>

      {/* Upload Results */}
      {uploadMutation.data && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-green-500" />
              {t('uploadResults')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {uploadMutation.data.summary.total}
                </div>
                <div className="text-sm text-gray-500">{t('totalFiles')}</div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {uploadMutation.data.summary.successful}
                </div>
                <div className="text-sm text-gray-500">{t('successful')}</div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">
                  {uploadMutation.data.summary.failed}
                </div>
                <div className="text-sm text-gray-500">{t('failed')}</div>
              </div>
            </div>

            <Separator />

            <div className="space-y-3">
              {uploadMutation.data.results.map((result, index) => (
                <Card key={result.id} className="bg-gray-50 dark:bg-gray-800">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge 
                            variant={result.status === 'success' ? 'default' : 'destructive'}
                          >
                            {result.status === 'success' ? t('success') : t('failed')}
                          </Badge>
                          <span className="text-sm font-medium">
                            {t('file')} {index + 1}
                          </span>
                        </div>
                        
                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-2">
                          {result.summary}
                        </p>
                        
                        <div className="flex items-center gap-4 text-xs text-gray-500">
                          <span>{t('confidence')}: {Math.round(result.confidence * 100)}%</span>
                          <span>{t('processingTime')}: {formatProcessingTime(result.processingTime)}</span>
                          <span>{t('retries')}: {result.retryAttempts}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}