/**
 * WebSocket Demo Component
 * مكون عرض التواصل الفوري
 */

import { useState, useEffect } from 'react';
import { useWebSocket } from '../hooks/useWebSocket';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { Wifi, WifiOff, Users, MessageCircle, Activity } from 'lucide-react';

interface ChatMessage {
  id: string;
  fileId: string;
  userId: number;
  username: string;
  message: string;
  timestamp: Date;
  type: 'user' | 'assistant';
}

interface Notification {
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  timestamp: Date;
}

export function WebSocketDemo() {
  const webSocket = useWebSocket();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [currentRoom, setCurrentRoom] = useState<string>('');
  const [messageInput, setMessageInput] = useState('');
  const [connectionStats, setConnectionStats] = useState<any>(null);
  const [roomParticipants, setRoomParticipants] = useState<any[]>([]);

  // Register WebSocket event listeners
  useEffect(() => {
    const unsubscribers: (() => void)[] = [];

    // Chat message listener
    unsubscribers.push(
      webSocket.onChatMessage((message: ChatMessage) => {
        setMessages(prev => [...prev, message]);
      })
    );

    // Notification listener
    unsubscribers.push(
      webSocket.onNotification((notification: Notification) => {
        setNotifications(prev => [notification, ...prev.slice(0, 9)]);
      })
    );

    // User joined room listener
    unsubscribers.push(
      webSocket.onUserJoinedRoom((user: any) => {
        setRoomParticipants(prev => [...prev, user]);
      })
    );

    // User left room listener
    unsubscribers.push(
      webSocket.onUserLeftRoom((user: any) => {
        setRoomParticipants(prev => prev.filter(p => p.userId !== user.userId));
      })
    );

    // Analysis progress listener
    unsubscribers.push(
      webSocket.onAnalysisProgress((progress: any) => {
        console.log('تقدم التحليل:', progress);
      })
    );

    return () => {
      unsubscribers.forEach(unsubscribe => unsubscribe());
    };
  }, [webSocket]);

  // Load connection stats
  useEffect(() => {
    const loadStats = async () => {
      const stats = await webSocket.getConnectionStats();
      setConnectionStats(stats);
    };

    if (webSocket.state.isConnected) {
      loadStats();
      const interval = setInterval(loadStats, 5000);
      return () => clearInterval(interval);
    }
  }, [webSocket.state.isConnected, webSocket]);

  const handleJoinRoom = () => {
    if (currentRoom.trim()) {
      webSocket.joinFileRoom(currentRoom);
      setMessages([]); // Clear messages when joining new room
    }
  };

  const handleLeaveRoom = () => {
    if (currentRoom.trim()) {
      webSocket.leaveFileRoom(currentRoom);
      setCurrentRoom('');
      setMessages([]);
      setRoomParticipants([]);
    }
  };

  const handleSendMessage = () => {
    if (messageInput.trim() && currentRoom.trim()) {
      webSocket.sendChatMessage(currentRoom, messageInput.trim());
      setMessageInput('');
    }
  };

  const getStatusColor = () => {
    if (webSocket.state.isConnected) return 'bg-green-500';
    if (webSocket.state.isConnecting) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getStatusText = () => {
    if (webSocket.state.isConnected) return 'متصل';
    if (webSocket.state.isConnecting) return 'جارٍ الاتصال...';
    return 'غير متصل';
  };

  return (
    <div className="container mx-auto p-6 space-y-6" dir="rtl">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-[#002B5B] mb-2">
          🔌 عرض التواصل الفوري
        </h1>
        <p className="text-gray-600">
          نظام WebSocket المتقدم لـ RKN-Terminal AI
        </p>
      </div>

      {/* Connection Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {webSocket.state.isConnected ? (
              <Wifi className="h-5 w-5 text-green-500" />
            ) : (
              <WifiOff className="h-5 w-5 text-red-500" />
            )}
            حالة الاتصال
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${getStatusColor()}`} />
              <span className="font-medium">{getStatusText()}</span>
            </div>
            {webSocket.state.connectionId && (
              <Badge variant="outline" className="font-mono">
                {webSocket.state.connectionId.slice(0, 8)}...
              </Badge>
            )}
            {webSocket.state.error && (
              <Badge variant="destructive">{webSocket.state.error}</Badge>
            )}
          </div>
          
          <div className="mt-4 flex gap-2">
            <Button 
              onClick={webSocket.reconnect}
              disabled={webSocket.state.isConnecting}
              size="sm"
            >
              إعادة الاتصال
            </Button>
            <Button 
              onClick={webSocket.disconnect}
              disabled={!webSocket.state.isConnected}
              variant="outline"
              size="sm"
            >
              قطع الاتصال
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Connection Statistics */}
      {connectionStats && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              إحصائيات الاتصال
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-[#002B5B]">
                  {connectionStats.totalConnections}
                </div>
                <div className="text-sm text-gray-600">إجمالي الاتصالات</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-[#F5C542]">
                  {connectionStats.authenticatedUsers}
                </div>
                <div className="text-sm text-gray-600">المستخدمون المسجلون</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {connectionStats.activeRooms}
                </div>
                <div className="text-sm text-gray-600">الغرف النشطة</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {connectionStats.userConnections}
                </div>
                <div className="text-sm text-gray-600">اتصالات المستخدمين</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Room Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            إدارة الغرف
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-4">
            <Input
              placeholder="معرف الملف (مثال: file-123)"
              value={currentRoom}
              onChange={(e) => setCurrentRoom(e.target.value)}
              disabled={!webSocket.state.isConnected}
              className="flex-1"
            />
            <Button 
              onClick={handleJoinRoom}
              disabled={!webSocket.state.isConnected || !currentRoom.trim()}
            >
              انضمام
            </Button>
            <Button 
              onClick={handleLeaveRoom}
              disabled={!currentRoom}
              variant="outline"
            >
              مغادرة
            </Button>
          </div>
          
          {roomParticipants.length > 0 && (
            <div>
              <p className="text-sm font-medium mb-2">المشاركون في الغرفة:</p>
              <div className="flex flex-wrap gap-2">
                {roomParticipants.map((participant, index) => (
                  <Badge key={index} variant="secondary">
                    {participant.username}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Chat Interface */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="h-5 w-5" />
            المحادثة الفورية
          </CardTitle>
          <CardDescription>
            {currentRoom ? `الغرفة: ${currentRoom}` : 'لم يتم الانضمام لأي غرفة'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-64 w-full border rounded-md p-4 mb-4">
            {messages.length === 0 ? (
              <div className="text-center text-gray-500">
                لا توجد رسائل بعد...
              </div>
            ) : (
              <div className="space-y-3">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`p-3 rounded-lg max-w-sm ${
                      message.type === 'user'
                        ? 'bg-[#002B5B] text-white mr-auto'
                        : 'bg-gray-100 text-gray-900 ml-auto'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-medium text-sm">
                        {message.username}
                      </span>
                      <span className="text-xs opacity-70">
                        {new Date(message.timestamp).toLocaleTimeString('ar-SA')}
                      </span>
                    </div>
                    <p className="text-sm">{message.message}</p>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
          
          <div className="flex gap-2">
            <Input
              placeholder="اكتب رسالتك هنا..."
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              disabled={!webSocket.state.isConnected || !currentRoom}
              className="flex-1"
            />
            <Button 
              onClick={handleSendMessage}
              disabled={!webSocket.state.isConnected || !currentRoom || !messageInput.trim()}
            >
              إرسال
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      {notifications.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>الإشعارات الفورية</CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-32">
              <div className="space-y-2">
                {notifications.map((notification, index) => (
                  <div
                    key={index}
                    className={`p-2 rounded border-l-4 ${
                      notification.type === 'success'
                        ? 'border-green-500 bg-green-50'
                        : notification.type === 'error'
                        ? 'border-red-500 bg-red-50'
                        : notification.type === 'warning'
                        ? 'border-yellow-500 bg-yellow-50'
                        : 'border-blue-500 bg-blue-50'
                    }`}
                  >
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium text-sm">{notification.title}</p>
                        <p className="text-xs text-gray-600">{notification.message}</p>
                      </div>
                      <span className="text-xs text-gray-400">
                        {new Date(notification.timestamp).toLocaleTimeString('ar-SA')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}