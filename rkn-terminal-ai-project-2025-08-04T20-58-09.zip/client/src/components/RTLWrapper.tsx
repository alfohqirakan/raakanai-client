import { useEffect } from 'react';
import { useDirection } from '@/lib/direction';
import { cn } from '@/lib/utils';

interface RTLWrapperProps {
  children: React.ReactNode;
  className?: string;
}

export function RTLWrapper({ children, className }: RTLWrapperProps) {
  const { dir, language } = useDirection();

  useEffect(() => {
    // Set document direction and language
    document.documentElement.dir = dir;
    document.documentElement.lang = language;
    
    // Add RTL-specific classes to body
    const body = document.body;
    if (dir === 'rtl') {
      body.classList.add('rtl');
      body.classList.remove('ltr');
    } else {
      body.classList.add('ltr');
      body.classList.remove('rtl');
    }
    
    // Add language-specific classes
    body.classList.remove('lang-ar', 'lang-en');
    body.classList.add(`lang-${language}`);
    
    return () => {
      // Cleanup on unmount
      body.classList.remove('rtl', 'ltr', 'lang-ar', 'lang-en');
    };
  }, [dir, language]);

  const wrapperClasses = cn(
    'min-h-screen',
    // Font families based on language
    dir === 'rtl' ? 'font-arabic' : 'font-sans',
    // Direction-specific styles
    dir === 'rtl' && 'rtl-layout',
    // Custom className
    className
  );

  return (
    <div 
      dir={dir} 
      lang={language}
      className={wrapperClasses}
      data-direction={dir}
      data-language={language}
    >
      {children}
    </div>
  );
}

// Enhanced RTL-aware component wrapper
export function RTLAware({ 
  children, 
  className, 
  rtlClassName,
  ltrClassName 
}: {
  children: React.ReactNode;
  className?: string;
  rtlClassName?: string;
  ltrClassName?: string;
}) {
  const { dir } = useDirection();
  
  const computedClassName = cn(
    className,
    dir === 'rtl' ? rtlClassName : ltrClassName
  );
  
  return (
    <div className={computedClassName} dir={dir}>
      {children}
    </div>
  );
}

// Direction toggle button component
export function DirectionToggle({ className }: { className?: string }) {
  const { dir, toggleDirection } = useDirection();
  
  return (
    <button
      onClick={toggleDirection}
      className={cn(
        'p-2 rounded-md transition-colors',
        'hover:bg-gray-100 dark:hover:bg-gray-800',
        'focus:outline-none focus:ring-2 focus:ring-blue-500',
        className
      )}
      aria-label={dir === 'rtl' ? 'Switch to English' : 'التبديل للعربية'}
      title={dir === 'rtl' ? 'Switch to English' : 'التبديل للعربية'}
    >
      <span className="text-sm font-medium">
        {dir === 'rtl' ? 'EN' : 'ع'}
      </span>
    </button>
  );
}

// RTL-aware flex container
export function RTLFlex({ 
  children, 
  className,
  reverse = false 
}: {
  children: React.ReactNode;
  className?: string;
  reverse?: boolean;
}) {
  const { dir } = useDirection();
  
  const flexClasses = cn(
    'flex',
    // Apply reverse logic based on direction and reverse prop
    (dir === 'rtl' && !reverse) || (dir === 'ltr' && reverse) 
      ? 'flex-row-reverse' 
      : 'flex-row',
    className
  );
  
  return <div className={flexClasses}>{children}</div>;
}

// RTL-aware text alignment
export function RTLText({ 
  children, 
  className,
  align = 'start' 
}: {
  children: React.ReactNode;
  className?: string;
  align?: 'start' | 'end' | 'center' | 'justify';
}) {
  const { dir } = useDirection();
  
  const getTextAlignClass = () => {
    switch (align) {
      case 'start':
        return dir === 'rtl' ? 'text-right' : 'text-left';
      case 'end':
        return dir === 'rtl' ? 'text-left' : 'text-right';
      case 'center':
        return 'text-center';
      case 'justify':
        return 'text-justify';
      default:
        return dir === 'rtl' ? 'text-right' : 'text-left';
    }
  };
  
  return (
    <div className={cn(getTextAlignClass(), className)}>
      {children}
    </div>
  );
}