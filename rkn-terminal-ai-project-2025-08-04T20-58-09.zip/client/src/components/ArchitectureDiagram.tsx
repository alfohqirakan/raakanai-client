import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Settings, 
  Building2, 
  Search, 
  Shield, 
  ArrowRight,
  Brain,
  Zap
} from 'lucide-react';

interface SystemNode {
  id: string;
  nameAr: string;
  nameEn: string;
  outcome: string;
  outcomeEn: string;
  icon: React.ReactNode;
  status: 'operational' | 'complete' | 'active';
  successRate?: string;
}

const systemNodes: SystemNode[] = [
  {
    id: 'government',
    nameAr: 'الأنظمة الحكومية',
    nameEn: 'Government Systems',
    outcome: 'تحول رقمي متكامل',
    outcomeEn: 'Complete Digital Transformation',
    icon: <Settings className="w-6 h-6" />,
    status: 'operational',
    successRate: '80%'
  },
  {
    id: 'neom',
    nameAr: 'نيوم',
    nameEn: 'NEOM',
    outcome: 'مدن المستقبل',
    outcomeEn: 'Cities of the Future',
    icon: <Building2 className="w-6 h-6" />,
    status: 'complete',
    successRate: '100%'
  },
  {
    id: 'research',
    nameAr: 'البحث الوطني',
    nameEn: 'National Research',
    outcome: 'ابتكار وطني',
    outcomeEn: 'National Innovation',
    icon: <Search className="w-6 h-6" />,
    status: 'operational',
    successRate: '66.7%'
  },
  {
    id: 'infrastructure',
    nameAr: 'البنية التحتية',
    nameEn: 'Infrastructure',
    outcome: 'أمن سيبراني',
    outcomeEn: 'Cybersecurity',
    icon: <Shield className="w-6 h-6" />,
    status: 'active',
    successRate: '100%'
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'operational': return 'bg-green-100 text-green-800 border-green-200';
    case 'complete': return 'bg-blue-100 text-blue-800 border-blue-200';
    case 'active': return 'bg-amber-100 text-amber-800 border-amber-200';
    default: return 'bg-gray-100 text-gray-800 border-gray-200';
  }
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case 'operational': return '🟢';
    case 'complete': return '🔵';
    case 'active': return '🟡';
    default: return '⚪';
  }
};

export default function ArchitectureDiagram() {
  return (
    <div className="w-full max-w-6xl mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-3">
          <Brain className="w-8 h-8 text-amber-600" />
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            راكان AI
          </h1>
          <Zap className="w-8 h-8 text-amber-600" />
        </div>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          نظام الذكاء الاصطناعي السيادي السعودي
        </p>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Saudi Sovereign AI System Architecture
        </p>
      </div>

      {/* Architecture Diagram */}
      <div className="relative">
        {/* Central Rakan AI Node */}
        <div className="flex justify-center mb-12">
          <Card className="w-64 bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 border-2 border-amber-200 dark:border-amber-700 shadow-lg">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center gap-2 mb-3">
                <Brain className="w-8 h-8 text-amber-600" />
                <span className="text-2xl font-bold text-gray-900 dark:text-white">
                  راكان AI
                </span>
              </div>
              <Badge className="bg-green-100 text-green-800 border-green-200">
                🟢 نظام سيادي نشط
              </Badge>
              <div className="mt-3 text-sm text-gray-600 dark:text-gray-300">
                Sovereign AI Core
              </div>
            </CardContent>
          </Card>
        </div>

        {/* System Connections */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {systemNodes.map((node, index) => (
            <div key={node.id} className="relative">
              {/* Connection Line */}
              <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 h-12 w-0.5 bg-gray-300 dark:bg-gray-600"></div>
              
              {/* Input System */}
              <Card className="mb-4 bg-purple-50 dark:bg-purple-900/20 border-purple-200 dark:border-purple-700">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="text-purple-600 dark:text-purple-400">
                      {node.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 dark:text-white">
                        {node.nameAr}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        {node.nameEn}
                      </p>
                    </div>
                    <Badge className={getStatusColor(node.status)}>
                      {getStatusIcon(node.status)} {node.successRate || 'نشط'}
                    </Badge>
                  </div>
                </CardContent>
              </Card>

              {/* Arrow */}
              <div className="flex justify-center my-2">
                <ArrowRight className="w-6 h-6 text-gray-400" />
              </div>

              {/* Output System */}
              <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-700">
                <CardContent className="p-4">
                  <div className="text-center">
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                      {node.outcome}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-300">
                      {node.outcomeEn}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          ))}
        </div>
      </div>

      {/* System Status Summary */}
      <Card className="bg-gradient-to-r from-blue-50 to-green-50 dark:from-blue-900/20 dark:to-green-900/20">
        <CardHeader>
          <CardTitle className="text-center">حالة النظام الإجمالية</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="space-y-2">
              <div className="text-2xl font-bold text-green-600">100%</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">السيادة الرقمية</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-blue-600">80%</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">الحوكمة القانونية</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-amber-600">66.7%</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">الذاكرة الوطنية</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-purple-600">5/8</div>
              <div className="text-sm text-gray-600 dark:text-gray-300">الأنظمة النشطة</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-wrap justify-center gap-4">
        <Button 
          variant="outline" 
          className="bg-white dark:bg-gray-800 border-purple-200 hover:bg-purple-50"
        >
          🔍 عرض التفاصيل التقنية
        </Button>
        <Button 
          variant="outline"
          className="bg-white dark:bg-gray-800 border-green-200 hover:bg-green-50"
        >
          📊 تقرير الأداء
        </Button>
        <Button 
          variant="outline"
          className="bg-white dark:bg-gray-800 border-amber-200 hover:bg-amber-50"
        >
          🛡️ حالة الأمان
        </Button>
        <Button 
          variant="default"
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
        >
          🚀 لوحة التحكم
        </Button>
      </div>
    </div>
  );
}