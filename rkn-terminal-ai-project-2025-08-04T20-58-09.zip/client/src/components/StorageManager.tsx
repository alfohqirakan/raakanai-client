import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from '@/hooks/useTranslation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { 
  Cloud, 
  HardDrive, 
  CheckCircle, 
  AlertTriangle, 
  XCircle,
  Upload,
  Download,
  BarChart3,
  Zap,
  Shield,
  Globe
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface StorageInfo {
  provider: string;
  bucket: string;
  region: string;
  isCloudAvailable: boolean;
  features: {
    signedUrls: boolean;
    publicUrls: boolean;
    metadata: boolean;
    scalability: string;
  };
}

interface StorageHealth {
  status: 'healthy' | 'degraded' | 'unhealthy';
  cloudStorage: boolean;
  localStorage: boolean;
  details: string[];
}

export function StorageManager() {
  const { t, isRTL } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showDetails, setShowDetails] = useState(false);

  // Get storage information
  const { data: storageInfo, isLoading: infoLoading } = useQuery<{ data: StorageInfo }>({
    queryKey: ['/api/storage/info'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Get storage health
  const { data: storageHealth, isLoading: healthLoading, refetch: refetchHealth } = useQuery<{ data: StorageHealth }>({
    queryKey: ['/api/storage/health'],
    refetchInterval: 60000, // Refresh every minute
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'degraded':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'unhealthy':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return <AlertTriangle className="h-5 w-5 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy':
        return 'bg-green-500';
      case 'degraded':
        return 'bg-yellow-500';
      case 'unhealthy':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'healthy':
        return t('healthy');
      case 'degraded':
        return t('degraded');
      case 'unhealthy':
        return t('unhealthy');
      default:
        return t('unknown');
    }
  };

  if (infoLoading || healthLoading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500 mx-auto mb-4"></div>
            <p className="text-sm text-gray-500">{t('loading')}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={cn("w-full max-w-4xl mx-auto space-y-6", isRTL && "rtl")}>
      {/* Storage Overview */}
      <Card className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Cloud className="h-6 w-6 text-purple-600" />
            {t('storageManagement')}
            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
              {storageInfo?.data?.provider || 'Unknown'}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Cloud Storage Status */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Cloud className="h-5 w-5 text-blue-500" />
                <span className="font-medium">{t('cloudStorage')}</span>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-white",
                    storageHealth?.data?.cloudStorage ? "bg-green-500" : "bg-red-500"
                  )}
                >
                  {storageHealth?.data?.cloudStorage ? t('available') : t('unavailable')}
                </Badge>
              </div>
              
              {storageInfo?.data?.isCloudAvailable && (
                <div className="text-sm text-gray-600 space-y-1">
                  <div>Region: {storageInfo.data.region}</div>
                  <div>Bucket: {storageInfo.data.bucket}</div>
                </div>
              )}
            </div>

            {/* Local Storage Status */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <HardDrive className="h-5 w-5 text-gray-500" />
                <span className="font-medium">{t('localStorage')}</span>
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-white",
                    storageHealth?.data?.localStorage ? "bg-green-500" : "bg-red-500"
                  )}
                >
                  {storageHealth?.data?.localStorage ? t('available') : t('unavailable')}
                </Badge>
              </div>
              
              <div className="text-sm text-gray-600">
                {t('localStorageDescription')}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Storage Health Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            {getStatusIcon(storageHealth?.data?.status || 'unknown')}
            {t('storageHealth')}
            <Badge 
              className={cn("text-white", getStatusColor(storageHealth?.data?.status || 'unknown'))}
            >
              {getStatusText(storageHealth?.data?.status || 'unknown')}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Health Details */}
          {storageHealth?.data?.details && (
            <div className="space-y-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowDetails(!showDetails)}
                className="flex items-center gap-2"
              >
                <BarChart3 className="h-4 w-4" />
                {showDetails ? t('hideDetails') : t('showDetails')}
              </Button>

              {showDetails && (
                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg space-y-2">
                  {storageHealth.data.details.map((detail, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      {detail}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Storage Features */}
          {storageInfo?.data?.features && (
            <div className="space-y-3">
              <h4 className="font-medium">{t('availableFeatures')}</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="flex items-center gap-2">
                  <Upload className="h-4 w-4" />
                  <span className="text-sm">{t('signedUrls')}</span>
                  {storageInfo.data.features.signedUrls ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-500" />
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  <span className="text-sm">{t('publicUrls')}</span>
                  {storageInfo.data.features.publicUrls ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-500" />
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4" />
                  <span className="text-sm">{t('metadata')}</span>
                  {storageInfo.data.features.metadata ? (
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  ) : (
                    <XCircle className="h-4 w-4 text-red-500" />
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  <span className="text-sm">{t('scalability')}</span>
                  <Badge variant="outline" className="text-xs">
                    {storageInfo.data.features.scalability}
                  </Badge>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => refetchHealth()}
              className="flex items-center gap-2"
            >
              <CheckCircle className="h-4 w-4" />
              {t('refreshHealth')}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Storage Recommendations */}
      {storageHealth?.data?.status !== 'healthy' && (
        <Card className="border-yellow-300 bg-yellow-50 dark:bg-yellow-900/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-yellow-700 dark:text-yellow-300">
              <AlertTriangle className="h-5 w-5" />
              {t('storageRecommendations')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {!storageHealth?.data?.cloudStorage && (
              <div className="text-sm text-yellow-700 dark:text-yellow-300">
                • {t('cloudStorageRecommendation')}
              </div>
            )}
            
            {!storageHealth?.data?.localStorage && (
              <div className="text-sm text-yellow-700 dark:text-yellow-300">
                • {t('localStorageRecommendation')}
              </div>
            )}
            
            {storageHealth?.data?.status === 'unhealthy' && (
              <div className="text-sm text-yellow-700 dark:text-yellow-300">
                • {t('criticalStorageWarning')}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}