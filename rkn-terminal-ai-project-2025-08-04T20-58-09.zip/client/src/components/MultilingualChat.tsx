import { useState, useRef } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const SUPPORTED_LANGUAGES = {
  "ar": "العربية",
  "en": "English", 
  "fr": "Français",
  "es": "Español",
  "de": "Deutsch",
  "ru": "Русский",
  "zh": "中文",
  "ja": "日本語",
  "ko": "한국어",
  "tr": "Türkçe",
  "pt": "Português",
  "hi": "हिन्दी",
  "it": "Italiano",
  "id": "Bahasa Indonesia",
  "fa": "فارسی"
};

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  lang: string;
  timestamp: Date;
}

export default function MultilingualChat() {
  const { user } = useAuth();
  const { toast } = useToast();
  const messageRef = useRef<HTMLTextAreaElement>(null);
  const [selectedLang, setSelectedLang] = useState<string>("ar");
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);

  const sendMessage = async () => {
    if (!messageRef.current || !messageRef.current.value.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى كتابة رسالة للإرسال",
        variant: "destructive"
      });
      return;
    }

    const messageContent = messageRef.current.value;
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: messageContent,
      lang: selectedLang,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    messageRef.current.value = '';
    setIsLoading(true);

    try {
      const response = await fetch('/api/multilingual/speak', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token') || ''}`
        },
        credentials: 'include',
        body: JSON.stringify({
          message: messageContent,
          lang: selectedLang
        })
      });

      const data = await response.json();

      if (data.status === '✅ success') {
        const aiMessage: ChatMessage = {
          id: (Date.now() + 1).toString(),
          role: 'assistant',
          content: data.data.reply,
          lang: selectedLang,
          timestamp: new Date()
        };
        setMessages(prev => [...prev, aiMessage]);
        
        toast({
          title: "تم الرد",
          description: `تم الرد باللغة ${SUPPORTED_LANGUAGES[selectedLang as keyof typeof SUPPORTED_LANGUAGES]}`
        });
      } else {
        throw new Error(data.message || 'فشل في الحصول على الرد');
      }
    } catch (error) {
      console.error('Multilingual chat error:', error);
      toast({
        title: "خطأ في المحادثة",
        description: "فشل في الحصول على الرد. يرجى المحاولة مرة أخرى",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const translateMessage = async (text: string, toLang: string) => {
    try {
      const response = await fetch('/api/multilingual/translate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token') || ''}`
        },
        credentials: 'include',
        body: JSON.stringify({
          text,
          fromLang: 'auto',
          toLang
        })
      });

      const data = await response.json();
      
      if (data.status === '✅ success') {
        return data.data.translatedText;
      }
    } catch (error) {
      console.error('Translation error:', error);
    }
    return text;
  };

  const clearChat = () => {
    setMessages([]);
    toast({
      title: "تم المسح",
      description: "تم مسح سجل المحادثة"
    });
  };

  return (
    <Card className="h-full bg-gradient-to-br from-[#001e3c] to-[#000d1a] border-yellow-500 text-white">
      <CardHeader className="border-b border-yellow-500">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-3 rtl:space-x-reverse">
            <div className="w-8 h-8 bg-yellow-500 rounded-lg flex items-center justify-center">
              <span className="text-black text-xl">🌍</span>
            </div>
            <span>المحادثة متعددة اللغات</span>
          </div>
          <Button 
            onClick={clearChat}
            variant="outline" 
            size="sm"
            className="border-yellow-500 text-yellow-300 hover:bg-yellow-500 hover:text-black"
          >
            مسح المحادثة
          </Button>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex flex-col h-full p-4 space-y-4">
        {/* Language Selection */}
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          <label className="text-yellow-300 font-medium">اللغة:</label>
          <Select value={selectedLang} onValueChange={setSelectedLang}>
            <SelectTrigger className="w-48 bg-[#0a1929] border-yellow-500 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-[#0a1929] border-yellow-500">
              {Object.entries(SUPPORTED_LANGUAGES).map(([code, name]) => (
                <SelectItem key={code} value={code} className="text-white hover:bg-yellow-500 hover:text-black">
                  {name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Messages Display */}
        <div className="flex-1 overflow-y-auto space-y-3 bg-black/20 rounded-lg p-4 min-h-[300px]">
          {messages.length === 0 ? (
            <div className="text-center text-gray-400 py-8">
              <div className="text-4xl mb-4">💬</div>
              <p>مرحباً {user?.username || 'مستخدم'}!</p>
              <p>ابدأ محادثة بأي لغة تريدها</p>
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.role === 'user'
                      ? 'bg-yellow-500 text-black'
                      : 'bg-gray-700 text-white'
                  }`}
                >
                  <div className="text-sm opacity-75 mb-1">
                    {message.role === 'user' ? 'أنت' : 'راكان AI'} • {SUPPORTED_LANGUAGES[message.lang as keyof typeof SUPPORTED_LANGUAGES]}
                  </div>
                  <div className="whitespace-pre-wrap">{message.content}</div>
                  <div className="text-xs opacity-60 mt-1">
                    {message.timestamp.toLocaleTimeString('ar-SA')}
                  </div>
                </div>
              </div>
            ))
          )}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-gray-700 text-white p-3 rounded-lg">
                <div className="flex items-center space-x-2 rtl:space-x-reverse">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-yellow-500"></div>
                  <span>جاري الكتابة...</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Message Input */}
        <div className="space-y-3">
          <Textarea
            ref={messageRef}
            placeholder={`اكتب رسالتك باللغة ${SUPPORTED_LANGUAGES[selectedLang as keyof typeof SUPPORTED_LANGUAGES]}...`}
            className="bg-[#0a1929] border-yellow-500 text-white placeholder-gray-400 resize-none"
            rows={3}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && e.ctrlKey) {
                sendMessage();
              }
            }}
          />
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-400">
              Ctrl + Enter للإرسال
            </span>
            <Button
              onClick={sendMessage}
              disabled={isLoading}
              className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold"
            >
              {isLoading ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-black"></div>
              ) : (
                'إرسال'
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}