import { Button } from '@/components/ui/button';
import { useTranslation } from '@/hooks/useTranslation';

export function LanguageSwitcher() {
  const { changeLanguage, currentLanguage } = useTranslation();

  const toggleLanguage = () => {
    const newLang = currentLanguage === 'ar' ? 'en' : 'ar';
    changeLanguage(newLang);
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleLanguage}
      className="text-gray-300 hover:text-white hover:bg-gray-700 transition-colors"
    >
      {currentLanguage === 'ar' ? 'EN' : 'عربي'}
    </Button>
  );
}