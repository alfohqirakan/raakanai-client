import { useQuery } from "@tanstack/react-query";
import type { StatsResponse } from "@shared/types";

export default function AIInsights() {
  const { data: stats, isLoading } = useQuery<StatsResponse>({
    queryKey: ["/api/stats"],
  });

  if (isLoading) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-semibold mb-4">رؤى الذكاء الاصطناعي</h3>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-charcoal border border-gray-600 rounded-xl p-6 animate-pulse">
            <div className="h-4 bg-gray-700 rounded mb-4"></div>
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-3 bg-gray-700 rounded"></div>
              ))}
            </div>
          </div>
          <div className="bg-charcoal border border-gray-600 rounded-xl p-6 animate-pulse">
            <div className="h-4 bg-gray-700 rounded mb-4"></div>
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-3 bg-gray-700 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </section>
    );
  }

  const fileTypes = stats?.fileTypes || {};
  const totalFiles = stats?.totalFiles || 0;

  return (
    <section className="mb-8">
      <h3 className="text-xl font-semibold mb-4">رؤى الذكاء الاصطناعي</h3>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Analysis Summary */}
        <div className="bg-charcoal border border-gray-600 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-ai-purple/20 rounded-lg flex items-center justify-center">
              <i className="fas fa-chart-pie text-ai-purple"></i>
            </div>
            <h4 className="font-semibold">ملخص التحليل</h4>
          </div>
          <div className="space-y-3">
            {Object.entries(fileTypes).map(([type, count]) => {
              const percentage = totalFiles > 0 ? (count as number / totalFiles) * 100 : 0;
              const getTypeInfo = (type: string) => {
                switch (type) {
                  case 'application':
                    return { label: 'ملفات PDF ومستندات', color: 'bg-red-500' };
                  case 'image':
                    return { label: 'صور', color: 'bg-green-500' };
                  case 'text':
                    return { label: 'مستندات نصية', color: 'bg-blue-500' };
                  default:
                    return { label: type, color: 'bg-gray-500' };
                }
              };

              const typeInfo = getTypeInfo(type);

              return (
                <div key={type} className="flex justify-between items-center">
                  <span className="text-gray-400">{typeInfo.label}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-2 bg-gray-700 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${typeInfo.color} rounded-full transition-all duration-500`}
                        style={{ width: `${percentage}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium">{Math.round(percentage)}%</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-charcoal border border-gray-600 rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-electric-blue/20 rounded-lg flex items-center justify-center">
              <i className="fas fa-history text-electric-blue"></i>
            </div>
            <h4 className="font-semibold">النشاط الحديث</h4>
          </div>
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-success/20 rounded-full flex items-center justify-center flex-shrink-0">
                <i className="fas fa-check text-success text-xs"></i>
              </div>
              <div className="flex-1">
                <p className="text-sm">تم تحليل {stats?.analyzedFiles || 0} ملف بنجاح</p>
                <p className="text-xs text-gray-500">منذ بدء التشغيل</p>
              </div>
            </div>
            {stats?.processingFiles > 0 && (
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-warning/20 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-clock text-warning text-xs"></i>
                </div>
                <div className="flex-1">
                  <p className="text-sm">{stats.processingFiles} ملف قيد المعالجة</p>
                  <p className="text-xs text-gray-500">جاري التحليل</p>
                </div>
              </div>
            )}
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-electric-blue/20 rounded-full flex items-center justify-center flex-shrink-0">
                <i className="fas fa-brain text-electric-blue text-xs"></i>
              </div>
              <div className="flex-1">
                <p className="text-sm">النظام جاهز للتحليل</p>
                <p className="text-xs text-gray-500">الذكاء الاصطناعي متاح</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
