import { useQuery } from "@tanstack/react-query";
import type { StatsResponse } from "@shared/types";

export default function Sidebar() {
  const { data: stats } = useQuery<StatsResponse>({
    queryKey: ["/api/stats"],
  });

  return (
    <aside className="w-64 bg-charcoal border-l border-gray-700 flex-shrink-0 hidden lg:block">
      <div className="p-6">
        {/* Official RKN-Terminal AI Logo */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 bg-gradient-to-br from-royal-blue to-bright-gold rounded-xl flex items-center justify-center royal-glow">
            <svg
              width="24"
              height="24"
              viewBox="0 0 32 32"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="falcon-animate"
            >
              <path
                d="M16 4L20 8L18 12L22 14L20 18L16 16L12 18L10 14L14 12L12 8L16 4Z"
                fill="#FFFFFF"
              />
              <circle cx="18" cy="10" r="1" fill="#F5C542" className="gold-pulse" />
              <circle cx="14" cy="10" r="1" fill="#F5C542" className="gold-pulse" />
            </svg>
          </div>
          <div>
            <h1 className="text-xl font-kufi font-bold text-royal-blue">RKN-Terminal AI</h1>
            <p className="text-xs text-bright-gold font-space-grotesk">راكان الذكاء السيادي</p>
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="space-y-2">
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl bg-electric-blue/20 text-electric-blue border border-electric-blue/30 transition-all hover:bg-electric-blue/30">
            <i className="fas fa-home w-5"></i>
            <span>الرئيسية</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-gray-700/50 transition-all">
            <i className="fas fa-upload w-5"></i>
            <span>رفع الملفات</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-gray-700/50 transition-all">
            <i className="fas fa-folder w-5"></i>
            <span>إدارة الملفات</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-gray-700/50 transition-all">
            <i className="fas fa-robot w-5"></i>
            <span>الذكاء الاصطناعي</span>
          </a>
          <a href="/code-playground" className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-gray-700/50 transition-all hover:text-ai-gold">
            <i className="fas fa-code w-5"></i>
            <span>محرر الأكواد</span>
          </a>
          <a href="/monitoring" className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-gray-700/50 transition-all">
            <i className="fas fa-chart-line w-5"></i>
            <span>لوحة المراقبة</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-gray-700/50 transition-all">
            <i className="fas fa-chart-bar w-5"></i>
            <span>التحليلات</span>
          </a>
          <a href="#" className="flex items-center gap-3 px-4 py-3 rounded-xl text-gray-300 hover:bg-gray-700/50 transition-all">
            <i className="fas fa-cog w-5"></i>
            <span>الإعدادات</span>
          </a>
        </nav>

        {/* Quick Stats */}
        <div className="mt-8 space-y-4">
          <div className="bg-gray-800/50 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">الملفات المحفوظة</span>
              <span className="text-lg font-bold text-success">
                {stats?.totalFiles || 0}
              </span>
            </div>
          </div>
          <div className="bg-gray-800/50 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-400">العمليات اليوم</span>
              <span className="text-lg font-bold text-electric-blue">
                {stats?.todayOperations || 0}
              </span>
            </div>
          </div>
        </div>
        {/* Copyright Footer */}
        <div className="mt-auto p-3 border-t border-gray-700">
          <div className="bg-gradient-to-r from-[#002B5B] to-[#F5C542] p-3 rounded-lg text-center">
            <div className="text-white font-bold text-xs leading-tight">
              برمجة وتصميم
            </div>
            <div className="text-white font-bold text-sm leading-tight">
              المهندس السعودي
            </div>
            <div className="text-white font-bold text-base leading-tight">
              راكان قاسم الفهيقي
            </div>
            <div className="text-white text-xs mt-1 opacity-80">
              حقوق الملكية محفوظة © {new Date().getFullYear()}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
