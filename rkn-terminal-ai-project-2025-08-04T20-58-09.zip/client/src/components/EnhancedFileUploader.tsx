import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { formatFileSize } from '@/lib/fileUtils';
import { useTranslation } from '@/hooks/useTranslation';
import type { AxiosProgressEvent } from 'axios';

interface UploadProgress {
  [key: string]: number;
}

interface FileWithProgress {
  file: File;
  id: string;
  progress: number;
  status: 'uploading' | 'success' | 'error';
  error?: string;
}

export function EnhancedFileUploader() {
  const [uploadingFiles, setUploadingFiles] = useState<FileWithProgress[]>([]);
  const { toast } = useToast();
  const { user } = useAuth();
  const { t } = useTranslation();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async ({ files }: { files: File[] }) => {
      const formData = new FormData();
      files.forEach(file => {
        formData.append('files', file);
      });

      return axios.post('/api/files/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (progressEvent: AxiosProgressEvent) => {
          const percent = Math.round(
            (progressEvent.loaded * 100) / (progressEvent.total || 1)
          );
          
          // Update progress for all files (simplified approach)
          setUploadingFiles(prev => 
            prev.map(file => 
              file.status === 'uploading' 
                ? { ...file, progress: percent }
                : file
            )
          );
        },
      });
    },
    onSuccess: (response) => {
      const data = response.data;
      
      if (data.status === '✅ success') {
        setUploadingFiles(prev => 
          prev.map(file => ({ 
            ...file, 
            status: 'success' as const, 
            progress: 100 
          }))
        );

        toast({
          title: t('uploadSuccess'),
          description: data.message || `${t('uploaded')} ${data.data.files.length} ${t('filesCount')} ${t('successfully')}`,
        });

        // Clear uploading files after success
        setTimeout(() => setUploadingFiles([]), 2000);
        
        // Refresh files list
        queryClient.invalidateQueries({ queryKey: ['/api/files'] });
      } else {
        throw new Error(data.message || 'فشل في رفع الملفات');
      }
    },
    onError: (error: any) => {
      const errorMessage = error.response?.data?.message || error.message || 'فشل في رفع الملفات';
      
      setUploadingFiles(prev => 
        prev.map(file => ({ 
          ...file, 
          status: 'error' as const, 
          error: errorMessage 
        }))
      );

      toast({
        title: t('errorUpload'),
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (!user) {
      toast({
        title: t('loginRequired'),
        description: t('mustLoginToUpload'),
        variant: "destructive",
      });
      return;
    }

    // Check file size limits
    const oversizedFiles = acceptedFiles.filter(file => file.size > 50 * 1024 * 1024);
    if (oversizedFiles.length > 0) {
      toast({
        title: t('fileTooBig'),
        description: `${t('maxFileSize50MB')}. ${t('rejectedFiles')}: ${oversizedFiles.map(f => f.name).join(', ')}`,
        variant: "destructive",
      });
      return;
    }

    // Check upload limits
    const uploadLimit = user.plan === 'pro' ? 100 : 5;
    const remainingUploads = uploadLimit - (user.uploadCount || 0);
    
    if (acceptedFiles.length > remainingUploads) {
      toast({
        title: "تجاوز حد الرفع",
        description: `يمكنك رفع ${remainingUploads} ملف فقط. ترقية لخطة احترافية للمزيد`,
        variant: "destructive",
      });
      return;
    }

    // Prepare files for upload
    const filesToUpload = acceptedFiles.map(file => ({
      file,
      id: `${Date.now()}-${Math.random()}`,
      progress: 0,
      status: 'uploading' as const,
    }));

    setUploadingFiles(filesToUpload);
    uploadMutation.mutate({ files: acceptedFiles });
  }, [user, uploadMutation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    multiple: true,
    maxFiles: 10,
    accept: {
      'image/*': ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg'],
      'application/pdf': ['.pdf'],
      'text/*': ['.txt', '.csv'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'application/vnd.ms-excel': ['.xls'],
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'],
      'application/json': ['.json'],
      'text/javascript': ['.js'],
      'application/javascript': ['.js'],
      'text/typescript': ['.ts'],
      'text/html': ['.html'],
      'text/css': ['.css'],
      'application/zip': ['.zip'],
      'application/x-rar-compressed': ['.rar'],
      'application/x-7z-compressed': ['.7z'],
    },
  });

  const clearCompletedUploads = () => {
    setUploadingFiles(prev => prev.filter(file => file.status === 'uploading'));
  };

  return (
    <div className="space-y-6">
      {/* Upload Zone */}
      <div
        {...getRootProps()}
        className={`
          border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer
          ${isDragActive 
            ? 'border-electric-blue bg-electric-blue/10' 
            : 'border-gray-600 hover:border-electric-blue/50 hover:bg-gray-800/50'
          }
        `}
      >
        <input {...getInputProps()} />
        <div className="space-y-4">
          <div className="w-16 h-16 bg-gradient-to-br from-electric-blue to-ai-purple rounded-2xl flex items-center justify-center mx-auto">
            <i className="fas fa-cloud-upload-alt text-2xl text-white"></i>
          </div>
          
          {isDragActive ? (
            <div>
              <h3 className="text-xl font-semibold text-electric-blue">أسقط الملفات هنا</h3>
              <p className="text-gray-400">سيتم رفعها تلقائياً</p>
            </div>
          ) : (
            <div>
              <h3 className="text-xl font-semibold mb-2">اسحب وأسقط الملفات هنا</h3>
              <p className="text-gray-400 mb-4">أو انقر لاختيار الملفات</p>
              <Button variant="outline" className="border-electric-blue text-electric-blue hover:bg-electric-blue hover:text-white">
                اختر ملفات
              </Button>
            </div>
          )}
          
          <div className="text-sm text-gray-500">
            <p>الأنواع المدعومة: الصور، المستندات، الأكواد، الأرشيف</p>
            <p>الحد الأقصى: 50 ميجابايت لكل ملف • {user?.plan === 'pro' ? '100' : '5'} ملف للحساب</p>
            {user && (
              <p className="text-electric-blue">
                استخدمت {user.uploadCount || 0} من {user.plan === 'pro' ? '100' : '5'} ملف
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Upload Progress */}
      {uploadingFiles.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-lg font-semibold">حالة الرفع</h4>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={clearCompletedUploads}
              className="text-xs"
            >
              مسح المكتملة
            </Button>
          </div>
          
          <div className="space-y-3">
            {uploadingFiles.map((fileItem) => (
              <div 
                key={fileItem.id} 
                className="bg-charcoal rounded-lg p-4 border border-gray-700"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className={`
                      w-8 h-8 rounded-full flex items-center justify-center text-sm
                      ${fileItem.status === 'success' ? 'bg-green-500' : 
                        fileItem.status === 'error' ? 'bg-red-500' : 'bg-electric-blue'}
                    `}>
                      {fileItem.status === 'success' ? '✓' : 
                       fileItem.status === 'error' ? '✗' : 
                       <i className="fas fa-spinner animate-spin"></i>}
                    </div>
                    <div>
                      <p className="font-medium truncate max-w-xs">{fileItem.file.name}</p>
                      <p className="text-sm text-gray-400">{formatFileSize(fileItem.file.size)}</p>
                    </div>
                  </div>
                  
                  <div className="text-sm">
                    {fileItem.status === 'uploading' && `${fileItem.progress}%`}
                    {fileItem.status === 'success' && <span className="text-green-400">مكتمل</span>}
                    {fileItem.status === 'error' && <span className="text-red-400">فشل</span>}
                  </div>
                </div>
                
                {fileItem.status === 'uploading' && (
                  <Progress value={fileItem.progress} className="h-2" />
                )}
                
                {fileItem.status === 'error' && fileItem.error && (
                  <p className="text-red-400 text-sm mt-2">{fileItem.error}</p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}