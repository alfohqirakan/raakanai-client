import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const demoResponses = {
  fr: {
    message: "اكتب لي مقدمة برمجية عن الذكاء الاصطناعي",
    response: `**Intelligence Artificielle - Introduction à la Programmation**

L'intelligence artificielle est un domaine fascinant qui révolutionne notre approche du développement logiciel. Cette technologie transforme la façon dont nous concevons, créons et optimisons nos applications.

**Concepts Fondamentaux :**

1. **Apprentissage Automatique (Machine Learning)** : Les algorithmes s'adaptent et s'améliorent automatiquement grâce aux données d'entraînement, permettant aux systèmes de faire des prédictions précises.

2. **Réseaux de Neurones Artificiels** : Inspirés du fonctionnement du cerveau humain, ces modèles traitent l'information à travers des couches interconnectées pour résoudre des problèmes complexes.

3. **Traitement du Langage Naturel (NLP)** : Cette branche permet aux machines de comprendre, interpréter et générer du langage humain de manière contextuelle et naturelle.

**Écosystème Technologique :**
- **Python** : TensorFlow, PyTorch, scikit-learn, Keras
- **JavaScript** : TensorFlow.js, ML5.js, Brain.js
- **Plateformes Cloud** : OpenAI GPT, Google AI, Azure Cognitive Services
- **Frameworks** : Hugging Face Transformers, FastAPI, LangChain

**Applications Concrètes :**
- Assistants conversationnels intelligents et chatbots
- Reconnaissance d'images et vision par ordinateur avancée
- Systèmes de recommandation personnalisés
- Analyse prédictive et automatisation des décisions
- Génération de contenu créatif et technique

L'IA redéfinit les paradigmes de développement, offrant aux programmeurs des outils puissants pour créer des solutions innovantes et intelligentes qui s'adaptent aux besoins des utilisateurs.`
  },
  en: {
    message: "اكتب لي مقدمة برمجية عن الذكاء الاصطناعي",
    response: `**Artificial Intelligence - Programming Introduction**

Artificial Intelligence (AI) represents one of the most fascinating technological revolutions of our time. In programming, AI involves creating systems capable of mimicking human intelligence to solve complex problems.

**Core Concepts:**

1. **Machine Learning**: Algorithms learn from data to make predictions or decisions.

2. **Neural Networks**: Inspired by the human brain, these models process information in interconnected ways.

3. **Natural Language Processing (NLP)**: Enables machines to understand and generate human language.

**Key Technologies:**
- Python with TensorFlow, PyTorch, scikit-learn
- JavaScript with TensorFlow.js
- Frameworks like OpenAI GPT, Hugging Face Transformers

**Practical Applications:**
- Virtual assistants and chatbots
- Image recognition and computer vision
- Recommendation systems
- Predictive analytics and automated decision-making

AI is transforming how we develop software, offering infinite possibilities for innovation and intelligent automation.`
  },
  es: {
    message: "اكتب لي مقدمة برمجية عن الذكاء الاصطناعي",
    response: `**Inteligencia Artificial - Introducción a la Programación**

La Inteligencia Artificial (IA) representa una de las revoluciones tecnológicas más fascinantes de nuestro tiempo. En programación, la IA consiste en crear sistemas capaces de imitar la inteligencia humana para resolver problemas complejos.

**Conceptos Fundamentales:**

1. **Aprendizaje Automático (Machine Learning)**: Los algoritmos aprenden de los datos para hacer predicciones o tomar decisiones.

2. **Redes Neuronales**: Inspiradas en el cerebro humano, estos modelos procesan información de manera interconectada.

3. **Procesamiento de Lenguaje Natural (PLN)**: Permite a las máquinas entender y generar lenguaje humano.

**Tecnologías Clave:**
- Python con TensorFlow, PyTorch, scikit-learn
- JavaScript con TensorFlow.js
- Frameworks como OpenAI GPT, Hugging Face Transformers

**Aplicaciones Prácticas:**
- Asistentes virtuales y chatbots
- Reconocimiento de imágenes y visión por computadora
- Sistemas de recomendación
- Análisis predictivo y toma de decisiones automatizada

La IA está transformando la forma en que desarrollamos software, ofreciendo posibilidades infinitas de innovación y automatización inteligente.`
  }
};

export default function MultilingualDemo() {
  const [selectedDemo, setSelectedDemo] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  const runDemo = async (lang: string) => {
    setSelectedDemo('');
    setIsLoading(true);
    
    // Simulate API delay
    setTimeout(() => {
      setSelectedDemo(lang);
      setIsLoading(false);
    }, 2000);
  };

  return (
    <Card className="h-full bg-gradient-to-br from-[#001e3c] to-[#000d1a] border-yellow-500 text-white">
      <CardHeader className="border-b border-yellow-500">
        <CardTitle className="flex items-center space-x-3 rtl:space-x-reverse">
          <div className="w-8 h-8 bg-yellow-500 rounded-lg flex items-center justify-center">
            <span className="text-black text-xl">🧪</span>
          </div>
          <span>عرض توضيحي للنظام متعدد اللغات</span>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex flex-col h-full p-4 space-y-4">
        <div className="bg-black/20 rounded-lg p-4">
          <h3 className="text-yellow-300 font-bold mb-2">طلبك الأصلي:</h3>
          <div className="bg-yellow-500 text-black p-3 rounded-lg mb-3">
            <strong>الرسالة:</strong> "اكتب لي مقدمة برمجية عن الذكاء الاصطناعي"<br/>
            <strong>اللغة المطلوبة:</strong> "fr" (Français)<br/>
            <strong>ردك:</strong> "L'intelligence artificielle est un domaine fascinant..."
          </div>
          
          <div className="grid grid-cols-3 gap-3">
            <Button 
              onClick={() => runDemo('fr')}
              disabled={isLoading}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              🇫🇷 Français
            </Button>
            <Button 
              onClick={() => runDemo('en')}
              disabled={isLoading}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              🇺🇸 English
            </Button>
            <Button 
              onClick={() => runDemo('es')}
              disabled={isLoading}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              🇪🇸 Español
            </Button>
          </div>
        </div>

        <div className="flex-1 bg-black/20 rounded-lg p-4 overflow-y-auto">
          {isLoading && (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-500"></div>
              <span className="ml-3">جاري معالجة الطلب بالذكاء الاصطناعي...</span>
            </div>
          )}
          
          {selectedDemo && !isLoading && (
            <div className="space-y-4">
              <div className="border-l-4 border-yellow-500 pl-4">
                <h4 className="text-yellow-300 font-bold">
                  استجابة الذكاء الاصطناعي باللغة {selectedDemo === 'fr' ? 'الفرنسية' : selectedDemo === 'en' ? 'الإنجليزية' : 'الإسبانية'}:
                </h4>
              </div>
              <div className="bg-gray-800 p-4 rounded-lg text-white whitespace-pre-line">
                {demoResponses[selectedDemo as keyof typeof demoResponses].response}
              </div>
              <div className="text-sm text-gray-400">
                ✅ تم إنشاء المحتوى بنجاح باستخدام GPT-4o
              </div>
            </div>
          )}
          
          {!selectedDemo && !isLoading && (
            <div className="text-center text-gray-400 py-8">
              <div className="text-4xl mb-4">🌍</div>
              <p>اختر لغة لمشاهدة العرض التوضيحي</p>
              <p className="text-sm mt-2">سيتم إنشاء مقدمة برمجية عن الذكاء الاصطناعي باللغة المختارة</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}