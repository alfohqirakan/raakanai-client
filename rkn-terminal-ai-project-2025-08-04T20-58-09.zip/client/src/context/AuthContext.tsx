import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';

interface User {
  id: string;
  username: string;
  email?: string;
  displayName?: string;
  avatar?: string;
  provider?: string;
  plan: string;
  uploadCount: number;
  createdAt: Date;
}

interface AuthContextType {
  currentUser: User | null;
  loginWithGoogle: () => Promise<void>;
  loginWithCredentials: (username: string, password: string) => Promise<void>;
  register: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // التحقق من حالة المصادقة عند تحميل التطبيق
  useEffect(() => {
    const initializeAuth = async () => {
      try {
        const response = await fetch('/api/auth/me', {
          credentials: 'include'
        });
        
        if (response.ok) {
          const data = await response.json();
          if (data.status === '✅ success' && data.user) {
            setCurrentUser(data.user);
          }
        }
      } catch (error) {
        console.error('فشل جلب بيانات المستخدم:', error);
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();
  }, []);

  // تسجيل الدخول بالبيانات التقليدية
  const loginWithCredentials = async (username: string, password: string) => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username, password })
      });

      const data = await response.json();
      
      if (data.status === '✅ success' && data.user) {
        setCurrentUser(data.user);
        toast({
          title: "تم تسجيل الدخول بنجاح",
          description: `أهلاً وسهلاً ${data.user.displayName || data.user.username}`,
        });
        navigate('/');
      } else {
        throw new Error(data.message || 'فشل تسجيل الدخول');
      }
    } catch (error: any) {
      toast({
        title: "خطأ في تسجيل الدخول",
        description: error.message || "تأكد من اسم المستخدم وكلمة المرور",
        variant: "destructive",
      });
      throw error;
    }
  };

  // إنشاء حساب جديد
  const register = async (username: string, password: string) => {
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ username, password })
      });

      const data = await response.json();
      
      if (data.status === '✅ success' && data.user) {
        setCurrentUser(data.user);
        toast({
          title: "تم إنشاء الحساب بنجاح",
          description: `مرحباً بك في منصة راكان AI، ${data.user.username}`,
        });
        navigate('/');
      } else {
        throw new Error(data.message || 'فشل إنشاء الحساب');
      }
    } catch (error: any) {
      toast({
        title: "خطأ في إنشاء الحساب",
        description: error.message || "تأكد من البيانات المدخلة",
        variant: "destructive",
      });
      throw error;
    }
  };

  // تسجيل الدخول مع Google
  const loginWithGoogle = async () => {
    try {
      // فتح نافذة منبثقة لتسجيل الدخول مع Google
      const width = 500;
      const height = 600;
      const left = window.screen.width / 2 - width / 2;
      const top = window.screen.height / 2 - height / 2;
      
      const loginWindow = window.open(
        '/api/auth/google',
        'google-login',
        `width=${width},height=${height},top=${top},left=${left},scrollbars=yes,resizable=yes`
      );
      
      if (!loginWindow) {
        throw new Error('تم حظر النوافذ المنبثقة. يرجى السماح بالنوافذ المنبثقة والمحاولة مرة أخرى.');
      }

      // مراقبة النافذة المنبثقة
      const checkWindow = setInterval(async () => {
        try {
          if (loginWindow.closed) {
            clearInterval(checkWindow);
            // التحقق من حالة المصادقة بعد إغلاق النافذة
            const response = await fetch('/api/auth/me', {
              credentials: 'include'
            });
            
            if (response.ok) {
              const data = await response.json();
              if (data.status === '✅ success' && data.user) {
                setCurrentUser(data.user);
                toast({
                  title: "تم تسجيل الدخول بنجاح",
                  description: `أهلاً وسهلاً ${data.user.displayName || data.user.username}`,
                });
                navigate('/');
                return;
              }
            }
            
            // إذا لم يتم تسجيل الدخول بنجاح
            toast({
              title: "تم إلغاء تسجيل الدخول",
              description: "لم يتم إكمال عملية تسجيل الدخول مع Google",
              variant: "destructive",
            });
          }
        } catch (error) {
          console.error('خطأ في مراقبة نافذة تسجيل الدخول:', error);
        }
      }, 1000);

      // تنظيف المراقبة بعد 5 دقائق
      setTimeout(() => {
        clearInterval(checkWindow);
        if (!loginWindow.closed) {
          loginWindow.close();
        }
      }, 300000);

    } catch (error: any) {
      toast({
        title: "خطأ في تسجيل الدخول مع Google",
        description: error.message || "حدث خطأ أثناء تسجيل الدخول",
        variant: "destructive",
      });
      throw error;
    }
  };

  // تسجيل الخروج
  const logout = async () => {
    try {
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });

      if (response.ok) {
        setCurrentUser(null);
        toast({
          title: "تم تسجيل الخروج بنجاح",
          description: "شكراً لاستخدامك منصة راكان AI",
        });
        navigate('/login');
      }
    } catch (error) {
      console.error('خطأ في تسجيل الخروج:', error);
      // حتى لو فشل في الخادم، نقوم بتسجيل الخروج محلياً
      setCurrentUser(null);
      navigate('/login');
    }
  };

  const value = {
    currentUser,
    loginWithGoogle,
    loginWithCredentials,
    register,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth يجب استخدامه داخل AuthProvider');
  }
  return context;
};

export type { User, AuthContextType };