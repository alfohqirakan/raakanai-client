/**
 * File utility functions for client-side operations
 */

/**
 * Format file size in human readable format
 * @param bytes - Size in bytes
 * @returns Formatted string in Arabic
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 بايت';
  
  const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  
  return `${Math.round(bytes / Math.pow(1024, i) * 100) / 100} ${sizes[i]}`;
}

/**
 * Get file type icon based on file extension or mime type
 * @param fileName - File name or mime type
 * @returns Icon class name
 */
export function getFileIcon(fileName: string): string {
  const extension = fileName.toLowerCase().split('.').pop() || '';
  
  // Image files
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension)) {
    return 'fas fa-image';
  }
  
  // Document files
  if (['pdf'].includes(extension)) {
    return 'fas fa-file-pdf';
  }
  
  if (['doc', 'docx'].includes(extension)) {
    return 'fas fa-file-word';
  }
  
  if (['xls', 'xlsx'].includes(extension)) {
    return 'fas fa-file-excel';
  }
  
  if (['ppt', 'pptx'].includes(extension)) {
    return 'fas fa-file-powerpoint';
  }
  
  // Text files
  if (['txt', 'csv'].includes(extension)) {
    return 'fas fa-file-alt';
  }
  
  // Code files
  if (['js', 'ts', 'jsx', 'tsx'].includes(extension)) {
    return 'fab fa-js-square';
  }
  
  if (['html', 'htm'].includes(extension)) {
    return 'fab fa-html5';
  }
  
  if (['css'].includes(extension)) {
    return 'fab fa-css3-alt';
  }
  
  if (['json'].includes(extension)) {
    return 'fas fa-code';
  }
  
  // Archive files
  if (['zip', 'rar', '7z'].includes(extension)) {
    return 'fas fa-file-archive';
  }
  
  // Default
  return 'fas fa-file';
}

/**
 * Get file category in Arabic
 * @param fileName - File name
 * @returns Category in Arabic
 */
export function getFileCategory(fileName: string): string {
  const extension = fileName.toLowerCase().split('.').pop() || '';
  
  if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension)) {
    return 'صورة';
  }
  
  if (['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'].includes(extension)) {
    return 'مستند';
  }
  
  if (['txt', 'csv'].includes(extension)) {
    return 'ملف نصي';
  }
  
  if (['js', 'ts', 'jsx', 'tsx', 'html', 'css', 'json'].includes(extension)) {
    return 'كود';
  }
  
  if (['zip', 'rar', '7z'].includes(extension)) {
    return 'أرشيف';
  }
  
  return 'ملف';
}

/**
 * Validate file size
 * @param file - File object
 * @param maxSizeMB - Maximum size in MB
 * @returns Validation result
 */
export function validateFileSize(file: File, maxSizeMB: number = 50): { valid: boolean; error?: string } {
  const maxSizeBytes = maxSizeMB * 1024 * 1024;
  
  if (file.size > maxSizeBytes) {
    return {
      valid: false,
      error: `حجم الملف كبير جداً. الحد الأقصى ${maxSizeMB} ميجابايت`
    };
  }
  
  if (file.size === 0) {
    return {
      valid: false,
      error: 'الملف فارغ'
    };
  }
  
  return { valid: true };
}

/**
 * Check if file type is supported
 * @param file - File object
 * @returns Validation result
 */
export function validateFileType(file: File): { valid: boolean; error?: string } {
  const allowedTypes = [
    // Images
    'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml',
    // Documents
    'application/pdf',
    'text/plain', 'text/csv',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    // Code
    'text/javascript', 'application/javascript',
    'text/typescript', 'application/json',
    'text/html', 'text/css', 'application/xml', 'text/xml',
    // Archive
    'application/zip', 'application/x-rar-compressed', 'application/x-7z-compressed'
  ];

  if (!allowedTypes.includes(file.type)) {
    return {
      valid: false,
      error: 'نوع الملف غير مدعوم. الأنواع المدعومة: الصور، المستندات، النصوص، الأكواد، والأرشيف'
    };
  }

  return { valid: true };
}

/**
 * Get estimated upload time
 * @param fileSize - File size in bytes
 * @param speedKbps - Upload speed in Kbps (default: 1000)
 * @returns Estimated time string
 */
export function getEstimatedUploadTime(fileSize: number, speedKbps: number = 1000): string {
  const fileSizeKb = fileSize / 1024;
  const timeSeconds = fileSizeKb / speedKbps;
  
  if (timeSeconds < 60) {
    return `${Math.ceil(timeSeconds)} ثانية`;
  }
  
  const minutes = Math.ceil(timeSeconds / 60);
  return `${minutes} دقيقة`;
}

/**
 * Generate preview for text files
 * @param file - File object
 * @returns Promise with preview text
 */
export async function generateTextPreview(file: File): Promise<string> {
  if (!file.type.startsWith('text/') && file.type !== 'application/json') {
    throw new Error('نوع الملف لا يدعم المعاينة النصية');
  }
  
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const text = e.target?.result as string;
      // Return first 500 characters for preview
      resolve(text.substring(0, 500) + (text.length > 500 ? '...' : ''));
    };
    
    reader.onerror = () => {
      reject(new Error('فشل في قراءة الملف'));
    };
    
    reader.readAsText(file);
  });
}

/**
 * Format time ago in Arabic
 * @param date - Date to format
 * @returns Formatted time string
 */
export function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `منذ ${days} ${days === 1 ? 'يوم' : 'أيام'}`;
  if (hours > 0) return `منذ ${hours} ${hours === 1 ? 'ساعة' : 'ساعات'}`;
  if (minutes > 0) return `منذ ${minutes} ${minutes === 1 ? 'دقيقة' : 'دقائق'}`;
  return 'الآن';
}