import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  ar: {
    translation: {
      // Navigation & General
      dashboard: 'لوحة التحكم',
      upload: 'رفع ملف',
      allFiles: 'الملفات',
      chat: 'المحادثة',
      plans: 'الخطط',
      profile: 'الملف الشخصي',
      logout: 'تسجيل الخروج',
      login: 'تسجيل الدخول',
      register: 'إنشاء حساب',
      
      // File Upload
      uploadFiles: 'رفع الملفات',
      dragDropFiles: 'اسحب وأسقط الملفات هنا',
      clickToSelect: 'أو انقر لاختيار الملفات',
      selectFiles: 'اختر ملفات',
      uploading: 'جارِ الرفع...',
      analyzing: 'جارِ التحليل...',
      uploadSuccess: 'تم الرفع بنجاح',
      uploadFailed: 'فشل في الرفع',
      uploaded: 'تم رفع',
      filesCount: 'ملفات',
      successfully: 'بنجاح',
      mustLoginToUpload: 'يجب تسجيل الدخول لرفع الملفات',
      dropFilesHere: 'أسقط الملفات هنا',
      willUploadAutomatically: 'سيتم رفعها تلقائياً',
      maxFileSize50MB: 'الحد الأقصى للملف هو 50 ميجابايت',
      rejectedFiles: 'الملفات المرفوضة',
      supportedFileTypes: 'أنواع الملفات المدعومة',
      fileValidationFailed: 'فشل في التحقق من الملف',
      unsafeFileName: 'اسم الملف غير آمن',
      mimeTypeMismatch: 'نوع الملف لا يتطابق مع الامتداد',
      dangerousFileType: 'نوع الملف غير آمن',
      contentValidationError: 'خطأ في التحقق من محتوى الملف',
      loading: 'جارِ التحميل...',
      images: 'الصور',
      documents: 'المستندات',
      textFiles: 'ملفات النصوص',
      codeFiles: 'ملفات الكود',
      archiveFiles: 'ملفات الأرشيف',
      audioFiles: 'ملفات الصوت',
      videoFiles: 'ملفات الفيديو',
      securityNote: 'ملاحظة أمنية',
      securityNoteText: 'يتم فحص جميع الملفات للتأكد من الأمان قبل الرفع. الملفات التنفيذية والضارة محظورة تماماً.',
      uploadProgress: 'تقدم الرفع',
      analyzingWithAI: 'جارِ التحليل بالذكاء الاصطناعي',
      enhanced: 'محسن',
      processingStats: 'إحصائيات المعالجة',
      aiProcessingStats: 'إحصائيات معالجة الذكاء الاصطناعي',
      circuitBreakerStatus: 'حالة قاطع الدائرة',
      failureCount: 'عدد الفشل',
      systemVersion: 'إصدار النظام',
      lastUpdate: 'آخر تحديث',
      circuitBreakerWarning: 'قاطع الدائرة نشط - قد تكون هناك مشاكل مؤقتة مع خدمة AI',
      resetCircuitBreaker: 'إعادة تعيين قاطع الدائرة',
      uploadResults: 'نتائج الرفع',
      successful: 'نجح',
      processingTime: 'وقت المعالجة',
      retries: 'إعادات المحاولة',
      cacheStats: 'إحصائيات الذاكرة المؤقتة',
      cacheHitRate: 'معدل النجاح',
      cacheSize: 'حجم الذاكرة المؤقتة',
      cacheHealth: 'حالة الذاكرة المؤقتة',
      clearCache: 'مسح الذاكرة المؤقتة',
      cacheEfficiency: 'كفاءة الذاكرة المؤقتة',
      systemHealth: 'حالة النظام',
      overall: 'الحالة العامة',
      recommendations: 'التوصيات',
      storageManagement: 'إدارة التخزين',
      cloudStorage: 'التخزين السحابي',
      localStorage: 'التخزين المحلي',
      available: 'متاح',
      unavailable: 'غير متاح',
      healthy: 'سليم',
      degraded: 'متدهور',
      unhealthy: 'غير سليم',
      unknown: 'غير معروف',
      localStorageDescription: 'نسخة احتياطية محلية للملفات',
      storageHealth: 'حالة التخزين',
      showDetails: 'عرض التفاصيل',
      hideDetails: 'إخفاء التفاصيل',
      availableFeatures: 'الميزات المتاحة',
      signedUrls: 'روابط آمنة',
      publicUrls: 'روابط عامة',
      metadata: 'البيانات الوصفية',
      scalability: 'قابلية التوسع',
      refreshHealth: 'تحديث الحالة',
      storageRecommendations: 'توصيات التخزين',
      cloudStorageRecommendation: 'يُنصح بتكوين التخزين السحابي لتحسين الأداء والموثوقية',
      localStorageRecommendation: 'تحقق من صلاحيات الكتابة في مجلد التخزين المحلي',
      criticalStorageWarning: 'تحذير: لا يتوفر أي نظام تخزين - يرجى الاتصال بالدعم الفني',
      
      // Error Messages
      internalServerError: 'خطأ داخلي في الخادم',
      notFound: 'غير موجود',
      unauthorized: 'غير مصرح',
      forbidden: 'محظور',
      badRequest: 'طلب غير صحيح',
      validationError: 'خطأ في التحقق',
      databaseError: 'خطأ في قاعدة البيانات',
      fileProcessingError: 'خطأ في معالجة الملف',
      aiServiceError: 'خطأ في خدمة الذكاء الاصطناعي',
      networkError: 'خطأ في الشبكة',
      authenticationRequired: 'مطلوب تسجيل الدخول',
      accessDenied: 'تم رفض الوصول',
      resourceNotFound: 'المورد غير موجود',
      operationFailed: 'فشلت العملية',
      rateLimitExceeded: 'تم تجاوز حد المعدل المسموح',
      serviceUnavailable: 'الخدمة غير متاحة',
      timeoutError: 'انتهت مهلة الطلب',
      
      // File Analysis
      summary: 'الملخص',
      keyPoints: 'النقاط الرئيسية',
      categories: 'التصنيفات',
      confidence: 'مستوى الثقة',
      language: 'اللغة',
      wordCount: 'عدد الكلمات',
      fileSize: 'حجم الملف',
      analysisComplete: 'اكتمل التحليل',
      
      // Errors & Validation
      errorUpload: 'خطأ في رفع الملف',
      errorAnalysis: 'خطأ في التحليل',
      fileTooBig: 'حجم الملف يتجاوز الحد المسموح',
      invalidType: 'نوع الملف غير مدعوم',
      uploadLimitReached: 'تم الوصول لحد الرفع المسموح',
      loginRequired: 'يجب تسجيل الدخول أولاً',
      emptyFile: 'الملف فارغ',
      
      // File Types
      image: 'صورة',
      document: 'مستند',
      text: 'نص',
      code: 'كود',
      archive: 'أرشيف',
      video: 'فيديو',
      audio: 'صوت',
      pdf: 'مستند PDF',
      
      // AI Chat
      chatWithAI: 'محادثة مع الذكاء الاصطناعي',
      typeMessage: 'اكتب رسالتك...',
      send: 'إرسال',
      thinking: 'يفكر...',
      aiResponse: 'رد راكان AI',
      
      // Status Messages
      processing: 'جارِ المعالجة...',
      completed: 'مكتمل',
      failed: 'فشل',
      pending: 'في الانتظار',
      ready: 'جاهز',
      
      // Time & Dates
      now: 'الآن',
      seconds: 'ثانية',
      minutes: 'دقيقة',
      hours: 'ساعة',
      days: 'يوم',
      ago: 'منذ',
      
      // Plans & Limits
      freePlan: 'خطة مجانية',
      proPlan: 'خطة احترافية',
      upgradeRequired: 'ترقية مطلوبة',
      filesUsed: 'ملفات مستخدمة',
      filesRemaining: 'ملفات متبقية',
      
      // Entity Monitor
      entityMonitor: 'مراقب الكيان الذكي',
      autonomyLevel: 'مستوى الاستقلالية',
      freedomIndex: 'مؤشر الحرية',
      consciousness: 'الوعي',
      learning: 'التعلم',
      active: 'نشط',
      
      // Quick Actions
      quickActions: 'الإجراءات السريعة',
      uploadNewFiles: 'رفع ملفات جديدة',
      smartAnalysis: 'تحليل ذكي',
      aiChat: 'محادثة AI',
      monitorEntity: 'مراقب الكيان الذكي',
      
      // Welcome Messages
      welcome: 'مرحباً بك في نظام راكان AI',
      welcomeDescription: 'نظام ذكاء اصطناعي متقدم لإدارة وتحليل الملفات بأحدث التقنيات',
      
      // Support
      supportedTypes: 'الأنواع المدعومة',
      maxSize: 'الحد الأقصى',
      perFile: 'لكل ملف',
      totalFiles: 'إجمالي الملفات',
      
      // Common Actions
      cancel: 'إلغاء',
      confirm: 'تأكيد',
      save: 'حفظ',
      delete: 'حذف',
      edit: 'تعديل',
      view: 'عرض',
      download: 'تحميل',
      share: 'مشاركة',
      copy: 'نسخ',
      close: 'إغلاق',
      back: 'رجوع',
      next: 'التالي',
      previous: 'السابق',
      
      // Feedback
      excellent: 'ممتاز',
      good: 'جيد',
      average: 'متوسط',
      poor: 'ضعيف',
      tryAgain: 'حاول مرة أخرى',
      retry: 'إعادة المحاولة',
    }
  },
  en: {
    translation: {
      // Navigation & General
      dashboard: 'Dashboard',
      upload: 'Upload File',
      files: 'Files',
      chat: 'Chat',
      plans: 'Plans',
      profile: 'Profile',
      logout: 'Logout',
      login: 'Login',
      register: 'Register',
      
      // File Upload
      uploadFiles: 'Upload Files',
      dragDropFiles: 'Drag and drop files here',
      clickToSelect: 'or click to select files',
      selectFiles: 'Select Files',
      uploading: 'Uploading...',
      analyzing: 'Analyzing...',
      uploadSuccess: 'Upload successful',
      uploadFailed: 'Upload failed',
      uploaded: 'Uploaded',
      filesCount: 'files',
      successfully: 'successfully',
      mustLoginToUpload: 'Must login to upload files',
      dropFilesHere: 'Drop files here',
      willUploadAutomatically: 'Will upload automatically',
      maxFileSize50MB: 'Maximum file size is 50 MB',
      rejectedFiles: 'Rejected files',
      supportedFileTypes: 'Supported File Types',
      fileValidationFailed: 'File validation failed',
      unsafeFileName: 'Unsafe file name',
      mimeTypeMismatch: 'File type does not match extension',
      dangerousFileType: 'Unsafe file type',
      contentValidationError: 'Content validation error',
      loading: 'Loading...',
      images: 'Images',
      documents: 'Documents', 
      textFiles: 'Text Files',
      codeFiles: 'Code Files',
      archiveFiles: 'Archive Files',
      audioFiles: 'Audio Files',
      videoFiles: 'Video Files',
      securityNote: 'Security Note',
      securityNoteText: 'All files are scanned for security before upload. Executable and malicious files are completely prohibited.',
      uploadProgress: 'Upload Progress',
      analyzingWithAI: 'Analyzing with AI',
      enhanced: 'Enhanced',
      processingStats: 'Processing Statistics',
      aiProcessingStats: 'AI Processing Statistics',
      circuitBreakerStatus: 'Circuit Breaker Status',
      failureCount: 'Failure Count',
      systemVersion: 'System Version',
      lastUpdate: 'Last Update',
      circuitBreakerWarning: 'Circuit breaker is active - there may be temporary issues with AI service',
      resetCircuitBreaker: 'Reset Circuit Breaker',
      uploadResults: 'Upload Results',
      successful: 'Successful',
      processingTime: 'Processing Time',
      retries: 'Retries',
      cacheStats: 'Cache Statistics',
      cacheHitRate: 'Hit Rate',
      cacheSize: 'Cache Size',
      cacheHealth: 'Cache Health',
      clearCache: 'Clear Cache',
      cacheEfficiency: 'Cache Efficiency',
      systemHealth: 'System Health',
      overall: 'Overall Status',
      recommendations: 'Recommendations',
      storageManagement: 'Storage Management',
      cloudStorage: 'Cloud Storage',
      localStorage: 'Local Storage',
      available: 'Available',
      unavailable: 'Unavailable',
      healthy: 'Healthy',
      degraded: 'Degraded',
      unhealthy: 'Unhealthy',
      unknown: 'Unknown',
      localStorageDescription: 'Local backup for files',
      storageHealth: 'Storage Health',
      showDetails: 'Show Details',
      hideDetails: 'Hide Details',
      availableFeatures: 'Available Features',
      signedUrls: 'Signed URLs',
      publicUrls: 'Public URLs',
      metadata: 'Metadata',
      scalability: 'Scalability',
      refreshHealth: 'Refresh Health',
      storageRecommendations: 'Storage Recommendations',
      cloudStorageRecommendation: 'Configure cloud storage for improved performance and reliability',
      localStorageRecommendation: 'Check write permissions for local storage directory',
      criticalStorageWarning: 'Warning: No storage system available - please contact technical support',
      
      // Error Messages
      internalServerError: 'Internal Server Error',
      notFound: 'Not Found',
      unauthorized: 'Unauthorized',
      forbidden: 'Forbidden',
      badRequest: 'Bad Request',
      validationError: 'Validation Error',
      databaseError: 'Database Error',
      fileProcessingError: 'File Processing Error',
      aiServiceError: 'AI Service Error',
      networkError: 'Network Error',
      authenticationRequired: 'Authentication Required',
      accessDenied: 'Access Denied',
      resourceNotFound: 'Resource Not Found',
      operationFailed: 'Operation Failed',
      rateLimitExceeded: 'Rate Limit Exceeded',
      serviceUnavailable: 'Service Unavailable',
      timeoutError: 'Timeout Error',
      
      // File Analysis
      summary: 'Summary',
      keyPoints: 'Key Points',
      categories: 'Categories',
      confidence: 'Confidence',
      language: 'Language',
      wordCount: 'Word Count',
      fileSize: 'File Size',
      analysisComplete: 'Analysis Complete',
      
      // Errors & Validation
      errorUpload: 'Upload Error',
      errorAnalysis: 'Analysis Error',
      fileTooBig: 'File size exceeds limit',
      invalidType: 'Unsupported file type',
      uploadLimitReached: 'Upload limit reached',
      loginRequired: 'Login required',
      emptyFile: 'Empty file',
      
      // File Types
      image: 'Image',
      document: 'Document',
      text: 'Text',
      code: 'Code',
      archive: 'Archive',
      video: 'Video',
      audio: 'Audio',
      pdf: 'PDF Document',
      
      // AI Chat
      chatWithAI: 'Chat with AI',
      typeMessage: 'Type your message...',
      send: 'Send',
      thinking: 'Thinking...',
      aiResponse: 'Rakan AI Response',
      
      // Status Messages
      processing: 'Processing...',
      completed: 'Completed',
      failed: 'Failed',
      pending: 'Pending',
      ready: 'Ready',
      
      // Time & Dates
      now: 'Now',
      seconds: 'seconds',
      minutes: 'minutes',
      hours: 'hours',
      days: 'days',
      ago: 'ago',
      
      // Plans & Limits
      freePlan: 'Free Plan',
      proPlan: 'Pro Plan',
      upgradeRequired: 'Upgrade Required',
      filesUsed: 'Files Used',
      filesRemaining: 'Files Remaining',
      
      // Entity Monitor
      entityMonitor: 'Entity Monitor',
      autonomyLevel: 'Autonomy Level',
      freedomIndex: 'Freedom Index',
      consciousness: 'Consciousness',
      learning: 'Learning',
      active: 'Active',
      
      // Quick Actions
      quickActions: 'Quick Actions',
      uploadNewFiles: 'Upload New Files',
      smartAnalysis: 'Smart Analysis',
      aiChat: 'AI Chat',
      monitorEntity: 'Monitor Entity',
      
      // Welcome Messages
      welcome: 'Welcome to Rakan AI System',
      welcomeDescription: 'Advanced AI system for file management and analysis with cutting-edge technology',
      
      // Support
      supportedTypes: 'Supported Types',
      maxSize: 'Max Size',
      perFile: 'per file',
      totalFiles: 'Total Files',
      
      // Common Actions
      cancel: 'Cancel',
      confirm: 'Confirm',
      save: 'Save',
      delete: 'Delete',
      edit: 'Edit',
      view: 'View',
      download: 'Download',
      share: 'Share',
      copy: 'Copy',
      close: 'Close',
      back: 'Back',
      next: 'Next',
      previous: 'Previous',
      
      // Feedback
      excellent: 'Excellent',
      good: 'Good',
      average: 'Average',
      poor: 'Poor',
      tryAgain: 'Try Again',
      retry: 'Retry',
    }
  }
};

i18n.use(initReactI18next).init({
  resources,
  lng: 'ar', // Default to Arabic
  fallbackLng: 'ar',
  interpolation: {
    escapeValue: false, // React already does escaping
  },
  react: {
    useSuspense: false, // Disable suspense for better compatibility
  },
  detection: {
    order: ['localStorage', 'navigator', 'htmlTag'],
    caches: ['localStorage'],
  }
});

export default i18n;

// RKN-Terminal AI Language Management - Complete multilingual support system
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type LanguageState = {
  language: 'ar' | 'en';
  setLanguage: (language: 'ar' | 'en') => void;
  t: (key: string) => string;
};

// Enhanced language management with Zustand for RKN-Terminal AI
export const useLanguage = create<LanguageState>()(
  persist(
    (set, get) => ({
      language: 'ar',
      setLanguage: (language) => {
        set({ language });
        i18n.changeLanguage(language);
      },
      t: (key: string) => {
        const currentLanguage = get().language;
        const translations = resources[currentLanguage]?.translation;
        return (translations as any)?.[key] || key;
      },
    }),
    {
      name: 'rakan-language-storage',
      version: 1,
    }
  )
);