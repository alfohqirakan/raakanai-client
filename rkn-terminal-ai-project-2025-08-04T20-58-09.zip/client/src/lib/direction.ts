import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type DirectionState = {
  dir: 'rtl' | 'ltr';
  language: 'ar' | 'en';
  toggleDirection: () => void;
  setDirection: (dir: 'rtl' | 'ltr') => void;
  setLanguage: (lang: 'ar' | 'en') => void;
};

export const useDirection = create<DirectionState>()(
  persist(
    (set, get) => ({
      dir: 'rtl', // الافتراضي: اليمين لليسار (العربية)
      language: 'ar', // الافتراضي: العربية
      
      toggleDirection: () => {
        const currentDir = get().dir;
        const newDir = currentDir === 'rtl' ? 'ltr' : 'rtl';
        const newLang = newDir === 'rtl' ? 'ar' : 'en';
        
        set({ 
          dir: newDir, 
          language: newLang 
        });
        
        // Update document attributes immediately
        document.documentElement.dir = newDir;
        document.documentElement.lang = newLang;
        
        // Trigger storage event for other components
        window.dispatchEvent(new CustomEvent('directionChange', { 
          detail: { dir: newDir, language: newLang } 
        }));
      },
      
      setDirection: (dir: 'rtl' | 'ltr') => {
        const language = dir === 'rtl' ? 'ar' : 'en';
        set({ dir, language });
        
        document.documentElement.dir = dir;
        document.documentElement.lang = language;
        
        window.dispatchEvent(new CustomEvent('directionChange', { 
          detail: { dir, language } 
        }));
      },
      
      setLanguage: (language: 'ar' | 'en') => {
        const dir = language === 'ar' ? 'rtl' : 'ltr';
        set({ dir, language });
        
        document.documentElement.dir = dir;
        document.documentElement.lang = language;
        
        window.dispatchEvent(new CustomEvent('directionChange', { 
          detail: { dir, language } 
        }));
      },
    }),
    {
      name: 'rakan-direction-storage',
      version: 1,
    }
  )
);

// Helper hooks for specific use cases
export const useIsRTL = () => useDirection((state) => state.dir === 'rtl');
export const useIsArabic = () => useDirection((state) => state.language === 'ar');

// Utility functions
export const getTextAlign = (dir: 'rtl' | 'ltr') => dir === 'rtl' ? 'text-right' : 'text-left';
export const getMarginStart = (dir: 'rtl' | 'ltr') => dir === 'rtl' ? 'mr' : 'ml';
export const getMarginEnd = (dir: 'rtl' | 'ltr') => dir === 'rtl' ? 'ml' : 'mr';
export const getPaddingStart = (dir: 'rtl' | 'ltr') => dir === 'rtl' ? 'pr' : 'pl';
export const getPaddingEnd = (dir: 'rtl' | 'ltr') => dir === 'rtl' ? 'pl' : 'pr';

// CSS class helpers
export const directionClasses = {
  textAlign: (dir: 'rtl' | 'ltr') => dir === 'rtl' ? 'text-right' : 'text-left',
  marginStart: (dir: 'rtl' | 'ltr', size: string = '4') => 
    dir === 'rtl' ? `mr-${size}` : `ml-${size}`,
  marginEnd: (dir: 'rtl' | 'ltr', size: string = '4') => 
    dir === 'rtl' ? `ml-${size}` : `mr-${size}`,
  paddingStart: (dir: 'rtl' | 'ltr', size: string = '4') => 
    dir === 'rtl' ? `pr-${size}` : `pl-${size}`,
  paddingEnd: (dir: 'rtl' | 'ltr', size: string = '4') => 
    dir === 'rtl' ? `pl-${size}` : `pr-${size}`,
  flexDirection: (dir: 'rtl' | 'ltr') => 
    dir === 'rtl' ? 'flex-row-reverse' : 'flex-row',
};