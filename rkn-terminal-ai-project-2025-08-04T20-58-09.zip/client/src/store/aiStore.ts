import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  fileId?: string;
  metadata?: {
    analysisType?: string;
    confidence?: number;
    processingTime?: number;
  };
}

interface AIAnalysisResult {
  summary: string;
  keyPoints: string[];
  categories: string[];
  sentiment?: number;
  confidence: number;
  language: string;
  wordCount?: number;
  processingTime: number;
  status: 'success' | 'partial' | 'failed';
}

interface VisionAnalysisResult {
  objects: string[];
  text: string;
  scene: string;
  description: string;
  confidence: number;
  metadata: {
    imageSize: { width: number; height: number };
    format: string;
    quality: string;
  };
}

interface AIState {
  // Chat Management
  chatHistory: Record<string, ChatMessage[]>;
  addMessage: (fileId: string, message: ChatMessage) => void;
  clearHistory: (fileId: string) => void;
  clearAllHistory: () => void;
  
  // Analysis Results Cache
  analysisResults: Record<string, AIAnalysisResult>;
  visionResults: Record<string, VisionAnalysisResult>;
  setAnalysisResult: (fileId: string, result: AIAnalysisResult) => void;
  setVisionResult: (fileId: string, result: VisionAnalysisResult) => void;
  
  // API Configuration
  apiKey: string | null;
  setApiKey: (key: string) => void;
  
  // UI State
  isProcessing: Record<string, boolean>;
  setProcessing: (fileId: string, processing: boolean) => void;
  
  // RKN-Terminal AI Specific Settings
  aiSettings: {
    language: 'ar' | 'en';
    analysisDepth: 'basic' | 'detailed' | 'comprehensive';
    enableVision: boolean;
    enableBatchProcessing: boolean;
    autoSaveResults: boolean;
  };
  updateAISettings: (settings: Partial<AIState['aiSettings']>) => void;
  
  // Performance Metrics
  metrics: {
    totalAnalyses: number;
    totalVisionAnalyses: number;
    averageProcessingTime: number;
    successRate: number;
  };
  updateMetrics: (type: 'analysis' | 'vision', processingTime: number, success: boolean) => void;
}

export const useAIStore = create<AIState>()(
  persist(
    (set, get) => ({
      // Chat Management
      chatHistory: {},
      addMessage: (fileId, message) => set(state => ({
        chatHistory: {
          ...state.chatHistory,
          [fileId]: [...(state.chatHistory[fileId] || []), message]
        }
      })),
      clearHistory: fileId => set(state => ({
        chatHistory: {
          ...state.chatHistory,
          [fileId]: []
        }
      })),
      clearAllHistory: () => set({ chatHistory: {} }),
      
      // Analysis Results Cache
      analysisResults: {},
      visionResults: {},
      setAnalysisResult: (fileId, result) => set(state => ({
        analysisResults: {
          ...state.analysisResults,
          [fileId]: result
        }
      })),
      setVisionResult: (fileId, result) => set(state => ({
        visionResults: {
          ...state.visionResults,
          [fileId]: result
        }
      })),
      
      // API Configuration
      apiKey: null,
      setApiKey: apiKey => set({ apiKey }),
      
      // UI State
      isProcessing: {},
      setProcessing: (fileId, processing) => set(state => ({
        isProcessing: {
          ...state.isProcessing,
          [fileId]: processing
        }
      })),
      
      // RKN-Terminal AI Settings
      aiSettings: {
        language: 'ar',
        analysisDepth: 'detailed',
        enableVision: true,
        enableBatchProcessing: true,
        autoSaveResults: true
      },
      updateAISettings: settings => set(state => ({
        aiSettings: { ...state.aiSettings, ...settings }
      })),
      
      // Performance Metrics
      metrics: {
        totalAnalyses: 0,
        totalVisionAnalyses: 0,
        averageProcessingTime: 0,
        successRate: 100
      },
      updateMetrics: (type, processingTime, success) => set(state => {
        const currentMetrics = state.metrics;
        const isVision = type === 'vision';
        
        const newTotalAnalyses = isVision ? 
          currentMetrics.totalVisionAnalyses + 1 : 
          currentMetrics.totalAnalyses + 1;
        
        const totalProcessingTime = currentMetrics.averageProcessingTime * 
          (currentMetrics.totalAnalyses + currentMetrics.totalVisionAnalyses);
        
        const newAverageProcessingTime = 
          (totalProcessingTime + processingTime) / 
          (currentMetrics.totalAnalyses + currentMetrics.totalVisionAnalyses + 1);
        
        const totalOperations = currentMetrics.totalAnalyses + currentMetrics.totalVisionAnalyses + 1;
        const successfulOperations = Math.round(currentMetrics.successRate / 100 * (totalOperations - 1)) + (success ? 1 : 0);
        const newSuccessRate = Math.round((successfulOperations / totalOperations) * 100);
        
        return {
          metrics: {
            totalAnalyses: isVision ? currentMetrics.totalAnalyses : currentMetrics.totalAnalyses + 1,
            totalVisionAnalyses: isVision ? currentMetrics.totalVisionAnalyses + 1 : currentMetrics.totalVisionAnalyses,
            averageProcessingTime: Math.round(newAverageProcessingTime),
            successRate: newSuccessRate
          }
        };
      })
    }),
    {
      name: 'rkan-ai-store',
      storage: createJSONStorage(() => localStorage),
      partialize: state => ({ 
        apiKey: state.apiKey,
        aiSettings: state.aiSettings,
        metrics: state.metrics
      }), // Store only persistent settings, not temporary data
      version: 1
    }
  )
);

// Selector hooks for better performance
export const useChatHistory = (fileId: string) => 
  useAIStore(state => state.chatHistory[fileId] || []);

export const useAnalysisResult = (fileId: string) => 
  useAIStore(state => state.analysisResults[fileId]);

export const useVisionResult = (fileId: string) => 
  useAIStore(state => state.visionResults[fileId]);

export const useProcessingStatus = (fileId: string) => 
  useAIStore(state => state.isProcessing[fileId] || false);

export const useAISettings = () => 
  useAIStore(state => state.aiSettings);

export const useAIMetrics = () => 
  useAIStore(state => state.metrics);

// Utility functions
export const generateMessageId = () => 
  `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

export const createChatMessage = (
  role: 'user' | 'assistant',
  content: string,
  fileId?: string,
  metadata?: ChatMessage['metadata']
): ChatMessage => ({
  id: generateMessageId(),
  role,
  content,
  timestamp: new Date(),
  fileId,
  metadata
});

console.log('🧠 RKN-Terminal AI Store initialized with persistent state management');

export type { ChatMessage, AIAnalysisResult, VisionAnalysisResult, AIState };