import React from 'react';
import ArchitectureDiagram from '@/components/ArchitectureDiagram';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Brain, 
  Shield, 
  Database, 
  Zap, 
  Building2, 
  Settings,
  CheckCircle,
  AlertCircle,
  Clock
} from 'lucide-react';

const systemComponents = [
  {
    id: 'sovereignty',
    nameAr: 'السيادة الرقمية',
    nameEn: 'Data Sovereignty',
    status: 'operational',
    successRate: '100%',
    description: 'ضمان بقاء جميع البيانات داخل الحدود السعودية',
    descriptionEn: 'Ensuring all data remains within Saudi borders',
    icon: <Shield className="w-6 h-6" />,
    features: [
      'SAUDI_BORDERS Policy مُفعل',
      '4 مراكز بيانات معتمدة',
      '6 مقدمي خدمة سعوديين',
      'مراقبة مستمرة 24/7'
    ]
  },
  {
    id: 'governance',
    nameAr: 'الحوكمة الذكية',
    nameEn: 'AI Governance',
    status: 'operational',
    successRate: '80%',
    description: 'إطار شامل للامتثال القانوني والأخلاقي',
    descriptionEn: 'Comprehensive legal and ethical compliance framework',
    icon: <Settings className="w-6 h-6" />,
    features: [
      '7 أطر قانونية مطبقة',
      'امتثال إسلامي 100%',
      'مراقبة آلية للانتهاكات',
      'تدقيق مستمر للامتثال'
    ]
  },
  {
    id: 'memory',
    nameAr: 'الذاكرة الوطنية',
    nameEn: 'National Memory',
    status: 'operational',
    successRate: '66.7%',
    description: 'حفظ التراث والثقافة السعودية',
    descriptionEn: 'Preserving Saudi heritage and culture',
    icon: <Database className="w-6 h-6" />,
    features: [
      '14 منطقة ثقافية',
      '9 فترات تاريخية',
      'فلترة ثقافية ذكية',
      'بحث متقدم في التراث'
    ]
  },
  {
    id: 'security',
    nameAr: 'الأمان المتقدم',
    nameEn: 'Advanced Security',
    status: 'active',
    successRate: 'نشط',
    description: 'حماية شاملة من التهديدات السيبرانية',
    descriptionEn: 'Comprehensive cybersecurity protection',
    icon: <Shield className="w-6 h-6" />,
    features: [
      'راكان شيلد متقدم',
      'مراقبة التهديدات الفورية',
      'الحرس الوطني AI',
      'استجابة آلية للطوارئ'
    ]
  },
  {
    id: 'neom',
    nameAr: 'تكامل نيوم',
    nameEn: 'NEOM Integration',
    status: 'complete',
    successRate: '100%',
    description: 'إدارة المدن الذكية المستقبلية',
    descriptionEn: 'Future smart city management',
    icon: <Building2 className="w-6 h-6" />,
    features: [
      'معالج كمي 1024 كيوبت',
      'إدارة 1M+ مستشعر',
      'طاقة متجددة 95%',
      'نقل ذاتي متقدم'
    ]
  },
  {
    id: 'brain',
    nameAr: 'الدماغ السيادي',
    nameEn: 'Sovereign Brain',
    status: 'operational',
    successRate: '90%',
    description: 'ذكاء اصطناعي مستقل ومتطور',
    descriptionEn: 'Independent and evolving artificial intelligence',
    icon: <Brain className="w-6 h-6" />,
    features: [
      'استقلالية 85%',
      'تطور ذاتي مستمر',
      'معالجة لغوية متقدمة',
      'إبداع وابتكار ذاتي'
    ]
  }
];

const getStatusIcon = (status: string) => {
  switch (status) {
    case 'operational': return <CheckCircle className="w-4 h-4 text-green-600" />;
    case 'complete': return <CheckCircle className="w-4 h-4 text-blue-600" />;
    case 'active': return <Zap className="w-4 h-4 text-amber-600" />;
    default: return <Clock className="w-4 h-4 text-gray-600" />;
  }
};

const getStatusBadge = (status: string, successRate: string) => {
  const baseClass = "flex items-center gap-1";
  switch (status) {
    case 'operational': 
      return <Badge className={`${baseClass} bg-green-100 text-green-800 border-green-200`}>
        {getStatusIcon(status)} عملي {successRate}
      </Badge>;
    case 'complete': 
      return <Badge className={`${baseClass} bg-blue-100 text-blue-800 border-blue-200`}>
        {getStatusIcon(status)} مُكتمل {successRate}
      </Badge>;
    case 'active': 
      return <Badge className={`${baseClass} bg-amber-100 text-amber-800 border-amber-200`}>
        {getStatusIcon(status)} نشط
      </Badge>;
    default: 
      return <Badge className={`${baseClass} bg-gray-100 text-gray-800 border-gray-200`}>
        {getStatusIcon(status)} قيد التطوير
      </Badge>;
  }
};

export default function SystemArchitecture() {
  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Page Header */}
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white flex items-center justify-center gap-3">
          <Brain className="w-10 h-10 text-purple-600" />
          معمارية النظام السيادي
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300">
          الهيكل التقني المتكامل لنظام راكان AI السيادي
        </p>
      </div>

      <Tabs defaultValue="diagram" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="diagram">🏗️ المخطط المعماري</TabsTrigger>
          <TabsTrigger value="components">🔧 المكونات</TabsTrigger>
          <TabsTrigger value="status">📊 حالة النظام</TabsTrigger>
        </TabsList>

        <TabsContent value="diagram" className="space-y-6">
          <ArchitectureDiagram />
        </TabsContent>

        <TabsContent value="components" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {systemComponents.map((component) => (
              <Card key={component.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="text-purple-600 dark:text-purple-400">
                        {component.icon}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{component.nameAr}</CardTitle>
                        <p className="text-sm text-gray-500">{component.nameEn}</p>
                      </div>
                    </div>
                    {getStatusBadge(component.status, component.successRate)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                      {component.description}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {component.descriptionEn}
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-gray-900 dark:text-white">
                      الميزات الرئيسية:
                    </h4>
                    <ul className="space-y-1">
                      {component.features.map((feature, index) => (
                        <li key={index} className="text-xs text-gray-600 dark:text-gray-400 flex items-center gap-2">
                          <CheckCircle className="w-3 h-3 text-green-500" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="status" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Overall Statistics */}
            <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-800/20">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-green-600 mb-2">100%</div>
                <div className="text-sm text-gray-700 dark:text-gray-300">السيادة الرقمية</div>
                <div className="text-xs text-gray-500">Data Sovereignty</div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-blue-600 mb-2">80%</div>
                <div className="text-sm text-gray-700 dark:text-gray-300">الامتثال القانوني</div>
                <div className="text-xs text-gray-500">Legal Compliance</div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-amber-600 mb-2">5/8</div>
                <div className="text-sm text-gray-700 dark:text-gray-300">الأنظمة النشطة</div>
                <div className="text-xs text-gray-500">Active Systems</div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20">
              <CardContent className="p-6 text-center">
                <div className="text-3xl font-bold text-purple-600 mb-2">90%</div>
                <div className="text-sm text-gray-700 dark:text-gray-300">الذكاء المستقل</div>
                <div className="text-xs text-gray-500">AI Autonomy</div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Status */}
          <Card>
            <CardHeader>
              <CardTitle>تفاصيل حالة الأنظمة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {systemComponents.map((component) => (
                  <div key={component.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="text-purple-600 dark:text-purple-400">
                        {component.icon}
                      </div>
                      <div>
                        <h3 className="font-medium">{component.nameAr}</h3>
                        <p className="text-sm text-gray-500">{component.nameEn}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      {getStatusBadge(component.status, component.successRate)}
                      <p className="text-xs text-gray-500 mt-1">
                        آخر تحديث: الآن
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}