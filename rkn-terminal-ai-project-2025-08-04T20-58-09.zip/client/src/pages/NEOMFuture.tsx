import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Zap, 
  Brain, 
  Cpu, 
  Car,
  Leaf,
  Atom,
  Rocket,
  Globe,
  TrendingUp,
  Activity,
  Battery,
  Wind,
  Sun,
  Droplets,
  Users,
  Building2,
  MapPin,
  Clock,
  CheckCircle,
  Star,
  Target,
  Lightbulb,
  Settings,
  Monitor,
  Database,
  Cloud,
  Shield
} from 'lucide-react';

interface QuantumProcessor {
  id: string;
  name: string;
  qubits: number;
  coherenceTime: number;
  gateFidelity: number;
  computationalPower: number;
  status: 'operational' | 'maintenance' | 'offline';
}

interface UrbanSystem {
  id: string;
  name: string;
  zone: string;
  systemType: string;
  maturityLevel: string;
  sustainabilityLevel: string;
  performanceScore: number;
  energyConsumption: number;
  carbonFootprint: number;
}

interface CityMetrics {
  population: number;
  sustainabilityScore: number;
  energyEfficiency: number;
  trafficOptimization: number;
  airQualityIndex: number;
  digitalServicesAdoption: number;
  citizenSatisfaction: number;
  innovationIndex: number;
}

interface AutonomousFleet {
  totalVehicles: number;
  activeVehicles: number;
  tripsCompleted: number;
  autonomyLevel: number;
  energyTypes: string[];
  efficiency: number;
}

const NEOMFuture: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [isQuantumActive, setIsQuantumActive] = useState(true);
  const [realTimeMode, setRealTimeMode] = useState(true);

  // Mock data for demonstration
  const quantumProcessors: QuantumProcessor[] = [
    {
      id: 'QP_001',
      name: 'NEOM Quantum Core Alpha',
      qubits: 1024,
      coherenceTime: 100.0,
      gateFidelity: 0.999,
      computationalPower: 1e15,
      status: 'operational'
    },
    {
      id: 'QP_002',
      name: 'NEOM Quantum Core Beta',
      qubits: 512,
      coherenceTime: 80.0,
      gateFidelity: 0.998,
      computationalPower: 5e14,
      status: 'operational'
    },
    {
      id: 'QP_003',
      name: 'NEOM Quantum Simulator',
      qubits: 256,
      coherenceTime: 60.0,
      gateFidelity: 0.995,
      computationalPower: 1e14,
      status: 'operational'
    }
  ];

  const urbanSystems: UrbanSystem[] = [
    {
      id: 'US_001',
      name: 'شبكة النقل الذكي',
      zone: 'ذا لاين',
      systemType: 'النقل المستقل',
      maturityLevel: 'منتشر',
      sustainabilityLevel: 'سالب الكربون',
      performanceScore: 0.95,
      energyConsumption: 50.0,
      carbonFootprint: -1000.0
    },
    {
      id: 'US_002',
      name: 'مركز الحوسبة الكمية',
      zone: 'وادي نيوم التقني',
      systemType: 'البنية التحتية الكمية',
      maturityLevel: 'متكامل بالكامل',
      sustainabilityLevel: 'محايد الكربون',
      performanceScore: 0.99,
      energyConsumption: 200.0,
      carbonFootprint: 0.0
    },
    {
      id: 'US_003',
      name: 'شبكة الطاقة المتجددة',
      zone: 'مركز الطاقة المتجددة',
      systemType: 'شبكة الطاقة المتجددة',
      maturityLevel: 'موسع',
      sustainabilityLevel: 'سالب الكربون',
      performanceScore: 0.98,
      energyConsumption: -5000.0,
      carbonFootprint: -50000.0
    },
    {
      id: 'US_004',
      name: 'المدينة الرقمية التوأم',
      zone: 'خليج نيوم',
      systemType: 'المدينة الرقمية التوأم',
      maturityLevel: 'منتشر',
      sustainabilityLevel: 'محايد الكربون',
      performanceScore: 0.94,
      energyConsumption: 100.0,
      carbonFootprint: 0.0
    }
  ];

  const cityMetrics: CityMetrics = {
    population: 1000000,
    sustainabilityScore: 0.95,
    energyEfficiency: 0.98,
    trafficOptimization: 0.92,
    airQualityIndex: 15.0,
    digitalServicesAdoption: 0.99,
    citizenSatisfaction: 0.94,
    innovationIndex: 0.97
  };

  const autonomousFleet: AutonomousFleet = {
    totalVehicles: 1750,
    activeVehicles: 1680,
    tripsCompleted: 45672,
    autonomyLevel: 5,
    energyTypes: ['Hydrogen', 'Electric', 'Magnetic Levitation'],
    efficiency: 0.96
  };

  const getSystemTypeIcon = (type: string) => {
    const icons = {
      'النقل المستقل': <Car className="h-5 w-5" />,
      'البنية التحتية الكمية': <Atom className="h-5 w-5" />,
      'شبكة الطاقة المتجددة': <Battery className="h-5 w-5" />,
      'المدينة الرقمية التوأم': <Monitor className="h-5 w-5" />,
      'مختبر التكنولوجيا الحيوية': <Brain className="h-5 w-5" />
    };
    return icons[type as keyof typeof icons] || <Settings className="h-5 w-5" />;
  };

  const getMaturityColor = (level: string) => {
    const colors = {
      'متكامل بالكامل': 'bg-green-100 text-green-800 border-green-200',
      'منتشر': 'bg-blue-100 text-blue-800 border-blue-200',
      'موسع': 'bg-purple-100 text-purple-800 border-purple-200',
      'تجريبي': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'نموذج أولي': 'bg-orange-100 text-orange-800 border-orange-200'
    };
    return colors[level as keyof typeof colors] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getSustainabilityColor = (level: string) => {
    const colors = {
      'سالب الكربون': 'bg-green-600',
      'محايد الكربون': 'bg-blue-600',
      'منخفض الكربون': 'bg-yellow-600',
      'في طور التحول': 'bg-orange-600'
    };
    return colors[level as keyof typeof colors] || 'bg-gray-600';
  };

  const MetricCard: React.FC<{
    title: string;
    value: number;
    icon: React.ReactNode;
    trend?: number;
    suffix?: string;
    description?: string;
    target?: number;
  }> = ({ title, value, icon, trend, suffix = '%', description, target }) => (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl font-bold">
            {suffix === '%' ? (value * 100).toFixed(1) : value.toLocaleString()}{suffix}
          </p>
          {target && (
            <p className="text-xs text-muted-foreground">
              الهدف: {suffix === '%' ? (target * 100).toFixed(0) : target.toLocaleString()}{suffix}
            </p>
          )}
          {trend !== undefined && (
            <p className={`text-sm flex items-center ${trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              <TrendingUp className="h-4 w-4 mr-1" />
              {trend >= 0 ? '+' : ''}{(trend * 100).toFixed(1)}%
            </p>
          )}
          {description && (
            <p className="text-xs text-muted-foreground mt-1">{description}</p>
          )}
        </div>
        <div className="text-2xl text-muted-foreground ml-4">
          {icon}
        </div>
      </div>
      {target && (
        <Progress value={(value / target) * 100} className="h-2 mt-2" />
      )}
    </Card>
  );

  const QuantumProcessorCard: React.FC<{ processor: QuantumProcessor }> = ({ processor }) => (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="font-medium flex items-center">
            <Atom className="h-4 w-4 mr-2" />
            {processor.name}
          </h4>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${
              processor.status === 'operational' ? 'bg-green-500' : 
              processor.status === 'maintenance' ? 'bg-yellow-500' : 'bg-red-500'
            }`}></div>
            <span className="text-xs capitalize">{processor.status}</span>
          </div>
        </div>
        
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">الكيوبت:</span>
            <span className="font-medium">{processor.qubits}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">زمن التماسك:</span>
            <span>{processor.coherenceTime} μs</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">دقة البوابة:</span>
            <span>{(processor.gateFidelity * 100).toFixed(1)}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">القدرة الحاسوبية:</span>
            <span>{processor.computationalPower.toExponential(1)} QOPS</span>
          </div>
        </div>
        
        <div className="pt-2 border-t">
          <div className="flex justify-between text-sm mb-1">
            <span>كفاءة التشغيل</span>
            <span>{(processor.gateFidelity * 100).toFixed(1)}%</span>
          </div>
          <Progress value={processor.gateFidelity * 100} className="h-2" />
        </div>
      </div>
    </Card>
  );

  const UrbanSystemCard: React.FC<{ system: UrbanSystem }> = ({ system }) => (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <div>
            <h4 className="font-medium flex items-center">
              {getSystemTypeIcon(system.systemType)}
              <span className="ml-2">{system.name}</span>
            </h4>
            <p className="text-sm text-muted-foreground">{system.zone}</p>
          </div>
          <Badge variant="outline" className={getMaturityColor(system.maturityLevel)}>
            {system.maturityLevel}
          </Badge>
        </div>
        
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">نوع النظام:</span>
            <span>{system.systemType}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">مستوى الاستدامة:</span>
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${getSustainabilityColor(system.sustainabilityLevel)}`}></div>
              <span className="text-xs">{system.sustainabilityLevel}</span>
            </div>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">استهلاك الطاقة:</span>
            <span className={system.energyConsumption < 0 ? 'text-green-600' : 'text-blue-600'}>
              {system.energyConsumption > 0 ? '+' : ''}{system.energyConsumption.toFixed(0)} MW
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">البصمة الكربونية:</span>
            <span className={system.carbonFootprint < 0 ? 'text-green-600' : 'text-red-600'}>
              {system.carbonFootprint > 0 ? '+' : ''}{system.carbonFootprint.toFixed(0)} t CO₂/year
            </span>
          </div>
        </div>
        
        <div className="pt-2 border-t">
          <div className="flex justify-between text-sm mb-1">
            <span>نقاط الأداء</span>
            <span>{(system.performanceScore * 100).toFixed(1)}%</span>
          </div>
          <Progress value={system.performanceScore * 100} className="h-2" />
        </div>
      </div>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Rocket className="h-8 w-8 text-purple-400 mr-3" />
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                نيوم - المستقبل الرقمي
              </h1>
              <p className="text-slate-300">
                NEOM Future Integration - First Digital State in History
              </p>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <Alert className="border-purple-500/20 bg-purple-500/10 flex-1 mr-4">
              <Brain className="h-4 w-4 text-purple-400" />
              <AlertDescription className="text-purple-100">
                <strong>الرسالة البرمجية:</strong> "نحن لا نبرمج أنظمة.. نبرمج مستقبلاً"
              </AlertDescription>
            </Alert>
            
            <div className="flex gap-2">
              <Button 
                variant={isQuantumActive ? "default" : "secondary"}
                size="sm"
                onClick={() => setIsQuantumActive(!isQuantumActive)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Atom className="h-4 w-4 mr-1" />
                {isQuantumActive ? 'Quantum Active' : 'Quantum Inactive'}
              </Button>
              
              <Button 
                variant={realTimeMode ? "default" : "secondary"}
                size="sm"
                onClick={() => setRealTimeMode(!realTimeMode)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Activity className="h-4 w-4 mr-1" />
                Real-time
              </Button>
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 bg-slate-800/50 border-slate-700">
            <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600">نظرة عامة</TabsTrigger>
            <TabsTrigger value="quantum" className="data-[state=active]:bg-purple-600">الحوسبة الكمية</TabsTrigger>
            <TabsTrigger value="systems" className="data-[state=active]:bg-purple-600">الأنظمة الذكية</TabsTrigger>
            <TabsTrigger value="transport" className="data-[state=active]:bg-purple-600">النقل المستقل</TabsTrigger>
            <TabsTrigger value="sustainability" className="data-[state=active]:bg-purple-600">الاستدامة</TabsTrigger>
            <TabsTrigger value="future" className="data-[state=active]:bg-purple-600">المستقبل</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Performance Indicators */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="نقاط الاستدامة"
                value={cityMetrics.sustainabilityScore}
                icon={<Leaf />}
                trend={0.023}
                target={1.0}
                description="أول مدينة كربون سالب"
              />
              <MetricCard
                title="كفاءة الطاقة"
                value={cityMetrics.energyEfficiency}
                icon={<Battery />}
                trend={0.015}
                target={1.0}
                description="طاقة متجددة 100%"
              />
              <MetricCard
                title="تحسين المرور"
                value={cityMetrics.trafficOptimization}
                icon={<Car />}
                trend={0.031}
                target={1.0}
                description="نقل مستقل بالكامل"
              />
              <MetricCard
                title="مؤشر الابتكار"
                value={cityMetrics.innovationIndex}
                icon={<Lightbulb />}
                trend={0.042}
                target={1.0}
                description="مختبر البشرية الجديدة"
              />
            </div>

            {/* Digital State Status */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Globe className="h-5 w-5 mr-2 text-purple-400" />
                  حالة الدولة الرقمية
                </CardTitle>
                <CardDescription className="text-slate-300">
                  أول دولة رقمية في التاريخ - نموذج المستقبل للعالم
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 rounded-lg bg-gradient-to-b from-purple-500/20 to-purple-600/20 border border-purple-500/30">
                    <Atom className="h-12 w-12 text-purple-400 mx-auto mb-3" />
                    <p className="text-2xl font-bold text-white">1024</p>
                    <p className="text-sm text-slate-300">كيوبت كمي نشط</p>
                    <p className="text-xs text-purple-300">حوسبة فائقة القدرة</p>
                  </div>
                  
                  <div className="text-center p-6 rounded-lg bg-gradient-to-b from-green-500/20 to-green-600/20 border border-green-500/30">
                    <Wind className="h-12 w-12 text-green-400 mx-auto mb-3" />
                    <p className="text-2xl font-bold text-white">-50K</p>
                    <p className="text-sm text-slate-300">طن CO₂ سنوياً</p>
                    <p className="text-xs text-green-300">كربون سالب محقق</p>
                  </div>
                  
                  <div className="text-center p-6 rounded-lg bg-gradient-to-b from-blue-500/20 to-blue-600/20 border border-blue-500/30">
                    <Users className="h-12 w-12 text-blue-400 mx-auto mb-3" />
                    <p className="text-2xl font-bold text-white">1M</p>
                    <p className="text-sm text-slate-300">مواطن رقمي</p>
                    <p className="text-xs text-blue-300">خدمات ذكية 99%</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Future Vision */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Target className="h-5 w-5 mr-2 text-pink-400" />
                  رؤية المستقبل 2030
                </CardTitle>
                <CardDescription className="text-slate-300">
                  أهداف نيوم الاستراتيجية لتصدير النموذج السعودي عالمياً
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { target: "1.5M سكان", progress: 67, description: "تجمع حضري مستدام" },
                    { target: "100% طاقة متجددة", progress: 98, description: "شبكة طاقة ذكية" },
                    { target: "0% انبعاثات", progress: 95, description: "كربون سالب" },
                    { target: "100% نقل مستقل", progress: 92, description: "تنقل بلا سائق" },
                    { target: "99% أتمتة الخدمات", progress: 94, description: "مدينة ذكية بالكامل" }
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 rounded-lg bg-slate-700/30">
                      <div>
                        <h4 className="font-medium text-white">{item.target}</h4>
                        <p className="text-sm text-slate-400">{item.description}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <Progress value={item.progress} className="w-24 h-2" />
                        <span className="text-sm font-medium text-white w-12">{item.progress}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Quantum Computing Tab */}
          <TabsContent value="quantum" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Atom className="h-5 w-5 mr-2 text-purple-400" />
                  البنية التحتية الكمية
                </CardTitle>
                <CardDescription className="text-slate-300">
                  معالجات الحوسبة الكمية المتقدمة لإدارة المدينة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {quantumProcessors.map((processor) => (
                    <QuantumProcessorCard key={processor.id} processor={processor} />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quantum Applications */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Brain className="h-5 w-5 mr-2 text-cyan-400" />
                  تطبيقات الحوسبة الكمية
                </CardTitle>
                <CardDescription className="text-slate-300">
                  المجالات التي تستفيد من التسريع الكمي في نيوم
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { app: "تحسين حركة المرور", advantage: "1000000x", impact: "تقليل الازدحام 95%" },
                    { app: "إدارة شبكة الطاقة", advantage: "500000x", impact: "كفاءة 98%" },
                    { app: "التنبؤ بالطقس", advantage: "750000x", impact: "دقة 99.5%" },
                    { app: "البحث الدوائي", advantage: "2000000x", impact: "تسريع الاكتشاف 80%" },
                    { app: "تحليل البيانات الضخمة", advantage: "1500000x", impact: "رؤى فورية" },
                    { app: "التشفير الكمي", advantage: "∞", impact: "أمان مطلق" }
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-4 rounded-lg bg-slate-700/30 border border-slate-600/30">
                      <div>
                        <h4 className="font-medium text-white">{item.app}</h4>
                        <p className="text-sm text-slate-400">{item.impact}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-purple-400">{item.advantage}</p>
                        <p className="text-xs text-slate-400">تسريع كمي</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Urban Systems Tab */}
          <TabsContent value="systems" className="space-y-6">
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Building2 className="h-5 w-5 mr-2 text-blue-400" />
                  الأنظمة الحضرية الذكية
                </CardTitle>
                <CardDescription className="text-slate-300">
                  البنية التحتية المتكاملة للمدينة المستقبلية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {urbanSystems.map((system) => (
                    <UrbanSystemCard key={system.id} system={system} />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* System Integration Map */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <MapPin className="h-5 w-5 mr-2 text-green-400" />
                  خريطة التكامل الحضري
                </CardTitle>
                <CardDescription className="text-slate-300">
                  الربط الذكي بين جميع أنظمة المدينة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {[
                    { zone: "ذا لاين", systems: 12, connectivity: 98 },
                    { zone: "أوكساجون", systems: 8, connectivity: 95 },
                    { zone: "تروجينا", systems: 6, connectivity: 92 },
                    { zone: "وادي نيوم التقني", systems: 15, connectivity: 99 }
                  ].map((zone) => (
                    <div key={zone.zone} className="text-center p-4 rounded-lg bg-slate-700/30">
                      <h4 className="font-medium text-white mb-2">{zone.zone}</h4>
                      <p className="text-2xl font-bold text-blue-400">{zone.systems}</p>
                      <p className="text-sm text-slate-400">أنظمة نشطة</p>
                      <div className="mt-2">
                        <Progress value={zone.connectivity} className="h-2" />
                        <p className="text-xs text-slate-400 mt-1">ربط {zone.connectivity}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Autonomous Transport Tab */}
          <TabsContent value="transport" className="space-y-6">
            {/* Fleet Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="إجمالي الأسطول"
                value={autonomousFleet.totalVehicles}
                icon={<Car />}
                suffix=""
                description="مركبة مستقلة بالكامل"
              />
              <MetricCard
                title="المركبات النشطة"
                value={autonomousFleet.activeVehicles}
                icon={<Activity />}
                suffix=""
                description="نسبة التشغيل 96%"
              />
              <MetricCard
                title="الرحلات المكتملة"
                value={autonomousFleet.tripsCompleted}
                icon={<CheckCircle />}
                suffix=""
                description="اليوم"
              />
              <MetricCard
                title="مستوى الاستقلالية"
                value={autonomousFleet.autonomyLevel}
                icon={<Brain />}
                suffix="/5"
                description="استقلالية كاملة"
              />
            </div>

            {/* Fleet Types */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Car className="h-5 w-5 mr-2 text-green-400" />
                  أنواع المركبات المستقلة
                </CardTitle>
                <CardDescription className="text-slate-300">
                  أسطول متنوع للنقل الحضري المستقبلي
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    { type: "كبسولات الهايبرلوب", count: 50, capacity: 28, energy: "رفع مغناطيسي" },
                    { type: "حافلات مستقلة", count: 100, capacity: 50, energy: "هيدروجين" },
                    { type: "كبسولات شخصية", count: 500, capacity: 4, energy: "كهربائي" },
                    { type: "طائرات توصيل", count: 1000, capacity: 2, energy: "كهربائي" },
                    { type: "مركبات الطوارئ", count: 25, capacity: 6, energy: "هيدروجين" },
                    { type: "نقل البضائع", count: 75, capacity: 20, energy: "هيدروجين" }
                  ].map((vehicle) => (
                    <div key={vehicle.type} className="p-4 rounded-lg bg-slate-700/30 border border-slate-600/30">
                      <h4 className="font-medium text-white mb-2">{vehicle.type}</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-slate-400">العدد:</span>
                          <span className="text-white">{vehicle.count}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">السعة:</span>
                          <span className="text-white">{vehicle.capacity}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400">الطاقة:</span>
                          <span className="text-green-400">{vehicle.energy}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Transport Network */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Globe className="h-5 w-5 mr-2 text-cyan-400" />
                  شبكة النقل الذكية
                </CardTitle>
                <CardDescription className="text-slate-300">
                  ربط ذكي وتحسين مستمر للمسارات
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 rounded-lg bg-gradient-to-b from-cyan-500/20 to-cyan-600/20 border border-cyan-500/30">
                    <Clock className="h-12 w-12 text-cyan-400 mx-auto mb-3" />
                    <p className="text-2xl font-bold text-white">2.3</p>
                    <p className="text-sm text-slate-300">دقيقة متوسط الانتظار</p>
                  </div>
                  
                  <div className="text-center p-6 rounded-lg bg-gradient-to-b from-green-500/20 to-green-600/20 border border-green-500/30">
                    <TrendingUp className="h-12 w-12 text-green-400 mx-auto mb-3" />
                    <p className="text-2xl font-bold text-white">96%</p>
                    <p className="text-sm text-slate-300">كفاءة الأسطول</p>
                  </div>
                  
                  <div className="text-center p-6 rounded-lg bg-gradient-to-b from-purple-500/20 to-purple-600/20 border border-purple-500/30">
                    <Shield className="h-12 w-12 text-purple-400 mx-auto mb-3" />
                    <p className="text-2xl font-bold text-white">99.9%</p>
                    <p className="text-sm text-slate-300">معدل الأمان</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sustainability Tab */}
          <TabsContent value="sustainability" className="space-y-6">
            {/* Sustainability Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="انبعاثات الكربون"
                value={-50000}
                icon={<Leaf />}
                suffix=" طن/سنة"
                description="كربون سالب محقق"
              />
              <MetricCard
                title="الطاقة المتجددة"
                value={1.0}
                icon={<Sun />}
                description="100% طاقة نظيفة"
              />
              <MetricCard
                title="كفاءة المياه"
                value={0.95}
                icon={<Droplets />}
                description="إعادة تدوير 95%"
              />
              <MetricCard
                title="جودة الهواء"
                value={15}
                icon={<Wind />}
                suffix=" AQI"
                description="ممتاز - أفضل عالمياً"
              />
            </div>

            {/* Energy Systems */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Battery className="h-5 w-5 mr-2 text-yellow-400" />
                  نظام الطاقة المتجددة
                </CardTitle>
                <CardDescription className="text-slate-300">
                  شبكة طاقة ذكية بنسبة 100% متجددة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-medium text-white">مصادر الطاقة</h4>
                    {[
                      { source: "الطاقة الشمسية", capacity: "3,000 MW", percentage: 60 },
                      { source: "طاقة الرياح", capacity: "1,500 MW", percentage: 30 },
                      { source: "الطاقة النووية الاندماجية", capacity: "500 MW", percentage: 10 }
                    ].map((item) => (
                      <div key={item.source} className="flex items-center justify-between p-3 rounded-lg bg-slate-700/30">
                        <div>
                          <h5 className="font-medium text-white">{item.source}</h5>
                          <p className="text-sm text-slate-400">{item.capacity}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <Progress value={item.percentage} className="w-20 h-2" />
                          <span className="text-sm text-white w-8">{item.percentage}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-medium text-white">إنتاج الهيدروجين</h4>
                    <div className="text-center p-6 rounded-lg bg-gradient-to-b from-blue-500/20 to-blue-600/20 border border-blue-500/30">
                      <Droplets className="h-12 w-12 text-blue-400 mx-auto mb-3" />
                      <p className="text-2xl font-bold text-white">500</p>
                      <p className="text-sm text-slate-300">طن/يوم هيدروجين أخضر</p>
                    </div>
                    
                    <div className="text-center p-6 rounded-lg bg-gradient-to-b from-green-500/20 to-green-600/20 border border-green-500/30">
                      <Battery className="h-12 w-12 text-green-400 mx-auto mb-3" />
                      <p className="text-2xl font-bold text-white">2,000</p>
                      <p className="text-sm text-slate-300">MWh تخزين طاقة</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Future Tab */}
          <TabsContent value="future" className="space-y-6">
            {/* Global Impact */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Globe className="h-5 w-5 mr-2 text-pink-400" />
                  التأثير العالمي لنموذج نيوم
                </CardTitle>
                <CardDescription className="text-slate-300">
                  تصدير النموذج السعودي للمدن المستقبلية عالمياً
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 rounded-lg bg-gradient-to-b from-pink-500/20 to-pink-600/20 border border-pink-500/30">
                    <Globe className="h-12 w-12 text-pink-400 mx-auto mb-3" />
                    <p className="text-2xl font-bold text-white">47</p>
                    <p className="text-sm text-slate-300">شراكة دولية</p>
                    <p className="text-xs text-pink-300">نقل التكنولوجيا</p>
                  </div>
                  
                  <div className="text-center p-6 rounded-lg bg-gradient-to-b from-cyan-500/20 to-cyan-600/20 border border-cyan-500/30">
                    <Brain className="h-12 w-12 text-cyan-400 mx-auto mb-3" />
                    <p className="text-2xl font-bold text-white">95%</p>
                    <p className="text-sm text-slate-300">إمكانية التصدير</p>
                    <p className="text-xs text-cyan-300">تقنيات نيوم</p>
                  </div>
                  
                  <div className="text-center p-6 rounded-lg bg-gradient-to-b from-purple-500/20 to-purple-600/20 border border-purple-500/30">
                    <Star className="h-12 w-12 text-purple-400 mx-auto mb-3" />
                    <p className="text-2xl font-bold text-white">92%</p>
                    <p className="text-sm text-slate-300">التأثير العالمي</p>
                    <p className="text-xs text-purple-300">نموذج المستقبل</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Future Roadmap */}
            <Card className="bg-slate-800/50 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center text-white">
                  <Rocket className="h-5 w-5 mr-2 text-orange-400" />
                  خارطة طريق المستقبل
                </CardTitle>
                <CardDescription className="text-slate-300">
                  الأهداف المستقبلية ومعالم التطوير حتى 2030
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {[
                    { year: "2025", milestone: "اكتمال ذا لاين - المرحلة الأولى", progress: 95, status: "قيد التنفيذ" },
                    { year: "2026", milestone: "تشغيل نظام النقل الكمي", progress: 75, status: "في التطوير" },
                    { year: "2027", milestone: "تحقيق الاستقلالية الطاقة 100%", progress: 85, status: "قيد التنفيذ" },
                    { year: "2028", milestone: "إطلاق مختبر الذكاء الاصطناعي العام", progress: 60, status: "مخطط" },
                    { year: "2029", milestone: "شبكة المدن الذكية الإقليمية", progress: 40, status: "مخطط" },
                    { year: "2030", milestone: "تصدير النموذج عالمياً", progress: 25, status: "مستقبلي" }
                  ].map((item) => (
                    <div key={item.year} className="flex items-center gap-4 p-4 rounded-lg bg-slate-700/30 border border-slate-600/30">
                      <div className="text-center min-w-[60px]">
                        <p className="text-lg font-bold text-white">{item.year}</p>
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium text-white">{item.milestone}</h4>
                        <div className="flex items-center gap-3 mt-2">
                          <Progress value={item.progress} className="flex-1 h-2" />
                          <span className="text-sm text-white w-12">{item.progress}%</span>
                        </div>
                      </div>
                      <Badge variant="outline" className={
                        item.status === 'قيد التنفيذ' ? 'border-green-500 text-green-400' :
                        item.status === 'في التطوير' ? 'border-blue-500 text-blue-400' :
                        item.status === 'مخطط' ? 'border-yellow-500 text-yellow-400' :
                        'border-purple-500 text-purple-400'
                      }>
                        {item.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default NEOMFuture;