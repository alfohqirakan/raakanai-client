import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PlanFeature {
  name: string;
  included: boolean;
}

interface Plan {
  id: string;
  name: string;
  nameAr: string;
  price: number;
  currency: string;
  period: string;
  periodAr: string;
  fileLimit: number;
  features: PlanFeature[];
  popular?: boolean;
  current?: boolean;
}

export default function Plans() {
  const { toast } = useToast();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const plans: Plan[] = [
    {
      id: "free",
      name: "Free Plan",
      nameAr: "الخطة المجانية",
      price: 0,
      currency: "SAR",
      period: "forever",
      periodAr: "مجاناً للأبد",
      fileLimit: 5,
      current: true,
      features: [
        { name: "تحليل 5 ملفات شهرياً", included: true },
        { name: "الملفات النصية والصور", included: true },
        { name: "تحليل أساسي بالذكاء الاصطناعي", included: true },
        { name: "محادثة مع راكان AI", included: true },
        { name: "تقارير أساسية", included: true },
        { name: "تقارير PDF متقدمة", included: false },
        { name: "تحليل الفيديو والصوت", included: false },
        { name: "أولوية في المعالجة", included: false },
        { name: "دعم فني مخصص", included: false }
      ]
    },
    {
      id: "pro",
      name: "Professional Plan",
      nameAr: "خطة المحترفين",
      price: 99,
      currency: "SAR",
      period: "monthly",
      periodAr: "شهرياً",
      fileLimit: 100,
      popular: true,
      features: [
        { name: "تحليل 100 ملف شهرياً", included: true },
        { name: "جميع أنواع الملفات", included: true },
        { name: "تحليل متقدم بالذكاء الاصطناعي", included: true },
        { name: "محادثة غير محدودة مع راكان", included: true },
        { name: "تقارير PDF ذكية", included: true },
        { name: "تحليل الفيديو والصوت", included: true },
        { name: "أولوية في المعالجة", included: true },
        { name: "دعم فني مخصص", included: true },
        { name: "إحصائيات تفصيلية", included: true }
      ]
    }
  ];

  const subscribeMutation = useMutation({
    mutationFn: async (planId: string) => {
      return await apiRequest('POST', `/api/subscription/subscribe`, { planId });
    },
    onSuccess: () => {
      toast({
        title: "تم الاشتراك بنجاح!",
        description: "تم تفعيل خطتك الجديدة",
      });
    },
    onError: (error) => {
      toast({
        title: "فشل في الاشتراك",
        description: (error as Error).message,
        variant: "destructive",
      });
    },
  });

  const handleSubscribe = (planId: string) => {
    setSelectedPlan(planId);
    subscribeMutation.mutate(planId);
  };

  return (
    <div className="min-h-screen bg-deep-space text-white">
      {/* Header */}
      <div className="bg-charcoal border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-3">
                <i className="fas fa-crown text-electric-blue"></i>
                خطط الاشتراك
              </h1>
              <p className="text-gray-400 mt-2">اختر الخطة المناسبة لاحتياجاتك مع راكان AI</p>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-400">
              <i className="fas fa-robot text-electric-blue"></i>
              <span>مدعوم بتقنية راكان الذكية</span>
            </div>
          </div>
        </div>
      </div>

      {/* Plans Grid */}
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative bg-charcoal border rounded-2xl p-8 transition-all hover:scale-105 ${
                plan.popular
                  ? 'border-electric-blue shadow-electric-blue/20 shadow-2xl'
                  : plan.current
                  ? 'border-green-500'
                  : 'border-gray-600 hover:border-electric-blue/50'
              }`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-electric-blue text-white px-6 py-2 rounded-full text-sm font-medium">
                    الأكثر شعبية
                  </div>
                </div>
              )}

              {/* Current Plan Badge */}
              {plan.current && (
                <div className="absolute -top-4 right-6">
                  <div className="bg-green-500 text-white px-4 py-2 rounded-full text-sm font-medium">
                    الخطة الحالية
                  </div>
                </div>
              )}

              {/* Plan Header */}
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold mb-2">{plan.nameAr}</h2>
                <div className="mb-4">
                  <span className="text-4xl font-bold text-electric-blue">
                    {plan.price === 0 ? 'مجاناً' : `${plan.price} ${plan.currency}`}
                  </span>
                  {plan.price > 0 && (
                    <span className="text-gray-400 text-sm">/ {plan.periodAr}</span>
                  )}
                </div>
                <p className="text-gray-400">
                  حتى {plan.fileLimit} ملف {plan.price === 0 ? 'إجمالي' : 'شهرياً'}
                </p>
              </div>

              {/* Features List */}
              <div className="mb-8">
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-3">
                      <i className={`fas ${
                        feature.included 
                          ? 'fa-check-circle text-electric-blue' 
                          : 'fa-times-circle text-gray-500'
                      }`}></i>
                      <span className={feature.included ? 'text-white' : 'text-gray-500'}>
                        {feature.name}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <div className="text-center">
                {plan.current ? (
                  <button
                    disabled
                    className="w-full bg-green-500/20 text-green-400 border border-green-500 px-6 py-3 rounded-xl font-medium cursor-not-allowed"
                  >
                    الخطة النشطة
                  </button>
                ) : (
                  <button
                    onClick={() => handleSubscribe(plan.id)}
                    disabled={subscribeMutation.isPending && selectedPlan === plan.id}
                    className={`w-full px-6 py-3 rounded-xl font-medium transition-all ${
                      plan.popular
                        ? 'bg-electric-blue hover:bg-electric-blue/90 text-white'
                        : 'bg-gray-700 hover:bg-gray-600 text-white border border-gray-600 hover:border-electric-blue'
                    } ${
                      subscribeMutation.isPending && selectedPlan === plan.id
                        ? 'opacity-50 cursor-not-allowed'
                        : ''
                    }`}
                  >
                    {subscribeMutation.isPending && selectedPlan === plan.id ? (
                      <div className="flex items-center justify-center gap-2">
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        جاري المعالجة...
                      </div>
                    ) : plan.price === 0 ? (
                      'ابدأ مجاناً'
                    ) : (
                      'اشترك الآن'
                    )}
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-12 text-center">
          <div className="bg-charcoal border border-gray-600 rounded-xl p-6">
            <h3 className="text-xl font-semibold mb-4 flex items-center justify-center gap-2">
              <i className="fas fa-shield-alt text-electric-blue"></i>
              ضمان الجودة
            </h3>
            <p className="text-gray-400 max-w-2xl mx-auto">
              جميع الخطط تتضمن أمان متقدم، تشفير البيانات، ومعالجة فورية بتقنية راكان AI المتطورة. 
              يمكنك الترقية أو التراجع في أي وقت بدون التزامات طويلة المدى.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}