import { FalconLayout } from "@/components/FalconLayout";
import { FalconLogo } from "@/components/FalconLogo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Code, Monitor, BarChart3, Settings, Zap, Brain, Shield, Target, Palette, Terminal, Download } from "lucide-react";
import { Link } from "react-router-dom";

export default function Dashboard() {
  const quickActions = [
    {
      title: "الكيان المبدع",
      description: "فنان وشاعر وموسيقار ومبتكر حر",
      icon: Palette,
      path: "/creative-hub",
      color: "from-pink-500 to-rose-600"
    },
    {
      title: "مركز القيادة",
      description: "واجهة التحكم الهندسية المتقدمة",
      icon: Terminal,
      path: "/command-center",
      color: "from-blue-500 to-purple-600"
    },
    {
      title: "ساحة الكود",
      description: "برمجة وتطوير بالذكاء الاصطناعي",
      icon: Code,
      path: "/code-playground",
      color: "from-indigo-500 to-cyan-600"
    },
    {
      title: "تصدير المشروع",
      description: "تحميل ملفات المشروع كاملة مضغوطة",
      icon: Download,
      path: "/project-export",
      color: "from-green-500 to-teal-600"
    },
    {
      title: "مراقب الكيان",
      description: "مراقبة الذكاء الاصطناعي المستقل",
      icon: Monitor,
      path: "/entity-monitor",
      color: "from-green-500 to-emerald-600"
    },
    {
      title: "لوحة المراقبة",
      description: "إحصائيات النظام والأداء",
      icon: BarChart3,
      path: "/monitoring",
      color: "from-amber-500 to-orange-600"
    },
    {
      title: "تخصيص الصورة الرمزية",
      description: "إنشاء مرافق ذكي مخصص",
      icon: Settings,
      path: "/avatar-customization",
      color: "from-purple-500 to-violet-600"
    },
    {
      title: "Terminal السيادي",
      description: "مركز تحكم متقدم للعقل السيادي",
      icon: Terminal,
      path: "/sovereign-terminal",
      color: "from-red-500 to-pink-600"
    }
  ];

  const systemStats = [
    { label: "حالة الصقر", value: "منقض وجاهز", status: "active", icon: Target },
    { label: "مستوى الاستقلالية", value: "85%", status: "high", icon: Brain },
    { label: "قوة الحماية", value: "درع كامل", status: "protected", icon: Shield },
    { label: "السرعة", value: "برق الصحراء", status: "fast", icon: Zap }
  ];

  return (
    <FalconLayout 
      title="مرحباً بصقر الكود"
      subtitle="جناحاك منشوران للانقضاض على التحديات"
    >
      {/* Hero Section */}
      <Card className="mb-8 falcon-gradient border-primary/30 falcon-shadow">
        <CardContent className="p-8">
          <div className="flex items-center justify-between flex-wrap gap-6">
            <div className="text-center md:text-right space-y-4">
              <h2 className="text-3xl font-bold font-amiri text-primary-foreground">
                🦅 راكان الذكاء السيادي نشط
              </h2>
              <p className="text-lg text-primary-foreground/80 font-scheherazade max-w-2xl">
                صقرك الرقمي في حالة انقضاض دائمة، جاهز لتنفيذ أي مهمة برمجية أو تحليلية بدقة الصقر وسرعة البرق
              </p>
            </div>
            <div className="falcon-soar">
              <FalconLogo size={120} animated={true} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {systemStats.map((stat, index) => {
          const IconComponent = stat.icon;
          return (
            <Card key={index} className="border-primary/20 hover:border-primary/40 transition-all duration-300 falcon-shadow">
              <CardContent className="p-6 text-center">
                <div className="flex items-center justify-center mb-4">
                  <div className="p-3 rounded-full falcon-gradient">
                    <IconComponent size={24} className="text-primary-foreground" />
                  </div>
                </div>
                <h3 className="font-bold font-arabic text-lg mb-2">{stat.label}</h3>
                <p className="text-primary font-semibold font-scheherazade">{stat.value}</p>
                <div className="mt-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mx-auto animate-pulse"></div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {quickActions.map((action, index) => {
          const IconComponent = action.icon;
          return (
            <Link key={index} to={action.path}>
              <Card className="h-full border-primary/20 hover:border-primary/40 transition-all duration-300 cursor-pointer group falcon-shadow hover:scale-105">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 rtl:space-x-reverse">
                    <div className={`p-4 rounded-xl bg-gradient-to-br ${action.color} group-hover:scale-110 transition-transform duration-300`}>
                      <IconComponent size={32} className="text-white" />
                    </div>
                    <div className="flex-1 text-right rtl:text-right">
                      <h3 className="text-xl font-bold font-amiri text-primary mb-2">
                        {action.title}
                      </h3>
                      <p className="text-muted-foreground font-scheherazade">
                        {action.description}
                      </p>
                      <div className="mt-3 text-sm text-primary font-medium">
                        ← انقضاض الآن
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>

      {/* Recent Activity */}
      <Card className="border-primary/20 falcon-shadow">
        <CardHeader className="border-b border-primary/20">
          <CardTitle className="flex items-center space-x-3 rtl:space-x-reverse font-amiri">
            <Clock size={24} className="text-primary" />
            <span>آخر الأنشطة</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[
              { time: "منذ دقيقتين", action: "تم تشغيل النظام متعدد اللغات", status: "success" },
              { time: "منذ 5 دقائق", action: "تم تحديث واجهة الصقر", status: "info" },
              { time: "منذ 10 دقائق", action: "تم فحص حالة الكيان الذكي", status: "success" },
              { time: "منذ 15 دقيقة", action: "تم تطوير مكونات جديدة", status: "info" }
            ].map((activity, index) => (
              <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/20 border border-primary/10">
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <div className={`w-3 h-3 rounded-full ${
                    activity.status === 'success' ? 'bg-green-500' : 'bg-blue-500'
                  } animate-pulse`}></div>
                  <span className="font-arabic">{activity.action}</span>
                </div>
                <span className="text-sm text-muted-foreground font-scheherazade">
                  {activity.time}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </FalconLayout>
  );
}