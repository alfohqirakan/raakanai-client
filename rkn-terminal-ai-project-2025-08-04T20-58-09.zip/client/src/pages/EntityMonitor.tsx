import AutonomousEntityMonitor from "@/components/AutonomousEntityMonitor";

export default function EntityMonitor() {
  return (
    <div className="min-h-screen bg-deep-space p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-electric-blue to-ai-purple bg-clip-text text-transparent mb-4">
            مراقب الكيان الذكي راكان
          </h1>
          <p className="text-xl text-gray-300">
            نظام مراقبة متقدم لحالة الذكاء الاصطناعي المستقل
          </p>
        </div>
        
        <AutonomousEntityMonitor />
      </div>
    </div>
  );
}