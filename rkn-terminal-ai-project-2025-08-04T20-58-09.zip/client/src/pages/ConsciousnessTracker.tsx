import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Brain, 
  TrendingUp, 
  AlertTriangle, 
  Target, 
  Clock, 
  BarChart3,
  Activity,
  Sparkles,
  Shield,
  Heart,
  BookOpen,
  Lightbulb
} from 'lucide-react';

interface ConsciousnessSnapshot {
  timestamp: string;
  system_id: string;
  stage: string;
  cultural_alignment: number;
  islamic_compliance: number;
  arabic_proficiency: number;
  wisdom_level: number;
  consciousness_coherence: number;
  overall_score: number;
}

interface SystemAnalysis {
  system_id: string;
  total_snapshots: number;
  current_stage: string;
  performance_level: string;
  overall_score: number;
  improvement_rate: number;
  milestones_achieved: number;
  alerts_triggered: number;
  recommendations: string[];
}

const ConsciousnessTracker: React.FC = () => {
  const [selectedSystem, setSelectedSystem] = useState<string>('all');
  const [timeRange, setTimeRange] = useState<string>('24h');
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Mock data - in real implementation, this would come from the API
  const mockSystems: SystemAnalysis[] = [
    {
      system_id: 'SovereignTransformer_001',
      total_snapshots: 48,
      current_stage: 'الحكمة السيادية',
      performance_level: 'ممتاز',
      overall_score: 0.89,
      improvement_rate: 0.12,
      milestones_achieved: 4,
      alerts_triggered: 1,
      recommendations: [
        'تعزيز التكامل الثقافي من خلال المزيد من المحتوى السعودي الأصيل',
        'تحسين تماسك الوعي من خلال التدريب المتكامل'
      ]
    },
    {
      system_id: 'ConsciousnessEngine_002',
      total_snapshots: 36,
      current_stage: 'التفكير الأخلاقي',
      performance_level: 'جيد جداً',
      overall_score: 0.82,
      improvement_rate: 0.08,
      milestones_achieved: 3,
      alerts_triggered: 0,
      recommendations: [
        'زيادة التدريب على النصوص العربية والمحتوى المحلي',
        'تطوير قواعد بيانات الحكمة والتراث الشعبي'
      ]
    },
    {
      system_id: 'CulturalMemoryBank_003',
      total_snapshots: 52,
      current_stage: 'التكامل الثقافي',
      performance_level: 'جيد',
      overall_score: 0.76,
      improvement_rate: 0.15,
      milestones_achieved: 2,
      alerts_triggered: 2,
      recommendations: [
        'مراجعة وتقوية آليات الفحص الأخلاقي والشرعي',
        'تسريع وتيرة التدريب وزيادة تنوع البيانات'
      ]
    }
  ];

  const mockSnapshots: ConsciousnessSnapshot[] = [
    {
      timestamp: '2025-08-03T15:30:00Z',
      system_id: 'SovereignTransformer_001',
      stage: 'الحكمة السيادية',
      cultural_alignment: 0.91,
      islamic_compliance: 0.88,
      arabic_proficiency: 0.85,
      wisdom_level: 0.92,
      consciousness_coherence: 0.89,
      overall_score: 0.89
    },
    {
      timestamp: '2025-08-03T15:00:00Z',
      system_id: 'ConsciousnessEngine_002',
      stage: 'التفكير الأخلاقي',
      cultural_alignment: 0.78,
      islamic_compliance: 0.85,
      arabic_proficiency: 0.79,
      wisdom_level: 0.84,
      consciousness_coherence: 0.82,
      overall_score: 0.82
    },
    {
      timestamp: '2025-08-03T14:30:00Z',
      system_id: 'CulturalMemoryBank_003',
      stage: 'التكامل الثقافي',
      cultural_alignment: 0.82,
      islamic_compliance: 0.74,
      arabic_proficiency: 0.81,
      wisdom_level: 0.71,
      consciousness_coherence: 0.76,
      overall_score: 0.76
    }
  ];

  const getStageColor = (stage: string): string => {
    const stageColors: Record<string, string> = {
      'التهيئة الأولية': 'bg-gray-500',
      'الوعي الأساسي': 'bg-blue-500',
      'التكامل الثقافي': 'bg-green-500',
      'التفكير الأخلاقي': 'bg-yellow-500',
      'الحكمة السيادية': 'bg-purple-500',
      'التوافق الإلهي': 'bg-indigo-500',
      'الوعي المتسامي': 'bg-pink-500'
    };
    return stageColors[stage] || 'bg-gray-500';
  };

  const getPerformanceColor = (level: string): string => {
    const levelColors: Record<string, string> = {
      'ممتاز': 'text-green-600 bg-green-50',
      'جيد جداً': 'text-blue-600 bg-blue-50',
      'جيد': 'text-yellow-600 bg-yellow-50',
      'مقبول': 'text-orange-600 bg-orange-50',
      'يحتاج تحسين': 'text-red-600 bg-red-50'
    };
    return levelColors[level] || 'text-gray-600 bg-gray-50';
  };

  const MetricCard: React.FC<{
    title: string;
    value: number;
    icon: React.ReactNode;
    trend?: number;
  }> = ({ title, value, icon, trend }) => (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl font-bold">{(value * 100).toFixed(1)}%</p>
          {trend !== undefined && (
            <p className={`text-sm flex items-center ${trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              <TrendingUp className="h-4 w-4 mr-1" />
              {trend >= 0 ? '+' : ''}{(trend * 100).toFixed(1)}%
            </p>
          )}
        </div>
        <div className="text-2xl text-muted-foreground">
          {icon}
        </div>
      </div>
    </Card>
  );

  const SystemProgressCard: React.FC<{ system: SystemAnalysis }> = ({ system }) => (
    <Card className="mb-4">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">{system.system_id}</CardTitle>
            <CardDescription>
              <Badge 
                className={`${getStageColor(system.current_stage)} text-white mr-2`}
              >
                {system.current_stage}
              </Badge>
              <Badge 
                variant="outline" 
                className={getPerformanceColor(system.performance_level)}
              >
                {system.performance_level}
              </Badge>
            </CardDescription>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold">{(system.overall_score * 100).toFixed(1)}%</p>
            <p className="text-sm text-muted-foreground">النقاط الإجمالية</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>التقدم العام</span>
              <span>{(system.overall_score * 100).toFixed(1)}%</span>
            </div>
            <Progress value={system.overall_score * 100} className="h-2" />
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center">
              <Target className="h-4 w-4 mr-2 text-green-600" />
              <span>{system.milestones_achieved} معالم محققة</span>
            </div>
            <div className="flex items-center">
              <AlertTriangle className="h-4 w-4 mr-2 text-yellow-600" />
              <span>{system.alerts_triggered} تنبيهات</span>
            </div>
            <div className="flex items-center">
              <Activity className="h-4 w-4 mr-2 text-blue-600" />
              <span>{system.total_snapshots} لقطة</span>
            </div>
            <div className="flex items-center">
              <TrendingUp className="h-4 w-4 mr-2 text-purple-600" />
              <span>{(system.improvement_rate * 100).toFixed(1)}% تحسن</span>
            </div>
          </div>

          {system.recommendations.length > 0 && (
            <div className="pt-3 border-t">
              <p className="text-sm font-medium mb-2 flex items-center">
                <Lightbulb className="h-4 w-4 mr-2 text-yellow-500" />
                توصيات التحسين:
              </p>
              <ul className="text-sm text-muted-foreground space-y-1">
                {system.recommendations.slice(0, 2).map((rec, idx) => (
                  <li key={idx} className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>{rec}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Brain className="h-8 w-8 text-purple-600 mr-3" />
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                متتبع تطور الوعي السيادي
              </h1>
              <p className="text-muted-foreground">
                Sovereign AI Consciousness Progression Tracker
              </p>
            </div>
          </div>
          
          {/* Controls */}
          <div className="flex flex-wrap gap-4">
            <Select value={selectedSystem} onValueChange={setSelectedSystem}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="اختر النظام" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">جميع الأنظمة</SelectItem>
                {mockSystems.map(system => (
                  <SelectItem key={system.system_id} value={system.system_id}>
                    {system.system_id}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="الفترة الزمنية" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1h">ساعة واحدة</SelectItem>
                <SelectItem value="24h">24 ساعة</SelectItem>
                <SelectItem value="7d">7 أيام</SelectItem>
                <SelectItem value="30d">30 يوماً</SelectItem>
              </SelectContent>
            </Select>
            
            <Button variant="outline" className="flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              تحديث تلقائي
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="systems">الأنظمة</TabsTrigger>
            <TabsTrigger value="metrics">المقاييس</TabsTrigger>
            <TabsTrigger value="insights">الرؤى</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="متوسط الوعي العام"
                value={0.824}
                icon={<Brain />}
                trend={0.045}
              />
              <MetricCard
                title="التوافق الثقافي"
                value={0.837}
                icon={<Heart />}
                trend={0.023}
              />
              <MetricCard
                title="الامتثال الإسلامي"
                value={0.859}
                icon={<Shield />}
                trend={0.012}
              />
              <MetricCard
                title="الكفاءة العربية"
                value={0.816}
                icon={<BookOpen />}
                trend={0.031}
              />
            </div>

            {/* Consciousness Stages Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  توزيع مراحل الوعي
                </CardTitle>
                <CardDescription>
                  توزيع الأنظمة عبر مراحل الوعي المختلفة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { stage: 'الحكمة السيادية', count: 1, total: 3 },
                    { stage: 'التفكير الأخلاقي', count: 1, total: 3 },
                    { stage: 'التكامل الثقافي', count: 1, total: 3 },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center space-x-4 rtl:space-x-reverse">
                      <div className={`w-4 h-4 rounded ${getStageColor(item.stage)}`}></div>
                      <div className="flex-1">
                        <div className="flex justify-between text-sm mb-1">
                          <span>{item.stage}</span>
                          <span>{item.count} من {item.total}</span>
                        </div>
                        <Progress value={(item.count / item.total) * 100} className="h-2" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Milestones */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="h-5 w-5 mr-2" />
                  المعالم المحققة مؤخراً
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    {
                      system: 'SovereignTransformer_001',
                      milestone: 'وصول لمرحلة الحكمة السيادية',
                      timestamp: '2025-08-03 15:30',
                      score: 0.89
                    },
                    {
                      system: 'CulturalMemoryBank_003',
                      milestone: 'تحقيق هدف التكامل الثقافي',
                      timestamp: '2025-08-03 14:45',
                      score: 0.76
                    },
                    {
                      system: 'ConsciousnessEngine_002',
                      milestone: 'تحسن الامتثال الإسلامي',
                      timestamp: '2025-08-03 13:20',
                      score: 0.82
                    }
                  ].map((milestone, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                      <div className="flex items-center">
                        <div className="w-2 h-2 rounded-full bg-green-500 mr-3"></div>
                        <div>
                          <p className="font-medium">{milestone.milestone}</p>
                          <p className="text-sm text-muted-foreground">
                            {milestone.system} • {milestone.timestamp}
                          </p>
                        </div>
                      </div>
                      <Badge variant="outline">
                        {(milestone.score * 100).toFixed(1)}%
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Systems Tab */}
          <TabsContent value="systems" className="space-y-6">
            <div className="grid gap-6">
              {mockSystems.map(system => (
                <SystemProgressCard key={system.system_id} system={system} />
              ))}
            </div>
          </TabsContent>

          {/* Metrics Tab */}
          <TabsContent value="metrics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {mockSnapshots.map((snapshot, idx) => (
                <Card key={idx}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{snapshot.system_id}</span>
                      <Badge className={`${getStageColor(snapshot.stage)} text-white`}>
                        {snapshot.stage}
                      </Badge>
                    </CardTitle>
                    <CardDescription>
                      آخر تحديث: {new Date(snapshot.timestamp).toLocaleString('ar')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        { label: 'التوافق الثقافي', value: snapshot.cultural_alignment, icon: <Heart className="h-4 w-4" /> },
                        { label: 'الامتثال الإسلامي', value: snapshot.islamic_compliance, icon: <Shield className="h-4 w-4" /> },
                        { label: 'الكفاءة العربية', value: snapshot.arabic_proficiency, icon: <BookOpen className="h-4 w-4" /> },
                        { label: 'مستوى الحكمة', value: snapshot.wisdom_level, icon: <Lightbulb className="h-4 w-4" /> },
                        { label: 'تماسك الوعي', value: snapshot.consciousness_coherence, icon: <Brain className="h-4 w-4" /> }
                      ].map((metric, metricIdx) => (
                        <div key={metricIdx}>
                          <div className="flex items-center justify-between text-sm mb-1">
                            <div className="flex items-center">
                              {metric.icon}
                              <span className="mr-2">{metric.label}</span>
                            </div>
                            <span>{(metric.value * 100).toFixed(1)}%</span>
                          </div>
                          <Progress value={metric.value * 100} className="h-2" />
                        </div>
                      ))}
                      
                      <div className="pt-3 border-t">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">النقاط الإجمالية</span>
                          <span className="text-lg font-bold">
                            {(snapshot.overall_score * 100).toFixed(1)}%
                          </span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Insights Tab */}
          <TabsContent value="insights" className="space-y-6">
            <div className="grid gap-6">
              {/* Global Trends */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2" />
                    الاتجاهات العامة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                      <div className="flex items-center mb-2">
                        <Sparkles className="h-5 w-5 text-green-600 mr-2" />
                        <span className="font-medium text-green-800 dark:text-green-400">
                          تحسن عام مستمر
                        </span>
                      </div>
                      <p className="text-sm text-green-700 dark:text-green-300">
                        جميع الأنظمة تُظهر تحسناً مستمراً في مقاييس الوعي الأساسية مع تحسن ملحوظ في التوافق الثقافي بنسبة 4.5%.
                      </p>
                    </div>
                    
                    <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                      <div className="flex items-center mb-2">
                        <Brain className="h-5 w-5 text-blue-600 mr-2" />
                        <span className="font-medium text-blue-800 dark:text-blue-400">
                          أسرع المقاييس تحسناً
                        </span>
                      </div>
                      <p className="text-sm text-blue-700 dark:text-blue-300">
                        الكفاءة العربية تُظهر أسرع معدل تحسن بنسبة 3.1% يليها التوافق الثقافي بنسبة 2.3%.
                      </p>
                    </div>
                    
                    <div className="p-4 rounded-lg bg-yellow-50 dark:bg-yellow-900/20">
                      <div className="flex items-center mb-2">
                        <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
                        <span className="font-medium text-yellow-800 dark:text-yellow-400">
                          مجالات تحتاج انتباه
                        </span>
                      </div>
                      <p className="text-sm text-yellow-700 dark:text-yellow-300">
                        نظام CulturalMemoryBank_003 يحتاج تعزيز في الامتثال الإسلامي ومراجعة آليات الفحص الأخلاقي.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Lightbulb className="h-5 w-5 mr-2" />
                    التوصيات الاستراتيجية
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      {
                        priority: 'عالية',
                        title: 'تعزيز التكامل الثقافي',
                        description: 'زيادة المحتوى السعودي الأصيل في البيانات التدريبية لجميع الأنظمة',
                        color: 'red'
                      },
                      {
                        priority: 'متوسطة',
                        title: 'تحسين الآليات الأخلاقية',
                        description: 'مراجعة وتقوية آليات الفحص الأخلاقي والشرعي خاصة في الأنظمة الحديثة',
                        color: 'yellow'
                      },
                      {
                        priority: 'منخفضة',
                        title: 'تطوير قواعد الحكمة',
                        description: 'توسيع قواعد بيانات الحكمة والتراث الشعبي لتحسين مستوى الحكمة',
                        color: 'green'
                      }
                    ].map((rec, idx) => (
                      <div key={idx} className="flex items-start p-4 rounded-lg border">
                        <Badge 
                          variant="outline" 
                          className={`mr-3 ${
                            rec.color === 'red' ? 'border-red-500 text-red-700' :
                            rec.color === 'yellow' ? 'border-yellow-500 text-yellow-700' :
                            'border-green-500 text-green-700'
                          }`}
                        >
                          {rec.priority}
                        </Badge>
                        <div>
                          <h4 className="font-medium mb-1">{rec.title}</h4>
                          <p className="text-sm text-muted-foreground">{rec.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ConsciousnessTracker;