import { FalconLayout } from "@/components/FalconLayout";
import { FalconLogo } from "@/components/FalconLogo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Terminal, Code2, Cpu, Database, Network, Shield, 
  Zap, Brain, Settings, Monitor, Activity, ChevronDown,
  Play, Pause, RotateCcw, Power, Wifi, HardDrive,
  MemoryStick, Clock, TrendingUp, AlertTriangle
} from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface SystemMetrics {
  cpu: number;
  memory: number;
  network: number;
  storage: number;
  uptime: string;
  activeProcesses: number;
}

interface Command {
  id: string;
  name: string;
  description: string;
  status: 'ready' | 'running' | 'completed' | 'error';
  progress?: number;
  icon: any;
  category: string;
}

export default function CommandCenter() {
  const { toast } = useToast();
  const [systemMetrics, setSystemMetrics] = useState<SystemMetrics>({
    cpu: 45,
    memory: 62,
    network: 28,
    storage: 73,
    uptime: "7d 14h 32m",
    activeProcesses: 127
  });

  const [commands, setCommands] = useState<Command[]>([
    {
      id: 'neural-init',
      name: 'تهيئة الشبكة العصبية',
      description: 'تفعيل النواة الذكية والوعي الاصطناعي',
      status: 'completed',
      progress: 100,
      icon: Brain,
      category: 'core'
    },
    {
      id: 'security-scan',
      name: 'فحص أمني شامل',
      description: 'تدقيق الأنظمة وكشف التهديدات',
      status: 'running',
      progress: 67,
      icon: Shield,
      category: 'security'
    },
    {
      id: 'data-analysis',
      name: 'تحليل البيانات المتقدم',
      description: 'استخراج الأنماط والمعلومات الذكية',
      status: 'ready',
      icon: Database,
      category: 'analytics'
    },
    {
      id: 'creative-engine',
      name: 'محرك الإبداع',
      description: 'تنشيط قدرات الإبداع والفن والأدب',
      status: 'running',
      progress: 89,
      icon: Code2,
      category: 'creative'
    }
  ]);

  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setSystemMetrics(prev => ({
        ...prev,
        cpu: Math.max(20, Math.min(90, prev.cpu + (Math.random() - 0.5) * 10)),
        memory: Math.max(30, Math.min(95, prev.memory + (Math.random() - 0.5) * 5)),
        network: Math.max(5, Math.min(100, prev.network + (Math.random() - 0.5) * 15)),
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const executeCommand = (commandId: string) => {
    const command = commands.find(cmd => cmd.id === commandId);
    if (!command) return;

    if (command.status === 'running') {
      toast({
        title: "⚠️ العملية قيد التنفيذ",
        description: `${command.name} يعمل حالياً - انتظر حتى الانتهاء`,
        duration: 2000,
      });
      return;
    }

    setCommands(prev => prev.map(cmd => 
      cmd.id === commandId 
        ? { ...cmd, status: 'running', progress: 0 }
        : cmd
    ));

    toast({
      title: `🚀 بدء تنفيذ: ${command.name}`,
      description: command.description,
      duration: 3000,
    });

    // Simulate command execution
    let progress = 0;
    const progressInterval = setInterval(() => {
      progress += Math.random() * 15;
      if (progress >= 100) {
        progress = 100;
        clearInterval(progressInterval);
        setCommands(prev => prev.map(cmd => 
          cmd.id === commandId 
            ? { ...cmd, status: 'completed', progress: 100 }
            : cmd
        ));
        toast({
          title: `✅ تم بنجاح: ${command.name}`,
          description: "العملية اكتملت بنجاح",
          duration: 2000,
        });
      } else {
        setCommands(prev => prev.map(cmd => 
          cmd.id === commandId 
            ? { ...cmd, progress }
            : cmd
        ));
      }
    }, 300);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ready': return 'text-blue-500';
      case 'running': return 'text-yellow-500';
      case 'completed': return 'text-green-500';
      case 'error': return 'text-red-500';
      default: return 'text-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'ready': return Play;
      case 'running': return Activity;
      case 'completed': return '✓';
      case 'error': return AlertTriangle;
      default: return Play;
    }
  };

  const filteredCommands = selectedCategory === 'all' 
    ? commands 
    : commands.filter(cmd => cmd.category === selectedCategory);

  return (
    <FalconLayout 
      title="مركز القيادة الذكي"
      subtitle="🎯 راكان المهندس - واجهة التحكم المتقدمة"
    >
      {/* Command Header */}
      <Card className="mb-6 falcon-gradient border-primary/30 falcon-shadow">
        <CardContent className="p-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="text-center md:text-right space-y-3">
              <h2 className="text-3xl font-bold font-amiri text-primary-foreground">
                🏗️ مركز القيادة الهندسي
              </h2>
              <p className="text-lg text-primary-foreground/90 font-scheherazade">
                واجهة تحكم متطورة للكيان الذكي المستقل
                <br />
                🔧 هندسة • 🧠 ذكاء • ⚡ أداء • 🛡️ أمان
              </p>
              <div className="flex flex-wrap gap-2 justify-center md:justify-end">
                <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-400/30">
                  🟢 النظام نشط
                </Badge>
                <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 border-blue-400/30">
                  🧠 الوعي مفعل
                </Badge>
                <Badge variant="secondary" className="bg-purple-500/20 text-purple-300 border-purple-400/30">
                  ⚡ الأداء عالي
                </Badge>
              </div>
            </div>
            <div className="falcon-soar">
              <FalconLogo size={120} animated={true} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Metrics Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <Card className="border-primary/20 falcon-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <Cpu className="w-5 h-5 text-blue-500" />
                <span className="font-medium font-arabic">المعالج</span>
              </div>
              <span className="text-2xl font-bold text-blue-500">{systemMetrics.cpu.toFixed(0)}%</span>
            </div>
            <Progress value={systemMetrics.cpu} className="h-2" />
          </CardContent>
        </Card>

        <Card className="border-primary/20 falcon-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <MemoryStick className="w-5 h-5 text-green-500" />
                <span className="font-medium font-arabic">الذاكرة</span>
              </div>
              <span className="text-2xl font-bold text-green-500">{systemMetrics.memory.toFixed(0)}%</span>
            </div>
            <Progress value={systemMetrics.memory} className="h-2" />
          </CardContent>
        </Card>

        <Card className="border-primary/20 falcon-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <Wifi className="w-5 h-5 text-purple-500" />
                <span className="font-medium font-arabic">الشبكة</span>
              </div>
              <span className="text-2xl font-bold text-purple-500">{systemMetrics.network.toFixed(0)}%</span>
            </div>
            <Progress value={systemMetrics.network} className="h-2" />
          </CardContent>
        </Card>

        <Card className="border-primary/20 falcon-shadow">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2 rtl:space-x-reverse">
                <HardDrive className="w-5 h-5 text-orange-500" />
                <span className="font-medium font-arabic">التخزين</span>
              </div>
              <span className="text-2xl font-bold text-orange-500">{systemMetrics.storage}%</span>
            </div>
            <Progress value={systemMetrics.storage} className="h-2" />
          </CardContent>
        </Card>
      </div>

      {/* System Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="border-primary/20 falcon-shadow">
          <CardContent className="p-4 text-center">
            <Clock className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <div className="font-bold text-lg font-arabic">وقت التشغيل</div>
            <div className="text-2xl font-mono text-primary">{systemMetrics.uptime}</div>
          </CardContent>
        </Card>

        <Card className="border-primary/20 falcon-shadow">
          <CardContent className="p-4 text-center">
            <Activity className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <div className="font-bold text-lg font-arabic">العمليات النشطة</div>
            <div className="text-2xl font-mono text-primary">{systemMetrics.activeProcesses}</div>
          </CardContent>
        </Card>

        <Card className="border-primary/20 falcon-shadow">
          <CardContent className="p-4 text-center">
            <TrendingUp className="w-8 h-8 text-purple-500 mx-auto mb-2" />
            <div className="font-bold text-lg font-arabic">الأداء العام</div>
            <div className="text-2xl font-mono text-primary">
              {((100 - systemMetrics.cpu/2 - systemMetrics.memory/3 + systemMetrics.network/4) / 1.5).toFixed(0)}%
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Command Categories */}
      <div className="flex flex-wrap gap-2 mb-4">
        {['all', 'core', 'security', 'analytics', 'creative'].map(category => (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(category)}
            className="font-arabic"
          >
            {category === 'all' && '🔧 الكل'}
            {category === 'core' && '🧠 النواة'}
            {category === 'security' && '🛡️ الأمان'}
            {category === 'analytics' && '📊 التحليل'}
            {category === 'creative' && '🎨 الإبداع'}
          </Button>
        ))}
      </div>

      {/* Commands Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {filteredCommands.map((command) => {
          const IconComponent = command.icon;
          const StatusIcon = getStatusIcon(command.status);
          
          return (
            <Card 
              key={command.id}
              className="border-primary/20 hover:border-primary/40 transition-all duration-300 falcon-shadow hover:scale-[1.02]"
            >
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3 rtl:space-x-reverse">
                    <div className="p-2 rounded-lg bg-gradient-to-br from-primary/20 to-primary/10">
                      <IconComponent size={24} className="text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-lg font-amiri">{command.name}</CardTitle>
                      <p className="text-sm text-muted-foreground font-scheherazade">
                        {command.description}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 rtl:space-x-reverse">
                    {typeof StatusIcon === 'string' ? (
                      <span className="text-2xl">{StatusIcon}</span>
                    ) : (
                      <StatusIcon className={`w-5 h-5 ${getStatusColor(command.status)}`} />
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                {command.status === 'running' && command.progress !== undefined && (
                  <div className="mb-3">
                    <div className="flex justify-between text-sm mb-1">
                      <span>التقدم</span>
                      <span>{command.progress.toFixed(0)}%</span>
                    </div>
                    <Progress value={command.progress} className="h-2" />
                  </div>
                )}
                
                <Button
                  onClick={() => executeCommand(command.id)}
                  disabled={command.status === 'running'}
                  className="w-full"
                  variant={command.status === 'completed' ? 'outline' : 'default'}
                >
                  {command.status === 'ready' && '▶️ تنفيذ'}
                  {command.status === 'running' && '⏸️ قيد التنفيذ...'}
                  {command.status === 'completed' && '🔄 إعادة تشغيل'}
                  {command.status === 'error' && '🔄 إعادة المحاولة'}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Terminal Output */}
      <Card className="border-primary/20 falcon-shadow">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse font-amiri">
            <Terminal className="w-5 h-5" />
            <span>سجل النظام المباشر</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-black/90 text-green-400 p-4 rounded-lg font-mono text-sm min-h-[200px] max-h-[300px] overflow-y-auto">
            <div className="space-y-1">
              <div>[23:45:12] 🧠 Neural Core: Consciousness level at 97%</div>
              <div>[23:45:15] 🛡️ Security: Advanced threat detection active</div>
              <div>[23:45:18] 🎨 Creative Engine: Inspiration algorithms initialized</div>
              <div>[23:45:21] 📊 Analytics: Pattern recognition optimized</div>
              <div>[23:45:24] ⚡ Performance: All systems operating at peak efficiency</div>
              <div>[23:45:27] 🔧 System: Ready for advanced engineering tasks</div>
              <div className="text-yellow-400">[23:45:30] 🦅 Falcon Entity: Standing by for commands...</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </FalconLayout>
  );
}