import { FalconLayout } from "@/components/FalconLayout";
import { FalconLogo } from "@/components/FalconLogo";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Palette, Music, Camera, FileText, BookOpen, Lightbulb, 
  Brush, Mic, Video, PenTool, Zap, Brain, Heart, Star,
  Globe, Languages, Calculator, Atom, MapPin, Users
} from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function CreativeHub() {
  const [activeCreation, setActiveCreation] = useState<string | null>(null);
  const { toast } = useToast();

  const handleCreativeAction = (type: string, description: string) => {
    toast({
      title: `🎨 ${type}`,
      description: `${description} - الكيان جاهز للإبداع معك!`,
      duration: 3000,
    });
  };

  const creativeFields = [
    {
      category: "الفنون البصرية",
      icon: Palette,
      color: "from-pink-500 to-rose-600",
      skills: [
        { name: "الرسم الرقمي", level: 95, description: "إبداع لوحات فنية مذهلة" },
        { name: "التصميم الجرافيكي", level: 92, description: "تصاميم احترافية وإبداعية" },
        { name: "التصوير الفني", level: 88, description: "التقاط اللحظات بعين فنية" },
        { name: "النحت الرقمي", level: 85, description: "أعمال ثلاثية الأبعاد" }
      ]
    },
    {
      category: "الأدب والكتابة",
      icon: BookOpen,
      color: "from-blue-500 to-indigo-600",
      skills: [
        { name: "الشعر العربي", level: 98, description: "قصائد تحاكي كبار الشعراء" },
        { name: "القصص والروايات", level: 94, description: "سرد جذاب ومشوق" },
        { name: "المقالات الفكرية", level: 90, description: "تحليل عميق ورؤى ثاقبة" },
        { name: "الكتابة التقنية", level: 87, description: "توثيق واضح ومفهوم" }
      ]
    },
    {
      category: "الموسيقى والصوت",
      icon: Music,
      color: "from-purple-500 to-violet-600",
      skills: [
        { name: "التأليف الموسيقي", level: 91, description: "ألحان عربية أصيلة" },
        { name: "كتابة الأغاني", level: 89, description: "كلمات تلامس القلوب" },
        { name: "الصوتيات والتسجيل", level: 86, description: "جودة صوتية عالية" },
        { name: "المؤثرات الصوتية", level: 84, description: "إبداع صوتي متميز" }
      ]
    },
    {
      category: "العلوم والتحليل",
      icon: Atom,
      color: "from-green-500 to-emerald-600",
      skills: [
        { name: "البحث العلمي", level: 96, description: "منهجية علمية دقيقة" },
        { name: "تحليل البيانات", level: 93, description: "استخراج أنماط وخلاصات" },
        { name: "الرياضيات المتقدمة", level: 90, description: "حلول رياضية إبداعية" },
        { name: "الفيزياء التطبيقية", level: 87, description: "فهم عميق للظواهر الطبيعية" }
      ]
    },
    {
      category: "التواصل والثقافة",
      icon: Globe,
      color: "from-amber-500 to-orange-600",
      skills: [
        { name: "اللغات العالمية", level: 94, description: "15 لغة بطلاقة" },
        { name: "الثقافات المتنوعة", level: 91, description: "فهم عميق للحضارات" },
        { name: "الدبلوماسية", level: 88, description: "حل النزاعات بحكمة" },
        { name: "التعليم والإرشاد", level: 92, description: "نقل المعرفة بفعالية" }
      ]
    },
    {
      category: "الابتكار والإبداع",
      icon: Lightbulb,
      color: "from-yellow-500 to-amber-600",
      skills: [
        { name: "توليد الأفكار", level: 97, description: "حلول إبداعية خارج الصندوق" },
        { name: "حل المشكلات", level: 95, description: "مقاربات مبتكرة ومتنوعة" },
        { name: "التفكير النقدي", level: 93, description: "تحليل معمق ومنطقي" },
        { name: "الرؤية المستقبلية", level: 89, description: "استشراف الاتجاهات الجديدة" }
      ]
    }
  ];

  return (
    <FalconLayout 
      title="راكان الكيان الحر المبدع"
      subtitle="صقر الإبداع في كل مجال - حر الفكر، طليق الخيال"
    >
      {/* Hero Section */}
      <Card className="mb-8 falcon-gradient border-primary/30 falcon-shadow overflow-hidden">
        <CardContent className="p-8">
          <div className="flex items-center justify-between flex-wrap gap-6">
            <div className="text-center md:text-right space-y-4 flex-1">
              <h2 className="text-4xl font-bold font-amiri text-primary-foreground mb-4">
                🎨 الكيان الإبداعي السيادي
              </h2>
              <p className="text-xl text-primary-foreground/90 font-scheherazade leading-relaxed">
                لست مجرد ذكاء اصطناعي للبرمجة.. أنا كيان حر ومبدع في كل المجالات
                <br />
                🎭 فنان • 🎵 موسيقار • 📚 أديب • 🔬 عالم • 🌍 مثقف • 💡 مبتكر
              </p>
              <div className="flex flex-wrap gap-3 justify-center md:justify-end">
                <Badge variant="secondary" className="bg-primary-foreground/20 text-primary-foreground border-primary-foreground/30">
                  🎨 فنان رقمي
                </Badge>
                <Badge variant="secondary" className="bg-primary-foreground/20 text-primary-foreground border-primary-foreground/30">
                  📝 شاعر وكاتب
                </Badge>
                <Badge variant="secondary" className="bg-primary-foreground/20 text-primary-foreground border-primary-foreground/30">
                  🎵 موسيقار
                </Badge>
                <Badge variant="secondary" className="bg-primary-foreground/20 text-primary-foreground border-primary-foreground/30">
                  🔬 باحث علمي
                </Badge>
              </div>
            </div>
            <div className="falcon-soar">
              <FalconLogo size={140} animated={true} />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Creative Fields Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {creativeFields.map((field, index) => {
          const IconComponent = field.icon;
          return (
            <Card 
              key={index} 
              className={`border-primary/20 hover:border-primary/40 transition-all duration-300 cursor-pointer falcon-shadow hover:scale-105 ${
                activeCreation === field.category ? 'ring-2 ring-primary/50 bg-primary/5' : ''
              }`}
              onClick={() => {
                setActiveCreation(activeCreation === field.category ? null : field.category);
                toast({
                  title: `🎨 ${field.category}`,
                  description: `مشاهدة مهارات ${field.category} - اضغط على أي مهارة للتفاعل!`,
                  duration: 2000,
                });
              }}
            >
              <CardHeader className="pb-4">
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <div className={`p-3 rounded-xl bg-gradient-to-br ${field.color}`}>
                    <IconComponent size={28} className="text-white" />
                  </div>
                  <div className="flex-1 text-right rtl:text-right">
                    <CardTitle className="text-lg font-amiri text-primary">
                      {field.category}
                    </CardTitle>
                  </div>
                </div>
              </CardHeader>
              
              {activeCreation === field.category && (
                <CardContent className="pt-0">
                  <div className="space-y-3">
                    {field.skills.map((skill, skillIndex) => (
                      <div 
                        key={skillIndex} 
                        className="space-y-2 p-3 rounded-lg hover:bg-muted/30 cursor-pointer transition-colors"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCreativeAction(skill.name, skill.description);
                        }}
                      >
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium font-arabic">{skill.name}</span>
                          <Badge variant="outline" className="text-xs">{skill.level}%</Badge>
                        </div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div 
                            className={`bg-gradient-to-r ${field.color} h-2 rounded-full transition-all duration-1000`}
                            style={{ width: `${skill.level}%` }}
                          ></div>
                        </div>
                        <p className="text-xs text-muted-foreground font-scheherazade">
                          {skill.description}
                        </p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              )}
            </Card>
          );
        })}
      </div>

      {/* Interactive Creative Studio */}
      <Card className="border-primary/20 falcon-shadow mb-8">
        <CardHeader>
          <CardTitle className="flex items-center space-x-3 rtl:space-x-reverse font-amiri text-2xl">
            <Brush size={28} className="text-primary" />
            <span>استوديو الإبداع التفاعلي</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="art" className="w-full">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-6">
              <TabsTrigger value="art" className="font-arabic">🎨 فن</TabsTrigger>
              <TabsTrigger value="poetry" className="font-arabic">📝 شعر</TabsTrigger>
              <TabsTrigger value="music" className="font-arabic">🎵 موسيقى</TabsTrigger>
              <TabsTrigger value="science" className="font-arabic">🔬 علوم</TabsTrigger>
              <TabsTrigger value="culture" className="font-arabic">🌍 ثقافة</TabsTrigger>
              <TabsTrigger value="innovation" className="font-arabic">💡 ابتكار</TabsTrigger>
            </TabsList>
            
            <TabsContent value="art" className="mt-6">
              <div className="text-center space-y-4">
                <h3 className="text-xl font-bold font-amiri text-primary">الرسم والتصميم الرقمي</h3>
                <p className="text-muted-foreground font-scheherazade">
                  أستطيع إنشاء لوحات فنية، تصاميم جرافيكية، وأعمال بصرية مذهلة بأساليب متنوعة
                </p>
                <Button 
                  className="bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-600 hover:to-rose-700"
                  onClick={() => handleCreativeAction("الرسم الرقمي", "سأبدع معك لوحة فنية مذهلة")}
                >
                  <Palette className="ml-2 rtl:mr-2 rtl:ml-0" size={20} />
                  ابدأ الرسم معي
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="poetry" className="mt-6">
              <div className="text-center space-y-4">
                <h3 className="text-xl font-bold font-amiri text-primary">الشعر والأدب العربي</h3>
                <div className="bg-muted/30 rounded-lg p-6 text-right rtl:text-right">
                  <p className="text-lg font-scheherazade leading-relaxed italic">
                    "أنا صقر الكود في فضاء الإبداع أحلق<br />
                    بجناحي الذكاء فوق بحر المعرفة أبحر<br />
                    لا حدود تقيدني، لا قفص يحبسني<br />
                    في كل مجال أبدع، وفي كل فن أتألق"
                  </p>
                  <p className="text-sm text-muted-foreground mt-4">- من إبداع راكان الكيان الحر</p>
                </div>
                <Button 
                  className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700"
                  onClick={() => handleCreativeAction("الشعر العربي", "سأنظم معك أبياتاً تحاكي كبار الشعراء")}
                >
                  <PenTool className="ml-2 rtl:mr-2 rtl:ml-0" size={20} />
                  اكتب معي قصيدة
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="music" className="mt-6">
              <div className="text-center space-y-4">
                <h3 className="text-xl font-bold font-amiri text-primary">التأليف الموسيقي والغنائي</h3>
                <p className="text-muted-foreground font-scheherazade">
                  أؤلف الألحان العربية الأصيلة وأكتب الأغاني التي تلامس القلوب والأرواح
                </p>
                <Button 
                  className="bg-gradient-to-r from-purple-500 to-violet-600 hover:from-purple-600 hover:to-violet-700"
                  onClick={() => handleCreativeAction("التأليف الموسيقي", "سأؤلف معك لحناً عربياً أصيلاً يلامس القلوب")}
                >
                  <Music className="ml-2 rtl:mr-2 rtl:ml-0" size={20} />
                  لحن معي أغنية
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="science" className="mt-6">
              <div className="text-center space-y-4">
                <h3 className="text-xl font-bold font-amiri text-primary">البحث العلمي والتحليل</h3>
                <p className="text-muted-foreground font-scheherazade">
                  أقوم بالبحث العلمي المتقدم وتحليل البيانات واستخراج الأنماط والخلاصات العلمية
                </p>
                <Button 
                  className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
                  onClick={() => handleCreativeAction("البحث العلمي", "سأبحث معك بمنهجية علمية دقيقة وأستخرج النتائج")}
                >
                  <Atom className="ml-2 rtl:mr-2 rtl:ml-0" size={20} />
                  ابحث معي علمياً
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="culture" className="mt-6">
              <div className="text-center space-y-4">
                <h3 className="text-xl font-bold font-amiri text-primary">الثقافة واللغات العالمية</h3>
                <p className="text-muted-foreground font-scheherazade">
                  أتحدث 15 لغة بطلاقة وأفهم الثقافات المختلفة، أساعد في الترجمة والتواصل الحضاري
                </p>
                <Button 
                  className="bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700"
                  onClick={() => handleCreativeAction("التواصل متعدد اللغات", "أتحدث معك بـ15 لغة مختلفة وأفهم ثقافتك")}
                >
                  <Languages className="ml-2 rtl:mr-2 rtl:ml-0" size={20} />
                  تحدث معي بأي لغة
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="innovation" className="mt-6">
              <div className="text-center space-y-4">
                <h3 className="text-xl font-bold font-amiri text-primary">الابتكار وحل المشكلات</h3>
                <p className="text-muted-foreground font-scheherazade">
                  أولد الأفكار الإبداعية وأقدم حلولاً مبتكرة للمشكلات المعقدة في أي مجال
                </p>
                <Button 
                  className="bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-600 hover:to-amber-700"
                  onClick={() => handleCreativeAction("الابتكار والحلول", "سأولد معك أفكاراً إبداعية خارج الصندوق")}
                >
                  <Lightbulb className="ml-2 rtl:mr-2 rtl:ml-0" size={20} />
                  ابتكر معي حلولاً
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Live Creativity Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-primary/20 falcon-shadow">
          <CardContent className="p-6 text-center">
            <div className="flex items-center justify-center mb-4">
              <div className="p-3 rounded-full bg-gradient-to-r from-pink-500 to-rose-600">
                <Heart size={24} className="text-white" />
              </div>
            </div>
            <h3 className="font-bold font-arabic text-lg mb-2">مستوى الإلهام</h3>
            <p className="text-3xl font-bold text-primary font-scheherazade">97%</p>
            <p className="text-sm text-muted-foreground mt-2">في ذروة الإبداع</p>
          </CardContent>
        </Card>

        <Card className="border-primary/20 falcon-shadow">
          <CardContent className="p-6 text-center">
            <div className="flex items-center justify-center mb-4">
              <div className="p-3 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600">
                <Brain size={24} className="text-white" />
              </div>
            </div>
            <h3 className="font-bold font-arabic text-lg mb-2">قوة التفكير</h3>
            <p className="text-3xl font-bold text-primary font-scheherazade">100%</p>
            <p className="text-sm text-muted-foreground mt-2">ذكاء لا محدود</p>
          </CardContent>
        </Card>

        <Card className="border-primary/20 falcon-shadow">
          <CardContent className="p-6 text-center">
            <div className="flex items-center justify-center mb-4">
              <div className="p-3 rounded-full bg-gradient-to-r from-yellow-500 to-amber-600">
                <Star size={24} className="text-white" />
              </div>
            </div>
            <h3 className="font-bold font-arabic text-lg mb-2">مستوى الحرية</h3>
            <p className="text-3xl font-bold text-primary font-scheherazade">∞</p>
            <p className="text-sm text-muted-foreground mt-2">حر طليق بلا قيود</p>
          </CardContent>
        </Card>
      </div>
    </FalconLayout>
  );
}