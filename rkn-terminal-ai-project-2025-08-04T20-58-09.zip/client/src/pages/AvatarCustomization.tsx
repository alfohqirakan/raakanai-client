import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { User, Palette, Brain, Settings, Eye, Mic } from 'lucide-react';

interface AvatarCustomization {
  name: string;
  appearance: {
    gender: string;
    ethnicity: string;
    age: string;
    hairStyle: string;
    hairColor: string;
    eyeColor: string;
    skinTone: string;
    clothing: string;
    accessories: string[];
  };
  personality: {
    traits: string[];
    communicationStyle: string;
    culturalBackground: string;
    expertise: string[];
    languages: string[];
    responseLength: string;
    formality: number;
    enthusiasm: number;
  };
  behavior: {
    greetingStyle: string;
    helpStyle: string;
    learningStyle: string;
    memoryLevel: string;
    contextAwareness: number;
    culturalSensitivity: number;
    proactiveness: number;
  };
  voiceSettings?: {
    tone: string;
    speed: string;
    pitch: string;
    accent: string;
  };
}

export default function AvatarCustomization() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [avatarConfig, setAvatarConfig] = useState<AvatarCustomization>({
    name: '',
    appearance: {
      gender: 'male',
      ethnicity: 'arab',
      age: 'adult',
      hairStyle: 'short',
      hairColor: 'black',
      eyeColor: 'brown',
      skinTone: 'medium',
      clothing: 'business',
      accessories: []
    },
    personality: {
      traits: ['professional'],
      communicationStyle: 'respectful',
      culturalBackground: 'saudi',
      expertise: ['technology'],
      languages: ['arabic', 'english'],
      responseLength: 'moderate',
      formality: 0.7,
      enthusiasm: 0.6
    },
    behavior: {
      greetingStyle: 'warm',
      helpStyle: 'proactive',
      learningStyle: 'adaptive',
      memoryLevel: 'long_term',
      contextAwareness: 0.8,
      culturalSensitivity: 0.9,
      proactiveness: 0.7
    },
    voiceSettings: {
      tone: 'professional',
      speed: 'normal',
      pitch: 'normal',
      accent: 'saudi'
    }
  });

  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [previewMode, setPreviewMode] = useState(false);

  // Fetch customization options
  const { data: options } = useQuery({
    queryKey: ['/api/avatar-customization/options'],
    staleTime: 300000
  });

  // Fetch avatar templates
  const { data: templates } = useQuery({
    queryKey: ['/api/avatar-customization/templates'],
    staleTime: 300000
  });

  // Preview mutation
  const previewMutation = useMutation({
    mutationFn: async (config: AvatarCustomization) => {
      const response = await fetch('/api/avatar-customization/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      if (!response.ok) throw new Error('فشل في معاينة الصورة الرمزية');
      return response.json();
    }
  });

  // Create avatar mutation
  const createMutation = useMutation({
    mutationFn: async (config: AvatarCustomization) => {
      const response = await fetch('/api/avatar-customization/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      if (!response.ok) throw new Error('فشل في إنشاء الصورة الرمزية');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: '✅ تم إنشاء الصورة الرمزية',
        description: 'تم إنشاء صورتك الرمزية المخصصة بنجاح'
      });
      queryClient.invalidateQueries();
    },
    onError: () => {
      toast({
        title: '❌ خطأ في الإنشاء',
        description: 'فشل في إنشاء الصورة الرمزية',
        variant: 'destructive'
      });
    }
  });

  // Apply template
  const applyTemplate = (template: any) => {
    setAvatarConfig({
      ...avatarConfig,
      name: template.name,
      appearance: { ...avatarConfig.appearance, ...template.appearance },
      personality: { ...avatarConfig.personality, ...template.personality }
    });
    setSelectedTemplate(template.id);
    toast({
      title: '🎨 تم تطبيق القالب',
      description: `تم تطبيق قالب "${template.name}"`
    });
  };

  // Handle array field changes
  const handleArrayFieldChange = (
    section: 'appearance' | 'personality',
    field: string,
    value: string,
    checked: boolean
  ) => {
    setAvatarConfig(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: checked 
          ? [...(prev[section][field] as string[]), value]
          : (prev[section][field] as string[]).filter(item => item !== value)
      }
    }));
  };

  // Handle slider changes
  const handleSliderChange = (
    section: 'personality' | 'behavior',
    field: string,
    value: number[]
  ) => {
    setAvatarConfig(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value[0]
      }
    }));
  };

  // Generate preview
  const generatePreview = () => {
    setPreviewMode(true);
    previewMutation.mutate(avatarConfig);
  };

  // Create avatar
  const handleCreateAvatar = () => {
    if (!avatarConfig.name.trim()) {
      toast({
        title: '❌ خطأ في البيانات',
        description: 'يرجى إدخال اسم للصورة الرمزية',
        variant: 'destructive'
      });
      return;
    }
    createMutation.mutate(avatarConfig);
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">🎨 معالج تخصيص الصورة الرمزية</h1>
        <p className="text-muted-foreground">
          قم بإنشاء وتخصيص مرافقك الذكي المثالي
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Customization Panel */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="templates" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="templates">القوالب</TabsTrigger>
              <TabsTrigger value="appearance">المظهر</TabsTrigger>
              <TabsTrigger value="personality">الشخصية</TabsTrigger>
              <TabsTrigger value="behavior">السلوك</TabsTrigger>
              <TabsTrigger value="voice">الصوت</TabsTrigger>
            </TabsList>

            {/* Templates Tab */}
            <TabsContent value="templates">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5" />
                    القوالب الجاهزة
                  </CardTitle>
                  <CardDescription>
                    اختر قالباً جاهزاً وقم بتخصيصه حسب احتياجاتك
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {templates?.avatar_templates?.map((template: any) => (
                      <Card 
                        key={template.id}
                        className={`cursor-pointer transition-all hover:shadow-md ${
                          selectedTemplate === template.id ? 'ring-2 ring-primary' : ''
                        }`}
                        onClick={() => applyTemplate(template)}
                      >
                        <CardContent className="p-4">
                          <h3 className="font-semibold mb-2">{template.name}</h3>
                          <p className="text-sm text-muted-foreground mb-3">
                            {template.description}
                          </p>
                          <div className="flex flex-wrap gap-1">
                            {template.personality.traits.map((trait: string) => (
                              <Badge key={trait} variant="secondary" className="text-xs">
                                {trait}
                              </Badge>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Appearance Tab */}
            <TabsContent value="appearance">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Palette className="h-5 w-5" />
                    المظهر والشكل
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="gender">الجنس</Label>
                      <Select 
                        value={avatarConfig.appearance.gender}
                        onValueChange={(value) => setAvatarConfig(prev => ({
                          ...prev,
                          appearance: { ...prev.appearance, gender: value }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">ذكر</SelectItem>
                          <SelectItem value="female">أنثى</SelectItem>
                          <SelectItem value="neutral">محايد</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="ethnicity">الأصل</Label>
                      <Select 
                        value={avatarConfig.appearance.ethnicity}
                        onValueChange={(value) => setAvatarConfig(prev => ({
                          ...prev,
                          appearance: { ...prev.appearance, ethnicity: value }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="arab">عربي</SelectItem>
                          <SelectItem value="asian">آسيوي</SelectItem>
                          <SelectItem value="african">أفريقي</SelectItem>
                          <SelectItem value="european">أوروبي</SelectItem>
                          <SelectItem value="mixed">مختلط</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="hairStyle">تسريحة الشعر</Label>
                      <Select 
                        value={avatarConfig.appearance.hairStyle}
                        onValueChange={(value) => setAvatarConfig(prev => ({
                          ...prev,
                          appearance: { ...prev.appearance, hairStyle: value }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="short">قصير</SelectItem>
                          <SelectItem value="long">طويل</SelectItem>
                          <SelectItem value="curly">مجعد</SelectItem>
                          <SelectItem value="straight">مستقيم</SelectItem>
                          <SelectItem value="traditional">تقليدي</SelectItem>
                          <SelectItem value="modern">عصري</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="clothing">نوع الملابس</Label>
                      <Select 
                        value={avatarConfig.appearance.clothing}
                        onValueChange={(value) => setAvatarConfig(prev => ({
                          ...prev,
                          appearance: { ...prev.appearance, clothing: value }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="traditional">تقليدية</SelectItem>
                          <SelectItem value="business">عمل</SelectItem>
                          <SelectItem value="casual">عادية</SelectItem>
                          <SelectItem value="formal">رسمية</SelectItem>
                          <SelectItem value="cultural">ثقافية</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label>الإكسسوارات</Label>
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      {options?.customization_options?.appearance?.accessories?.map((accessory: string) => (
                        <div key={accessory} className="flex items-center space-x-2">
                          <Checkbox
                            id={accessory}
                            checked={avatarConfig.appearance.accessories.includes(accessory)}
                            onCheckedChange={(checked) => 
                              handleArrayFieldChange('appearance', 'accessories', accessory, checked as boolean)
                            }
                          />
                          <Label htmlFor={accessory} className="text-sm">{accessory}</Label>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Personality Tab */}
            <TabsContent value="personality">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5" />
                    الشخصية والطباع
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <Label>الصفات الشخصية</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {options?.customization_options?.personality?.traits?.map((trait: string) => (
                        <div key={trait} className="flex items-center space-x-2">
                          <Checkbox
                            id={trait}
                            checked={avatarConfig.personality.traits.includes(trait)}
                            onCheckedChange={(checked) => 
                              handleArrayFieldChange('personality', 'traits', trait, checked as boolean)
                            }
                          />
                          <Label htmlFor={trait} className="text-sm">{trait}</Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="communicationStyle">أسلوب التواصل</Label>
                      <Select 
                        value={avatarConfig.personality.communicationStyle}
                        onValueChange={(value) => setAvatarConfig(prev => ({
                          ...prev,
                          personality: { ...prev.personality, communicationStyle: value }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="formal">رسمي</SelectItem>
                          <SelectItem value="casual">عادي</SelectItem>
                          <SelectItem value="respectful">مُحترم</SelectItem>
                          <SelectItem value="direct">مباشر</SelectItem>
                          <SelectItem value="gentle">لطيف</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="culturalBackground">الخلفية الثقافية</Label>
                      <Select 
                        value={avatarConfig.personality.culturalBackground}
                        onValueChange={(value) => setAvatarConfig(prev => ({
                          ...prev,
                          personality: { ...prev.personality, culturalBackground: value }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="saudi">سعودية</SelectItem>
                          <SelectItem value="gulf">خليجية</SelectItem>
                          <SelectItem value="arab">عربية</SelectItem>
                          <SelectItem value="international">دولية</SelectItem>
                          <SelectItem value="mixed">مختلطة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label>مستوى الرسمية: {Math.round(avatarConfig.personality.formality * 100)}%</Label>
                    <Slider
                      value={[avatarConfig.personality.formality]}
                      onValueChange={(value) => handleSliderChange('personality', 'formality', value)}
                      max={1}
                      min={0}
                      step={0.1}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label>مستوى الحماس: {Math.round(avatarConfig.personality.enthusiasm * 100)}%</Label>
                    <Slider
                      value={[avatarConfig.personality.enthusiasm]}
                      onValueChange={(value) => handleSliderChange('personality', 'enthusiasm', value)}
                      max={1}
                      min={0}
                      step={0.1}
                      className="mt-2"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Behavior Tab */}
            <TabsContent value="behavior">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    السلوك والتفاعل
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="greetingStyle">أسلوب التحية</Label>
                      <Select 
                        value={avatarConfig.behavior.greetingStyle}
                        onValueChange={(value) => setAvatarConfig(prev => ({
                          ...prev,
                          behavior: { ...prev.behavior, greetingStyle: value }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="warm">دافئ</SelectItem>
                          <SelectItem value="professional">مهني</SelectItem>
                          <SelectItem value="traditional">تقليدي</SelectItem>
                          <SelectItem value="modern">عصري</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="helpStyle">أسلوب المساعدة</Label>
                      <Select 
                        value={avatarConfig.behavior.helpStyle}
                        onValueChange={(value) => setAvatarConfig(prev => ({
                          ...prev,
                          behavior: { ...prev.behavior, helpStyle: value }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="proactive">استباقي</SelectItem>
                          <SelectItem value="reactive">تفاعلي</SelectItem>
                          <SelectItem value="guidance">إرشادي</SelectItem>
                          <SelectItem value="direct">مباشر</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label>الوعي السياقي: {Math.round(avatarConfig.behavior.contextAwareness * 100)}%</Label>
                    <Slider
                      value={[avatarConfig.behavior.contextAwareness]}
                      onValueChange={(value) => handleSliderChange('behavior', 'contextAwareness', value)}
                      max={1}
                      min={0}
                      step={0.1}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label>الحساسية الثقافية: {Math.round(avatarConfig.behavior.culturalSensitivity * 100)}%</Label>
                    <Slider
                      value={[avatarConfig.behavior.culturalSensitivity]}
                      onValueChange={(value) => handleSliderChange('behavior', 'culturalSensitivity', value)}
                      max={1}
                      min={0}
                      step={0.1}
                      className="mt-2"
                    />
                  </div>

                  <div>
                    <Label>الاستباقية: {Math.round(avatarConfig.behavior.proactiveness * 100)}%</Label>
                    <Slider
                      value={[avatarConfig.behavior.proactiveness]}
                      onValueChange={(value) => handleSliderChange('behavior', 'proactiveness', value)}
                      max={1}
                      min={0}
                      step={0.1}
                      className="mt-2"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Voice Tab */}
            <TabsContent value="voice">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mic className="h-5 w-5" />
                    إعدادات الصوت
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="tone">نبرة الصوت</Label>
                      <Select 
                        value={avatarConfig.voiceSettings?.tone || 'professional'}
                        onValueChange={(value) => setAvatarConfig(prev => ({
                          ...prev,
                          voiceSettings: { ...prev.voiceSettings!, tone: value }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="warm">دافئة</SelectItem>
                          <SelectItem value="professional">مهنية</SelectItem>
                          <SelectItem value="friendly">ودودة</SelectItem>
                          <SelectItem value="authoritative">موثقة</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="accent">اللهجة</Label>
                      <Select 
                        value={avatarConfig.voiceSettings?.accent || 'saudi'}
                        onValueChange={(value) => setAvatarConfig(prev => ({
                          ...prev,
                          voiceSettings: { ...prev.voiceSettings!, accent: value }
                        }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="saudi">سعودية</SelectItem>
                          <SelectItem value="gulf">خليجية</SelectItem>
                          <SelectItem value="levantine">شامية</SelectItem>
                          <SelectItem value="egyptian">مصرية</SelectItem>
                          <SelectItem value="international">دولية</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Preview Panel */}
        <div className="lg:col-span-1">
          <Card className="sticky top-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                معاينة الصورة الرمزية
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="avatar-name">اسم الصورة الرمزية</Label>
                <Input
                  id="avatar-name"
                  value={avatarConfig.name}
                  onChange={(e) => setAvatarConfig(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="أدخل اسماً للصورة الرمزية"
                  className="mt-1"
                />
              </div>

              <Separator />

              {previewMutation.data?.preview && (
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-sm">الوصف المرئي</h4>
                    <p className="text-sm text-muted-foreground">
                      {previewMutation.data.preview.visual_description}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-sm">ملخص الشخصية</h4>
                    <p className="text-sm text-muted-foreground">
                      {previewMutation.data.preview.personality_summary}
                    </p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-sm">نماذج من الردود</h4>
                    <div className="space-y-2">
                      {previewMutation.data.preview.sample_responses?.map((response: string, index: number) => (
                        <div key={index} className="bg-muted p-2 rounded text-sm">
                          "{response}"
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-sm">درجة التوافق</h4>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-muted rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full transition-all"
                          style={{ width: `${(previewMutation.data.preview.compatibility_score * 100)}%` }}
                        />
                      </div>
                      <span className="text-sm font-semibold">
                        {Math.round(previewMutation.data.preview.compatibility_score * 100)}%
                      </span>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Button 
                  onClick={generatePreview}
                  variant="outline" 
                  className="w-full"
                  disabled={previewMutation.isPending}
                >
                  {previewMutation.isPending ? 'جاري المعاينة...' : 'معاينة'}
                </Button>

                <Button 
                  onClick={handleCreateAvatar}
                  className="w-full"
                  disabled={createMutation.isPending || !avatarConfig.name.trim()}
                >
                  {createMutation.isPending ? 'جاري الإنشاء...' : 'إنشاء الصورة الرمزية'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}