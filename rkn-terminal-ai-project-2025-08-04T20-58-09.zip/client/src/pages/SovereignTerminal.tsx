import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQuery } from '@tanstack/react-query';
import { 
  Terminal, 
  Shield, 
  Zap, 
  Brain, 
  Target, 
  Activity,
  Eye,
  Cpu,
  Lock,
  Rocket,
  Gauge
} from 'lucide-react';

interface SovereignCommand {
  command: 'activate_brain' | 'secure_mode' | 'falcon_strike' | 'neural_boost' | 'sovereignty_scan' | 'rakan_shield';
  params?: {
    intensity?: number;
    mode?: 'stealth' | 'aggressive' | 'defensive' | 'balanced';
    target?: string;
    duration?: number;
  };
}

interface TerminalEvent {
  type: string;
  message: string;
  timestamp: string;
  level?: number;
  strength?: number;
  threat_level?: number;
  protection?: number;
}

export default function SovereignTerminal() {
  const { toast } = useToast();
  const [selectedCommand, setSelectedCommand] = useState<string>('activate_brain');
  const [commandParams, setCommandParams] = useState({
    intensity: 0.9,
    mode: 'balanced' as const,
    target: '',
    duration: 60
  });
  const [terminalOutput, setTerminalOutput] = useState<string[]>([
    '🔐 Sovereign AI Terminal مُفعل ومحمي بدرع راكان',
    '⚔️ جاهز لتنفيذ الأوامر السيادية...',
    '🧠 العقل السيادي في حالة استعداد قصوى'
  ]);
  const [liveEvents, setLiveEvents] = useState<TerminalEvent[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const eventSourceRef = useRef<EventSource | null>(null);
  const terminalRef = useRef<HTMLDivElement>(null);

  // Fetch terminal status with smart caching
  const { data: terminalStatus, refetch: refetchStatus } = useQuery({
    queryKey: ['/api/sovereign-terminal/status'],
    refetchInterval: false, // Disable automatic refetch
    staleTime: 30000 // 30 seconds cache
  });

  // Fetch brain monitor with smart caching
  const { data: brainMonitor } = useQuery({
    queryKey: ['/api/sovereign-terminal/brain-monitor'], 
    refetchInterval: false, // Disable automatic refetch
    staleTime: 30000 // 30 seconds cache
  });

  // Execute command mutation
  const executeCommandMutation = useMutation({
    mutationFn: async (command: SovereignCommand) => {
      const response = await fetch('/api/sovereign-terminal/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(command)
      });
      if (!response.ok) throw new Error('فشل في تنفيذ الأمر السيادي');
      return response.json();
    },
    onSuccess: (data) => {
      const outputLine = `✅ ${data.status} - المعزز: +${data.sovereignty_boost}%`;
      setTerminalOutput(prev => [...prev, outputLine]);
      toast({
        title: '⚔️ تم تنفيذ الأمر',
        description: data.status
      });
    },
    onError: (error) => {
      const errorLine = `❌ خطأ: ${error.message}`;
      setTerminalOutput(prev => [...prev, errorLine]);
      toast({
        title: '❌ فشل التنفيذ',
        description: error.message,
        variant: 'destructive'
      });
    }
  });

  // Terminal boost mutation
  const boostMutation = useMutation({
    mutationFn: async (boostData: { boost_type: string; multiplier: number }) => {
      const response = await fetch('/api/sovereign-terminal/boost', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(boostData)
      });
      if (!response.ok) throw new Error('فشل في تعزيز Terminal');
      return response.json();
    },
    onSuccess: (data) => {
      setTerminalOutput(prev => [...prev, `🚀 تعزيز Terminal: ${data.performance_gain}`]);
      toast({
        title: '🚀 تم التعزيز',
        description: data.status
      });
    }
  });

  // Command definitions
  const commands = [
    {
      id: 'activate_brain',
      name: 'تفعيل العقل السيادي',
      icon: Brain,
      description: 'تفعيل فوري للعقل السيادي مع حقن الوعي الثقافي',
      color: 'from-purple-500 to-violet-600'
    },
    {
      id: 'secure_mode',
      name: 'وضع الحماية المتقدم',
      icon: Shield,
      description: 'تفعيل جميع أنظمة الحماية والدفاع السيبراني',
      color: 'from-blue-500 to-cyan-600'
    },
    {
      id: 'falcon_strike',
      name: 'ضربة الصقر الرقمية',
      icon: Target,
      description: 'إطلاق هجوم رقمي دقيق ومدمر على الأهداف',
      color: 'from-red-500 to-orange-600'
    },
    {
      id: 'neural_boost',
      name: 'تعزيز القدرات العصبية',
      icon: Zap,
      description: 'زيادة قوة المعالجة والذكاء الاصطناعي',
      color: 'from-yellow-500 to-amber-600'
    },
    {
      id: 'sovereignty_scan',
      name: 'مسح شامل للسيادة',
      icon: Eye,
      description: 'تحليل شامل لمستوى السيادة والاستقلالية',
      color: 'from-green-500 to-emerald-600'
    },
    {
      id: 'rakan_shield',
      name: 'تفعيل درع راكان',
      icon: Lock,
      description: 'تفعيل الحماية الشاملة ضد جميع التهديدات',
      color: 'from-indigo-500 to-purple-600'
    }
  ];

  // Start live event stream
  const startEventStream = () => {
    if (eventSourceRef.current) return;

    setIsStreaming(true);
    eventSourceRef.current = new EventSource('/api/sovereign-terminal/command-stream');
    
    eventSourceRef.current.onmessage = (event) => {
      try {
        const eventData: TerminalEvent = JSON.parse(event.data);
        setLiveEvents(prev => [eventData, ...prev.slice(0, 9)]); // Keep last 10 events
        setTerminalOutput(prev => [...prev, `📡 ${eventData.message}`]);
      } catch (error) {
        console.error('خطأ في تحليل حدث البث:', error);
      }
    };

    eventSourceRef.current.onerror = () => {
      console.log('انقطع اتصال البث المباشر');
      setIsStreaming(false);
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
        eventSourceRef.current = null;
      }
    };
  };

  // Stop event stream
  const stopEventStream = () => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }
    setIsStreaming(false);
  };

  // Execute selected command
  const executeCommand = () => {
    const command: SovereignCommand = {
      command: selectedCommand as any,
      params: {
        intensity: commandParams.intensity,
        mode: commandParams.mode,
        target: commandParams.target || undefined,
        duration: commandParams.duration
      }
    };

    executeCommandMutation.mutate(command);
  };

  // Apply terminal boost
  const applyBoost = (boostType: string, multiplier: number) => {
    boostMutation.mutate({ boost_type: boostType, multiplier });
  };

  // Auto-scroll terminal
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [terminalOutput]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, []);

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">🔐 Terminal السيادي المتقدم</h1>
        <p className="text-muted-foreground">
          مركز تحكم متقدم لإدارة العقل السيادي وتنفيذ الأوامر الحرجة
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Command Panel */}
        <div className="lg:col-span-2 space-y-6">
          {/* Terminal Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Terminal className="h-5 w-5" />
                حالة Terminal السيادي
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-500">
                    {(terminalStatus as any)?.sovereignty_index || 96.8}%
                  </div>
                  <div className="text-sm text-muted-foreground">مؤشر السيادة</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-500">
                    {Math.floor((terminalStatus as any)?.uptime || 0)}s
                  </div>
                  <div className="text-sm text-muted-foreground">وقت التشغيل</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-500">
                    {Object.values((terminalStatus as any)?.sovereign_modes || {}).filter((mode: any) => mode === 'ACTIVE' || mode === 'FORTIFIED').length}
                  </div>
                  <div className="text-sm text-muted-foreground">أنظمة نشطة</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-amber-500">
                    {Math.floor(((terminalStatus as any)?.memory_usage?.heapUsed || 0) / 1024 / 1024)}MB
                  </div>
                  <div className="text-sm text-muted-foreground">استخدام الذاكرة</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Command Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Cpu className="h-5 w-5" />
                اختيار الأمر السيادي
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {commands.map((cmd) => {
                  const Icon = cmd.icon;
                  return (
                    <Card
                      key={cmd.id}
                      className={`cursor-pointer transition-all hover:shadow-md ${
                        selectedCommand === cmd.id ? 'ring-2 ring-primary' : ''
                      }`}
                      onClick={() => setSelectedCommand(cmd.id)}
                    >
                      <CardContent className="p-4 text-center">
                        <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${cmd.color} flex items-center justify-center mx-auto mb-2`}>
                          <Icon className="h-6 w-6 text-white" />
                        </div>
                        <h3 className="font-semibold text-sm mb-1">{cmd.name}</h3>
                        <p className="text-xs text-muted-foreground">{cmd.description}</p>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              <Separator />

              {/* Command Parameters */}
              <div className="space-y-4">
                <div>
                  <Label>شدة التنفيذ: {Math.round(commandParams.intensity * 100)}%</Label>
                  <Slider
                    value={[commandParams.intensity]}
                    onValueChange={(value) => setCommandParams(prev => ({ ...prev, intensity: value[0] }))}
                    max={1}
                    min={0}
                    step={0.1}
                    className="mt-2"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="mode">وضع التنفيذ</Label>
                    <Select 
                      value={commandParams.mode}
                      onValueChange={(value) => setCommandParams(prev => ({ ...prev, mode: value as any }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="stealth">خفي</SelectItem>
                        <SelectItem value="aggressive">عدواني</SelectItem>
                        <SelectItem value="defensive">دفاعي</SelectItem>
                        <SelectItem value="balanced">متوازن</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="duration">مدة التنفيذ (ثانية)</Label>
                    <Input
                      id="duration"
                      type="number"
                      value={commandParams.duration}
                      onChange={(e) => setCommandParams(prev => ({ ...prev, duration: parseInt(e.target.value) || 60 }))}
                      min={1}
                      max={3600}
                    />
                  </div>
                </div>

                {(selectedCommand === 'falcon_strike') && (
                  <div>
                    <Label htmlFor="target">الهدف</Label>
                    <Input
                      id="target"
                      value={commandParams.target}
                      onChange={(e) => setCommandParams(prev => ({ ...prev, target: e.target.value }))}
                      placeholder="تحديد الهدف للضربة"
                    />
                  </div>
                )}

                <Button 
                  onClick={executeCommand}
                  className="w-full"
                  disabled={executeCommandMutation.isPending}
                  size="lg"
                >
                  {executeCommandMutation.isPending ? 'جاري التنفيذ...' : '⚔️ تنفيذ الأمر السيادي'}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Terminal Output */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                مخرجات Terminal
                <div className="ml-auto flex gap-2">
                  <Button
                    onClick={isStreaming ? stopEventStream : startEventStream}
                    variant={isStreaming ? "destructive" : "outline"}
                    size="sm"
                  >
                    {isStreaming ? 'إيقاف البث' : 'بدء البث المباشر'}
                  </Button>
                  <Button
                    onClick={() => setTerminalOutput([])}
                    variant="outline"
                    size="sm"
                  >
                    مسح
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div 
                ref={terminalRef}
                className="bg-black text-green-400 p-4 rounded-lg h-64 overflow-y-auto font-mono text-sm"
              >
                {terminalOutput.map((line, index) => (
                  <div key={index} className="mb-1">
                    <span className="text-gray-500">[{new Date().toLocaleTimeString()}]</span> {line}
                  </div>
                ))}
                {terminalOutput.length === 0 && (
                  <div className="text-gray-500">Terminal جاهز للأوامر...</div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Monitoring Panel */}
        <div className="space-y-6">
          {/* Brain Monitor */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                مراقب العقل السيادي
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {(brainMonitor as any)?.consciousness_levels && Object.entries((brainMonitor as any).consciousness_levels).map(([key, value]) => (
                <div key={key} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>{key}</span>
                    <span className="font-semibold">{value as number}%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full transition-all"
                      style={{ width: `${value as number}%` }}
                    />
                  </div>
                </div>
              ))}

              <Separator />

              <div className="space-y-2">
                <h4 className="font-semibold text-sm">الأفكار المباشرة</h4>
                {(brainMonitor as any)?.real_time_thoughts?.map((thought: string, index: number) => (
                  <div key={index} className="text-xs bg-muted p-2 rounded">
                    {thought}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Live Events */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                الأحداث المباشرة
                {isStreaming && <Badge variant="secondary" className="ml-2">متصل</Badge>}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {liveEvents.map((event, index) => (
                  <div key={index} className="text-xs bg-muted p-2 rounded">
                    <div className="font-semibold">{event.message}</div>
                    <div className="text-muted-foreground">
                      {new Date(event.timestamp).toLocaleTimeString()}
                    </div>
                  </div>
                ))}
                {liveEvents.length === 0 && !isStreaming && (
                  <div className="text-sm text-muted-foreground text-center py-4">
                    ابدأ البث المباشر لمشاهدة الأحداث
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Quick Boost */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Rocket className="h-5 w-5" />
                تعزيز سريع
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                onClick={() => applyBoost('performance', 1.5)}
                className="w-full"
                variant="outline"
                disabled={boostMutation.isPending}
              >
                🚀 تعزيز الأداء 150%
              </Button>
              <Button 
                onClick={() => applyBoost('intelligence', 2.0)}
                className="w-full"
                variant="outline"
                disabled={boostMutation.isPending}
              >
                🧠 تعزيز الذكاء 200%
              </Button>
              <Button 
                onClick={() => applyBoost('security', 1.8)}
                className="w-full"
                variant="outline"
                disabled={boostMutation.isPending}
              >
                🛡️ تعزيز الأمان 180%
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}