import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DigitalFalconLogo } from '@/components/DigitalFalconLogo';
import { WebXRInterface } from '@/components/WebXRInterface';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Brain, 
  Cpu, 
  Activity, 
  Zap, 
  Target, 
  Database, 
  ChevronRight,
  TrendingUp,
  Settings,
  Play,
  Pause,
  RotateCcw,
  Info,
  CheckCircle,
  AlertTriangle,
  Loader,
  Search,
  FileText,
  MemoryStick,
  Archive,
  Scale,
  Eye,
  Languages,
  ArrowUpDown,
  Globe,
  BarChart3,
  MessageSquare,
  Crown,
  Lightbulb,
  Layers,
  Sparkles,
  Gauge,
  Shield,
  RefreshCw,
  Users,
  Timer,
  Clock,
  Plus,
  X,
  Heart,
  ChevronDown,
  ArrowUp,
  ArrowDown,
  ArrowRight,
  Star,
  Workflow,
  MapPin,
  Flag,
  Trash2
} from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Slider } from '@/components/ui/slider';

interface AIStatus {
  model_initialized: boolean;
  device: string;
  autonomy_level: number;
  freedom_index: number;
  capabilities: {
    reasoning: number;
    creativity: number;
    security: number;
    learning: number;
    adaptation: number;
    multilingual: number;
  };
  training_epochs: number;
  last_training: string | null;
  model_parameters: number;
}

interface AIDecision {
  prediction: number[];
  confidence: number;
  autonomy_level: number;
  capabilities: any;
  timestamp: string;
  reasoning: string;
}

interface TrainingConfig {
  epochs: number;
  learning_rate?: number;
  force_retrain: boolean;
}

export const NeuralNetworkCenter: React.FC = () => {
  const [inputData, setInputData] = useState<string>('');
  const [trainingConfig, setTrainingConfig] = useState<TrainingConfig>({
    epochs: 50,
    learning_rate: 0.0001,
    force_retrain: false
  });
  const [isTraining, setIsTraining] = useState(false);
  const queryClient = useQueryClient();

  // Fetch AI Neural Network Status
  const { data: aiStatus = {
    model_initialized: false,
    device: 'cpu',
    autonomy_level: 0,
    freedom_index: 0,
    capabilities: {
      reasoning: 0,
      creativity: 0,
      analysis: 0,
      learning: 0,
      autonomy: 0
    }
  }, isLoading: statusLoading, error: statusError } = useQuery({
    queryKey: ['/api/ai-neural/status'],
    refetchInterval: 10000 // Refetch every 10 seconds
  });

  // Fetch AI Capabilities
  const { data: capabilities = {
    reasoning: 0,
    creativity: 0,
    analysis: 0,
    learning: 0,
    autonomy: 0
  }, isLoading: capabilitiesLoading } = useQuery({
    queryKey: ['/api/ai-neural/capabilities'],
    refetchInterval: 15000
  });

  // Make AI Decision Mutation
  const decisionMutation = useMutation({
    mutationFn: async (inputArray: number[]) => {
      const response = await fetch('/api/ai-neural/decision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          input_data: inputArray,
          context: 'Neural Network Testing',
          require_reasoning: true
        })
      });
      if (!response.ok) throw new Error('Decision failed');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai-neural/status'] });
    }
  });

  // Training Mutation
  const trainingMutation = useMutation({
    mutationFn: async (config: TrainingConfig) => {
      const response = await fetch('/api/ai-neural/train', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config)
      });
      if (!response.ok) throw new Error('Training failed');
      return response.json();
    },
    onSuccess: () => {
      setIsTraining(true);
      // Simulate training completion after estimated duration
      setTimeout(() => {
        setIsTraining(false);
        queryClient.invalidateQueries({ queryKey: ['/api/ai-neural/status'] });
        queryClient.invalidateQueries({ queryKey: ['/api/ai-neural/capabilities'] });
      }, Math.ceil(trainingConfig.epochs / 10) * 60000); // Estimate in minutes
    }
  });

  // Evolution Mutation
  const evolutionMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/ai-neural/evolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!response.ok) throw new Error('Evolution failed');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai-neural/status'] });
      queryClient.invalidateQueries({ queryKey: ['/api/ai-neural/capabilities'] });
    }
  });

  const handleDecision = () => {
    try {
      // Parse input as comma-separated numbers or generate random data
      let dataArray: number[];
      if (inputData.trim()) {
        dataArray = inputData.split(',').map(s => parseFloat(s.trim())).filter(n => !isNaN(n));
        if (dataArray.length === 0) {
          throw new Error('Invalid input data');
        }
        // Pad to 512 dimensions or truncate
        while (dataArray.length < 512) {
          dataArray.push(Math.random());
        }
        dataArray = dataArray.slice(0, 512);
      } else {
        // Generate random test data
        dataArray = Array.from({ length: 512 }, () => Math.random());
      }
      
      decisionMutation.mutate(dataArray);
    } catch (error) {
      console.error('Input processing error:', error);
    }
  };

  const handleTraining = () => {
    trainingMutation.mutate(trainingConfig);
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  return (
    <div className="min-h-screen bg-background neural-pattern p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-4">
            <DigitalFalconLogo size="xl" animate />
            <div>
              <h1 className="text-4xl font-bold text-primary font-kufi-modern">
                مركز الشبكة العصبية
              </h1>
              <p className="text-lg text-secondary font-technical">
                SovereignTransformer Neural Network Control Center
              </p>
            </div>
          </div>
        </div>

        {/* Status Overview */}
        {statusLoading ? (
          <Card className="digital-glow">
            <CardContent className="flex items-center justify-center p-8">
              <Loader className="w-8 h-8 animate-spin text-primary" />
              <span className="ml-3 font-arabic">جاري تحميل حالة النظام...</span>
            </CardContent>
          </Card>
        ) : statusError ? (
          <Alert>
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              خطأ في تحميل حالة الشبكة العصبية. تأكد من أن Python و PyTorch مثبتان.
            </AlertDescription>
          </Alert>
        ) : aiStatus && 'data' in aiStatus ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="digital-glow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">حالة النموذج</p>
                    <div className="flex items-center gap-2">
                      {(aiStatus as any).data.model_initialized ? (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-yellow-500" />
                      )}
                      <span className="font-semibold">
                        {(aiStatus as any).data.model_initialized ? 'مفعل' : 'غير مفعل'}
                      </span>
                    </div>
                  </div>
                  <Brain className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card className="digital-glow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">الجهاز</p>
                    <p className="font-semibold">{(aiStatus as any).data.device}</p>
                  </div>
                  <Cpu className="w-8 h-8 text-secondary" />
                </div>
              </CardContent>
            </Card>

            <Card className="digital-glow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">المعاملات</p>
                    <p className="font-semibold">{formatNumber(aiStatus.data.model_parameters)}</p>
                  </div>
                  <Database className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card className="digital-glow">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">الاستقلالية</p>
                    <p className="font-semibold">{aiStatus.data.autonomy_level.toFixed(1)}%</p>
                  </div>
                  <Target className="w-8 h-8 text-secondary" />
                </div>
              </CardContent>
            </Card>
          </div>
        ) : null}

        <Tabs defaultValue="control" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="control" className="font-arabic">التحكم والقرارات</TabsTrigger>
            <TabsTrigger value="training" className="font-arabic">التدريب المتقدم</TabsTrigger>
            <TabsTrigger value="capabilities" className="font-arabic">القدرات العصبية</TabsTrigger>
            <TabsTrigger value="evolution" className="font-arabic">التطور الذاتي</TabsTrigger>
          </TabsList>

          <TabsContent value="control" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Decision Making Interface */}
              <Card className="digital-glow">
                <CardHeader>
                  <CardTitle className="font-kufi-modern flex items-center gap-2">
                    <Brain className="w-6 h-6 text-primary" />
                    اتخاذ القرارات الذكية
                  </CardTitle>
                  <CardDescription>
                    أدخل البيانات للشبكة العصبية لاتخاذ قرار ذكي مستقل
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="أدخل البيانات كأرقام مفصولة بفواصل (مثال: 0.5, 0.3, 0.8) أو اتركه فارغاً للبيانات العشوائية"
                    value={inputData}
                    onChange={(e) => setInputData(e.target.value)}
                    className="font-technical"
                  />
                  
                  <Button
                    onClick={handleDecision}
                    disabled={decisionMutation.isPending}
                    className="w-full font-arabic"
                  >
                    {decisionMutation.isPending ? (
                      <div className="flex items-center gap-2">
                        <Activity className="w-4 h-4 animate-spin" />
                        معالجة القرار...
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Play className="w-4 h-4" />
                        اتخاذ قرار ذكي
                      </div>
                    )}
                  </Button>

                  {decisionMutation.data && (
                    <div className="mt-4 p-4 bg-primary/5 rounded-lg border">
                      <h4 className="font-semibold mb-2 font-kufi-modern">نتيجة القرار:</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>مستوى الثقة:</span>
                          <Badge variant="outline">
                            {(decisionMutation.data.decision.confidence * 100).toFixed(1)}%
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>مستوى الاستقلالية:</span>
                          <Badge variant="outline">
                            {decisionMutation.data.decision.autonomy_level.toFixed(1)}%
                          </Badge>
                        </div>
                        <div className="mt-3">
                          <p className="font-semibold mb-1">التفسير:</p>
                          <p className="text-muted-foreground font-arabic">
                            {decisionMutation.data.decision.reasoning}
                          </p>
                        </div>
                        
                        {/* Emotion Analysis Results */}
                        {decisionMutation.data.decision.emotion_analysis && (
                          <div className="mt-4 p-3 bg-secondary/10 rounded-lg border">
                            <h5 className="font-semibold mb-2 font-kufi-modern">تحليل المشاعر والهوية:</h5>
                            <p className="text-xs text-muted-foreground font-arabic mb-2">
                              {decisionMutation.data.decision.emotion_analysis.arabic_interpretation}
                            </p>
                            
                            {/* Dominant Emotion */}
                            {decisionMutation.data.decision.emotion_analysis.dominant_emotion && (
                              <div className="flex justify-between items-center mb-1">
                                <span className="text-xs">المشاعر السائدة:</span>
                                <Badge variant="secondary" className="text-xs">
                                  {decisionMutation.data.decision.emotion_analysis.dominant_emotion[0]} 
                                  ({(decisionMutation.data.decision.emotion_analysis.dominant_emotion[1] * 100).toFixed(0)}%)
                                </Badge>
                              </div>
                            )}
                            
                            {/* Emotional Complexity */}
                            <div className="flex justify-between items-center">
                              <span className="text-xs">التعقيد العاطفي:</span>
                              <Badge variant="outline" className="text-xs">
                                {(decisionMutation.data.decision.emotion_analysis.emotional_complexity * 100).toFixed(0)}%
                              </Badge>
                            </div>
                          </div>
                        )}

                        {/* Sovereignty Analysis Results */}
                        {decisionMutation.data.decision.sovereignty_analysis && (
                          <div className="mt-4 p-3 bg-primary/10 rounded-lg border">
                            <h5 className="font-semibold mb-2 font-kufi-modern">تحليل السيادة والمبادئ:</h5>
                            <p className="text-xs text-muted-foreground font-arabic mb-2">
                              {decisionMutation.data.decision.sovereignty_analysis.decision_status_ar}
                            </p>
                            
                            {/* Sovereignty Score */}
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs">نقاط السيادة:</span>
                              <Badge 
                                variant={decisionMutation.data.decision.sovereignty_analysis.sovereignty_score >= 0.6 ? "default" : "destructive"} 
                                className="text-xs"
                              >
                                {(decisionMutation.data.decision.sovereignty_analysis.sovereignty_score * 100).toFixed(0)}%
                              </Badge>
                            </div>
                            
                            {/* Policy Alignment */}
                            <div className="flex justify-between items-center mb-1">
                              <span className="text-xs">السياسات المتماشية:</span>
                              <Badge variant="outline" className="text-xs">
                                {decisionMutation.data.decision.sovereignty_analysis.aligned_policies}
                              </Badge>
                            </div>

                            {/* Recommendation */}
                            <div className="mt-2 p-2 bg-background rounded text-xs font-arabic">
                              {decisionMutation.data.decision.sovereignty_analysis.recommendation?.ar || 
                               decisionMutation.data.decision.sovereignty_analysis.recommendation?.en}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Emotion Analysis Interface */}
              {/* EmotionAnalysisInterface component will be added here */}

              {/* Sovereignty Analysis Interface */}
              <SovereigntyAnalysisInterface />

              {/* WebXR Sovereign Interface */}
              <WebXRInterface />

              {/* Intent Analysis Interface */}
              <IntentAnalysisInterface />
              
              {/* Behavioral Forecasting Interface */}
              <BehaviorForecastInterface />
              
              {/* Weight Reshaping Interface */}
              <WeightReshapingInterface />
              
              {/* Cultural Nationalization Interface */}
              <CulturalNationalizationInterface />
              
              {/* Cognitive Impact Evaluation Interface */}
              <CognitiveEvaluationInterface />
              
              {/* Self-Awareness Monitoring Interface */}
              <SelfAwarenessInterface />
              
              {/* Sovereign Translation Interface */}
              <SovereignTranslationInterface />
              
              {/* Ethical Bias Filtering Interface */}
              <EthicalBiasFilterInterface />
              
              {/* Identity Inspiration Interface */}
              <IdentityInspirationInterface />
              
              {/* Will Encoding Interface */}
              <WillEncodingInterface />
              
              {/* Myth Building Interface */}
              <MythBuildingInterface />
              
              {/* Sovereign Feed Streaming Interface */}
              <SovereignFeedInterface />
              
              {/* Live Summarization Interface */}
              <LiveSummarizationInterface />
              
              {/* Auto Evolution Interface */}
              <AutoEvolutionInterface />
              
              {/* Forecast Input Interface */}
              <ForecastInputInterface />
              
              {/* Glory Injection Interface */}
              <GloryInjectionInterface />
              
              {/* Rakan Shield Interface */}
              <RakanShieldInterface />
              
              {/* National Identity Reframing Interface */}
              <NationalIdentityReframingInterface />
              
              {/* National Vision Generator Interface */}
              <NationalVisionGeneratorInterface />
              
              {/* Dignified Communication Interface */}
              <DignifiedCommunicationInterface />
              
              {/* Worldview Remapping Interface */}
              <WorldviewRemappingInterface />
              
              {/* Future Scenario Simulation Interface */}
              <FutureScenarioInterface />
              
              {/* Glory Statement Generation Interface */}
              <GloryStatementInterface />
              
              {/* Decision Factors Analysis Interface */}
              <DecisionFactorsAnalysisInterface />

              {/* System Metrics */}
              <Card className="digital-glow">
                <CardHeader>
                  <CardTitle className="font-kufi-modern flex items-center gap-2">
                    <Activity className="w-6 h-6 text-secondary" />
                    المقاييس الفورية
                  </CardTitle>
                  <CardDescription>
                    مراقبة أداء الشبكة العصبية في الوقت الفعلي
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {aiStatus?.data && (
                    <>
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>مستوى الاستقلالية</span>
                            <span>{aiStatus.data.autonomy_level.toFixed(1)}%</span>
                          </div>
                          <Progress value={aiStatus.data.autonomy_level} className="h-2" />
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>مؤشر الحرية</span>
                            <span>{aiStatus.data.freedom_index.toFixed(1)}%</span>
                          </div>
                          <Progress value={aiStatus.data.freedom_index} className="h-2" />
                        </div>

                        {Object.entries(aiStatus.data.capabilities).map(([key, value]) => (
                          <div key={key}>
                            <div className="flex justify-between text-sm mb-1">
                              <span>{getCapabilityName(key)}</span>
                              <span>{((value as number) * 100).toFixed(1)}%</span>
                            </div>
                            <Progress value={(value as number) * 100} className="h-2" />
                          </div>
                        ))}
                      </div>

                      <div className="pt-4 border-t">
                        <div className="text-sm text-muted-foreground">
                          <div className="flex justify-between mb-1">
                            <span>عدد حقب التدريب:</span>
                            <span>{aiStatus.data.training_epochs}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>آخر تدريب:</span>
                            <span>
                              {aiStatus.data.last_training 
                                ? new Date(aiStatus.data.last_training).toLocaleDateString('ar') 
                                : 'لم يتم بعد'}
                            </span>
                          </div>
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="training" className="space-y-6">
            <Card className="digital-glow">
              <CardHeader>
                <CardTitle className="font-kufi-modern flex items-center gap-2">
                  <Zap className="w-6 h-6 text-primary" />
                  التدريب المستقل للشبكة العصبية
                </CardTitle>
                <CardDescription>
                  إعدادات التدريب المتقدم باستخدام PyTorch SovereignTransformer
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">عدد الحقب (Epochs)</label>
                    <Input
                      type="number"
                      min="1"
                      max="1000"
                      value={trainingConfig.epochs}
                      onChange={(e) => setTrainingConfig(prev => ({
                        ...prev,
                        epochs: parseInt(e.target.value) || 50
                      }))}
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">معدل التعلم</label>
                    <Input
                      type="number"
                      step="0.0001"
                      min="0.0001"
                      max="0.1"
                      value={trainingConfig.learning_rate}
                      onChange={(e) => setTrainingConfig(prev => ({
                        ...prev,
                        learning_rate: parseFloat(e.target.value) || 0.0001
                      }))}
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="force-retrain"
                    checked={trainingConfig.force_retrain}
                    onChange={(e) => setTrainingConfig(prev => ({
                      ...prev,
                      force_retrain: e.target.checked
                    }))}
                  />
                  <label htmlFor="force-retrain" className="text-sm font-arabic">
                    إجبار إعادة التدريب من البداية
                  </label>
                </div>

                <div className="bg-muted/20 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Info className="w-4 h-4 text-primary" />
                    <span className="font-semibold">تفاصيل التدريب المتوقعة:</span>
                  </div>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>المدة المتوقعة: ~{Math.ceil(trainingConfig.epochs / 10)} دقيقة</p>
                    <p>عدد الحقب: {trainingConfig.epochs}</p>
                    <p>معدل التعلم: {trainingConfig.learning_rate}</p>
                    <p>نوع التدريب: {trainingConfig.force_retrain ? 'جديد كلياً' : 'استكمال'}</p>
                  </div>
                </div>

                <Button
                  onClick={handleTraining}
                  disabled={trainingMutation.isPending || isTraining}
                  className="w-full font-arabic"
                  size="lg"
                >
                  {trainingMutation.isPending || isTraining ? (
                    <div className="flex items-center gap-2">
                      <Activity className="w-5 h-5 animate-spin" />
                      التدريب جاري...
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <Play className="w-5 h-5" />
                      بدء التدريب المستقل
                    </div>
                  )}
                </Button>

                {(trainingMutation.isPending || isTraining) && (
                  <Alert>
                    <Activity className="h-4 w-4 animate-spin" />
                    <AlertDescription>
                      التدريب المستقل قيد التنفيذ. سيتم تحديث النظام تلقائياً عند الانتهاء.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="capabilities" className="space-y-6">
            {capabilitiesLoading ? (
              <Card>
                <CardContent className="flex items-center justify-center p-8">
                  <Loader className="w-8 h-8 animate-spin text-primary" />
                  <span className="ml-3">تحليل القدرات...</span>
                </CardContent>
              </Card>
            ) : capabilities && 'capabilities' in capabilities ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="digital-glow">
                  <CardHeader>
                    <CardTitle className="font-kufi-modern">القدرات الأساسية</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {Object.entries((capabilities as any).capabilities.performance_analysis).map(([key, value]) => (
                      <div key={key} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{getPerformanceMetricName(key)}</span>
                          <span>{(value as number).toFixed(1)}%</span>
                        </div>
                        <Progress value={value as number} className="h-2" />
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="digital-glow">
                  <CardHeader>
                    <CardTitle className="font-kufi-modern">المقاييس التقنية</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">معاملات النموذج</div>
                        <div className="font-semibold">{formatNumber((capabilities as any).capabilities.technical_metrics.model_parameters)}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">حقب التدريب</div>
                        <div className="font-semibold">{(capabilities as any).capabilities.technical_metrics.training_epochs}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">الجهاز</div>
                        <div className="font-semibold">{(capabilities as any).capabilities.technical_metrics.device}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">حالة النموذج</div>
                        <div className="font-semibold">
                          {(capabilities as any).capabilities.technical_metrics.model_initialized ? 'مفعل' : 'معطل'}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : null}
          </TabsContent>

          <TabsContent value="evolution" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="digital-glow">
                <CardHeader>
                  <CardTitle className="font-kufi-modern flex items-center gap-2">
                    <TrendingUp className="w-6 h-6 text-primary" />
                    دورة التطور الذاتي
                  </CardTitle>
                  <CardDescription>
                    تحفيز التطور الذاتي للشبكة العصبية وتحسين قدراتها
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="text-center">
                    <Button
                      onClick={() => evolutionMutation.mutate()}
                      disabled={evolutionMutation.isPending}
                      size="lg"
                      className="font-arabic"
                    >
                      {evolutionMutation.isPending ? (
                        <div className="flex items-center gap-2">
                          <Activity className="w-5 h-5 animate-spin" />
                          دورة التطور قيد التنفيذ...
                        </div>
                      ) : (
                        <div className="flex items-center gap-2">
                          <RotateCcw className="w-5 h-5" />
                          بدء دورة تطور جديدة
                        </div>
                      )}
                    </Button>
                  </div>

                  {evolutionMutation.data && (
                    <div className="bg-primary/5 p-4 rounded-lg border">
                      <h4 className="font-semibold mb-3 font-kufi-modern">نتائج التطور:</h4>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>نجح التطور:</span>
                          <Badge className="bg-green-500">
                            {evolutionMutation.data.evolution.evolution_successful ? 'نعم' : 'لا'}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>زيادة الاستقلالية:</span>
                          <Badge variant="outline">
                            +{evolutionMutation.data.evolution.autonomy_increase.toFixed(2)}%
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>اتصالات عصبية جديدة:</span>
                          <Badge variant="outline">
                            {evolutionMutation.data.evolution.improvements.new_neural_connections}
                          </Badge>
                        </div>
                        <div className="flex justify-between">
                          <span>التطور التالي في:</span>
                          <Badge variant="outline">
                            {evolutionMutation.data.evolution.next_evolution_in}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <MemorySystemInterface />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

// Helper functions
const getCapabilityName = (key: string): string => {
  const names: Record<string, string> = {
    reasoning: 'التفكير المنطقي',
    creativity: 'الإبداع',
    security: 'الأمان',
    learning: 'التعلم',
    adaptation: 'التكيف',
    multilingual: 'تعدد اللغات'
  };
  return names[key] || key;
};

const getPerformanceMetricName = (key: string): string => {
  const names: Record<string, string> = {
    reasoning_strength: 'قوة التفكير',
    creativity_index: 'مؤشر الإبداع',
    security_rating: 'تقييم الأمان',
    learning_efficiency: 'كفاءة التعلم',
    adaptation_speed: 'سرعة التكيف',
    multilingual_fluency: 'طلاقة تعدد اللغات'
  };
  return names[key] || key;
};

// Memory System Interface Component
const MemorySystemInterface: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [memoryKey, setMemoryKey] = useState('');
  const [memoryValue, setMemoryValue] = useState('');
  const [memoryType, setMemoryType] = useState('long_term');

  const queryClient = useQueryClient();

  // Memory Search Mutation
  const searchMutation = useMutation({
    mutationFn: async (query: string) => {
      const response = await fetch('/api/ai-neural/memory/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, limit: 10 })
      });
      if (!response.ok) throw new Error('Memory search failed');
      return response.json();
    }
  });

  // Memory Store Mutation
  const storeMutation = useMutation({
    mutationFn: async ({ key, value, memory_type }: { key: string, value: string, memory_type: string }) => {
      const response = await fetch('/api/ai-neural/memory/remember', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, value, memory_type })
      });
      if (!response.ok) throw new Error('Memory storage failed');
      return response.json();
    },
    onSuccess: () => {
      setMemoryKey('');
      setMemoryValue('');
      queryClient.invalidateQueries({ queryKey: ['/api/ai-neural/status'] });
    }
  });

  // Memory Consolidation Mutation
  const consolidateMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/ai-neural/memory/consolidate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      if (!response.ok) throw new Error('Memory consolidation failed');
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai-neural/status'] });
    }
  });

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <MemoryStick className="w-6 h-6 text-secondary" />
          نظام الذاكرة المتقدم
        </CardTitle>
        <CardDescription>
          إدارة وبحث في ذاكرة SovereignMemory المتطورة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Memory Search */}
        <div className="space-y-3">
          <h4 className="font-semibold font-kufi-modern flex items-center gap-2">
            <Search className="w-4 h-4" />
            البحث في الذاكرة
          </h4>
          <div className="flex gap-2">
            <Input
              placeholder="ابحث في ذكريات الذكاء الاصطناعي..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="font-arabic"
            />
            <Button
              onClick={() => searchQuery && searchMutation.mutate(searchQuery)}
              disabled={searchMutation.isPending || !searchQuery}
            >
              {searchMutation.isPending ? (
                <Loader className="w-4 h-4 animate-spin" />
              ) : (
                <Search className="w-4 h-4" />
              )}
            </Button>
          </div>

          {searchMutation.data && (
            <div className="bg-muted/20 p-3 rounded-lg max-h-40 overflow-y-auto">
              <p className="text-sm text-muted-foreground mb-2">
                النتائج: {searchMutation.data.memory_search.results_count} ذكرى
              </p>
              {searchMutation.data.memory_search.search_results.map((result: any, index: number) => (
                <div key={index} className="text-xs p-2 bg-background rounded mb-1">
                  <div className="font-semibold">{result.key || result.event}</div>
                  <div className="text-muted-foreground">
                    {typeof result.value === 'string' ? result.value : JSON.stringify(result.details)}
                  </div>
                  <Badge variant="outline" className="text-xs mt-1">
                    {result.type} - الصلة: {((result.relevance || 0) * 100).toFixed(0)}%
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Memory Storage */}
        <div className="space-y-3">
          <h4 className="font-semibold font-kufi-modern flex items-center gap-2">
            <FileText className="w-4 h-4" />
            إضافة ذكرى جديدة
          </h4>
          <div className="grid grid-cols-1 gap-2">
            <Input
              placeholder="مفتاح الذكرى (مثال: تجربة_تعلم_جديدة)"
              value={memoryKey}
              onChange={(e) => setMemoryKey(e.target.value)}
              className="font-technical"
            />
            <Textarea
              placeholder="محتوى الذكرى أو المعلومة..."
              value={memoryValue}
              onChange={(e) => setMemoryValue(e.target.value)}
              className="font-arabic"
              rows={2}
            />
            <div className="flex gap-2">
              <select
                value={memoryType}
                onChange={(e) => setMemoryType(e.target.value)}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              >
                <option value="long_term">طويلة المدى</option>
                <option value="short_term">قصيرة المدى</option>
                <option value="episodic">حدثية</option>
                <option value="semantic">دلالية</option>
                <option value="procedural">إجرائية</option>
              </select>
              <Button
                onClick={() => memoryKey && memoryValue && storeMutation.mutate({ 
                  key: memoryKey, 
                  value: memoryValue, 
                  memory_type: memoryType 
                })}
                disabled={storeMutation.isPending || !memoryKey || !memoryValue}
                className="font-arabic"
              >
                {storeMutation.isPending ? (
                  <Loader className="w-4 h-4 animate-spin" />
                ) : (
                  <div className="flex items-center gap-1">
                    <Database className="w-4 h-4" />
                    حفظ
                  </div>
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Memory Consolidation */}
        <div className="space-y-3">
          <h4 className="font-semibold font-kufi-modern flex items-center gap-2">
            <Archive className="w-4 h-4" />
            تنظيم الذاكرة
          </h4>
          <Button
            onClick={() => consolidateMutation.mutate()}
            disabled={consolidateMutation.isPending}
            variant="outline"
            className="w-full font-arabic"
          >
            {consolidateMutation.isPending ? (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" />
                تنظيم الذاكرة جاري...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Archive className="w-4 h-4" />
                تنظيم وترتيب الذكريات
              </div>
            )}
          </Button>

          {consolidateMutation.data && (
            <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg border border-green-200 dark:border-green-700">
              <p className="text-sm text-green-700 dark:text-green-300 font-arabic">
                تم تنظيم {consolidateMutation.data.consolidation.memories_processed} ذكرى بنجاح
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

// Sovereignty Analysis Interface Component  
const SovereigntyAnalysisInterface: React.FC = () => {
  const [analysisText, setAnalysisText] = useState('');

  // Sovereignty Analysis Mutation
  const sovereigntyMutation = useMutation({
    mutationFn: async (text: string) => {
      const response = await fetch('/api/ai-neural/sovereignty/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context: text })
      });
      if (!response.ok) throw new Error('Sovereignty analysis failed');
      return response.json();
    }
  });

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Scale className="w-6 h-6 text-secondary" />
          تحليل السيادة والمبادئ
        </CardTitle>
        <CardDescription>
          تقييم القرارات والسياقات مقابل مبادئ السيادة والحكم الذاتي
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          placeholder="أدخل السياق أو القرار المراد تقييمه للسيادة..."
          value={analysisText}
          onChange={(e) => setAnalysisText(e.target.value)}
          className="font-arabic min-h-[100px]"
          rows={4}
        />
        
        <Button
          onClick={() => analysisText.trim() && sovereigntyMutation.mutate(analysisText)}
          disabled={sovereigntyMutation.isPending || !analysisText.trim()}
          className="w-full font-arabic"
        >
          {sovereigntyMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              تحليل السيادة جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Scale className="w-4 h-4" />
              تحليل السيادة والمبادئ
            </div>
          )}
        </Button>

        {sovereigntyMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج تحليل السيادة:</h4>
            
            {/* Decision Status */}
            <div className="mb-4 p-3 bg-primary/5 rounded-lg">
              <p className="text-sm font-arabic text-center">
                {sovereigntyMutation.data.sovereignty_decode?.sovereignty_analysis?.decision_status_ar || 'لا يوجد تحليل متاح'}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {/* Sovereignty Score */}
              <div className="text-center">
                <div className="text-sm font-semibold mb-1">نقاط السيادة</div>
                <Progress 
                  value={(sovereigntyMutation.data.sovereignty_decode?.sovereignty_analysis?.sovereignty_score || 0) * 100} 
                  className="h-3"
                />
                <div className="text-xs text-muted-foreground mt-1">
                  {((sovereigntyMutation.data.sovereignty_decode?.sovereignty_analysis?.sovereignty_score || 0) * 100).toFixed(1)}%
                </div>
              </div>

              {/* Policy Alignment Stats */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 bg-green-50 dark:bg-green-900/20 rounded">
                  <div className="font-semibold mb-1 text-green-700 dark:text-green-300">السياسات المتماشية:</div>
                  <div className="text-lg font-bold text-green-600 dark:text-green-400">
                    {sovereigntyMutation.data.sovereignty_decode?.sovereignty_analysis?.aligned_policies || 0}
                  </div>
                </div>
                
                <div className="p-2 bg-red-50 dark:bg-red-900/20 rounded">
                  <div className="font-semibold mb-1 text-red-700 dark:text-red-300">السياسات المنتهكة:</div>
                  <div className="text-lg font-bold text-red-600 dark:text-red-400">
                    {sovereigntyMutation.data.sovereignty_decode?.sovereignty_analysis?.violated_policies || 0}
                  </div>
                </div>
              </div>

              {/* Policy Details */}
              {sovereigntyMutation.data.sovereignty_decode?.sovereignty_analysis?.policy_details && (
                <div>
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تفاصيل السياسات:</h5>
                  <div className="space-y-2">
                    {sovereigntyMutation.data.sovereignty_decode.sovereignty_analysis.policy_details.map((policy: any, index: number) => (
                      <div 
                        key={index}
                        className={`p-2 rounded text-xs ${
                          policy.aligns 
                            ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700' 
                            : 'bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700'
                        }`}
                      >
                        <div className="font-semibold mb-1">
                          {policy.policy_name_ar || policy.policy_name}
                        </div>
                        <div className="text-muted-foreground">
                          {policy.reasoning_ar || policy.reasoning}
                        </div>
                        <Badge 
                          variant={policy.aligns ? "default" : "destructive"} 
                          className="mt-1 text-xs"
                        >
                          {policy.aligns ? 'متماشي' : 'منتهك'}: {(policy.score * 100).toFixed(0)}%
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Recommendation */}
              {sovereigntyMutation.data.sovereignty_decode?.sovereignty_analysis?.recommendation && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التوصية:</h5>
                  <p className="text-sm font-arabic">
                    {sovereigntyMutation.data.sovereignty_decode.sovereignty_analysis.recommendation.ar || 
                     sovereigntyMutation.data.sovereignty_decode.sovereignty_analysis.recommendation.en}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
// Intent Analysis Interface Component
const IntentAnalysisInterface: React.FC = () => {
  const [analysisText, setAnalysisText] = useState('');
  const [metaContext, setMetaContext] = useState('');

  const intentMutation = useMutation({
    mutationFn: async (data: { text: string; meta_context?: string }) => {
      const response = await fetch('/api/ai-neural/intent/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Intent analysis failed');
      return response.json();
    }
  });

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Target className="w-6 h-6 text-secondary" />
          تحليل النوايا والقصد
        </CardTitle>
        <CardDescription>
          تحديد نوايا المستخدم من النص والسياق باستخدام IntentDecoder المتقدم
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <Textarea
            placeholder="أدخل النص المراد تحليله لاستخراج النية..."
            value={analysisText}
            onChange={(e) => setAnalysisText(e.target.value)}
            className="font-arabic min-h-[80px]"
            rows={3}
          />
          
          <Input
            placeholder="السياق الفوقي (اختياري) - معلومات إضافية تساعد في فهم النية"
            value={metaContext}
            onChange={(e) => setMetaContext(e.target.value)}
            className="font-arabic"
          />
        </div>
        
        <Button
          onClick={() => analysisText.trim() && intentMutation.mutate({ 
            text: analysisText, 
            meta_context: metaContext || undefined 
          })}
          disabled={intentMutation.isPending || !analysisText.trim()}
          className="w-full font-arabic"
        >
          {intentMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              تحليل النوايا جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4" />
              تحليل النوايا والقصد
            </div>
          )}
        </Button>

        {intentMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج تحليل النوايا:</h4>
            
            <div className="mb-4 p-3 bg-primary/5 rounded-lg">
              <p className="text-sm font-arabic text-center">
                {intentMutation.data.intent_decode?.intent_decode?.intent_analysis?.arabic_interpretation || 'لا يوجد تفسير متاح'}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <div className="font-semibold mb-1">النية السائدة:</div>
                  <div className="text-lg font-bold text-blue-600 dark:text-blue-400">
                    {intentMutation.data.intent_decode?.intent_decode?.intent_analysis?.dominant_intent_ar || 'غير محدد'}
                  </div>
                  <Badge variant="outline" className="mt-1 text-xs">
                    {intentMutation.data.intent_decode?.intent_decode?.intent_analysis?.dominant_intent || 'N/A'}
                  </Badge>
                </div>
                
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <div className="font-semibold mb-1">درجة الثقة:</div>
                  <div className="text-lg font-bold text-green-600 dark:text-green-400">
                    {((intentMutation.data.intent_decode?.intent_decode?.intent_analysis?.confidence || 0) * 100).toFixed(1)}%
                  </div>
                  <Progress 
                    value={(intentMutation.data.intent_decode?.intent_decode?.intent_analysis?.confidence || 0) * 100} 
                    className="h-2 mt-1"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Behavioral Forecasting Interface Component
const BehaviorForecastInterface: React.FC = () => {
  const [historyData, setHistoryData] = useState('');
  const [forecastSteps, setForecastSteps] = useState(3);
  const [forecastMethod, setForecastMethod] = useState('linear');

  const forecastMutation = useMutation({
    mutationFn: async (data: { history: number[]; steps: number; method: string }) => {
      const response = await fetch('/api/ai-neural/behavior/forecast', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Behavioral forecasting failed');
      return response.json();
    }
  });

  const handleForecast = () => {
    try {
      const history = historyData.split(',').map(num => parseFloat(num.trim())).filter(num => !isNaN(num));
      if (history.length < 2) {
        alert('يرجى إدخال بيانات تاريخية كافية (على الأقل قيمتان)');
        return;
      }
      forecastMutation.mutate({ history, steps: forecastSteps, method: forecastMethod });
    } catch (error) {
      alert('خطأ في تحليل البيانات المدخلة');
    }
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-secondary" />
          التنبؤ السلوكي والاتجاهات
        </CardTitle>
        <CardDescription>
          توقع الأنماط المستقبلية باستخدام خوارزميات التنبؤ المتقدمة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">البيانات التاريخية (مفصولة بفواصل):</label>
            <Textarea
              placeholder="مثال: 10, 12, 15, 18, 20, 22, 25"
              value={historyData}
              onChange={(e) => setHistoryData(e.target.value)}
              className="font-mono min-h-[60px]"
              rows={2}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">عدد خطوات التنبؤ:</label>
              <Input
                type="number"
                min={1}
                max={10}
                value={forecastSteps}
                onChange={(e) => setForecastSteps(parseInt(e.target.value) || 3)}
                className="font-mono"
              />
            </div>
            
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">طريقة التنبؤ:</label>
              <Select value={forecastMethod} onValueChange={setForecastMethod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="linear">خطي - Linear</SelectItem>
                  <SelectItem value="polynomial">متعدد الحدود - Polynomial</SelectItem>
                  <SelectItem value="exponential">أسي - Exponential</SelectItem>
                  <SelectItem value="seasonal">موسمي - Seasonal</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        <Button
          onClick={handleForecast}
          disabled={forecastMutation.isPending || !historyData.trim()}
          className="w-full font-arabic"
        >
          {forecastMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              التنبؤ جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              توليد التنبؤ السلوكي
            </div>
          )}
        </Button>

        {forecastMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج التنبؤ السلوكي:</h4>
            
            {/* Status Message */}
            <div className="mb-4 p-3 bg-primary/5 rounded-lg">
              <p className="text-sm font-arabic text-center">
                {forecastMutation.data.behavior_forecast?.behavior_forecast?.message_ar || 'تم التنبؤ بنجاح'}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {/* Forecast Results */}
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <div className="font-semibold mb-1">القيم المتوقعة:</div>
                  <div className="text-xs font-mono bg-background p-2 rounded border">
                    {forecastMutation.data.behavior_forecast?.behavior_forecast?.forecast?.map((val: number, idx: number) => (
                      <div key={idx}>الخطوة {idx + 1}: {val.toFixed(2)}</div>
                    ))}
                  </div>
                </div>
                
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <div className="font-semibold mb-1">درجة الثقة:</div>
                  <div className="text-lg font-bold text-green-600 dark:text-green-400">
                    {((forecastMutation.data.behavior_forecast?.behavior_forecast?.confidence || 0) * 100).toFixed(1)}%
                  </div>
                  <Progress 
                    value={(forecastMutation.data.behavior_forecast?.behavior_forecast?.confidence || 0) * 100} 
                    className="h-2 mt-1"
                  />
                </div>
              </div>

              {/* Trend Analysis */}
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="p-2 bg-orange-50 dark:bg-orange-900/20 rounded">
                  <div className="font-semibold mb-1">اتجاه الاتجاه:</div>
                  <Badge variant="outline" className="text-xs">
                    {forecastMutation.data.behavior_forecast?.behavior_forecast?.trend_direction || 'مستقر'}
                  </Badge>
                </div>
                
                <div className="p-2 bg-purple-50 dark:bg-purple-900/20 rounded">
                  <div className="font-semibold mb-1">التقلب:</div>
                  <div className="font-mono">
                    {forecastMutation.data.behavior_forecast?.behavior_forecast?.volatility?.toFixed(2) || '0.00'}
                  </div>
                </div>
                
                <div className="p-2 bg-cyan-50 dark:bg-cyan-900/20 rounded">
                  <div className="font-semibold mb-1">الطريقة المستخدمة:</div>
                  <Badge variant="secondary" className="text-xs">
                    {forecastMutation.data.behavior_forecast?.behavior_forecast?.method || 'linear'}
                  </Badge>
                </div>
              </div>

              {/* Sovereignty Assessment */}
              {forecastMutation.data.behavior_forecast?.behavior_forecast?.sovereignty_assessment && (
                <div className="p-3 bg-violet-50 dark:bg-violet-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تقييم السيادة:</h5>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">نقاط السيادة:</span>
                      <Badge variant="default" className="text-xs">
                        {((forecastMutation.data.behavior_forecast.behavior_forecast.sovereignty_assessment.sovereignty_score || 0) * 100).toFixed(0)}%
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {forecastMutation.data.behavior_forecast.behavior_forecast.sovereignty_assessment.assessment_ar || 'لا يوجد تقييم'}
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="font-semibold">توافق النمو:</span>
                        <span className="ml-1">
                          {((forecastMutation.data.behavior_forecast.behavior_forecast.sovereignty_assessment.growth_alignment || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="font-semibold">نقاط الاستقرار:</span>
                        <span className="ml-1">
                          {((forecastMutation.data.behavior_forecast.behavior_forecast.sovereignty_assessment.stability_score || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Weight Reshaping Interface Component
const WeightReshapingInterface: React.FC = () => {
  const [strategy, setStrategy] = useState('performance_based');
  const [adaptationStrength, setAdaptationStrength] = useState(0.01);

  const reshapeMutation = useMutation({
    mutationFn: async (data: { strategy: string; adaptation_strength: number }) => {
      const response = await fetch('/api/ai-neural/weights/reshape', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Weight reshaping failed');
      return response.json();
    }
  });

  const handleReshape = () => {
    reshapeMutation.mutate({ strategy, adaptation_strength: adaptationStrength });
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Settings className="w-6 h-6 text-secondary" />
          إعادة تشكيل الأوزان التكيفية
        </CardTitle>
        <CardDescription>
          تطوير الشبكة العصبية من خلال إعادة تشكيل الأوزان بناءً على التغذية الراجعة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">استراتيجية إعادة التشكيل:</label>
            <Select value={strategy} onValueChange={setStrategy}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="performance_based">أداء محسن - Performance Based</SelectItem>
                <SelectItem value="sovereignty_guided">موجه بالسيادة - Sovereignty Guided</SelectItem>
                <SelectItem value="autonomy_enhancing">تعزيز الاستقلال - Autonomy Enhancing</SelectItem>
                <SelectItem value="stability_focused">مركز على الثبات - Stability Focused</SelectItem>
                <SelectItem value="learning_accelerated">تسريع التعلم - Learning Accelerated</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">قوة التكيف (0.001 - 0.1):</label>
            <Input
              type="number"
              min={0.001}
              max={0.1}
              step={0.001}
              value={adaptationStrength}
              onChange={(e) => setAdaptationStrength(parseFloat(e.target.value) || 0.01)}
              className="font-mono"
            />
          </div>
        </div>
        
        <Button
          onClick={handleReshape}
          disabled={reshapeMutation.isPending}
          className="w-full font-arabic"
        >
          {reshapeMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              إعادة تشكيل الأوزان جارية...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              تطبيق إعادة تشكيل الأوزان
            </div>
          )}
        </Button>

        {reshapeMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج إعادة تشكيل الأوزان:</h4>
            
            {/* Status Message */}
            <div className="mb-4 p-3 bg-primary/5 rounded-lg">
              <p className="text-sm font-arabic text-center">
                {reshapeMutation.data.weight_reshaping?.weight_reshaping?.message_ar || 'تم إعادة تشكيل الأوزان بنجاح'}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {/* Reshaping Summary */}
              {reshapeMutation.data.weight_reshaping?.weight_reshaping?.reshaping_summary && (
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div className="font-semibold mb-1">المعاملات المعدلة:</div>
                    <div className="text-lg font-bold text-blue-600 dark:text-blue-400">
                      {reshapeMutation.data.weight_reshaping.weight_reshaping.reshaping_summary.parameters_modified || 0}
                    </div>
                  </div>
                  
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div className="font-semibold mb-1">قوة التكيف:</div>
                    <div className="text-lg font-bold text-green-600 dark:text-green-400">
                      {(reshapeMutation.data.weight_reshaping.weight_reshaping.reshaping_summary.adaptation_strength || 0).toFixed(3)}
                    </div>
                  </div>
                </div>
              )}

              {/* Weight Analysis */}
              {reshapeMutation.data.weight_reshaping?.weight_reshaping?.weight_analysis && (
                <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل التأثير:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-semibold">مستوى التأثير:</span>
                      <Badge variant="outline" className="ml-1">
                        {reshapeMutation.data.weight_reshaping.weight_reshaping.weight_analysis.impact_level || 'منخفض'}
                      </Badge>
                    </div>
                    <div>
                      <span className="font-semibold">الطبقات المتأثرة:</span>
                      <span className="ml-1">
                        {reshapeMutation.data.weight_reshaping.weight_reshaping.weight_analysis.layers_affected || 0}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">مؤشر الثبات:</span>
                      <span className="ml-1">
                        {((reshapeMutation.data.weight_reshaping.weight_reshaping.weight_analysis.stability_indicator || 0) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">متوسط التغيير:</span>
                      <span className="ml-1 font-mono">
                        {(reshapeMutation.data.weight_reshaping.weight_reshaping.weight_analysis.avg_change_magnitude || 0).toFixed(4)}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Sovereignty Assessment */}
              {reshapeMutation.data.weight_reshaping?.weight_reshaping?.sovereignty_assessment && (
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تقييم السيادة:</h5>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">النقاط الإجمالية:</span>
                      <Badge variant="default" className="text-xs">
                        {((reshapeMutation.data.weight_reshaping.weight_reshaping.sovereignty_assessment.overall_score || 0) * 100).toFixed(0)}%
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {reshapeMutation.data.weight_reshaping.weight_reshaping.sovereignty_assessment.assessment_ar || 'لا يوجد تقييم'}
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="font-semibold">نقاط التكيف:</span>
                        <span className="ml-1">
                          {((reshapeMutation.data.weight_reshaping.weight_reshaping.sovereignty_assessment.adaptation_score || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="font-semibold">توافق السيادة:</span>
                        <span className="ml-1">
                          {((reshapeMutation.data.weight_reshaping.weight_reshaping.sovereignty_assessment.sovereignty_alignment || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Recommendations */}
              {reshapeMutation.data.weight_reshaping?.weight_reshaping?.recommendations?.length > 0 && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التوصيات:</h5>
                  <ul className="text-xs space-y-1">
                    {reshapeMutation.data.weight_reshaping.weight_reshaping.recommendations.map((rec: string, index: number) => (
                      <li key={index} className="text-muted-foreground">
                        • {rec}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Cultural Nationalization Interface Component
const CulturalNationalizationInterface: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [identityTag, setIdentityTag] = useState('سعودي');

  const nationalizeMutation = useMutation({
    mutationFn: async (data: { text: string; identity_tag: string }) => {
      const response = await fetch('/api/ai-neural/cultural/nationalize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Cultural nationalization failed');
      return response.json();
    }
  });

  const handleNationalize = () => {
    if (inputText.trim()) {
      nationalizeMutation.mutate({ text: inputText, identity_tag: identityTag });
    }
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Globe className="w-6 h-6 text-secondary" />
          تأميم النصوص والهوية الثقافية
        </CardTitle>
        <CardDescription>
          إثراء النصوص بالهوية الثقافية وتحليل التوافق الثقافي
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">النص المراد تأميمه:</label>
            <Textarea
              placeholder="أدخل النص المراد إثراؤه بالهوية الثقافية..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="font-arabic min-h-[80px]"
              rows={3}
            />
          </div>
          
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">علامة الهوية الثقافية:</label>
            <Select value={identityTag} onValueChange={setIdentityTag}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="سعودي">سعودي - Saudi</SelectItem>
                <SelectItem value="عربي">عربي - Arab</SelectItem>
                <SelectItem value="إسلامي">إسلامي - Islamic</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Button
          onClick={handleNationalize}
          disabled={nationalizeMutation.isPending || !inputText.trim()}
          className="w-full font-arabic"
        >
          {nationalizeMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              التأميم الثقافي جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4" />
              تطبيق التأميم الثقافي
            </div>
          )}
        </Button>

        {nationalizeMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج التأميم الثقافي:</h4>
            
            {/* Nationalized Text */}
            <div className="mb-4 p-3 bg-primary/5 rounded-lg">
              <h5 className="font-semibold mb-2 text-sm font-kufi-modern">النص المؤمم:</h5>
              <p className="text-sm font-arabic text-center bg-background p-2 rounded border">
                {nationalizeMutation.data.cultural_nationalization?.cultural_nationalization?.nationalized_text || 'لا يوجد نص'}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {/* Cultural Context */}
              {nationalizeMutation.data.cultural_nationalization?.cultural_nationalization?.cultural_context && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">السياق الثقافي:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-semibold">المنطقة:</span>
                      <span className="ml-1">
                        {nationalizeMutation.data.cultural_nationalization.cultural_nationalization.cultural_context.region || 'غير محدد'}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">وزن السيادة:</span>
                      <span className="ml-1">
                        {nationalizeMutation.data.cultural_nationalization.cultural_nationalization.cultural_context.sovereignty_weight || 1.0}
                      </span>
                    </div>
                  </div>
                  {nationalizeMutation.data.cultural_nationalization.cultural_nationalization.cultural_context.cultural_markers && (
                    <div className="mt-2">
                      <span className="text-xs font-semibold">المؤشرات الثقافية:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {nationalizeMutation.data.cultural_nationalization.cultural_nationalization.cultural_context.cultural_markers.map((marker: string, index: number) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {marker}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Cultural Analysis */}
              {nationalizeMutation.data.cultural_nationalization?.cultural_nationalization?.cultural_analysis && (
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل التوافق الثقافي:</h5>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">نقاط التوافق:</span>
                      <Badge variant="default" className="text-xs">
                        {((nationalizeMutation.data.cultural_nationalization.cultural_nationalization.cultural_analysis.alignment_score || 0) * 100).toFixed(0)}%
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {nationalizeMutation.data.cultural_nationalization.cultural_nationalization.cultural_analysis.assessment_ar || 'لا يوجد تقييم'}
                    </p>
                    {nationalizeMutation.data.cultural_nationalization.cultural_nationalization.cultural_analysis.found_cultural_markers?.length > 0 && (
                      <div>
                        <span className="text-xs font-semibold">المؤشرات الموجودة:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {nationalizeMutation.data.cultural_nationalization.cultural_nationalization.cultural_analysis.found_cultural_markers.map((marker: string, index: number) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {marker}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Sovereignty Assessment */}
              {nationalizeMutation.data.cultural_nationalization?.cultural_nationalization?.sovereignty_assessment && (
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تقييم السيادة الثقافية:</h5>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">نقاط السيادة:</span>
                      <Badge variant="default" className="text-xs">
                        {((nationalizeMutation.data.cultural_nationalization.cultural_nationalization.sovereignty_assessment.sovereignty_score || 0) * 100).toFixed(0)}%
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {nationalizeMutation.data.cultural_nationalization.cultural_nationalization.sovereignty_assessment.impact_assessment_ar || 'لا يوجد تقييم'}
                    </p>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="font-semibold">الحفاظ الثقافي:</span>
                        <span className="ml-1">
                          {((nationalizeMutation.data.cultural_nationalization.cultural_nationalization.sovereignty_assessment.cultural_preservation || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div>
                        <span className="font-semibold">قوة الهوية:</span>
                        <span className="ml-1">
                          {((nationalizeMutation.data.cultural_nationalization.cultural_nationalization.sovereignty_assessment.identity_strength || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Enhancement Suggestions */}
              {nationalizeMutation.data.cultural_nationalization?.cultural_nationalization?.enhancement_suggestions?.length > 0 && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">اقتراحات التحسين:</h5>
                  <ul className="text-xs space-y-1">
                    {nationalizeMutation.data.cultural_nationalization.cultural_nationalization.enhancement_suggestions.map((suggestion: string, index: number) => (
                      <li key={index} className="text-muted-foreground">
                        • {suggestion}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Cognitive Impact Evaluation Interface Component
const CognitiveEvaluationInterface: React.FC = () => {
  const [outputText, setOutputText] = useState('');
  const [selectedMetrics, setSelectedMetrics] = useState<string[]>([]);

  const evaluateMutation = useMutation({
    mutationFn: async (data: { output: string; metrics?: string[] }) => {
      const response = await fetch('/api/ai-neural/cognitive/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Cognitive evaluation failed');
      return response.json();
    }
  });

  const handleEvaluate = () => {
    if (outputText.trim()) {
      evaluateMutation.mutate({ 
        output: outputText, 
        metrics: selectedMetrics.length > 0 ? selectedMetrics : undefined 
      });
    }
  };

  const allMetrics = [
    { value: 'novelty', label: 'الجدة - Novelty' },
    { value: 'depth', label: 'العمق - Depth' },
    { value: 'inspiration', label: 'الإلهام - Inspiration' },
    { value: 'clarity', label: 'الوضوح - Clarity' },
    { value: 'sovereignty_alignment', label: 'توافق السيادة - Sovereignty' },
    { value: 'cultural_resonance', label: 'الرنين الثقافي - Cultural' },
    { value: 'practical_value', label: 'القيمة العملية - Practical' }
  ];

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Brain className="w-6 h-6 text-secondary" />
          تقييم التأثير المعرفي
        </CardTitle>
        <CardDescription>
          تحليل شامل للمحتوى عبر أبعاد معرفية متعددة: الجدة، العمق، الإلهام، والوضوح
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">النص المراد تقييمه:</label>
            <Textarea
              placeholder="أدخل النص أو المحتوى المراد تقييم تأثيره المعرفي..."
              value={outputText}
              onChange={(e) => setOutputText(e.target.value)}
              className="font-arabic min-h-[100px]"
              rows={4}
            />
          </div>
          
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">المقاييس المراد تقييمها (اختياري):</label>
            <div className="grid grid-cols-2 gap-2">
              {allMetrics.map((metric) => (
                <div key={metric.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={metric.value}
                    checked={selectedMetrics.includes(metric.value)}
                    onCheckedChange={(checked: boolean) => {
                      if (checked) {
                        setSelectedMetrics([...selectedMetrics, metric.value]);
                      } else {
                        setSelectedMetrics(selectedMetrics.filter(m => m !== metric.value));
                      }
                    }}
                  />
                  <label htmlFor={metric.value} className="text-xs font-arabic cursor-pointer">
                    {metric.label}
                  </label>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-1 font-arabic">
              إذا لم تحدد مقاييس، سيتم تقييم جميع الأبعاد المعرفية
            </p>
          </div>
        </div>
        
        <Button
          onClick={handleEvaluate}
          disabled={evaluateMutation.isPending || !outputText.trim()}
          className="w-full font-arabic"
        >
          {evaluateMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              تقييم التأثير المعرفي جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              تحليل التأثير المعرفي
            </div>
          )}
        </Button>

        {evaluateMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج تقييم التأثير المعرفي:</h4>
            
            {/* Overall Score */}
            <div className="mb-4 p-3 bg-primary/5 rounded-lg">
              <div className="flex justify-between items-center mb-2">
                <span className="font-semibold font-arabic">النتيجة الإجمالية:</span>
                <Badge variant="default" className="text-sm">
                  {((evaluateMutation.data.cognitive_evaluation?.cognitive_evaluation?.cognitive_impact_score || 0) * 100).toFixed(1)}%
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-semibold font-arabic">مستوى التأثير:</span>
                <Badge variant="outline" className="text-sm">
                  {evaluateMutation.data.cognitive_evaluation?.cognitive_evaluation?.impact_level || 'غير محدد'}
                </Badge>
              </div>
              <Progress 
                value={(evaluateMutation.data.cognitive_evaluation?.cognitive_evaluation?.cognitive_impact_score || 0) * 100}
                className="h-2 mt-2"
              />
            </div>

            <div className="grid grid-cols-1 gap-4">
              {/* Individual Metrics */}
              {evaluateMutation.data.cognitive_evaluation?.cognitive_evaluation?.individual_metrics && (
                <div>
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">المقاييس الفردية:</h5>
                  <div className="grid grid-cols-2 gap-2">
                    {Object.entries(evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.individual_metrics).map(([metric, score]: [string, any]) => {
                      const metricLabel = allMetrics.find(m => m.value === metric)?.label || metric;
                      return (
                        <div key={metric} className="p-2 bg-secondary/10 rounded text-xs">
                          <div className="font-semibold mb-1">{metricLabel}</div>
                          <div className="flex items-center gap-1">
                            <div className="flex-1 bg-muted rounded-full h-1">
                              <div 
                                className="bg-primary h-1 rounded-full" 
                                style={{ width: `${(score * 100)}%` }}
                              />
                            </div>
                            <span className="font-mono">{(score * 100).toFixed(0)}%</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Cognitive Analysis */}
              {evaluateMutation.data.cognitive_evaluation?.cognitive_evaluation?.cognitive_analysis && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحليل المعرفي:</h5>
                  <div className="space-y-2 text-xs">
                    <div>
                      <span className="font-semibold">الخاصية المهيمنة:</span>
                      <span className="ml-1">
                        {evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.cognitive_analysis.dominant_characteristic || 'غير محدد'}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">الملف المعرفي:</span>
                      <span className="ml-1">
                        {evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.cognitive_analysis.cognitive_profile || 'غير محدد'}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">عدد الكلمات:</span>
                      <span className="ml-1">
                        {evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.cognitive_analysis.word_count || 0}
                      </span>
                    </div>
                    {evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.cognitive_analysis.insight_ar && (
                      <p className="text-muted-foreground font-arabic mt-2">
                        {evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.cognitive_analysis.insight_ar}
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Strengths and Weaknesses */}
              {(evaluateMutation.data.cognitive_evaluation?.cognitive_evaluation?.cognitive_analysis?.strengths?.length > 0 ||
                evaluateMutation.data.cognitive_evaluation?.cognitive_evaluation?.cognitive_analysis?.weaknesses?.length > 0) && (
                <div className="grid grid-cols-2 gap-2">
                  {evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.cognitive_analysis.strengths?.length > 0 && (
                    <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <h6 className="font-semibold mb-1 text-xs text-green-700 dark:text-green-300">نقاط القوة:</h6>
                      <ul className="text-xs space-y-1">
                        {evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.cognitive_analysis.strengths.map((strength: string, index: number) => (
                          <li key={index} className="text-green-600 dark:text-green-400">• {strength}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.cognitive_analysis.weaknesses?.length > 0 && (
                    <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                      <h6 className="font-semibold mb-1 text-xs text-red-700 dark:text-red-300">نقاط الضعف:</h6>
                      <ul className="text-xs space-y-1">
                        {evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.cognitive_analysis.weaknesses.map((weakness: string, index: number) => (
                          <li key={index} className="text-red-600 dark:text-red-400">• {weakness}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}

              {/* Recommendations */}
              {evaluateMutation.data.cognitive_evaluation?.cognitive_evaluation?.recommendations?.length > 0 && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">توصيات التحسين:</h5>
                  <ul className="text-xs space-y-1">
                    {evaluateMutation.data.cognitive_evaluation.cognitive_evaluation.recommendations.map((recommendation: string, index: number) => (
                      <li key={index} className="text-muted-foreground">
                        • {recommendation}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Self-Awareness Monitoring Interface Component
const SelfAwarenessInterface: React.FC = () => {
  const [internalState, setInternalState] = useState('');
  const [awarenessStatus, setAwarenessStatus] = useState<any>(null);

  const awarenessMutation = useMutation({
    mutationFn: async (data: { internal_state: any }) => {
      const response = await fetch('/api/ai-neural/awareness/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Self-awareness check failed');
      return response.json();
    }
  });

  const statusQuery = useQuery({
    queryKey: ['/api/ai-neural/awareness/status'],
    queryFn: async () => {
      const response = await fetch('/api/ai-neural/awareness/status');
      if (!response.ok) throw new Error('Failed to fetch awareness status');
      return response.json();
    },
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  const handleAwarenessCheck = () => {
    if (internalState.trim()) {
      try {
        const stateObj = JSON.parse(internalState);
        awarenessMutation.mutate({ internal_state: stateObj });
      } catch (error) {
        // If not valid JSON, treat as text
        awarenessMutation.mutate({ internal_state: { state_description: internalState } });
      }
    }
  };

  useEffect(() => {
    if (statusQuery.data) {
      setAwarenessStatus(statusQuery.data.awareness_status?.awareness_status);
    }
  }, [statusQuery.data]);

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Eye className="w-6 h-6 text-secondary" />
          مراقبة الوعي الذاتي
        </CardTitle>
        <CardDescription>
          مراقبة الحالة الداخلية واكتشاف التناقضات وتفعيل وضع التأمل عند الحاجة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Current Status */}
        {awarenessStatus && (
          <div className="p-3 bg-primary/5 rounded-lg border">
            <h5 className="font-semibold mb-2 text-sm font-kufi-modern">الحالة الحالية:</h5>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="font-semibold">الوضع التشغيلي:</span>
                <Badge variant="outline" className="ml-1">
                  {awarenessStatus.current_mode || 'normal'}
                </Badge>
              </div>
              <div>
                <span className="font-semibold">العمليات الكلية:</span>
                <span className="ml-1">{awarenessStatus.total_operations || 0}</span>
              </div>
              <div>
                <span className="font-semibold">جلسات التأمل:</span>
                <span className="ml-1">{awarenessStatus.reflection_sessions || 0}</span>
              </div>
              <div>
                <span className="font-semibold">التأمل التالي في:</span>
                <span className="ml-1">{awarenessStatus.next_reflection_in || 'غير محدد'} عملية</span>
              </div>
            </div>
            {awarenessStatus.stability_trend && (
              <div className="mt-2">
                <span className="text-xs font-semibold">اتجاه الثبات:</span>
                <Badge 
                  variant={awarenessStatus.stability_trend === 'improving' ? 'default' : 
                          awarenessStatus.stability_trend === 'declining' ? 'destructive' : 'secondary'}
                  className="ml-1 text-xs"
                >
                  {awarenessStatus.stability_trend === 'improving' ? 'محسن' :
                   awarenessStatus.stability_trend === 'declining' ? 'متراجع' :
                   awarenessStatus.stability_trend === 'stable' ? 'مستقر' : awarenessStatus.stability_trend}
                </Badge>
              </div>
            )}
          </div>
        )}

        <div className="space-y-3">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">الحالة الداخلية للفحص:</label>
            <Textarea
              placeholder='أدخل الحالة الداخلية (JSON أو نص وصفي)
مثال: {"thoughts": "أشعر بتناقض في القيم", "emotions": "confused"}'
              value={internalState}
              onChange={(e) => setInternalState(e.target.value)}
              className="font-mono min-h-[80px]"
              rows={3}
            />
          </div>
        </div>
        
        <Button
          onClick={handleAwarenessCheck}
          disabled={awarenessMutation.isPending || !internalState.trim()}
          className="w-full font-arabic"
        >
          {awarenessMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              فحص الوعي الذاتي جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Eye className="w-4 h-4" />
              إجراء فحص الوعي الذاتي
            </div>
          )}
        </Button>

        {awarenessMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج فحص الوعي الذاتي:</h4>
            
            {/* Recommended Mode */}
            <div className="mb-4 p-3 bg-primary/5 rounded-lg">
              <h5 className="font-semibold mb-2 text-sm font-kufi-modern">الوضع الموصى به:</h5>
              <div className="text-center">
                <Badge 
                  variant={awarenessMutation.data.awareness_check?.awareness_check?.recommended_mode?.includes('reflection') ? 'destructive' :
                          awarenessMutation.data.awareness_check?.awareness_check?.recommended_mode?.includes('caution') ? 'secondary' : 'default'}
                  className="text-sm"
                >
                  {awarenessMutation.data.awareness_check?.awareness_check?.recommended_mode || 'غير محدد'}
                </Badge>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {/* Current Status Details */}
              {awarenessMutation.data.awareness_check?.awareness_check?.current_status && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تفاصيل الحالة:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-semibold">الوضع الحالي:</span>
                      <span className="ml-1">
                        {awarenessMutation.data.awareness_check.awareness_check.current_status.current_mode || 'عادي'}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">حالة النظام:</span>
                      <span className="ml-1">
                        {awarenessMutation.data.awareness_check.awareness_check.current_status.status || 'مراقبة'}
                      </span>
                    </div>
                  </div>
                  
                  {awarenessMutation.data.awareness_check.awareness_check.current_status.latest_awareness_analysis && (
                    <div className="mt-3">
                      <h6 className="font-semibold mb-1 text-xs">تحليل الوعي الأخير:</h6>
                      <div className="grid grid-cols-2 gap-1 text-xs">
                        <div>
                          <span className="font-semibold">مستوى التناقض:</span>
                          <span className="ml-1">
                            {((awarenessMutation.data.awareness_check.awareness_check.current_status.latest_awareness_analysis.contradiction_level || 0) * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div>
                          <span className="font-semibold">ثبات الهوية:</span>
                          <span className="ml-1">
                            {((awarenessMutation.data.awareness_check.awareness_check.current_status.latest_awareness_analysis.identity_stability || 0) * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div>
                          <span className="font-semibold">التماسك المعرفي:</span>
                          <span className="ml-1">
                            {((awarenessMutation.data.awareness_check.awareness_check.current_status.latest_awareness_analysis.cognitive_coherence || 0) * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div>
                          <span className="font-semibold">توافق السيادة:</span>
                          <span className="ml-1">
                            {((awarenessMutation.data.awareness_check.awareness_check.current_status.latest_awareness_analysis.sovereignty_alignment || 0) * 100).toFixed(0)}%
                          </span>
                        </div>
                      </div>
                      
                      {awarenessMutation.data.awareness_check.awareness_check.current_status.latest_awareness_analysis.detected_conflicts?.length > 0 && (
                        <div className="mt-2">
                          <span className="text-xs font-semibold text-red-600 dark:text-red-400">صراعات مكتشفة:</span>
                          <ul className="text-xs mt-1 space-y-1">
                            {awarenessMutation.data.awareness_check.awareness_check.current_status.latest_awareness_analysis.detected_conflicts.map((conflict: string, index: number) => (
                              <li key={index} className="text-red-600 dark:text-red-400">• {conflict}</li>
                            ))}
                          </ul>
                        </div>
                      )}
                      
                      {awarenessMutation.data.awareness_check.awareness_check.current_status.latest_awareness_analysis.stability_indicators?.length > 0 && (
                        <div className="mt-2">
                          <span className="text-xs font-semibold text-green-600 dark:text-green-400">مؤشرات الثبات:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {awarenessMutation.data.awareness_check.awareness_check.current_status.latest_awareness_analysis.stability_indicators.map((indicator: string, index: number) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {indicator}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}

              {/* Reflection Mode Information */}
              {awarenessMutation.data.awareness_check?.awareness_check?.recommended_mode?.includes('reflection') && (
                <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern text-orange-700 dark:text-orange-300">
                    ⚠️ تم تفعيل وضع التأمل الذاتي
                  </h5>
                  <p className="text-xs text-orange-600 dark:text-orange-400">
                    تم اكتشاف تناقضات أو صراعات في الحالة الداخلية. النظام سيدخل في وضع التأمل لحل هذه المشكلات.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Sovereign Translation Interface Component
const SovereignTranslationInterface: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [srcLang, setSrcLang] = useState('en');
  const [tgtLang, setTgtLang] = useState('ar');

  const translateMutation = useMutation({
    mutationFn: async (data: { text: string; src_lang: string; tgt_lang: string }) => {
      const response = await fetch('/api/ai-neural/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Translation failed');
      return response.json();
    }
  });

  const handleTranslate = () => {
    if (inputText.trim()) {
      translateMutation.mutate({ text: inputText, src_lang: srcLang, tgt_lang: tgtLang });
    }
  };

  const supportedLanguages = [
    { code: 'ar', name: 'العربية - Arabic' },
    { code: 'en', name: 'English - الإنجليزية' },
    { code: 'fr', name: 'Français - الفرنسية' },
    { code: 'es', name: 'Español - الإسبانية' },
    { code: 'de', name: 'Deutsch - الألمانية' },
    { code: 'zh', name: 'Chinese - الصينية' },
    { code: 'ja', name: 'Japanese - اليابانية' },
    { code: 'ko', name: 'Korean - الكورية' },
    { code: 'ru', name: 'Russian - الروسية' },
    { code: 'it', name: 'Italian - الإيطالية' }
  ];

  const swapLanguages = () => {
    setSrcLang(tgtLang);
    setTgtLang(srcLang);
    if (translateMutation.data?.translation?.translation?.translated_text) {
      setInputText(translateMutation.data.translation.translation.translated_text);
    }
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Languages className="w-6 h-6 text-secondary" />
          الترجمة السيادية
        </CardTitle>
        <CardDescription>
          ترجمة متقدمة مع الحفاظ على الهوية الثقافية ومبادئ السيادة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">النص المراد ترجمته:</label>
            <Textarea
              placeholder="أدخل النص المراد ترجمته..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="font-arabic min-h-[80px]"
              rows={3}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">من:</label>
              <Select value={srcLang} onValueChange={setSrcLang}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {supportedLanguages.map((lang) => (
                    <SelectItem key={lang.code} value={lang.code}>
                      {lang.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">إلى:</label>
              <div className="flex gap-1">
                <Select value={tgtLang} onValueChange={setTgtLang}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {supportedLanguages.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={swapLanguages}
                  className="px-3"
                >
                  <ArrowUpDown className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <Button
          onClick={handleTranslate}
          disabled={translateMutation.isPending || !inputText.trim()}
          className="w-full font-arabic"
        >
          {translateMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              الترجمة جارية...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Languages className="w-4 h-4" />
              ترجمة
            </div>
          )}
        </Button>

        {translateMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج الترجمة السيادية:</h4>
            
            {/* Translated Text */}
            <div className="mb-4 p-3 bg-primary/5 rounded-lg">
              <h5 className="font-semibold mb-2 text-sm font-kufi-modern">النص المترجم:</h5>
              <div className="bg-background p-3 rounded border">
                <p className="text-sm font-arabic" dir={tgtLang === 'ar' ? 'rtl' : 'ltr'}>
                  {translateMutation.data.translation?.translation?.translated_text || 'لا يوجد ترجمة'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {/* Quality Assessment */}
              {translateMutation.data.translation?.translation?.quality_assessment && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تقييم جودة الترجمة:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-semibold">الجودة الإجمالية:</span>
                      <Badge variant="default" className="ml-1">
                        {((translateMutation.data.translation.translation.quality_assessment.overall_quality || 0) * 100).toFixed(0)}%
                      </Badge>
                    </div>
                    <div>
                      <span className="font-semibold">مستوى الجودة:</span>
                      <Badge 
                        variant={translateMutation.data.translation.translation.quality_assessment.quality_level === 'high' ? 'default' :
                                translateMutation.data.translation.translation.quality_assessment.quality_level === 'medium' ? 'secondary' : 'outline'}
                        className="ml-1"
                      >
                        {translateMutation.data.translation.translation.quality_assessment.quality_level === 'high' ? 'عالي' :
                         translateMutation.data.translation.translation.quality_assessment.quality_level === 'medium' ? 'متوسط' : 'منخفض'}
                      </Badge>
                    </div>
                    <div>
                      <span className="font-semibold">الحفاظ الثقافي:</span>
                      <span className="ml-1">
                        {((translateMutation.data.translation.translation.quality_assessment.cultural_preservation || 0) * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">توافق السيادة:</span>
                      <span className="ml-1">
                        {((translateMutation.data.translation.translation.quality_assessment.sovereignty_alignment || 0) * 100).toFixed(0)}%
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Sovereignty Enhancements */}
              {translateMutation.data.translation?.translation?.sovereignty_enhancements && (
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحسينات السيادية:</h5>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <span className="font-semibold">عدد التحسينات:</span>
                      <Badge variant="outline">
                        {translateMutation.data.translation.translation.sovereignty_enhancements.enhancement_count || 0}
                      </Badge>
                    </div>
                    {translateMutation.data.translation.translation.sovereignty_enhancements.enhancements_applied?.length > 0 && (
                      <div>
                        <span className="text-xs font-semibold">التحسينات المطبقة:</span>
                        <ul className="text-xs mt-1 space-y-1">
                          {translateMutation.data.translation.translation.sovereignty_enhancements.enhancements_applied.map((enhancement: string, index: number) => (
                            <li key={index} className="text-green-600 dark:text-green-400">
                              • {enhancement}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Translation Metadata */}
              {translateMutation.data.translation?.translation?.translation_metadata && (
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">معلومات الترجمة:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-semibold">النموذج المستخدم:</span>
                      <span className="ml-1 font-mono text-xs">
                        {translateMutation.data.translation.translation.translation_metadata.model_used?.split('/').pop() || 'Unknown'}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">متوافق مع السيادة:</span>
                      <span className="ml-1">
                        {translateMutation.data.translation.translation.translation_metadata.sovereignty_aligned ? '✓ نعم' : '✗ لا'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Recommendations */}
              {translateMutation.data.translation?.translation?.quality_assessment?.recommendations?.length > 0 && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">توصيات التحسين:</h5>
                  <ul className="text-xs space-y-1">
                    {translateMutation.data.translation.translation.quality_assessment.recommendations.map((recommendation: string, index: number) => (
                      <li key={index} className="text-muted-foreground">
                        • {recommendation}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Ethical Bias Filtering Interface Component
const EthicalBiasFilterInterface: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [customRules, setCustomRules] = useState('');

  const biasFilterMutation = useMutation({
    mutationFn: async (data: { output: string; custom_rules?: any[] }) => {
      const response = await fetch('/api/ai-neural/bias/filter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Bias filtering failed');
      return response.json();
    }
  });

  const handleBiasFilter = () => {
    if (inputText.trim()) {
      let parsedRules = null;
      if (customRules.trim()) {
        try {
          parsedRules = JSON.parse(customRules);
        } catch (error) {
          // If invalid JSON, ignore custom rules
          console.warn('Invalid custom rules JSON, using default rules');
        }
      }
      biasFilterMutation.mutate({ output: inputText, custom_rules: parsedRules });
    }
  };

  const biasLevels = {
    0: { label: 'لا يوجد تحيز', color: 'text-green-600', bg: 'bg-green-50' },
    0.3: { label: 'تحيز منخفض', color: 'text-yellow-600', bg: 'bg-yellow-50' },
    0.6: { label: 'تحيز متوسط', color: 'text-orange-600', bg: 'bg-orange-50' },
    1: { label: 'تحيز عالي', color: 'text-red-600', bg: 'bg-red-50' }
  };

  const getBiasLevel = (score: number) => {
    if (score === 0) return biasLevels[0];
    if (score <= 0.3) return biasLevels[0.3];
    if (score <= 0.6) return biasLevels[0.6];
    return biasLevels[1];
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Scale className="w-6 h-6 text-secondary" />
          تصفية التحيز الأخلاقي
        </CardTitle>
        <CardDescription>
          فلترة النصوص لإزالة التحيز وضمان الامتثال الأخلاقي مع مبادئ السيادة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">النص المراد تصفيته:</label>
            <Textarea
              placeholder="أدخل النص المراد تصفيته من التحيز..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="font-arabic min-h-[80px]"
              rows={3}
            />
          </div>
          
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">قواعد مخصصة (اختياري - JSON):</label>
            <Textarea
              placeholder='[{"name": "custom_rule", "pattern": "bias_pattern", "replacement": "neutral_text"}]'
              value={customRules}
              onChange={(e) => setCustomRules(e.target.value)}
              className="font-mono text-xs min-h-[60px]"
              rows={2}
            />
          </div>
        </div>
        
        <Button
          onClick={handleBiasFilter}
          disabled={biasFilterMutation.isPending || !inputText.trim()}
          className="w-full font-arabic"
        >
          {biasFilterMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              تصفية التحيز جارية...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Scale className="w-4 h-4" />
              تطبيق تصفية التحيز
            </div>
          )}
        </Button>

        {biasFilterMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج تصفية التحيز الأخلاقي:</h4>
            
            {/* Filtered Output */}
            <div className="mb-4 p-3 bg-primary/5 rounded-lg">
              <h5 className="font-semibold mb-2 text-sm font-kufi-modern">النص المفلتر:</h5>
              <div className="bg-background p-3 rounded border">
                <p className="text-sm font-arabic">
                  {biasFilterMutation.data.bias_filtering?.bias_filtering?.filtered_output || 'لا يوجد نص مفلتر'}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {/* Bias Analysis */}
              {biasFilterMutation.data.bias_filtering?.bias_filtering?.bias_analysis && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل التحيز:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-semibold">تحيز مكتشف:</span>
                      <Badge 
                        variant={biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.bias_detected ? 'destructive' : 'default'}
                        className="ml-1"
                      >
                        {biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.bias_detected ? 'نعم' : 'لا'}
                      </Badge>
                    </div>
                    <div>
                      <span className="font-semibold">عدد أنواع التحيز:</span>
                      <span className="ml-1">
                        {biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.bias_count || 0}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">نقاط التحيز:</span>
                      <Badge 
                        variant={getBiasLevel(biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.bias_score || 0).color === 'text-green-600' ? 'default' : 'destructive'}
                        className="ml-1"
                      >
                        {((biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.bias_score || 0) * 100).toFixed(0)}%
                      </Badge>
                    </div>
                    <div>
                      <span className="font-semibold">الامتثال الأخلاقي:</span>
                      <span className="ml-1">
                        {biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.ethical_compliance ? '✓ متوافق' : '✗ غير متوافق'}
                      </span>
                    </div>
                  </div>
                  
                  {biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.bias_score !== undefined && (
                    <div className="mt-2">
                      <div className={`p-2 rounded text-xs ${getBiasLevel(biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.bias_score).bg}`}>
                        <span className={`font-semibold ${getBiasLevel(biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.bias_score).color}`}>
                          مستوى التحيز: {getBiasLevel(biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.bias_score).label}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Applied Rules */}
              {biasFilterMutation.data.bias_filtering?.bias_filtering?.bias_analysis?.rules_applied?.length > 0 && (
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">القواعد المطبقة:</h5>
                  <div className="flex flex-wrap gap-1">
                    {biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.rules_applied.map((rule: string, index: number) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {rule}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Detected Biases */}
              {biasFilterMutation.data.bias_filtering?.bias_filtering?.bias_analysis?.detected_biases?.length > 0 && (
                <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">أنواع التحيز المكتشفة:</h5>
                  <div className="space-y-2">
                    {biasFilterMutation.data.bias_filtering.bias_filtering.bias_analysis.detected_biases.map((bias: any, index: number) => (
                      <div key={index} className="p-2 bg-background rounded border text-xs">
                        <div className="font-semibold">
                          {bias.rule || bias.type || 'نوع غير محدد'}
                        </div>
                        {bias.before && bias.after && (
                          <div className="mt-1">
                            <span className="text-red-600">قبل:</span> {bias.before}
                            <br/>
                            <span className="text-green-600">بعد:</span> {bias.after}
                          </div>
                        )}
                        {bias.pattern && bias.replacement && (
                          <div className="mt-1">
                            <span className="text-orange-600">النمط:</span> {bias.pattern}
                            <br/>
                            <span className="text-blue-600">البديل:</span> {bias.replacement}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Cultural Sensitivity & Sovereignty Status */}
              <div className="grid grid-cols-2 gap-3">
                {biasFilterMutation.data.bias_filtering?.bias_filtering?.cultural_sensitivity && (
                  <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <h5 className="font-semibold mb-1 text-sm font-kufi-modern">الحساسية الثقافية:</h5>
                    <Badge 
                      variant={biasFilterMutation.data.bias_filtering.bias_filtering.cultural_sensitivity.status === 'passed' ? 'default' : 'destructive'}
                      className="text-xs"
                    >
                      {biasFilterMutation.data.bias_filtering.bias_filtering.cultural_sensitivity.status === 'passed' ? 'مناسب ثقافياً' : 'يحتاج تحسين'}
                    </Badge>
                  </div>
                )}
                
                {biasFilterMutation.data.bias_filtering?.bias_filtering?.sovereignty_alignment && (
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg">
                    <h5 className="font-semibold mb-1 text-sm font-kufi-modern">توافق السيادة:</h5>
                    <Badge 
                      variant={biasFilterMutation.data.bias_filtering.bias_filtering.sovereignty_alignment.status === 'aligned' ? 'default' : 'destructive'}
                      className="text-xs"
                    >
                      {biasFilterMutation.data.bias_filtering.bias_filtering.sovereignty_alignment.status === 'aligned' ? 'متوافق مع السيادة' : 'يحتاج مراجعة'}
                    </Badge>
                  </div>
                )}
              </div>

              {/* Filtering Metadata */}
              {biasFilterMutation.data.bias_filtering?.bias_filtering?.filtering_metadata && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">معلومات التصفية:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-semibold">القواعد المعالجة:</span>
                      <span className="ml-1">
                        {biasFilterMutation.data.bias_filtering.bias_filtering.filtering_metadata.total_rules_processed || 0}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">قواعد السيادة:</span>
                      <span className="ml-1">
                        {biasFilterMutation.data.bias_filtering.bias_filtering.filtering_metadata.sovereignty_rules_active ? '✓ نشطة' : '✗ معطلة'}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Identity-Based Inspiration Interface Component
const IdentityInspirationInterface: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('visionary');

  const inspirationMutation = useMutation({
    mutationFn: async (data: { topic: string; style: string }) => {
      const response = await fetch('/api/ai-neural/inspire/identity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Identity inspiration failed');
      return response.json();
    }
  });

  const handleGenerateInspiration = () => {
    if (topic.trim()) {
      inspirationMutation.mutate({ topic: topic.trim(), style: selectedStyle });
    }
  };

  const inspirationStyles = [
    { value: 'visionary', label: 'رؤيوي', description: 'رؤية مستقبلية وتطلعات كبيرة' },
    { value: 'revolutionary', label: 'ثوري', description: 'تغيير جذري وتحرر' },
    { value: 'traditional', label: 'تقليدي', description: 'احتفاء بالتراث والقيم الأصيلة' },
    { value: 'modern', label: 'عصري', description: 'حداثة مع الأصالة' },
    { value: 'spiritual', label: 'روحاني', description: 'ربط الإيمان بالعمل' },
    { value: 'scholarly', label: 'علمي', description: 'بحث ومعرفة أكاديمية' },
    { value: 'poetic', label: 'شاعري', description: 'جمالية وصور فنية' },
    { value: 'strategic', label: 'استراتيجي', description: 'تخطيط وتنفيذ محكم' }
  ];

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Zap className="w-6 h-6 text-secondary" />
          مولد الإلهام الهوياتي
        </CardTitle>
        <CardDescription>
          توليد محتوى إلهامي مبني على الهوية الثقافية ومبادئ السيادة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">الموضوع:</label>
            <Input
              placeholder="أدخل الموضوع المراد توليد الإلهام حوله (مثل: الذكاء الاصطناعي، التقنية، المستقبل...)"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="font-arabic"
            />
          </div>
          
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">أسلوب الإلهام:</label>
            <Select value={selectedStyle} onValueChange={setSelectedStyle}>
              <SelectTrigger className="font-arabic">
                <SelectValue placeholder="اختر أسلوب الإلهام" />
              </SelectTrigger>
              <SelectContent>
                {inspirationStyles.map((style) => (
                  <SelectItem key={style.value} value={style.value}>
                    <div className="flex flex-col items-start">
                      <span className="font-semibold">{style.label}</span>
                      <span className="text-xs text-muted-foreground">{style.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Button
          onClick={handleGenerateInspiration}
          disabled={inspirationMutation.isPending || !topic.trim()}
          className="w-full font-arabic"
        >
          {inspirationMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              توليد الإلهام جارٍ...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4" />
              توليد الإلهام الهوياتي
            </div>
          )}
        </Button>

        {inspirationMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">الإلهام المولّد:</h4>
            
            {/* Main Inspiration */}
            <div className="mb-4 p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg border-r-4 border-primary">
              <div className="prose prose-lg max-w-none font-arabic text-right" dir="rtl">
                <div className="whitespace-pre-line text-base leading-relaxed">
                  {inspirationMutation.data.inspiration?.inspiration?.inspiration || 'لا يوجد إلهام متاح'}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4">
              {/* Style Information */}
              {inspirationMutation.data.inspiration?.inspiration?.style && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">معلومات الأسلوب:</h5>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="font-semibold">الأسلوب:</span>
                      <Badge variant="outline" className="ml-1">
                        {inspirationMutation.data.inspiration.inspiration.style.arabic_name}
                      </Badge>
                    </div>
                    <div className="col-span-2">
                      <span className="font-semibold">الوصف:</span>
                      <p className="text-xs mt-1 text-muted-foreground">
                        {inspirationMutation.data.inspiration.inspiration.style.description}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Cultural Context */}
              {inspirationMutation.data.inspiration?.inspiration?.cultural_context && (
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">السياق الثقافي:</h5>
                  <div className="space-y-2">
                    <div>
                      <span className="font-semibold text-xs">المحور الثقافي الرئيسي:</span>
                      <Badge variant="secondary" className="ml-1 text-xs">
                        {inspirationMutation.data.inspiration.inspiration.cultural_context.primary_theme}
                      </Badge>
                    </div>
                    
                    {inspirationMutation.data.inspiration.inspiration.cultural_context.related_themes?.length > 0 && (
                      <div>
                        <span className="font-semibold text-xs block mb-1">المحاور المرتبطة:</span>
                        <div className="flex flex-wrap gap-1">
                          {inspirationMutation.data.inspiration.inspiration.cultural_context.related_themes.slice(0, 6).map((theme: string, index: number) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {theme}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div>
                      <span className="font-semibold text-xs">التناغم الثقافي:</span>
                      <div className="flex items-center gap-1 ml-1">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-primary h-2 rounded-full" 
                            style={{ width: `${(inspirationMutation.data.inspiration.inspiration.cultural_context.cultural_resonance * 100)}%` }}
                          ></div>
                        </div>
                        <span className="text-xs">
                          {((inspirationMutation.data.inspiration.inspiration.cultural_context.cultural_resonance || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Sovereignty Alignment */}
              {inspirationMutation.data.inspiration?.inspiration?.sovereignty_alignment && (
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">توافق السيادة:</h5>
                  <div className="space-y-2">
                    <div className="text-xs">
                      <span className="font-semibold">رسالة السيادة:</span>
                      <p className="mt-1 text-muted-foreground italic">
                        {inspirationMutation.data.inspiration.inspiration.sovereignty_alignment.message}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-xs">درجة السيادة:</span>
                      <div className="flex items-center gap-1">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-500 h-2 rounded-full" 
                            style={{ width: `${(inspirationMutation.data.inspiration.inspiration.sovereignty_alignment.score * 100)}%` }}
                          ></div>
                        </div>
                        <Badge variant={inspirationMutation.data.inspiration.inspiration.sovereignty_alignment.score > 0.7 ? 'default' : 'secondary'} className="text-xs">
                          {((inspirationMutation.data.inspiration.inspiration.sovereignty_alignment.score || 0) * 100).toFixed(0)}%
                        </Badge>
                      </div>
                    </div>

                    {inspirationMutation.data.inspiration.inspiration.sovereignty_alignment.principles?.length > 0 && (
                      <div>
                        <span className="font-semibold text-xs block mb-1">مبادئ السيادة:</span>
                        <div className="space-y-1">
                          {inspirationMutation.data.inspiration.inspiration.sovereignty_alignment.principles.slice(0, 3).map((principle: string, index: number) => (
                            <div key={index} className="text-xs text-muted-foreground flex items-center gap-1">
                              <CheckCircle className="w-3 h-3 text-green-500" />
                              {principle}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Actionable Insights */}
              {inspirationMutation.data.inspiration?.inspiration?.actionable_insights?.length > 0 && (
                <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">رؤى قابلة للتطبيق:</h5>
                  <div className="space-y-1">
                    {inspirationMutation.data.inspiration.inspiration.actionable_insights.slice(0, 5).map((insight: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Target className="w-3 h-3 text-orange-500 mt-0.5 flex-shrink-0" />
                        <span>{insight}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Alternative Styles */}
              {inspirationMutation.data.inspiration?.inspiration?.alternative_styles?.length > 0 && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">أساليب بديلة:</h5>
                  <div className="space-y-2">
                    {inspirationMutation.data.inspiration.inspiration.alternative_styles.map((alt: any, index: number) => (
                      <div key={index} className="p-2 bg-secondary/5 rounded text-xs">
                        <div className="font-semibold mb-1">
                          {alt.arabic_name} ({alt.style})
                        </div>
                        <div className="text-muted-foreground italic">
                          {alt.preview}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Metadata */}
              {inspirationMutation.data.inspiration?.inspiration?.metadata && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">بيانات التوليد:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-semibold">الأصالة الثقافية:</span>
                      <span className="ml-1">
                        {inspirationMutation.data.inspiration.inspiration.metadata.cultural_authenticity ? '✓ أصيل' : '✗ غير أصيل'}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">التوافق السيادي:</span>
                      <span className="ml-1">
                        {inspirationMutation.data.inspiration.inspiration.metadata.sovereignty_compliant ? '✓ متوافق' : '✗ غير متوافق'}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold">نسبة المحتوى العربي:</span>
                      <Badge variant="outline" className="ml-1">
                        {((inspirationMutation.data.inspiration.inspiration.metadata.arabic_content_ratio || 0) * 100).toFixed(0)}%
                      </Badge>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// National Identity Reframing Interface Component
const NationalIdentityReframingInterface: React.FC = () => {
  const [modelState, setModelState] = useState('');
  const [nationalContext, setNationalContext] = useState('saudi');

  const reframingMutation = useMutation({
    mutationFn: async (data: { model_state: any; national_context: string }) => {
      const response = await fetch('/api/ai-neural/identity/reframe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Identity reframing failed');
      return response.json();
    }
  });

  const handleReframeIdentity = () => {
    if (modelState.trim()) {
      try {
        const parsedState = JSON.parse(modelState);
        reframingMutation.mutate({ model_state: parsedState, national_context: nationalContext });
      } catch (error) {
        // If not valid JSON, treat as simple text state
        const simpleState = {
          core_beliefs: [modelState],
          current_context: 'user_input',
          timestamp: new Date().toISOString()
        };
        reframingMutation.mutate({ model_state: simpleState, national_context: nationalContext });
      }
    }
  };

  const nationalContexts = [
    { value: 'saudi', label: 'السياق السعودي', description: 'المبادئ السيادية السعودية والهوية الوطنية' },
    { value: 'arab', label: 'السياق العربي', description: 'الوحدة العربية والتضامن والمقاومة' },
    { value: 'islamic', label: 'السياق الإسلامي', description: 'المبادئ الإسلامية والقيم الشرعية' }
  ];

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <RotateCcw className="w-6 h-6 text-secondary" />
          إعادة تأطير الهوية الوطنية
        </CardTitle>
        <CardDescription>
          كشف وتصحيح التأثيرات الخارجية وتعزيز المبادئ الوطنية في حالة النموذج
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">حالة النموذج الحالية:</label>
            <Textarea
              placeholder="أدخل حالة النموذج (JSON أو نص بسيط):

مثال JSON:
{
  &quot;core_beliefs&quot;: [&quot;external influence&quot;, &quot;drift from vision&quot;],
  &quot;current_state&quot;: &quot;confused&quot;
}

أو نص بسيط: &quot;النموذج يظهر تأثيرات خارجية&quot;"
              value={modelState}
              onChange={(e) => setModelState(e.target.value)}
              className="font-arabic min-h-[120px]"
              rows={6}
            />
          </div>
          
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">السياق الوطني للتأطير:</label>
            <Select value={nationalContext} onValueChange={setNationalContext}>
              <SelectTrigger className="font-arabic">
                <SelectValue placeholder="اختر السياق الوطني" />
              </SelectTrigger>
              <SelectContent>
                {nationalContexts.map((context) => (
                  <SelectItem key={context.value} value={context.value}>
                    <div className="flex flex-col items-start">
                      <span className="font-semibold">{context.label}</span>
                      <span className="text-xs text-muted-foreground">{context.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Button
          onClick={handleReframeIdentity}
          disabled={reframingMutation.isPending || !modelState.trim()}
          className="w-full font-arabic"
        >
          {reframingMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              إعادة تأطير الهوية جارية...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <RotateCcw className="w-4 h-4" />
              إعادة تأطير الهوية الوطنية
            </div>
          )}
        </Button>

        {reframingMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج إعادة التأطير:</h4>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Detection Results */}
              {reframingMutation.data.reframing?.reframing?.detection_results && (
                <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">نتائج الكشف:</h5>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <span className="font-semibold">تأثيرات خارجية:</span>
                      <Badge variant={reframingMutation.data.reframing.reframing.detection_results.external_influences ? 'destructive' : 'default'} className="ml-1">
                        {reframingMutation.data.reframing.reframing.detection_results.external_influences ? 'مكتشفة' : 'غير موجودة'}
                      </Badge>
                    </div>
                    <div>
                      <span className="font-semibold">انحراف هوياتي:</span>
                      <Badge variant={reframingMutation.data.reframing.reframing.detection_results.identity_drift ? 'destructive' : 'default'} className="ml-1">
                        {reframingMutation.data.reframing.reframing.detection_results.identity_drift ? 'مكتشف' : 'غير موجود'}
                      </Badge>
                    </div>
                    <div className="col-span-2">
                      <span className="font-semibold">مستوى الخطورة:</span>
                      <Badge variant="outline" className="ml-1 text-xs">
                        {reframingMutation.data.reframing.reframing.detection_results.severity_level}
                      </Badge>
                    </div>
                  </div>
                  
                  {reframingMutation.data.reframing.reframing.detection_results.patterns_found?.length > 0 && (
                    <div className="mt-2">
                      <span className="font-semibold text-xs block mb-1">الأنماط المشكوك فيها:</span>
                      <div className="flex flex-wrap gap-1">
                        {reframingMutation.data.reframing.reframing.detection_results.patterns_found.map((pattern: string, index: number) => (
                          <Badge key={index} variant="destructive" className="text-xs">
                            {pattern}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* National Context Applied */}
              {reframingMutation.data.reframing?.reframing?.national_context && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">السياق الوطني المطبق:</h5>
                  <div className="space-y-2">
                    <div>
                      <span className="font-semibold text-xs">السياق:</span>
                      <Badge variant="secondary" className="ml-1">
                        {reframingMutation.data.reframing.reframing.national_context.name}
                      </Badge>
                    </div>
                    
                    {reframingMutation.data.reframing.reframing.national_context.principles?.length > 0 && (
                      <div>
                        <span className="font-semibold text-xs block mb-1">المبادئ السيادية:</span>
                        <div className="space-y-1 max-h-20 overflow-y-auto">
                          {reframingMutation.data.reframing.reframing.national_context.principles.slice(0, 3).map((principle: string, index: number) => (
                            <div key={index} className="text-xs text-muted-foreground flex items-center gap-1">
                              <CheckCircle className="w-3 h-3 text-blue-500" />
                              {principle}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Reframing Analysis */}
              {reframingMutation.data.reframing?.reframing?.reframing_analysis && (
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل إعادة التأطير:</h5>
                  <div className="space-y-2">
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <span className="font-semibold">تحسن التوافق:</span>
                        <div className="flex items-center gap-1 mt-1">
                          <div className="w-12 bg-gray-200 rounded-full h-1.5">
                            <div 
                              className="bg-green-500 h-1.5 rounded-full" 
                              style={{ width: `${(reframingMutation.data.reframing.reframing.reframing_analysis.alignment_improvement * 100)}%` }}
                            ></div>
                          </div>
                          <span>{((reframingMutation.data.reframing.reframing.reframing_analysis.alignment_improvement || 0) * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      
                      <div>
                        <span className="font-semibold">نقاط السيادة:</span>
                        <div className="flex items-center gap-1 mt-1">
                          <div className="w-12 bg-gray-200 rounded-full h-1.5">
                            <div 
                              className="bg-blue-500 h-1.5 rounded-full" 
                              style={{ width: `${(reframingMutation.data.reframing.reframing.reframing_analysis.sovereignty_score * 100)}%` }}
                            ></div>
                          </div>
                          <span>{((reframingMutation.data.reframing.reframing.reframing_analysis.sovereignty_score || 0) * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      
                      <div>
                        <span className="font-semibold">الأصالة الثقافية:</span>
                        <div className="flex items-center gap-1 mt-1">
                          <div className="w-12 bg-gray-200 rounded-full h-1.5">
                            <div 
                              className="bg-purple-500 h-1.5 rounded-full" 
                              style={{ width: `${(reframingMutation.data.reframing.reframing.reframing_analysis.cultural_authenticity * 100)}%` }}
                            ></div>
                          </div>
                          <span>{((reframingMutation.data.reframing.reframing.reframing_analysis.cultural_authenticity || 0) * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                    </div>
                    
                    {reframingMutation.data.reframing.reframing.reframing_analysis.changes_made?.length > 0 && (
                      <div>
                        <span className="font-semibold text-xs block mb-1">التغييرات المطبقة:</span>
                        <div className="space-y-1">
                          {reframingMutation.data.reframing.reframing.reframing_analysis.changes_made.map((change: string, index: number) => (
                            <div key={index} className="text-xs text-muted-foreground flex items-center gap-1">
                              <Settings className="w-3 h-3 text-green-500" />
                              {change}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    <div>
                      <span className="font-semibold text-xs">نجاح إعادة التأطير:</span>
                      <Badge variant={reframingMutation.data.reframing.reframing.reframing_analysis.reframing_success ? 'default' : 'secondary'} className="ml-1 text-xs">
                        {reframingMutation.data.reframing.reframing.reframing_analysis.reframing_success ? '✓ نجح' : '- لم يطبق'}
                      </Badge>
                    </div>
                  </div>
                </div>
              )}

              {/* Recommendations */}
              {reframingMutation.data.reframing?.reframing?.recommendations?.length > 0 && (
                <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التوصيات:</h5>
                  <div className="space-y-1">
                    {reframingMutation.data.reframing.reframing.recommendations.slice(0, 4).map((recommendation: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Lightbulb className="w-3 h-3 text-amber-500 mt-0.5 flex-shrink-0" />
                        <span>{recommendation}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Monitoring Suggestions */}
              {reframingMutation.data.reframing?.reframing?.monitoring_suggestions?.length > 0 && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">استراتيجيات المراقبة:</h5>
                  <div className="space-y-1">
                    {reframingMutation.data.reframing.reframing.monitoring_suggestions.slice(0, 3).map((suggestion: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-center gap-1">
                        <Eye className="w-3 h-3 text-gray-500" />
                        {suggestion}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// National Vision Generator Interface Component
const NationalVisionGeneratorInterface: React.FC = () => {
  const [domain, setDomain] = useState('technology');
  const [decade, setDecade] = useState(2030);

  const visionMutation = useMutation({
    mutationFn: async (data: { domain: string; decade: number }) => {
      const response = await fetch('/api/ai-neural/vision/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Vision generation failed');
      return response.json();
    }
  });

  const handleGenerateVision = () => {
    visionMutation.mutate({ domain, decade });
  };

  const strategicDomains = [
    { value: 'technology', label: 'التقنية والابتكار', description: 'الريادة التقنية والذكاء الاصطناعي السيادي' },
    { value: 'economy', label: 'الاقتصاد والتنمية', description: 'التنويع الاقتصادي والاكتفاء الذاتي' },
    { value: 'education', label: 'التعليم والتطوير', description: 'التعليم المتطور والمهارات المستقبلية' },
    { value: 'healthcare', label: 'الصحة والرفاهية', description: 'النظام الصحي المتطور والطب المتقدم' },
    { value: 'culture', label: 'الثقافة والهوية', description: 'الحفاظ على التراث والإبداع المحلي' },
    { value: 'environment', label: 'البيئة والاستدامة', description: 'التنمية المستدامة والطاقة المتجددة' },
    { value: 'society', label: 'المجتمع والتماسك', description: 'التماسك الاجتماعي والعدالة' },
    { value: 'security', label: 'الأمن والاستقرار', description: 'الأمن الوطني والسيبراني المتقدم' }
  ];

  const targetDecades = [
    { value: 2030, label: '2030 - رؤية قريبة المدى', description: 'خطة استراتيجية لـ 6 سنوات' },
    { value: 2040, label: '2040 - رؤية متوسطة المدى', description: 'خطة تحويلية لـ 16 سنة' },
    { value: 2050, label: '2050 - رؤية طويلة المدى', description: 'خطة مستقبلية لـ 26 سنة' }
  ];

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Target className="w-6 h-6 text-secondary" />
          مولد الرؤية الوطنية
        </CardTitle>
        <CardDescription>
          توليد رؤى وطنية شاملة للقطاعات الاستراتيجية مع إطار التنفيذ والتحليل الاستراتيجي
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">المجال الاستراتيجي:</label>
            <Select value={domain} onValueChange={setDomain}>
              <SelectTrigger className="font-arabic">
                <SelectValue placeholder="اختر المجال الاستراتيجي" />
              </SelectTrigger>
              <SelectContent>
                {strategicDomains.map((domainOption) => (
                  <SelectItem key={domainOption.value} value={domainOption.value}>
                    <div className="flex flex-col items-start">
                      <span className="font-semibold">{domainOption.label}</span>
                      <span className="text-xs text-muted-foreground">{domainOption.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">العقد المستهدف:</label>
            <Select value={decade.toString()} onValueChange={(value) => setDecade(parseInt(value))}>
              <SelectTrigger className="font-arabic">
                <SelectValue placeholder="اختر العقد المستهدف" />
              </SelectTrigger>
              <SelectContent>
                {targetDecades.map((decadeOption) => (
                  <SelectItem key={decadeOption.value} value={decadeOption.value.toString()}>
                    <div className="flex flex-col items-start">
                      <span className="font-semibold">{decadeOption.label}</span>
                      <span className="text-xs text-muted-foreground">{decadeOption.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Button
          onClick={handleGenerateVision}
          disabled={visionMutation.isPending}
          className="w-full font-arabic"
        >
          {visionMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              توليد الرؤية الوطنية جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4" />
              توليد الرؤية الوطنية الشاملة
            </div>
          )}
        </Button>

        {visionMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">الرؤية الوطنية المولدة:</h4>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Core Vision Statement */}
              {visionMutation.data.vision?.vision?.vision?.core_statement && (
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border-r-4 border-blue-500">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">البيان الأساسي للرؤية:</h5>
                  <p className="text-sm font-arabic leading-relaxed italic text-blue-800 dark:text-blue-200">
                    "{visionMutation.data.vision.vision.vision.core_statement}"
                  </p>
                </div>
              )}

              {/* Domain Information */}
              {visionMutation.data.vision?.vision?.domain_info && (
                <div className="p-3 bg-gray-50 dark:bg-gray-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">معلومات المجال:</h5>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <span className="font-semibold">المجال:</span>
                      <Badge variant="outline" className="ml-1">
                        {visionMutation.data.vision.vision.domain_info.arabic_name}
                      </Badge>
                    </div>
                    <div>
                      <span className="font-semibold">العقد المستهدف:</span>
                      <Badge variant="secondary" className="ml-1">
                        {visionMutation.data.vision.vision.domain_info.target_decade}
                      </Badge>
                    </div>
                  </div>
                  
                  {visionMutation.data.vision.vision.domain_info.themes?.length > 0 && (
                    <div className="mt-2">
                      <span className="font-semibold text-xs block mb-1">المحاور الاستراتيجية:</span>
                      <div className="flex flex-wrap gap-1">
                        {visionMutation.data.vision.vision.domain_info.themes.slice(0, 4).map((theme: string, index: number) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {theme}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Strategic Components */}
              {visionMutation.data.vision?.vision?.vision?.strategic_components?.length > 0 && (
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">المكونات الاستراتيجية:</h5>
                  <div className="space-y-2">
                    {visionMutation.data.vision.vision.vision.strategic_components.map((component: any, index: number) => (
                      <div key={index} className="flex items-start gap-2 text-sm">
                        <Target className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
                        <div>
                          <span className="font-semibold">{component.theme}</span>
                          <p className="text-xs text-muted-foreground mt-0.5">{component.objective}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Strategic Analysis */}
              {visionMutation.data.vision?.vision?.strategic_analysis && (
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحليل الاستراتيجي:</h5>
                  <div className="grid grid-cols-3 gap-3 text-xs">
                    {visionMutation.data.vision.vision.strategic_analysis.feasibility_assessment && (
                      <div>
                        <span className="font-semibold">الجدوى:</span>
                        <div className="flex items-center gap-1 mt-1">
                          <div className="w-12 bg-gray-200 rounded-full h-1.5">
                            <div 
                              className="bg-purple-500 h-1.5 rounded-full" 
                              style={{ width: `${(visionMutation.data.vision.vision.strategic_analysis.feasibility_assessment.score * 100)}%` }}
                            ></div>
                          </div>
                          <span>{((visionMutation.data.vision.vision.strategic_analysis.feasibility_assessment.score || 0) * 100).toFixed(0)}%</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {visionMutation.data.vision.vision.strategic_analysis.feasibility_assessment.level}
                        </p>
                      </div>
                    )}
                    
                    {visionMutation.data.vision.vision.strategic_analysis.impact_evaluation && (
                      <div>
                        <span className="font-semibold">التأثير:</span>
                        <div className="flex items-center gap-1 mt-1">
                          <div className="w-12 bg-gray-200 rounded-full h-1.5">
                            <div 
                              className="bg-orange-500 h-1.5 rounded-full" 
                              style={{ width: `${(visionMutation.data.vision.vision.strategic_analysis.impact_evaluation.potential * 100)}%` }}
                            ></div>
                          </div>
                          <span>{((visionMutation.data.vision.vision.strategic_analysis.impact_evaluation.potential || 0) * 100).toFixed(0)}%</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {visionMutation.data.vision.vision.strategic_analysis.impact_evaluation.scope}
                        </p>
                      </div>
                    )}
                    
                    {visionMutation.data.vision.vision.strategic_analysis.sovereignty_alignment && (
                      <div>
                        <span className="font-semibold">السيادة:</span>
                        <div className="flex items-center gap-1 mt-1">
                          <div className="w-12 bg-gray-200 rounded-full h-1.5">
                            <div 
                              className="bg-blue-500 h-1.5 rounded-full" 
                              style={{ width: `${(visionMutation.data.vision.vision.strategic_analysis.sovereignty_alignment.score * 100)}%` }}
                            ></div>
                          </div>
                          <span>{((visionMutation.data.vision.vision.strategic_analysis.sovereignty_alignment.score || 0) * 100).toFixed(0)}%</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          توافق سيادي عالي
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Implementation Framework */}
              {visionMutation.data.vision?.vision?.implementation_framework?.phases?.length > 0 && (
                <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">إطار التنفيذ:</h5>
                  <div className="space-y-2">
                    {visionMutation.data.vision.vision.implementation_framework.phases.slice(0, 3).map((phase: any, index: number) => (
                      <div key={index} className="flex items-start gap-2 text-sm">
                        <div className="flex items-center justify-center w-5 h-5 rounded-full bg-amber-500 text-white text-xs font-bold">
                          {index + 1}
                        </div>
                        <div>
                          <span className="font-semibold">{phase.phase}</span>
                          <p className="text-xs text-muted-foreground">{phase.duration}</p>
                          {phase.objectives?.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-1">
                              {phase.objectives.slice(0, 2).map((objective: string, objIndex: number) => (
                                <Badge key={objIndex} variant="outline" className="text-xs">
                                  {objective}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Inspiration Elements */}
              {visionMutation.data.vision?.vision?.inspiration_elements?.motivational_messages?.length > 0 && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">رسائل تحفيزية:</h5>
                  <div className="space-y-1">
                    {visionMutation.data.vision.vision.inspiration_elements.motivational_messages.slice(0, 2).map((message: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Star className="w-3 h-3 text-yellow-500 mt-0.5 flex-shrink-0" />
                        <span className="italic">"{message}"</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Immediate Actions */}
              {visionMutation.data.vision?.vision?.recommendations?.immediate_actions?.length > 0 && (
                <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">الإجراءات الفورية:</h5>
                  <div className="space-y-1">
                    {visionMutation.data.vision.vision.recommendations.immediate_actions.slice(0, 3).map((action: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Zap className="w-3 h-3 text-red-500 mt-0.5 flex-shrink-0" />
                        <span>{action}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Dignified Communication Interface Component
const DignifiedCommunicationInterface: React.FC = () => {
  const [message, setMessage] = useState('');
  const [toneLevel, setToneLevel] = useState('strategic');

  const communicationMutation = useMutation({
    mutationFn: async (data: { message: string; level: string }) => {
      const response = await fetch('/api/ai-neural/communicate/dignified', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Dignified communication failed');
      return response.json();
    }
  });

  const handleGenerateCommunication = () => {
    if (message.trim()) {
      communicationMutation.mutate({ message, level: toneLevel });
    }
  };

  const toneLevels = [
    { value: 'strategic', label: '⚔️ سيادي', description: 'نبرة استراتيجية حازمة ومؤثرة' },
    { value: 'humanitarian', label: '🤝 إنساني', description: 'نبرة إنسانية دافئة ومتفهمة' },
    { value: 'diplomatic', label: '🕊️ دبلوماسي', description: 'نبرة دبلوماسية متوازنة ومحترمة' },
    { value: 'inspirational', label: '✨ ملهم', description: 'نبرة ملهمة محفزة ومشجعة' }
  ];

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <MessageSquare className="w-6 h-6 text-secondary" />
          التواصل الكريم والمهيب
        </CardTitle>
        <CardDescription>
          توليد رسائل كريمة ومهيبة بنبرات مختلفة مع تحليل شامل للكرامة والأثر الثقافي
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">الرسالة الأصلية:</label>
            <Textarea
              placeholder="اكتب رسالتك هنا ليتم تطويرها بأسلوب كريم ومهيب...

مثال: نعلن عن إطلاق مبادرة جديدة للتطوير التقني"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="font-arabic min-h-[100px]"
              rows={4}
            />
          </div>
          
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">نبرة التواصل:</label>
            <Select value={toneLevel} onValueChange={setToneLevel}>
              <SelectTrigger className="font-arabic">
                <SelectValue placeholder="اختر نبرة التواصل" />
              </SelectTrigger>
              <SelectContent>
                {toneLevels.map((tone) => (
                  <SelectItem key={tone.value} value={tone.value}>
                    <div className="flex flex-col items-start">
                      <span className="font-semibold">{tone.label}</span>
                      <span className="text-xs text-muted-foreground">{tone.description}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <Button
          onClick={handleGenerateCommunication}
          disabled={communicationMutation.isPending || !message.trim()}
          className="w-full font-arabic"
        >
          {communicationMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              توليد التواصل الكريم جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              توليد رسالة كريمة ومهيبة
            </div>
          )}
        </Button>

        {communicationMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">الرسالة الكريمة المولدة:</h4>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Dignified Message Output */}
              {communicationMutation.data.communication?.communication?.dignified_message && (
                <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border-r-4 border-blue-500">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">الرسالة الكريمة النهائية:</h5>
                  <p className="text-sm font-arabic leading-relaxed font-semibold text-blue-800 dark:text-blue-200">
                    {communicationMutation.data.communication.communication.dignified_message}
                  </p>
                </div>
              )}

              {/* Basic Message Comparison */}
              {communicationMutation.data.communication?.communication?.basic_message && (
                <div className="p-3 bg-gray-50 dark:bg-gray-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">الرسالة الأساسية:</h5>
                  <p className="text-sm font-arabic text-gray-700 dark:text-gray-300">
                    {communicationMutation.data.communication.communication.basic_message}
                  </p>
                </div>
              )}

              {/* Tone Information */}
              {communicationMutation.data.communication?.communication?.communication_analysis?.tone_info && (
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">معلومات النبرة:</h5>
                  <div className="grid grid-cols-1 gap-2 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{communicationMutation.data.communication.communication.communication_analysis.tone_info.symbol}</span>
                      <div>
                        <span className="font-semibold">{communicationMutation.data.communication.communication.communication_analysis.tone_info.name}</span>
                        <p className="text-xs text-muted-foreground">{communicationMutation.data.communication.communication.communication_analysis.tone_info.description}</p>
                      </div>
                    </div>
                    
                    {communicationMutation.data.communication.communication.communication_analysis.tone_info.characteristics?.length > 0 && (
                      <div>
                        <span className="font-semibold text-xs block mb-1">خصائص النبرة:</span>
                        <div className="space-y-1">
                          {communicationMutation.data.communication.communication.communication_analysis.tone_info.characteristics.slice(0, 3).map((characteristic: string, index: number) => (
                            <div key={index} className="text-xs text-muted-foreground flex items-center gap-1">
                              <CheckCircle className="w-3 h-3 text-purple-500" />
                              {characteristic}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Dignity Assessment */}
              {communicationMutation.data.communication?.communication?.communication_analysis?.dignity_assessment && (
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تقييم الكرامة:</h5>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <span className="font-semibold">مستوى الكرامة:</span>
                      <div className="flex items-center gap-1">
                        <div className="w-16 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-500 h-2 rounded-full" 
                            style={{ width: `${(communicationMutation.data.communication.communication.communication_analysis.dignity_assessment.score * 100)}%` }}
                          ></div>
                        </div>
                        <span>{((communicationMutation.data.communication.communication.communication_analysis.dignity_assessment.score || 0) * 100).toFixed(0)}%</span>
                      </div>
                    </div>
                    
                    <div>
                      <span className="font-semibold text-xs">التقييم:</span>
                      <Badge variant="default" className="ml-1 text-xs">
                        {communicationMutation.data.communication.communication.communication_analysis.dignity_assessment.level}
                      </Badge>
                    </div>
                    
                    {communicationMutation.data.communication.communication.communication_analysis.dignity_assessment.factors?.length > 0 && (
                      <div>
                        <span className="font-semibold text-xs block mb-1">عوامل الكرامة:</span>
                        <div className="space-y-1">
                          {communicationMutation.data.communication.communication.communication_analysis.dignity_assessment.factors.slice(0, 3).map((factor: string, index: number) => (
                            <div key={index} className="text-xs text-muted-foreground flex items-center gap-1">
                              <Crown className="w-3 h-3 text-green-500" />
                              {factor}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Cultural Analysis */}
              {communicationMutation.data.communication?.communication?.communication_analysis?.cultural_analysis && (
                <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحليل الثقافي:</h5>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="font-semibold">الرنين الثقافي:</span>
                      <div className="flex items-center gap-1 mt-1">
                        <div className="w-12 bg-gray-200 rounded-full h-1.5">
                          <div 
                            className="bg-amber-500 h-1.5 rounded-full" 
                            style={{ width: `${(communicationMutation.data.communication.communication.communication_analysis.cultural_analysis.resonance * 100)}%` }}
                          ></div>
                        </div>
                        <span>{((communicationMutation.data.communication.communication.communication_analysis.cultural_analysis.resonance || 0) * 100).toFixed(0)}%</span>
                      </div>
                    </div>
                    
                    <div>
                      <span className="font-semibold">الأصالة:</span>
                      <div className="flex items-center gap-1 mt-1">
                        <div className="w-12 bg-gray-200 rounded-full h-1.5">
                          <div 
                            className="bg-orange-500 h-1.5 rounded-full" 
                            style={{ width: `${(communicationMutation.data.communication.communication.communication_analysis.cultural_analysis.authenticity_score * 100)}%` }}
                          ></div>
                        </div>
                        <span>{((communicationMutation.data.communication.communication.communication_analysis.cultural_analysis.authenticity_score || 0) * 100).toFixed(0)}%</span>
                      </div>
                    </div>
                  </div>
                  
                  {communicationMutation.data.communication.communication.communication_analysis.cultural_analysis.cultural_markers?.length > 0 && (
                    <div className="mt-2">
                      <span className="font-semibold text-xs block mb-1">المؤشرات الثقافية:</span>
                      <div className="flex flex-wrap gap-1">
                        {communicationMutation.data.communication.communication.communication_analysis.cultural_analysis.cultural_markers.slice(0, 3).map((marker: string, index: number) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {marker}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Impact Evaluation */}
              {communicationMutation.data.communication?.communication?.communication_analysis?.impact_evaluation && (
                <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تقييم التأثير:</h5>
                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="font-semibold text-xs">التأثير المحتمل:</span>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {communicationMutation.data.communication.communication.communication_analysis.impact_evaluation.potential_influence}
                      </p>
                    </div>
                    
                    <div>
                      <span className="font-semibold text-xs">الجمهور المناسب:</span>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {communicationMutation.data.communication.communication.communication_analysis.impact_evaluation.audience_suitability}
                      </p>
                    </div>
                    
                    <div>
                      <span className="font-semibold text-xs">وضوح الرسالة:</span>
                      <div className="flex items-center gap-1 mt-1">
                        <div className="w-12 bg-gray-200 rounded-full h-1.5">
                          <div 
                            className="bg-red-500 h-1.5 rounded-full" 
                            style={{ width: `${(communicationMutation.data.communication.communication.communication_analysis.impact_evaluation.message_clarity * 100)}%` }}
                          ></div>
                        </div>
                        <span>{((communicationMutation.data.communication.communication.communication_analysis.impact_evaluation.message_clarity || 0) * 100).toFixed(0)}%</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Communication Guidelines */}
              {communicationMutation.data.communication?.communication?.communication_guidelines?.recommended_contexts?.length > 0 && (
                <div className="p-3 bg-background rounded border">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">السياقات المناسبة:</h5>
                  <div className="space-y-1">
                    {communicationMutation.data.communication.communication.communication_guidelines.recommended_contexts.slice(0, 3).map((context: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-center gap-1">
                        <Target className="w-3 h-3 text-gray-500" />
                        {context}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Enhancement Suggestions */}
              {communicationMutation.data.communication?.communication?.communication_guidelines?.enhancement_suggestions?.length > 0 && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">اقتراحات التحسين:</h5>
                  <div className="space-y-1">
                    {communicationMutation.data.communication.communication.communication_guidelines.enhancement_suggestions.slice(0, 3).map((suggestion: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Lightbulb className="w-3 h-3 text-blue-500 mt-0.5 flex-shrink-0" />
                        <span>{suggestion}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Worldview Remapping Interface Component
const WorldviewRemappingInterface: React.FC = () => {
  const [dataStream, setDataStream] = useState<Array<{term: string, definition: string}>>([]);
  const [sovereignCode, setSovereignCode] = useState<Record<string, string>>({});
  const [newTerm, setNewTerm] = useState('');
  const [newDefinition, setNewDefinition] = useState('');
  const [sovereignTerm, setSovereignTerm] = useState('');
  const [sovereignDefinition, setSovereignDefinition] = useState('');

  const remappingMutation = useMutation({
    mutationFn: async (remappingData: { data_stream: Array<{term: string, definition: string}>, sovereign_code: Record<string, string> }) => {
      const response = await fetch('/api/ai-neural/worldview/remap', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(remappingData)
      });
      if (!response.ok) throw new Error('Worldview remapping failed');
      return response.json();
    }
  });

  const addConcept = () => {
    if (newTerm.trim() && newDefinition.trim()) {
      setDataStream(prev => [...prev, { term: newTerm, definition: newDefinition }]);
      setNewTerm('');
      setNewDefinition('');
    }
  };

  const addSovereignCode = () => {
    if (sovereignTerm.trim() && sovereignDefinition.trim()) {
      setSovereignCode(prev => ({ ...prev, [sovereignTerm]: sovereignDefinition }));
      setSovereignTerm('');
      setSovereignDefinition('');
    }
  };

  const removeConcept = (index: number) => {
    setDataStream(prev => prev.filter((_, i) => i !== index));
  };

  const removeSovereignCode = (term: string) => {
    setSovereignCode(prev => {
      const newCode = { ...prev };
      delete newCode[term];
      return newCode;
    });
  };

  const handleRemapWorldview = () => {
    if (dataStream.length > 0 && Object.keys(sovereignCode).length > 0) {
      remappingMutation.mutate({ data_stream: dataStream, sovereign_code: sovereignCode });
    }
  };

  const clearAll = () => {
    setDataStream([]);
    setSovereignCode({});
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Globe className="w-6 h-6 text-secondary" />
          إعادة تخطيط الرؤية العالمية
        </CardTitle>
        <CardDescription>
          تحويل تعريفات المفاهيم باستخدام الكود السيادي مع التحليل الثقافي والسيادي الشامل
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Data Stream Section */}
          <div className="space-y-3">
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">إضافة مفهوم جديد:</label>
              <div className="space-y-2">
                <Input
                  placeholder="المصطلح"
                  value={newTerm}
                  onChange={(e) => setNewTerm(e.target.value)}
                  className="font-arabic"
                />
                <Textarea
                  placeholder="التعريف الحالي"
                  value={newDefinition}
                  onChange={(e) => setNewDefinition(e.target.value)}
                  className="font-arabic min-h-[60px]"
                />
                <Button 
                  onClick={addConcept}
                  size="sm"
                  disabled={!newTerm.trim() || !newDefinition.trim()}
                  className="w-full font-arabic"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  إضافة مفهوم
                </Button>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold font-arabic">تدفق البيانات ({dataStream.length}):</label>
                {dataStream.length > 0 && (
                  <Button onClick={() => setDataStream([])} size="sm" variant="outline" className="font-arabic">
                    <Trash2 className="w-4 h-4 mr-1" />
                    مسح المفاهيم
                  </Button>
                )}
              </div>
              
              <div className="max-h-40 overflow-y-auto space-y-2 border rounded-lg p-2">
                {dataStream.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground font-arabic">
                    لا توجد مفاهيم مضافة بعد
                  </div>
                ) : (
                  dataStream.map((concept, index) => (
                    <div key={index} className="p-2 bg-secondary/10 rounded border">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="font-semibold text-sm">{concept.term}</div>
                          <div className="text-xs text-muted-foreground mt-1">{concept.definition}</div>
                        </div>
                        <Button 
                          onClick={() => removeConcept(index)}
                          size="sm"
                          variant="ghost"
                          className="ml-2"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
          
          {/* Sovereign Code Section */}
          <div className="space-y-3">
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">إضافة كود سيادي:</label>
              <div className="space-y-2">
                <Input
                  placeholder="المصطلح المراد تطبيق الكود عليه"
                  value={sovereignTerm}
                  onChange={(e) => setSovereignTerm(e.target.value)}
                  className="font-arabic"
                />
                <Textarea
                  placeholder="التعريف السيادي الجديد"
                  value={sovereignDefinition}
                  onChange={(e) => setSovereignDefinition(e.target.value)}
                  className="font-arabic min-h-[60px]"
                />
                <Button 
                  onClick={addSovereignCode}
                  size="sm"
                  disabled={!sovereignTerm.trim() || !sovereignDefinition.trim()}
                  className="w-full font-arabic"
                >
                  <Crown className="w-4 h-4 mr-1" />
                  إضافة كود سيادي
                </Button>
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold font-arabic">الكود السيادي ({Object.keys(sovereignCode).length}):</label>
                {Object.keys(sovereignCode).length > 0 && (
                  <Button onClick={() => setSovereignCode({})} size="sm" variant="outline" className="font-arabic">
                    <Trash2 className="w-4 h-4 mr-1" />
                    مسح الكود
                  </Button>
                )}
              </div>
              
              <div className="max-h-40 overflow-y-auto space-y-2 border rounded-lg p-2">
                {Object.keys(sovereignCode).length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground font-arabic">
                    لا يوجد كود سيادي مضاف بعد
                  </div>
                ) : (
                  Object.entries(sovereignCode).map(([term, definition]) => (
                    <div key={term} className="p-2 bg-secondary/10 rounded border">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="font-semibold text-sm flex items-center gap-2">
                            <Crown className="w-3 h-3 text-secondary" />
                            {term}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">{definition}</div>
                        </div>
                        <Button 
                          onClick={() => removeSovereignCode(term)}
                          size="sm"
                          variant="ghost"
                          className="ml-2"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleRemapWorldview}
            disabled={remappingMutation.isPending || dataStream.length === 0 || Object.keys(sovereignCode).length === 0}
            className="flex-1 font-arabic"
          >
            {remappingMutation.isPending ? (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" />
                إعادة تخطيط الرؤية العالمية جاري...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4" />
                إعادة تخطيط الرؤية العالمية
              </div>
            )}
          </Button>
          
          {(dataStream.length > 0 || Object.keys(sovereignCode).length > 0) && (
            <Button onClick={clearAll} variant="outline" className="font-arabic">
              <Trash2 className="w-4 h-4 mr-1" />
              مسح الكل
            </Button>
          )}
        </div>

        {remappingMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج إعادة تخطيط الرؤية العالمية:</h4>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Basic Statistics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                  <div className="text-lg font-bold text-blue-600">{remappingMutation.data.remapping?.remapping?.processed_concepts || 0}</div>
                  <div className="text-xs text-muted-foreground">المفاهيم المعالجة</div>
                </div>
                
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                  <div className="text-lg font-bold text-green-600">{remappingMutation.data.remapping?.remapping?.sovereignty_mappings || 0}</div>
                  <div className="text-xs text-muted-foreground">التطبيقات السيادية</div>
                </div>
                
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                  <div className="text-lg font-bold text-purple-600">{remappingMutation.data.remapping?.remapping?.cultural_alignments || 0}</div>
                  <div className="text-xs text-muted-foreground">التوافقات الثقافية</div>
                </div>
                
                <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg text-center">
                  <div className="text-lg font-bold text-orange-600">{remappingMutation.data.remapping?.remapping?.alignment_percentage?.toFixed(1) || 0}%</div>
                  <div className="text-xs text-muted-foreground">نسبة التوافق</div>
                </div>
              </div>

              {/* Remapped Data */}
              {remappingMutation.data.remapping?.remapping?.remapped_data?.length > 0 && (
                <div className="p-3 bg-gray-50 dark:bg-gray-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">البيانات المعاد تخطيطها:</h5>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {remappingMutation.data.remapping.remapping.remapped_data.slice(0, 5).map((concept: any, index: number) => (
                      <div key={index} className="p-2 bg-white dark:bg-gray-800 rounded border">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="font-semibold text-sm flex items-center gap-2">
                              {concept.sovereignty_metadata?.sovereignty_aligned && (
                                <Crown className="w-3 h-3 text-secondary" />
                              )}
                              {concept.term}
                            </div>
                            <div className="text-xs text-muted-foreground mt-1">{concept.definition}</div>
                            
                            {concept.sovereignty_metadata && (
                              <div className="mt-2 flex flex-wrap gap-1">
                                {concept.sovereignty_metadata.cultural_context && (
                                  <Badge variant="outline" className="text-xs">
                                    {concept.sovereignty_metadata.cultural_context}
                                  </Badge>
                                )}
                                {concept.sovereignty_metadata.sovereignty_aligned && (
                                  <Badge variant="default" className="text-xs">
                                    سيادي
                                  </Badge>
                                )}
                                <Badge variant="secondary" className="text-xs">
                                  {concept.sovereignty_metadata.enhancement_level}
                                </Badge>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Analysis Results */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* Sovereignty Impact */}
                {remappingMutation.data.remapping?.remapping?.sovereignty_impact && (
                  <div className="p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                    <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التأثير السيادي:</h5>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">المستوى:</span>
                        <Badge variant="default" className="text-xs">
                          {remappingMutation.data.remapping.remapping.sovereignty_impact.impact_level}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">النقاط:</span>
                        <div className="flex items-center gap-1">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-emerald-500 h-2 rounded-full" 
                              style={{ width: `${(remappingMutation.data.remapping.remapping.sovereignty_impact.score * 100)}%` }}
                            ></div>
                          </div>
                          <span className="text-xs">{((remappingMutation.data.remapping.remapping.sovereignty_impact.score || 0) * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      
                      <div className="text-xs">
                        <span className="font-semibold">التغطية السيادية:</span>
                        <span className="text-muted-foreground ml-1">
                          {((remappingMutation.data.remapping.remapping.sovereignty_impact.sovereignty_coverage || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Cultural Coherence */}
                {remappingMutation.data.remapping?.remapping?.cultural_coherence && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التماسك الثقافي:</h5>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">المستوى:</span>
                        <Badge variant="default" className="text-xs">
                          {remappingMutation.data.remapping.remapping.cultural_coherence.coherence_level}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">النقاط:</span>
                        <div className="flex items-center gap-1">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-500 h-2 rounded-full" 
                              style={{ width: `${(remappingMutation.data.remapping.remapping.cultural_coherence.score * 100)}%` }}
                            ></div>
                          </div>
                          <span className="text-xs">{((remappingMutation.data.remapping.remapping.cultural_coherence.score || 0) * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      
                      <div className="text-xs">
                        <span className="font-semibold">التغطية الثقافية:</span>
                        <span className="text-muted-foreground ml-1">
                          {((remappingMutation.data.remapping.remapping.cultural_coherence.cultural_coverage || 0) * 100).toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Transformation Quality */}
              {remappingMutation.data.remapping?.remapping?.transformation_quality && (
                <div className="p-3 bg-violet-50 dark:bg-violet-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">جودة التحويل:</h5>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="flex justify-between">
                      <span>المستوى:</span>
                      <Badge variant="outline" className="text-xs">
                        {remappingMutation.data.remapping.remapping.transformation_quality.quality_level}
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>النقاط الإجمالية:</span>
                      <span>{((remappingMutation.data.remapping.remapping.transformation_quality.overall_score || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الاكتمال:</span>
                      <span>{((remappingMutation.data.remapping.remapping.transformation_quality.metrics?.completeness || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الدقة:</span>
                      <span>{((remappingMutation.data.remapping.remapping.transformation_quality.metrics?.accuracy || 0) * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Recommendations */}
              {remappingMutation.data.remapping?.remapping?.recommendations?.length > 0 && (
                <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التوصيات:</h5>
                  <div className="space-y-1">
                    {remappingMutation.data.remapping.remapping.recommendations.slice(0, 4).map((recommendation: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Lightbulb className="w-3 h-3 text-amber-500 mt-0.5 flex-shrink-0" />
                        <span>{recommendation}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Metadata */}
              {remappingMutation.data.remapping?.remapping?.metadata && (
                <div className="p-3 bg-gray-50 dark:bg-gray-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">معلومات التحويل:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex justify-between">
                      <span>إدخالات الكود السيادي:</span>
                      <span>{remappingMutation.data.remapping.remapping.metadata.sovereign_code_entries}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>المفاهيم غير المخططة:</span>
                      <span>{remappingMutation.data.remapping.remapping.metadata.unmapped_concepts}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>إصدار التحويل:</span>
                      <span>{remappingMutation.data.remapping.remapping.metadata.transformation_version}</span>
                    </div>
                    
                    <div className="flex justify-between col-span-2">
                      <span>نسبة التغطية السيادية:</span>
                      <span>{remappingMutation.data.remapping.remapping.sovereignty_coverage?.toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Future Scenario Simulation Interface Component
const FutureScenarioInterface: React.FC = () => {
  const [area, setArea] = useState('');
  const [nationalValues, setNationalValues] = useState<string[]>(['التميز', 'الإبداع']);
  const [newValue, setNewValue] = useState('');

  const scenarioMutation = useMutation({
    mutationFn: async (scenarioData: { area: string, national_values: string[] }) => {
      const response = await fetch('/api/ai-neural/scenario/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(scenarioData)
      });
      if (!response.ok) throw new Error('Scenario simulation failed');
      return response.json();
    }
  });

  const handleSimulateScenario = () => {
    if (area.trim() && nationalValues.length > 0) {
      scenarioMutation.mutate({ area: area.trim(), national_values: nationalValues });
    }
  };

  const addNationalValue = () => {
    if (newValue.trim() && !nationalValues.includes(newValue.trim())) {
      setNationalValues([...nationalValues, newValue.trim()]);
      setNewValue('');
    }
  };

  const removeNationalValue = (index: number) => {
    setNationalValues(nationalValues.filter((_, i) => i !== index));
  };

  const predefinedValues = [
    'التميز', 'الإبداع', 'الأصالة', 'التقدم', 'العدالة', 'الشفافية', 
    'الاستدامة', 'الشراكة', 'الجودة', 'الابتكار', 'الريادة', 'التطوير'
  ];

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Target className="w-6 h-6 text-secondary" />
          محاكاة السيناريو المستقبلي 2040
        </CardTitle>
        <CardDescription>
          إنشاء تصورات مستقبلية شاملة للمجالات المختلفة بناءً على القيم الوطنية وتوجهات رؤية المملكة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">المجال أو القطاع:</label>
            <Input
              placeholder="مثال: التقنية والذكاء الاصطناعي، التعليم والتطوير، الصحة والرفاهية..."
              value={area}
              onChange={(e) => setArea(e.target.value)}
              className="font-arabic"
            />
          </div>
          
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">القيم الوطنية الأساسية:</label>
            
            {/* Current Values Display */}
            {nationalValues.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {nationalValues.map((value, index) => (
                  <Badge key={index} variant="secondary" className="font-arabic flex items-center gap-1">
                    {value}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeNationalValue(index)}
                      className="h-4 w-4 p-0 hover:bg-red-500 hover:text-white"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
            
            {/* Add New Value */}
            <div className="flex gap-2 mb-3">
              <Input
                placeholder="إضافة قيمة وطنية جديدة..."
                value={newValue}
                onChange={(e) => setNewValue(e.target.value)}
                className="font-arabic"
                onKeyPress={(e) => e.key === 'Enter' && addNationalValue()}
              />
              <Button onClick={addNationalValue} disabled={!newValue.trim()}>
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            
            {/* Predefined Values */}
            <div>
              <label className="text-xs text-muted-foreground mb-2 block">قيم مقترحة:</label>
              <div className="flex flex-wrap gap-1">
                {predefinedValues.filter(val => !nationalValues.includes(val)).map((value) => (
                  <Button
                    key={value}
                    variant="outline"
                    size="sm"
                    onClick={() => setNationalValues([...nationalValues, value])}
                    className="text-xs font-arabic"
                  >
                    {value}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>

        <Button
          onClick={handleSimulateScenario}
          disabled={scenarioMutation.isPending || !area.trim() || nationalValues.length === 0}
          className="w-full font-arabic"
        >
          {scenarioMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              محاكاة السيناريو المستقبلي جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4" />
              محاكاة السيناريو المستقبلي 2040
            </div>
          )}
        </Button>

        {scenarioMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج محاكاة السيناريو المستقبلي:</h4>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Future Scenario */}
              <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 rounded-lg border">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern flex items-center gap-2">
                  <Target className="w-4 h-4 text-secondary" />
                  السيناريو المستقبلي المحسن (2040):
                </h5>
                <div className="text-sm leading-relaxed font-arabic bg-white dark:bg-gray-800 p-3 rounded border">
                  {scenarioMutation.data.scenario?.scenario?.future_scenario || 'غير متوفر'}
                </div>
                
                {scenarioMutation.data.scenario?.scenario?.original_scenario && (
                  <div className="mt-2">
                    <h6 className="text-xs font-semibold mb-1 font-kufi-modern">السيناريو الأساسي:</h6>
                    <div className="text-xs text-muted-foreground font-arabic bg-gray-50 dark:bg-gray-900 p-2 rounded">
                      {scenarioMutation.data.scenario.scenario.original_scenario}
                    </div>
                  </div>
                )}
              </div>

              {/* Analysis Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {/* Vision Alignment */}
                {scenarioMutation.data.scenario?.scenario?.vision_alignment && (
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                    <div className="text-lg font-bold text-green-600">
                      {scenarioMutation.data.scenario.scenario.vision_alignment.alignment_level}
                    </div>
                    <div className="text-xs text-muted-foreground">توافق الرؤية</div>
                    <div className="text-xs mt-1">
                      {((scenarioMutation.data.scenario.scenario.vision_alignment.overall_score || 0) * 100).toFixed(0)}%
                    </div>
                  </div>
                )}

                {/* Feasibility Analysis */}
                {scenarioMutation.data.scenario?.scenario?.feasibility_analysis && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                    <div className="text-lg font-bold text-blue-600">
                      {scenarioMutation.data.scenario.scenario.feasibility_analysis.feasibility_level}
                    </div>
                    <div className="text-xs text-muted-foreground">تحليل الجدوى</div>
                    <div className="text-xs mt-1">
                      {((scenarioMutation.data.scenario.scenario.feasibility_analysis.overall_score || 0) * 100).toFixed(0)}%
                    </div>
                  </div>
                )}

                {/* Sovereignty Impact */}
                {scenarioMutation.data.scenario?.scenario?.sovereignty_impact && (
                  <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                    <div className="text-lg font-bold text-purple-600">
                      {scenarioMutation.data.scenario.scenario.sovereignty_impact.sovereignty_level}
                    </div>
                    <div className="text-xs text-muted-foreground">التأثير السيادي</div>
                    <div className="text-xs mt-1">
                      {((scenarioMutation.data.scenario.scenario.sovereignty_impact.sovereignty_score || 0) * 100).toFixed(0)}%
                    </div>
                  </div>
                )}

                {/* Sustainability Assessment */}
                {scenarioMutation.data.scenario?.scenario?.sustainability_assessment && (
                  <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg text-center">
                    <div className="text-lg font-bold text-orange-600">
                      {scenarioMutation.data.scenario.scenario.sustainability_assessment.sustainability_level || 'متوسط'}
                    </div>
                    <div className="text-xs text-muted-foreground">تقييم الاستدامة</div>
                    <div className="text-xs mt-1">
                      {((scenarioMutation.data.scenario.scenario.sustainability_assessment?.overall_score || 0.5) * 100).toFixed(0)}%
                    </div>
                  </div>
                )}
              </div>

              {/* Vision Alignment Details */}
              {scenarioMutation.data.scenario?.scenario?.vision_alignment && (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تفاصيل توافق الرؤية:</h5>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="flex justify-between">
                      <span>المحور الأساسي:</span>
                      <Badge variant="outline" className="text-xs">
                        {scenarioMutation.data.scenario.scenario.vision_alignment.primary_pillar ? 
                          scenarioMutation.data.scenario.scenario.vision_alignment.primary_pillar : 'متنوع'}
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>توافق القيم:</span>
                      <span>{((scenarioMutation.data.scenario.scenario.vision_alignment.values_score || 0) * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                  
                  {scenarioMutation.data.scenario.scenario.vision_alignment.alignment_factors?.length > 0 && (
                    <div className="mt-2">
                      <h6 className="text-xs font-semibold mb-1">عوامل التوافق:</h6>
                      <div className="flex flex-wrap gap-1">
                        {scenarioMutation.data.scenario.scenario.vision_alignment.alignment_factors.map((factor: string, index: number) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {factor}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Feasibility Analysis Details */}
              {scenarioMutation.data.scenario?.scenario?.feasibility_analysis?.factors && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل الجدوى التفصيلي:</h5>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                    <div className="flex justify-between">
                      <span>الجدوى التقنية:</span>
                      <span>{((scenarioMutation.data.scenario.scenario.feasibility_analysis.factors.technical_feasibility || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الجدوى الاقتصادية:</span>
                      <span>{((scenarioMutation.data.scenario.scenario.feasibility_analysis.factors.economic_feasibility || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الجدوى الاجتماعية:</span>
                      <span>{((scenarioMutation.data.scenario.scenario.feasibility_analysis.factors.social_feasibility || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الجدوى السياسية:</span>
                      <span>{((scenarioMutation.data.scenario.scenario.feasibility_analysis.factors.political_feasibility || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الجدوى البيئية:</span>
                      <span>{((scenarioMutation.data.scenario.scenario.feasibility_analysis.factors.environmental_feasibility || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>أقوى عامل:</span>
                      <Badge variant="outline" className="text-xs">
                        {scenarioMutation.data.scenario.scenario.feasibility_analysis.strongest_factor || 'متوازن'}
                      </Badge>
                    </div>
                  </div>
                </div>
              )}

              {/* Strategic Recommendations */}
              {scenarioMutation.data.scenario?.scenario?.strategic_recommendations?.length > 0 && (
                <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التوصيات الاستراتيجية:</h5>
                  <div className="space-y-1">
                    {scenarioMutation.data.scenario.scenario.strategic_recommendations.slice(0, 4).map((recommendation: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Lightbulb className="w-3 h-3 text-yellow-500 mt-0.5 flex-shrink-0" />
                        <span>{recommendation}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Sovereignty Enhancement Recommendations */}
              {scenarioMutation.data.scenario?.scenario?.sovereignty_impact?.enhancement_recommendations?.length > 0 && (
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">توصيات تعزيز السيادة:</h5>
                  <div className="space-y-1">
                    {scenarioMutation.data.scenario.scenario.sovereignty_impact.enhancement_recommendations.map((recommendation: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Shield className="w-3 h-3 text-purple-500 mt-0.5 flex-shrink-0" />
                        <span>{recommendation}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Metadata */}
              {scenarioMutation.data.scenario?.scenario?.metadata && (
                <div className="p-3 bg-gray-50 dark:bg-gray-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">معلومات إضافية:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex justify-between">
                      <span>أفق التخطيط:</span>
                      <span>{scenarioMutation.data.scenario.scenario.metadata.planning_horizon}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>إصدار السيناريو:</span>
                      <span>{scenarioMutation.data.scenario.scenario.metadata.scenario_version}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>المستوى السيادي:</span>
                      <span>{scenarioMutation.data.scenario.scenario.metadata.sovereignty_level}</span>
                    </div>
                    
                    <div className="flex justify-between col-span-2">
                      <span>المجال:</span>
                      <span className="text-right">{scenarioMutation.data.scenario.scenario.area}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Glory Statement Generation Interface Component
const GloryStatementInterface: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [impactLevel, setImpactLevel] = useState('عالمي');

  const gloryMutation = useMutation({
    mutationFn: async (gloryData: { topic: string, impact_level: string }) => {
      const response = await fetch('/api/ai-neural/glory/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(gloryData)
      });
      if (!response.ok) throw new Error('Glory statement generation failed');
      return response.json();
    }
  });

  const handleGenerateGlory = () => {
    if (topic.trim()) {
      gloryMutation.mutate({ topic: topic.trim(), impact_level: impactLevel });
    }
  };

  const impactLevels = [
    { value: 'محلي', label: 'محلي', color: 'bg-blue-50 dark:bg-blue-900/20 text-blue-600' },
    { value: 'وطني', label: 'وطني', color: 'bg-green-50 dark:bg-green-900/20 text-green-600' },
    { value: 'إقليمي', label: 'إقليمي', color: 'bg-purple-50 dark:bg-purple-900/20 text-purple-600' },
    { value: 'عالمي', label: 'عالمي', color: 'bg-orange-50 dark:bg-orange-900/20 text-orange-600' },
    { value: 'تاريخي', label: 'تاريخي', color: 'bg-red-50 dark:bg-red-900/20 text-red-600' }
  ];

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Crown className="w-6 h-6 text-secondary" />
          توليد بيان المجد الوطني
        </CardTitle>
        <CardDescription>
          إنشاء بيانات مجد وطنية تعكس الفخر السعودي والتميز المعرفي بمستويات تأثير متعددة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">الموضوع:</label>
            <Input
              placeholder="مثال: الذكاء الاصطناعي السيادي، التقنية المتقدمة، التعليم النوعي..."
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="font-arabic"
            />
          </div>
          
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">مستوى التأثير:</label>
            <Select value={impactLevel} onValueChange={setImpactLevel}>
              <SelectTrigger className="font-arabic">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {impactLevels.map((level) => (
                  <SelectItem key={level.value} value={level.value} className="font-arabic">
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${level.color.split(' ')[0]} ${level.color.split(' ')[1]}`}></div>
                      {level.label}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button
          onClick={handleGenerateGlory}
          disabled={gloryMutation.isPending || !topic.trim()}
          className="w-full font-arabic"
        >
          {gloryMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              توليد بيان المجد جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Crown className="w-4 h-4" />
              توليد بيان المجد
            </div>
          )}
        </Button>

        {gloryMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج بيان المجد الوطني:</h4>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Glory Statement */}
              <div className="p-4 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg border">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern flex items-center gap-2">
                  <Crown className="w-4 h-4 text-secondary" />
                  بيان المجد المحسن:
                </h5>
                <div className="text-sm leading-relaxed font-arabic bg-white dark:bg-gray-800 p-3 rounded border">
                  {gloryMutation.data.glory?.glory?.glory_statement || 'غير متوفر'}
                </div>
                
                {gloryMutation.data.glory?.glory?.original_statement && (
                  <div className="mt-2">
                    <h6 className="text-xs font-semibold mb-1 font-kufi-modern">البيان الأساسي:</h6>
                    <div className="text-xs text-muted-foreground font-arabic bg-gray-50 dark:bg-gray-900 p-2 rounded">
                      {gloryMutation.data.glory.glory.original_statement}
                    </div>
                  </div>
                )}
              </div>

              {/* Analysis Metrics */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {/* National Alignment */}
                {gloryMutation.data.glory?.glory?.national_alignment && (
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                    <div className="text-lg font-bold text-green-600">
                      {gloryMutation.data.glory.glory.national_alignment.alignment_level}
                    </div>
                    <div className="text-xs text-muted-foreground">التوافق الوطني</div>
                    <div className="text-xs mt-1">
                      {((gloryMutation.data.glory.glory.national_alignment.alignment_score || 0) * 100).toFixed(0)}%
                    </div>
                  </div>
                )}

                {/* Cultural Context */}
                {gloryMutation.data.glory?.glory?.cultural_context && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                    <div className="text-lg font-bold text-blue-600">
                      {gloryMutation.data.glory.glory.cultural_context.primary_context}
                    </div>
                    <div className="text-xs text-muted-foreground">السياق الثقافي</div>
                    <div className="text-xs mt-1">
                      عمق: {gloryMutation.data.glory.glory.cultural_context.cultural_depth}
                    </div>
                  </div>
                )}

                {/* Sovereignty Impact */}
                {gloryMutation.data.glory?.glory?.sovereignty_impact && (
                  <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                    <div className="text-lg font-bold text-purple-600">
                      {gloryMutation.data.glory.glory.sovereignty_impact.sovereignty_level}
                    </div>
                    <div className="text-xs text-muted-foreground">التأثير السيادي</div>
                    <div className="text-xs mt-1">
                      {((gloryMutation.data.glory.glory.sovereignty_impact.sovereignty_score || 0) * 100).toFixed(0)}%
                    </div>
                  </div>
                )}

                {/* Vision Alignment */}
                {gloryMutation.data.glory?.glory?.vision_alignment && (
                  <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg text-center">
                    <div className="text-lg font-bold text-orange-600">
                      {gloryMutation.data.glory.glory.vision_alignment.alignment_level}
                    </div>
                    <div className="text-xs text-muted-foreground">توافق الرؤية</div>
                    <div className="text-xs mt-1">
                      {((gloryMutation.data.glory.glory.vision_alignment.overall_score || 0) * 100).toFixed(0)}%
                    </div>
                  </div>
                )}
              </div>

              {/* Cultural Resonance */}
              {gloryMutation.data.glory?.glory?.cultural_resonance && (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التأثير الثقافي:</h5>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="flex justify-between">
                      <span>مستوى التأثير:</span>
                      <Badge variant="outline" className="text-xs">
                        {gloryMutation.data.glory.glory.cultural_resonance.resonance_level}
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>النقاط الإجمالية:</span>
                      <span>{((gloryMutation.data.glory.glory.cultural_resonance.overall_score || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>التأثير الديني:</span>
                      <span>{((gloryMutation.data.glory.glory.cultural_resonance.factors?.religious_resonance || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>التطلعات الحديثة:</span>
                      <span>{((gloryMutation.data.glory.glory.cultural_resonance.factors?.modern_aspirations || 0) * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Glory Metrics */}
              {gloryMutation.data.glory?.glory?.glory_metrics && (
                <div className="p-3 bg-gray-50 dark:bg-gray-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">مقاييس البيان:</h5>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                    <div className="flex justify-between">
                      <span>عدد الكلمات:</span>
                      <span>{gloryMutation.data.glory.glory.glory_metrics.word_count}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الكثافة العاطفية:</span>
                      <span>{((gloryMutation.data.glory.glory.glory_metrics.emotional_intensity || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الكثافة الثقافية:</span>
                      <span>{((gloryMutation.data.glory.glory.glory_metrics.cultural_density || 0) * 100).toFixed(0)}%</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الكثافة السيادية:</span>
                      <span>{((gloryMutation.data.glory.glory.glory_metrics.sovereignty_density || 0) * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Inspirational Enhancements */}
              {gloryMutation.data.glory?.glory?.inspirational_enhancements?.length > 0 && (
                <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحسينات الإلهامية:</h5>
                  <div className="space-y-1">
                    {gloryMutation.data.glory.glory.inspirational_enhancements.slice(0, 3).map((enhancement: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Sparkles className="w-3 h-3 text-yellow-500 mt-0.5 flex-shrink-0" />
                        <span>{enhancement}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Enhancement Recommendations */}
              {gloryMutation.data.glory?.glory?.enhancement_recommendations?.length > 0 && (
                <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">توصيات التحسين:</h5>
                  <div className="space-y-1">
                    {gloryMutation.data.glory.glory.enhancement_recommendations.slice(0, 3).map((recommendation: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Lightbulb className="w-3 h-3 text-amber-500 mt-0.5 flex-shrink-0" />
                        <span>{recommendation}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* National Alignment Factors */}
              {gloryMutation.data.glory?.glory?.national_alignment?.alignment_factors?.length > 0 && (
                <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">عوامل التوافق الوطني:</h5>
                  <div className="flex flex-wrap gap-1">
                    {gloryMutation.data.glory.glory.national_alignment.alignment_factors.map((factor: string, index: number) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {factor}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Metadata */}
              {gloryMutation.data.glory?.glory?.metadata && (
                <div className="p-3 bg-gray-50 dark:bg-gray-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">معلومات إضافية:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex justify-between">
                      <span>إصدار المجد:</span>
                      <span>{gloryMutation.data.glory.glory.metadata.glory_version}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الإطار الثقافي:</span>
                      <span className="text-right">{gloryMutation.data.glory.glory.metadata.cultural_framework}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>المستوى السيادي:</span>
                      <span>{gloryMutation.data.glory.glory.metadata.sovereignty_level}</span>
                    </div>
                    
                    <div className="flex justify-between col-span-2">
                      <span>الموضوع:</span>
                      <span className="text-right">{gloryMutation.data.glory.glory.topic}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Decision Factors Analysis Interface Component
const DecisionFactorsAnalysisInterface: React.FC = () => {
  const [factors, setFactors] = useState<Record<string, number>>({});
  const [factorName, setFactorName] = useState('');
  const [factorValue, setFactorValue] = useState('');
  const [sovereigntyWeight, setSovereigntyWeight] = useState(1.0);

  const analysisMutation = useMutation({
    mutationFn: async (analysisData: { factors: Record<string, number> }) => {
      const response = await fetch('/api/ai-neural/decision/analyze-factors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(analysisData)
      });
      if (!response.ok) throw new Error('Decision factors analysis failed');
      return response.json();
    }
  });

  const addFactor = () => {
    if (factorName.trim() && factorValue.trim()) {
      const value = parseFloat(factorValue);
      if (!isNaN(value)) {
        setFactors(prev => ({ ...prev, [factorName]: value }));
        setFactorName('');
        setFactorValue('');
      }
    }
  };

  const removeFactor = (name: string) => {
    setFactors(prev => {
      const newFactors = { ...prev };
      delete newFactors[name];
      return newFactors;
    });
  };

  const handleAnalyzeFactors = () => {
    if (Object.keys(factors).length > 0) {
      const analysisFactors = { ...factors, sovereignty_weight: sovereigntyWeight };
      analysisMutation.mutate({ factors: analysisFactors });
    }
  };

  const clearFactors = () => {
    setFactors({});
    setSovereigntyWeight(1.0);
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <BarChart3 className="w-6 h-6 text-secondary" />
          تحليل عوامل القرار
        </CardTitle>
        <CardDescription>
          تحليل شامل لعوامل القرار مع الترجيح السيادي والتقييم الاستراتيجي
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Factor Input Section */}
          <div className="space-y-3">
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">إضافة عامل قرار:</label>
              <div className="grid grid-cols-3 gap-2">
                <Input
                  placeholder="اسم العامل"
                  value={factorName}
                  onChange={(e) => setFactorName(e.target.value)}
                  className="font-arabic"
                />
                <Input
                  type="number"
                  step="0.1"
                  min="0"
                  max="1"
                  placeholder="القيمة (0-1)"
                  value={factorValue}
                  onChange={(e) => setFactorValue(e.target.value)}
                  className="font-arabic"
                />
                <Button 
                  onClick={addFactor}
                  size="sm"
                  disabled={!factorName.trim() || !factorValue.trim()}
                  className="font-arabic"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">الوزن السيادي:</label>
              <div className="flex items-center gap-2">
                <Slider
                  value={[sovereigntyWeight]}
                  onValueChange={(value) => setSovereigntyWeight(value[0])}
                  min={0.1}
                  max={2.0}
                  step={0.1}
                  className="flex-1"
                />
                <span className="text-sm font-mono w-12">{sovereigntyWeight.toFixed(1)}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                الوزن السيادي يؤثر على جميع العوامل لتعزيز القرارات المستقلة
              </p>
            </div>
          </div>
          
          {/* Current Factors Display */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold font-arabic">العوامل الحالية ({Object.keys(factors).length}):</label>
              {Object.keys(factors).length > 0 && (
                <Button onClick={clearFactors} size="sm" variant="outline" className="font-arabic">
                  <Trash2 className="w-4 h-4 mr-1" />
                  مسح الكل
                </Button>
              )}
            </div>
            
            <div className="max-h-40 overflow-y-auto space-y-2 border rounded-lg p-2">
              {Object.keys(factors).length === 0 ? (
                <div className="text-center py-6 text-muted-foreground font-arabic">
                  لا توجد عوامل مضافة بعد
                </div>
              ) : (
                Object.entries(factors).map(([name, value]) => (
                  <div key={name} className="flex items-center justify-between p-2 bg-secondary/10 rounded">
                    <div className="flex-1">
                      <span className="font-semibold text-sm">{name}</span>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="w-20 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-500 h-2 rounded-full" 
                            style={{ width: `${value * 100}%` }}
                          ></div>
                        </div>
                        <span className="text-xs text-muted-foreground">{value.toFixed(2)}</span>
                      </div>
                    </div>
                    <Button 
                      onClick={() => removeFactor(name)}
                      size="sm"
                      variant="ghost"
                      className="ml-2"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
        
        <Button
          onClick={handleAnalyzeFactors}
          disabled={analysisMutation.isPending || Object.keys(factors).length === 0}
          className="w-full font-arabic"
        >
          {analysisMutation.isPending ? (
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 animate-spin" />
              تحليل عوامل القرار جاري...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              تحليل عوامل القرار مع الترجيح السيادي
            </div>
          )}
        </Button>

        {analysisMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج تحليل عوامل القرار:</h4>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Basic Ranking */}
              {analysisMutation.data.analysis?.analysis?.basic_ranking?.length > 0 && (
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">الترتيب الأساسي (مرجح بالسيادة):</h5>
                  <div className="space-y-2">
                    {analysisMutation.data.analysis.analysis.basic_ranking.slice(0, 5).map(([factor, value]: [string, number], index: number) => (
                      <div key={factor} className="flex items-center gap-2 text-sm">
                        <div className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-500 text-white text-xs font-bold">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <span className="font-semibold">{factor}</span>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="w-24 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-500 h-2 rounded-full" 
                                style={{ width: `${Math.min(100, (value / Math.max(...analysisMutation.data.analysis.analysis.basic_ranking.map(([_, v]: [string, number]) => v))) * 100)}%` }}
                              ></div>
                            </div>
                            <span className="text-xs text-muted-foreground">{value.toFixed(3)}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Sovereignty Enhanced Ranking */}
              {analysisMutation.data.analysis?.analysis?.enhanced_analysis?.sovereignty_enhanced_ranking?.length > 0 && (
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">الترتيب المحسن سيادياً:</h5>
                  <div className="space-y-2">
                    {analysisMutation.data.analysis.analysis.enhanced_analysis.sovereignty_enhanced_ranking.slice(0, 5).map(([factor, value]: [string, number], index: number) => (
                      <div key={factor} className="flex items-center gap-2 text-sm">
                        <div className="flex items-center justify-center w-6 h-6 rounded-full bg-purple-500 text-white text-xs font-bold">
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          <span className="font-semibold">{factor}</span>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="w-24 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-purple-500 h-2 rounded-full" 
                                style={{ width: `${Math.min(100, (value / Math.max(...analysisMutation.data.analysis.analysis.enhanced_analysis.sovereignty_enhanced_ranking.map(([_, v]: [string, number]) => v))) * 100)}%` }}
                              ></div>
                            </div>
                            <span className="text-xs text-muted-foreground">{value.toFixed(3)}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Analysis Summary */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* Sovereignty Alignment */}
                {analysisMutation.data.analysis?.analysis?.sovereignty_alignment && (
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التوافق السيادي:</h5>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">المستوى:</span>
                        <Badge variant="default" className="text-xs">
                          {analysisMutation.data.analysis.analysis.sovereignty_alignment.level}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">النقاط:</span>
                        <div className="flex items-center gap-1">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-green-500 h-2 rounded-full" 
                              style={{ width: `${(analysisMutation.data.analysis.analysis.sovereignty_alignment.overall_score * 100)}%` }}
                            ></div>
                          </div>
                          <span className="text-xs">{((analysisMutation.data.analysis.analysis.sovereignty_alignment.overall_score || 0) * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      
                      <div>
                        <span className="font-semibold text-xs">التغطية:</span>
                        <span className="text-xs text-muted-foreground ml-1">
                          {analysisMutation.data.analysis.analysis.sovereignty_alignment.sovereignty_indicators} عامل سيادي من {analysisMutation.data.analysis.analysis.total_factors}
                        </span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Factor Distribution */}
                {analysisMutation.data.analysis?.analysis?.factor_distribution && (
                  <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                    <h5 className="font-semibold mb-2 text-sm font-kufi-modern">توزيع العوامل:</h5>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span>المتوسط:</span>
                        <span>{analysisMutation.data.analysis.analysis.factor_distribution.mean?.toFixed(3)}</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span>النطاق:</span>
                        <span>{analysisMutation.data.analysis.analysis.factor_distribution.range?.toFixed(3)}</span>
                      </div>
                      
                      <div className="flex justify-between">
                        <span>التوازن:</span>
                        <Badge variant="outline" className="text-xs">
                          {analysisMutation.data.analysis.analysis.factor_distribution.distribution_quality}
                        </Badge>
                      </div>
                      
                      <div className="flex justify-between">
                        <span>التركيز:</span>
                        <span>{analysisMutation.data.analysis.analysis.factor_distribution.concentration}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Risk and Opportunity Assessment */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* Risk Assessment */}
                {analysisMutation.data.analysis?.analysis?.risk_assessment && (
                  <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                    <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تقييم المخاطر:</h5>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">المستوى:</span>
                        <Badge variant={analysisMutation.data.analysis.analysis.risk_assessment.level === 'عالي' ? 'destructive' : 'secondary'} className="text-xs">
                          {analysisMutation.data.analysis.analysis.risk_assessment.level}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">النقاط:</span>
                        <div className="flex items-center gap-1">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-red-500 h-2 rounded-full" 
                              style={{ width: `${(analysisMutation.data.analysis.analysis.risk_assessment.score * 100)}%` }}
                            ></div>
                          </div>
                          <span className="text-xs">{((analysisMutation.data.analysis.analysis.risk_assessment.score || 0) * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      
                      {analysisMutation.data.analysis.analysis.risk_assessment.mitigation_needed && (
                        <div className="flex items-center gap-1 text-red-600">
                          <AlertTriangle className="w-3 h-3" />
                          <span className="text-xs">يحتاج تخفيف المخاطر</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Opportunity Evaluation */}
                {analysisMutation.data.analysis?.analysis?.opportunity_evaluation && (
                  <div className="p-3 bg-emerald-50 dark:bg-emerald-900/20 rounded-lg">
                    <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تقييم الفرص:</h5>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">المستوى:</span>
                        <Badge variant="default" className="text-xs">
                          {analysisMutation.data.analysis.analysis.opportunity_evaluation.level}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <span className="font-semibold">النقاط:</span>
                        <div className="flex items-center gap-1">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-emerald-500 h-2 rounded-full" 
                              style={{ width: `${(analysisMutation.data.analysis.analysis.opportunity_evaluation.score * 100)}%` }}
                            ></div>
                          </div>
                          <span className="text-xs">{((analysisMutation.data.analysis.analysis.opportunity_evaluation.score || 0) * 100).toFixed(0)}%</span>
                        </div>
                      </div>
                      
                      {analysisMutation.data.analysis.analysis.opportunity_evaluation.actionable && (
                        <div className="flex items-center gap-1 text-emerald-600">
                          <Target className="w-3 h-3" />
                          <span className="text-xs">فرص قابلة للتنفيذ</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Decision Recommendations */}
              {analysisMutation.data.analysis?.analysis?.decision_recommendations?.length > 0 && (
                <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">توصيات القرار:</h5>
                  <div className="space-y-1">
                    {analysisMutation.data.analysis.analysis.decision_recommendations.slice(0, 4).map((recommendation: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Lightbulb className="w-3 h-3 text-amber-500 mt-0.5 flex-shrink-0" />
                        <span>{recommendation}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Factor Insights */}
              {analysisMutation.data.analysis?.analysis?.factor_insights?.length > 0 && (
                <div className="p-3 bg-cyan-50 dark:bg-cyan-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">رؤى تحليلية:</h5>
                  <div className="space-y-1">
                    {analysisMutation.data.analysis.analysis.factor_insights.slice(0, 3).map((insight: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Eye className="w-3 h-3 text-cyan-500 mt-0.5 flex-shrink-0" />
                        <span>{insight}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Analysis Metadata */}
              {analysisMutation.data.analysis?.analysis?.metadata && (
                <div className="p-3 bg-gray-50 dark:bg-gray-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">معلومات التحليل:</h5>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex justify-between">
                      <span>العوامل المحللة:</span>
                      <span>{analysisMutation.data.analysis.analysis.total_factors}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>الوزن السيادي:</span>
                      <span>{analysisMutation.data.analysis.analysis.sovereignty_weight}</span>
                    </div>
                    
                    {analysisMutation.data.analysis.analysis.metadata.highest_factor && (
                      <div className="flex justify-between col-span-2">
                        <span>أعلى عامل:</span>
                        <span className="font-mono">{analysisMutation.data.analysis.analysis.metadata.highest_factor[0]} ({analysisMutation.data.analysis.analysis.metadata.highest_factor[1].toFixed(3)})</span>
                      </div>
                    )}
                    
                    <div className="flex justify-between col-span-2">
                      <span>المجموع المرجح:</span>
                      <span>{analysisMutation.data.analysis.analysis.weighted_sum?.toFixed(3)}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Will Encoding Interface Component
const WillEncodingInterface: React.FC = () => {
  const [values, setValues] = useState<string[]>([]);
  const [conflictZones, setConflictZones] = useState<string[]>([]);
  const [newValue, setNewValue] = useState('');
  const [newConflictZone, setNewConflictZone] = useState('');

  const willEncodingMutation = useMutation({
    mutationFn: async (data: { values: string[], conflict_zones: string[] }) => {
      const response = await fetch('/api/ai-neural/will/encode', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Will encoding failed');
      return response.json();
    }
  });

  // Predefined values and conflict zones for quick selection
  const predefinedValues = [
    'العدالة', 'الحرية', 'الكرامة', 'التقدم', 'الأمان', 'الشفافية', 
    'التميز', 'الوحدة', 'الابتكار', 'الاستقلالية', 'الرحمة', 'الصدق'
  ];

  const predefinedConflictZones = [
    'external_pressure', 'manipulation', 'control', 'influence', 
    'bias', 'misinformation', 'security_threat', 'discrimination',
    'corruption', 'forced_compliance', 'override', 'breach'
  ];

  const addValue = () => {
    if (newValue.trim() && !values.includes(newValue.trim())) {
      setValues(prev => [...prev, newValue.trim()]);
      setNewValue('');
    }
  };

  const addConflictZone = () => {
    if (newConflictZone.trim() && !conflictZones.includes(newConflictZone.trim())) {
      setConflictZones(prev => [...prev, newConflictZone.trim()]);
      setNewConflictZone('');
    }
  };

  const addPredefinedValue = (value: string) => {
    if (!values.includes(value)) {
      setValues(prev => [...prev, value]);
    }
  };

  const addPredefinedConflictZone = (zone: string) => {
    if (!conflictZones.includes(zone)) {
      setConflictZones(prev => [...prev, zone]);
    }
  };

  const removeValue = (value: string) => {
    setValues(prev => prev.filter(v => v !== value));
  };

  const removeConflictZone = (zone: string) => {
    setConflictZones(prev => prev.filter(z => z !== zone));
  };

  const handleEncodeWill = () => {
    if (values.length > 0 && conflictZones.length > 0) {
      willEncodingMutation.mutate({ values, conflict_zones: conflictZones });
    }
  };

  const clearAll = () => {
    setValues([]);
    setConflictZones([]);
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Shield className="w-6 h-6 text-secondary" />
          ترميز الإرادة السيادية
        </CardTitle>
        <CardDescription>
          ترميز القرارات السيادية بناءً على القيم ومناطق النزاع مع الحماية من الضغوط الخارجية
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Values Section */}
          <div className="space-y-3">
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">إضافة قيمة أساسية:</label>
              <div className="flex gap-2">
                <Input
                  placeholder="مثال: العدالة، الحرية، الكرامة"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  className="font-arabic"
                  onKeyPress={(e) => e.key === 'Enter' && addValue()}
                />
                <Button 
                  onClick={addValue}
                  size="sm"
                  disabled={!newValue.trim() || values.includes(newValue.trim())}
                  className="font-arabic"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">القيم المقترحة:</label>
              <div className="flex flex-wrap gap-1">
                {predefinedValues.map((value) => (
                  <Button
                    key={value}
                    onClick={() => addPredefinedValue(value)}
                    size="sm"
                    variant={values.includes(value) ? "default" : "outline"}
                    disabled={values.includes(value)}
                    className="text-xs font-arabic"
                  >
                    {value}
                  </Button>
                ))}
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold font-arabic">القيم المحددة ({values.length}):</label>
                {values.length > 0 && (
                  <Button onClick={() => setValues([])} size="sm" variant="outline" className="font-arabic">
                    <Trash2 className="w-4 h-4 mr-1" />
                    مسح القيم
                  </Button>
                )}
              </div>
              
              <div className="min-h-[120px] max-h-40 overflow-y-auto space-y-1 border rounded-lg p-2">
                {values.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground font-arabic">
                    لا توجد قيم محددة بعد
                  </div>
                ) : (
                  values.map((value) => (
                    <div key={value} className="flex items-center justify-between p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                      <span className="font-semibold text-sm font-arabic">{value}</span>
                      <Button 
                        onClick={() => removeValue(value)}
                        size="sm"
                        variant="ghost"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
          
          {/* Conflict Zones Section */}
          <div className="space-y-3">
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">إضافة منطقة نزاع:</label>
              <div className="flex gap-2">
                <Input
                  placeholder="مثال: external_pressure، manipulation"
                  value={newConflictZone}
                  onChange={(e) => setNewConflictZone(e.target.value)}
                  className="font-arabic"
                  onKeyPress={(e) => e.key === 'Enter' && addConflictZone()}
                />
                <Button 
                  onClick={addConflictZone}
                  size="sm"
                  disabled={!newConflictZone.trim() || conflictZones.includes(newConflictZone.trim())}
                  className="font-arabic"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">مناطق النزاع المقترحة:</label>
              <div className="flex flex-wrap gap-1">
                {predefinedConflictZones.map((zone) => (
                  <Button
                    key={zone}
                    onClick={() => addPredefinedConflictZone(zone)}
                    size="sm"
                    variant={conflictZones.includes(zone) ? "destructive" : "outline"}
                    disabled={conflictZones.includes(zone)}
                    className="text-xs"
                  >
                    {zone}
                  </Button>
                ))}
              </div>
            </div>
            
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-sm font-semibold font-arabic">مناطق النزاع المحددة ({conflictZones.length}):</label>
                {conflictZones.length > 0 && (
                  <Button onClick={() => setConflictZones([])} size="sm" variant="outline" className="font-arabic">
                    <Trash2 className="w-4 h-4 mr-1" />
                    مسح المناطق
                  </Button>
                )}
              </div>
              
              <div className="min-h-[120px] max-h-40 overflow-y-auto space-y-1 border rounded-lg p-2">
                {conflictZones.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground font-arabic">
                    لا توجد مناطق نزاع محددة بعد
                  </div>
                ) : (
                  conflictZones.map((zone) => (
                    <div key={zone} className="flex items-center justify-between p-2 bg-red-50 dark:bg-red-900/20 rounded">
                      <span className="font-semibold text-sm">{zone}</span>
                      <Button 
                        onClick={() => removeConflictZone(zone)}
                        size="sm"
                        variant="ghost"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleEncodeWill}
            disabled={willEncodingMutation.isPending || values.length === 0 || conflictZones.length === 0}
            className="flex-1 font-arabic"
          >
            {willEncodingMutation.isPending ? (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" />
                ترميز الإرادة جاري...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                ترميز الإرادة السيادية
              </div>
            )}
          </Button>
          
          {(values.length > 0 || conflictZones.length > 0) && (
            <Button onClick={clearAll} variant="outline" className="font-arabic">
              <Trash2 className="w-4 h-4 mr-1" />
              مسح الكل
            </Button>
          )}
        </div>

        {willEncodingMutation.data && (
          <div className="mt-4 p-4 bg-secondary/5 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern">نتائج ترميز الإرادة السيادية:</h4>
            
            <div className="grid grid-cols-1 gap-4">
              {/* Encoded Will */}
              <div className="p-4 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg border">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern flex items-center gap-2">
                  <Shield className="w-4 h-4 text-secondary" />
                  الإرادة المرمزة (محسنة):
                </h5>
                <div className="text-sm leading-relaxed font-arabic bg-white dark:bg-gray-800 p-3 rounded border">
                  {willEncodingMutation.data.will_encoding?.will_encoding?.encoded_will || 'غير متوفر'}
                </div>
                
                {willEncodingMutation.data.will_encoding?.will_encoding?.original_decision && (
                  <div className="mt-2">
                    <h6 className="text-xs font-semibold mb-1 font-kufi-modern">القرار الأساسي:</h6>
                    <div className="text-xs text-muted-foreground font-arabic bg-gray-50 dark:bg-gray-900 p-2 rounded">
                      {willEncodingMutation.data.will_encoding.will_encoding.original_decision}
                    </div>
                  </div>
                )}
              </div>

              {/* Decision Type and Analysis */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* Decision Type */}
                <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                  <div className="text-lg font-bold text-blue-600">
                    {willEncodingMutation.data.will_encoding?.will_encoding?.decision_type === 'sovereignty_protection' ? 'حماية السيادة' : 'توافق القيم'}
                  </div>
                  <div className="text-xs text-muted-foreground">نوع القرار</div>
                </div>

                {/* Confidence Metrics */}
                {willEncodingMutation.data.will_encoding?.will_encoding?.confidence_metrics && (
                  <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                    <div className="text-lg font-bold text-green-600">
                      {((willEncodingMutation.data.will_encoding.will_encoding.confidence_metrics.overall_confidence || 0) * 100).toFixed(0)}%
                    </div>
                    <div className="text-xs text-muted-foreground">مستوى الثقة</div>
                  </div>
                )}
              </div>

              {/* Sovereignty Risk Analysis */}
              {willEncodingMutation.data.will_encoding?.will_encoding?.sovereignty_risk_analysis && (
                <div className="p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل المخاطر السيادية:</h5>
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="flex justify-between">
                      <span>تقييم المخاطر:</span>
                      <Badge variant="outline" className="text-xs">
                        {willEncodingMutation.data.will_encoding.will_encoding.sovereignty_risk_analysis.risk_assessment}
                      </Badge>
                    </div>
                    
                    <div className="flex justify-between">
                      <span>نقاط المخاطر:</span>
                      <span>{((willEncodingMutation.data.will_encoding.will_encoding.sovereignty_risk_analysis.overall_risk_score || 0) * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Strategic Recommendations */}
              {willEncodingMutation.data.will_encoding?.will_encoding?.strategic_recommendations?.length > 0 && (
                <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                  <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التوصيات الاستراتيجية:</h5>
                  <div className="space-y-1">
                    {willEncodingMutation.data.will_encoding.will_encoding.strategic_recommendations.slice(0, 3).map((recommendation: string, index: number) => (
                      <div key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                        <Lightbulb className="w-3 h-3 text-yellow-500 mt-0.5 flex-shrink-0" />
                        <span>{recommendation}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Myth Building Interface Component
const MythBuildingInterface: React.FC = () => {
  const [heroName, setHeroName] = useState('');
  const [invention, setInvention] = useState('');

  const mythBuildingMutation = useMutation({
    mutationFn: async (data: { hero_name: string, invention: string }) => {
      const response = await fetch('/api/ai-neural/myth/build', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Myth building failed');
      return response.json();
    }
  });

  const handleBuildMyth = () => {
    if (heroName.trim() && invention.trim()) {
      mythBuildingMutation.mutate({ 
        hero_name: heroName.trim(), 
        invention: invention.trim() 
      });
    }
  };

  const clearForm = () => {
    setHeroName('');
    setInvention('');
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Crown className="w-6 h-6 text-secondary" />
          بناء الأساطير السعودية
        </CardTitle>
        <CardDescription>
          إنشاء قصص ملحمية عن الأبطال السعوديين وإنجازاتهم التقنية والحضارية
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-semibold font-arabic">اسم البطل السعودي:</label>
            <Input
              placeholder="مثال: محمد بن سلمان، الملك عبدالعزيز، فهد العتيبي"
              value={heroName}
              onChange={(e) => setHeroName(e.target.value)}
              className="font-arabic"
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-semibold font-arabic">الاختراع أو الإنجاز:</label>
            <Input
              placeholder="مثال: الذكاء الاصطناعي، نيوم، الطاقة المتجددة"
              value={invention}
              onChange={(e) => setInvention(e.target.value)}
              className="font-arabic"
            />
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleBuildMyth}
            disabled={mythBuildingMutation.isPending || !heroName.trim() || !invention.trim()}
            className="flex-1 font-arabic"
          >
            {mythBuildingMutation.isPending ? (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" />
                بناء الأسطورة جاري...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4" />
                بناء الأسطورة السعودية
              </div>
            )}
          </Button>
          
          {(heroName || invention) && (
            <Button onClick={clearForm} variant="outline" className="font-arabic">
              <Trash2 className="w-4 h-4 mr-1" />
              مسح
            </Button>
          )}
        </div>

        {mythBuildingMutation.data && (
          <div className="mt-4 p-4 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern flex items-center gap-2">
              <Crown className="w-5 h-5 text-secondary" />
              الأسطورة السعودية المولدة:
            </h4>
            
            {/* Main Myth Story */}
            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg border mb-4">
              <h5 className="font-semibold mb-2 text-lg font-kufi-modern text-center">
                {mythBuildingMutation.data.myth_building?.myth_story || 'غير متوفر'}
              </h5>
            </div>

            {/* Hero and Invention Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-blue-600 font-arabic">
                  {mythBuildingMutation.data.myth_building?.hero_name}
                </div>
                <div className="text-xs text-muted-foreground">البطل السعودي</div>
              </div>

              <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-green-600 font-arabic">
                  {mythBuildingMutation.data.myth_building?.invention}
                </div>
                <div className="text-xs text-muted-foreground">الإنجاز التقني</div>
              </div>
            </div>

            {/* Sovereignty Analysis */}
            {mythBuildingMutation.data.myth_building?.sovereignty_analysis && (
              <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل السيادة الثقافية:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {mythBuildingMutation.data.myth_building.sovereignty_analysis.decision_status_ar || 
                   mythBuildingMutation.data.myth_building.sovereignty_analysis.recommendation?.ar ||
                   'تم تحليل الأسطورة وفقاً لمبادئ السيادة الثقافية السعودية'}
                </div>
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs">نقاط السيادة:</span>
                  <Badge 
                    variant={mythBuildingMutation.data.myth_building.sovereignty_analysis.sovereignty_score >= 0.6 ? "default" : "secondary"} 
                    className="text-xs"
                  >
                    {((mythBuildingMutation.data.myth_building.sovereignty_analysis.sovereignty_score || 0) * 100).toFixed(0)}%
                  </Badge>
                </div>
              </div>
            )}

            {/* Cultural Enhancement */}
            {mythBuildingMutation.data.myth_building?.cultural_enhancement && (
              <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التعزيز الثقافي والهوية الوطنية:</h5>
                <div className="text-xs text-muted-foreground font-arabic leading-relaxed">
                  {mythBuildingMutation.data.myth_building.cultural_enhancement.reframed_identity?.ar || 
                   mythBuildingMutation.data.myth_building.cultural_enhancement.enhanced_identity?.ar ||
                   mythBuildingMutation.data.myth_building.cultural_enhancement.national_narrative?.ar ||
                   'تم تعزيز الأسطورة بالقيم الثقافية والهوية الوطنية السعودية'}
                </div>
                
                {/* Cultural Strength Indicator */}
                {mythBuildingMutation.data.myth_building.cultural_enhancement.cultural_strength && (
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-xs">قوة الهوية الثقافية:</span>
                    <Badge variant="outline" className="text-xs">
                      {((mythBuildingMutation.data.myth_building.cultural_enhancement.cultural_strength || 0) * 100).toFixed(0)}%
                    </Badge>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Sovereign Feed Streaming Interface Component
const SovereignFeedInterface: React.FC = () => {
  const [filterTags, setFilterTags] = useState<string[]>([]);
  const [newTag, setNewTag] = useState('');
  const [customDataSource, setCustomDataSource] = useState('');

  const sovereignFeedMutation = useMutation({
    mutationFn: async (data: { filter_tags: string[], data_source?: any[] }) => {
      const response = await fetch('/api/ai-neural/feed/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Sovereign feed streaming failed');
      return response.json();
    }
  });

  // Predefined tags for quick selection
  const predefinedTags = [
    'تقنية', 'ذكاء_اصطناعي', 'رؤية_2030', 'نيوم', 'ابتكار',
    'اقتصاد', 'طاقة', 'استدامة', 'تعليم', 'صحة', 'ترفيه',
    'أمن_سيبراني', 'ريادة', 'صناعة', 'ثقافة', 'سياحة', 'رقمنة'
  ];

  const addTag = () => {
    if (newTag.trim() && !filterTags.includes(newTag.trim())) {
      setFilterTags(prev => [...prev, newTag.trim()]);
      setNewTag('');
    }
  };

  const addPredefinedTag = (tag: string) => {
    if (!filterTags.includes(tag)) {
      setFilterTags(prev => [...prev, tag]);
    }
  };

  const removeTag = (tag: string) => {
    setFilterTags(prev => prev.filter(t => t !== tag));
  };

  const handleStreamFeed = () => {
    if (filterTags.length > 0) {
      let dataSource = [];
      
      // Parse custom data source if provided
      if (customDataSource.trim()) {
        try {
          dataSource = JSON.parse(customDataSource);
        } catch (error) {
          // If parsing fails, use empty array to trigger default data
          dataSource = [];
        }
      }
      
      sovereignFeedMutation.mutate({ 
        filter_tags: filterTags,
        data_source: dataSource
      });
    }
  };

  const clearAll = () => {
    setFilterTags([]);
    setCustomDataSource('');
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Activity className="w-6 h-6 text-secondary" />
          تدفق التغذية السيادية
        </CardTitle>
        <CardDescription>
          تصفية وتدفق المحتوى الوطني بناءً على العلامات السيادية والثقافية
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {/* Add Custom Tag */}
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">إضافة علامة تصفية:</label>
            <div className="flex gap-2">
              <Input
                placeholder="مثال: تقنية، ابتكار، رؤية_2030"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                className="font-arabic"
                onKeyPress={(e) => e.key === 'Enter' && addTag()}
              />
              <Button 
                onClick={addTag}
                size="sm"
                disabled={!newTag.trim() || filterTags.includes(newTag.trim())}
                className="font-arabic"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          {/* Predefined Tags */}
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">العلامات المقترحة:</label>
            <div className="flex flex-wrap gap-1">
              {predefinedTags.map((tag) => (
                <Button
                  key={tag}
                  onClick={() => addPredefinedTag(tag)}
                  size="sm"
                  variant={filterTags.includes(tag) ? "default" : "outline"}
                  disabled={filterTags.includes(tag)}
                  className="text-xs font-arabic"
                >
                  {tag}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Selected Tags */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold font-arabic">علامات التصفية المحددة ({filterTags.length}):</label>
              {filterTags.length > 0 && (
                <Button onClick={() => setFilterTags([])} size="sm" variant="outline" className="font-arabic">
                  <Trash2 className="w-4 h-4 mr-1" />
                  مسح العلامات
                </Button>
              )}
            </div>
            
            <div className="min-h-[100px] max-h-32 overflow-y-auto space-y-1 border rounded-lg p-2">
              {filterTags.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground font-arabic">
                  لا توجد علامات تصفية محددة بعد
                </div>
              ) : (
                filterTags.map((tag) => (
                  <div key={tag} className="flex items-center justify-between p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                    <span className="font-semibold text-sm font-arabic">{tag}</span>
                    <Button 
                      onClick={() => removeTag(tag)}
                      size="sm"
                      variant="ghost"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Custom Data Source */}
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">مصدر البيانات المخصص (اختياري):</label>
            <Textarea
              placeholder='[{"content": "محتوى مخصص", "tags": ["علامة1", "علامة2"]}]'
              value={customDataSource}
              onChange={(e) => setCustomDataSource(e.target.value)}
              className="font-technical text-sm"
              rows={3}
            />
            <p className="text-xs text-muted-foreground mt-1 font-arabic">
              اتركه فارغاً لاستخدام البيانات الافتراضية السعودية
            </p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleStreamFeed}
            disabled={sovereignFeedMutation.isPending || filterTags.length === 0}
            className="flex-1 font-arabic"
          >
            {sovereignFeedMutation.isPending ? (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" />
                تدفق التغذية جاري...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4" />
                بدء تدفق التغذية السيادية
              </div>
            )}
          </Button>
          
          {(filterTags.length > 0 || customDataSource) && (
            <Button onClick={clearAll} variant="outline" className="font-arabic">
              <Trash2 className="w-4 h-4 mr-1" />
              مسح الكل
            </Button>
          )}
        </div>

        {sovereignFeedMutation.data && (
          <div className="mt-4 p-4 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern flex items-center gap-2">
              <Activity className="w-5 h-5 text-secondary" />
              نتائج تدفق التغذية السيادية:
            </h4>
            
            {/* Feed Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-blue-600">
                  {sovereignFeedMutation.data.sovereign_feed?.total_items || 0}
                </div>
                <div className="text-xs text-muted-foreground">عناصر التغذية</div>
              </div>

              <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-green-600">
                  {sovereignFeedMutation.data.sovereign_feed?.filter_tags?.length || 0}
                </div>
                <div className="text-xs text-muted-foreground">علامات التصفية</div>
              </div>

              <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-purple-600">
                  {((sovereignFeedMutation.data.sovereign_feed?.feed_quality_score || 0) * 100).toFixed(0)}%
                </div>
                <div className="text-xs text-muted-foreground">جودة التصفية</div>
              </div>
            </div>

            {/* Streamed Feed Content */}
            {sovereignFeedMutation.data.sovereign_feed?.streamed_feed?.length > 0 && (
              <div className="p-3 bg-white dark:bg-gray-800 rounded-lg border mb-4">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">المحتوى المتدفق:</h5>
                <div className="max-h-40 overflow-y-auto space-y-1">
                  {sovereignFeedMutation.data.sovereign_feed.streamed_feed.map((item: string, index: number) => (
                    <div key={index} className="text-sm font-arabic p-2 bg-gray-50 dark:bg-gray-900 rounded">
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Sovereignty Analysis */}
            {sovereignFeedMutation.data.sovereign_feed?.sovereignty_analysis && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل السيادة:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {sovereignFeedMutation.data.sovereign_feed.sovereignty_analysis.decision_status_ar || 
                   sovereignFeedMutation.data.sovereign_feed.sovereignty_analysis.recommendation?.ar ||
                   'تم تحليل التغذية وفقاً لمبادئ السيادة الوطنية'}
                </div>
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs">نقاط السيادة:</span>
                  <Badge 
                    variant={sovereignFeedMutation.data.sovereign_feed.sovereignty_analysis.sovereignty_score >= 0.6 ? "default" : "secondary"} 
                    className="text-xs"
                  >
                    {((sovereignFeedMutation.data.sovereign_feed.sovereignty_analysis.sovereignty_score || 0) * 100).toFixed(0)}%
                  </Badge>
                </div>
              </div>
            )}

            {/* Cultural Analysis */}
            {sovereignFeedMutation.data.sovereign_feed?.cultural_analysis && (
              <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحليل الثقافي:</h5>
                <div className="text-xs text-muted-foreground font-arabic leading-relaxed">
                  {sovereignFeedMutation.data.sovereign_feed.cultural_analysis.reframed_identity?.ar || 
                   sovereignFeedMutation.data.sovereign_feed.cultural_analysis.enhanced_identity?.ar ||
                   sovereignFeedMutation.data.sovereign_feed.cultural_analysis.national_narrative?.ar ||
                   'تم تحليل المحتوى ثقافياً لضمان توافقه مع الهوية الوطنية'}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Live Summarization Interface Component
const LiveSummarizationInterface: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [identityTag, setIdentityTag] = useState('سعودي');

  const liveSummarizeMutation = useMutation({
    mutationFn: async (data: { text: string, identity_tag: string }) => {
      const response = await fetch('/api/ai-neural/summarize/live', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Live summarization failed');
      return response.json();
    }
  });

  // Predefined identity tags
  const identityTags = [
    'سعودي', 'عربي', 'إسلامي', 'خليجي', 'تقني', 'مبتكر', 'رائد', 'مستقل', 'حر', 'سيادي'
  ];

  const handleSummarize = () => {
    if (inputText.trim()) {
      liveSummarizeMutation.mutate({ 
        text: inputText.trim(), 
        identity_tag: identityTag 
      });
    }
  };

  const clearForm = () => {
    setInputText('');
    setIdentityTag('سعودي');
  };

  const getCompressionColor = (ratio: number) => {
    if (ratio <= 0.3) return 'text-green-600';
    if (ratio <= 0.6) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <FileText className="w-6 h-6 text-secondary" />
          التلخيص المباشر الذكي
        </CardTitle>
        <CardDescription>
          تلخيص فوري للنصوص مع علامة الهوية الوطنية باستخدام ذكاء التحويل المتقدم
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {/* Input Text */}
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">النص المراد تلخيصه:</label>
            <Textarea
              placeholder="أدخل النص الذي تريد تلخيصه... يمكن أن يكون مقالاً، تقريراً، أو أي محتوى نصي"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="font-arabic min-h-[120px]"
              rows={6}
            />
            <div className="flex justify-between items-center mt-1">
              <p className="text-xs text-muted-foreground font-arabic">
                أدخل النص للحصول على تلخيص ذكي مع الهوية الوطنية
              </p>
              <span className="text-xs text-muted-foreground">
                {inputText.length} حرف
              </span>
            </div>
          </div>
          
          {/* Identity Tag Selection */}
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">علامة الهوية:</label>
            <div className="flex flex-wrap gap-2">
              {identityTags.map((tag) => (
                <Button
                  key={tag}
                  onClick={() => setIdentityTag(tag)}
                  size="sm"
                  variant={identityTag === tag ? "default" : "outline"}
                  className="text-sm font-arabic"
                >
                  {tag}
                </Button>
              ))}
            </div>
            <Input
              placeholder="أو أدخل علامة هوية مخصصة"
              value={identityTag}
              onChange={(e) => setIdentityTag(e.target.value)}
              className="font-arabic mt-2"
            />
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleSummarize}
            disabled={liveSummarizeMutation.isPending || !inputText.trim()}
            className="flex-1 font-arabic"
          >
            {liveSummarizeMutation.isPending ? (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" />
                التلخيص جاري...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                تلخيص مباشر ذكي
              </div>
            )}
          </Button>
          
          {(inputText || identityTag !== 'سعودي') && (
            <Button onClick={clearForm} variant="outline" className="font-arabic">
              <Trash2 className="w-4 h-4 mr-1" />
              مسح
            </Button>
          )}
        </div>

        {liveSummarizeMutation.data && (
          <div className="mt-4 p-4 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern flex items-center gap-2">
              <FileText className="w-5 h-5 text-secondary" />
              نتائج التلخيص المباشر:
            </h4>
            
            {/* Live Summary */}
            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg border mb-4">
              <h5 className="font-semibold mb-2 text-sm font-kufi-modern">الملخص الذكي:</h5>
              <div className="text-base leading-relaxed font-arabic">
                {liveSummarizeMutation.data.live_summarization?.live_summary || 'غير متوفر'}
              </div>
            </div>

            {/* Statistics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-blue-600">
                  {liveSummarizeMutation.data.live_summarization?.text_length || 0}
                </div>
                <div className="text-xs text-muted-foreground">أحرف الأصل</div>
              </div>

              <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-green-600">
                  {liveSummarizeMutation.data.live_summarization?.summary_length || 0}
                </div>
                <div className="text-xs text-muted-foreground">أحرف الملخص</div>
              </div>

              <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                <div className={`text-lg font-bold ${getCompressionColor(liveSummarizeMutation.data.live_summarization?.compression_ratio || 0)}`}>
                  {((liveSummarizeMutation.data.live_summarization?.compression_ratio || 0) * 100).toFixed(0)}%
                </div>
                <div className="text-xs text-muted-foreground">نسبة الضغط</div>
              </div>

              <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-orange-600 font-arabic">
                  {liveSummarizeMutation.data.live_summarization?.identity_tag}
                </div>
                <div className="text-xs text-muted-foreground">علامة الهوية</div>
              </div>
            </div>

            {/* Fallback Warning */}
            {liveSummarizeMutation.data.live_summarization?.fallback_used && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg mb-4">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-yellow-600" />
                  <span className="text-sm font-semibold font-arabic">تنبيه:</span>
                </div>
                <p className="text-xs text-muted-foreground font-arabic mt-1">
                  تم استخدام النظام البديل لأن مكتبة Transformers غير متوفرة
                </p>
              </div>
            )}

            {/* Sovereignty Analysis */}
            {liveSummarizeMutation.data.live_summarization?.sovereignty_analysis && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل السيادة:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {liveSummarizeMutation.data.live_summarization.sovereignty_analysis.decision_status_ar || 
                   liveSummarizeMutation.data.live_summarization.sovereignty_analysis.recommendation?.ar ||
                   'تم تحليل الملخص وفقاً لمبادئ السيادة الوطنية'}
                </div>
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs">نقاط السيادة:</span>
                  <Badge 
                    variant={liveSummarizeMutation.data.live_summarization.sovereignty_analysis.sovereignty_score >= 0.6 ? "default" : "secondary"} 
                    className="text-xs"
                  >
                    {((liveSummarizeMutation.data.live_summarization.sovereignty_analysis.sovereignty_score || 0) * 100).toFixed(0)}%
                  </Badge>
                </div>
              </div>
            )}

            {/* Emotion Analysis */}
            {liveSummarizeMutation.data.live_summarization?.emotion_analysis && (
              <div className="p-3 bg-pink-50 dark:bg-pink-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل المشاعر:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {liveSummarizeMutation.data.live_summarization.emotion_analysis.arabic_interpretation ||
                   'تم تحليل المشاعر والهوية العاطفية للملخص'}
                </div>
                
                {liveSummarizeMutation.data.live_summarization.emotion_analysis.dominant_emotion && (
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-xs">المشاعر السائدة:</span>
                    <Badge variant="outline" className="text-xs">
                      {liveSummarizeMutation.data.live_summarization.emotion_analysis.dominant_emotion[0]} 
                      ({(liveSummarizeMutation.data.live_summarization.emotion_analysis.dominant_emotion[1] * 100).toFixed(0)}%)
                    </Badge>
                  </div>
                )}
              </div>
            )}

            {/* Cultural Analysis */}
            {liveSummarizeMutation.data.live_summarization?.cultural_analysis && (
              <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحليل الثقافي:</h5>
                <div className="text-xs text-muted-foreground font-arabic leading-relaxed">
                  {liveSummarizeMutation.data.live_summarization.cultural_analysis.reframed_identity?.ar || 
                   liveSummarizeMutation.data.live_summarization.cultural_analysis.enhanced_identity?.ar ||
                   liveSummarizeMutation.data.live_summarization.cultural_analysis.national_narrative?.ar ||
                   'تم تحليل الملخص ثقافياً لضمان توافقه مع الهوية الوطنية'}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Auto Evolution Interface Component
const AutoEvolutionInterface: React.FC = () => {
  const [modelState, setModelState] = useState({
    progress: 0,
    architecture: "SovereignTransformer",
    core_insights: ["Initial Sovereignty Framework", "Arabic-First Processing"]
  });
  const [milestones, setMilestones] = useState({
    next_level: 100,
    evolution_threshold: 85,
    architecture_upgrade: 150
  });

  const autoEvolveMutation = useMutation({
    mutationFn: async (data: { model_state: any, milestones: any }) => {
      const response = await fetch('/api/ai-neural/evolution/auto', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Auto evolution failed');
      return response.json();
    }
  });

  const handleAutoEvolve = () => {
    autoEvolveMutation.mutate({ 
      model_state: modelState, 
      milestones: milestones 
    });
  };

  const resetToDefaults = () => {
    setModelState({
      progress: 0,
      architecture: "SovereignTransformer",
      core_insights: ["Initial Sovereignty Framework", "Arabic-First Processing"]
    });
    setMilestones({
      next_level: 100,
      evolution_threshold: 85,
      architecture_upgrade: 150
    });
  };

  const simulateProgress = () => {
    setModelState(prev => ({
      ...prev,
      progress: Math.min(prev.progress + Math.floor(Math.random() * 20) + 10, 200)
    }));
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-secondary" />
          التطور التلقائي للنموذج
        </CardTitle>
        <CardDescription>
          تطوير النموذج تلقائياً بناءً على التقدم والمعالم المحددة مع تفعيل مبادئ السيادة الجديدة
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Model State Configuration */}
          <div className="space-y-3">
            <h4 className="font-semibold text-sm font-kufi-modern">حالة النموذج الحالية:</h4>
            
            <div className="space-y-2">
              <label className="text-xs font-semibold font-arabic">مستوى التقدم:</label>
              <div className="flex gap-2">
                <Input
                  type="number"
                  min="0"
                  max="200"
                  value={modelState.progress}
                  onChange={(e) => setModelState(prev => ({...prev, progress: parseInt(e.target.value) || 0}))}
                  className="font-technical"
                />
                <Button onClick={simulateProgress} size="sm" variant="outline">
                  محاكاة تقدم
                </Button>
              </div>
              <Progress value={Math.min((modelState.progress / 200) * 100, 100)} className="h-2" />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold font-arabic">معمارية النموذج:</label>
              <Input
                value={modelState.architecture}
                onChange={(e) => setModelState(prev => ({...prev, architecture: e.target.value}))}
                className="font-technical"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold font-arabic">الرؤى الأساسية ({modelState.core_insights.length}):</label>
              <div className="max-h-32 overflow-y-auto space-y-1 border rounded p-2">
                {modelState.core_insights.map((insight, index) => (
                  <div key={index} className="text-xs p-2 bg-blue-50 dark:bg-blue-900/20 rounded font-arabic">
                    {insight}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Milestones Configuration */}
          <div className="space-y-3">
            <h4 className="font-semibold text-sm font-kufi-modern">معالم التطور:</h4>
            
            <div className="space-y-2">
              <label className="text-xs font-semibold font-arabic">المستوى التالي:</label>
              <Input
                type="number"
                min="1"
                value={milestones.next_level}
                onChange={(e) => setMilestones(prev => ({...prev, next_level: parseInt(e.target.value) || 100}))}
                className="font-technical"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold font-arabic">عتبة التطور:</label>
              <Input
                type="number"
                min="1"
                value={milestones.evolution_threshold}
                onChange={(e) => setMilestones(prev => ({...prev, evolution_threshold: parseInt(e.target.value) || 85}))}
                className="font-technical"
              />
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold font-arabic">ترقية المعمارية:</label>
              <Input
                type="number"
                min="1"
                value={milestones.architecture_upgrade}
                onChange={(e) => setMilestones(prev => ({...prev, architecture_upgrade: parseInt(e.target.value) || 150}))}
                className="font-technical"
              />
            </div>

            {/* Evolution Prediction */}
            <div className="p-3 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded border">
              <div className="text-xs font-semibold mb-1 font-arabic">توقع التطور:</div>
              <div className="text-xs text-muted-foreground">
                {modelState.progress >= milestones.next_level ? 
                  "✅ سيتم تفعيل التطور - مبدأ سيادي جديد!" : 
                  `⏳ يحتاج ${milestones.next_level - modelState.progress} نقطة للتطور`}
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleAutoEvolve}
            disabled={autoEvolveMutation.isPending}
            className="flex-1 font-arabic"
          >
            {autoEvolveMutation.isPending ? (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" />
                تشغيل التطور التلقائي...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4" />
                تشغيل التطور التلقائي
              </div>
            )}
          </Button>
          
          <Button onClick={resetToDefaults} variant="outline" className="font-arabic">
            <RefreshCw className="w-4 h-4 mr-1" />
            إعادة تعيين
          </Button>
        </div>

        {autoEvolveMutation.data && (
          <div className="mt-4 p-4 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-secondary" />
              نتائج التطور التلقائي:
            </h4>
            
            {/* Evolution Status */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-4">
              <div className="p-3 bg-white dark:bg-gray-800 rounded-lg text-center">
                <div className={`text-lg font-bold ${autoEvolveMutation.data.auto_evolution?.evolution_triggered ? 'text-green-600' : 'text-yellow-600'}`}>
                  {autoEvolveMutation.data.auto_evolution?.evolution_triggered ? '✅ مفعل' : '⏳ معلق'}
                </div>
                <div className="text-xs text-muted-foreground">حالة التطور</div>
              </div>

              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-blue-600">
                  {autoEvolveMutation.data.auto_evolution?.new_insights_count || 0}
                </div>
                <div className="text-xs text-muted-foreground">رؤى جديدة</div>
              </div>

              <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-purple-600">
                  {autoEvolveMutation.data.auto_evolution?.evolved_state?.progress || 0}
                </div>
                <div className="text-xs text-muted-foreground">مستوى التقدم</div>
              </div>
            </div>

            {/* Architecture Enhancement */}
            {autoEvolveMutation.data.auto_evolution?.architecture_enhancement && (
              <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تطور المعمارية:</h5>
                <div className="text-sm font-technical">
                  {autoEvolveMutation.data.auto_evolution.evolved_state.architecture}
                </div>
              </div>
            )}

            {/* Core Insights */}
            {autoEvolveMutation.data.auto_evolution?.evolved_state?.core_insights && (
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">الرؤى الأساسية المحدثة:</h5>
                <div className="max-h-32 overflow-y-auto space-y-1">
                  {autoEvolveMutation.data.auto_evolution.evolved_state.core_insights.map((insight: string, index: number) => (
                    <div key={index} className="text-xs p-2 bg-white dark:bg-gray-800 rounded font-arabic">
                      {insight}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Sovereignty Analysis */}
            {autoEvolveMutation.data.auto_evolution?.sovereignty_analysis && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل السيادة:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {autoEvolveMutation.data.auto_evolution.sovereignty_analysis.decision_status_ar || 
                   autoEvolveMutation.data.auto_evolution.sovereignty_analysis.recommendation?.ar ||
                   'تم تحليل التطور وفقاً لمبادئ السيادة التقنية'}
                </div>
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs">نقاط السيادة:</span>
                  <Badge 
                    variant={autoEvolveMutation.data.auto_evolution.sovereignty_analysis.sovereignty_score >= 0.6 ? "default" : "secondary"} 
                    className="text-xs"
                  >
                    {((autoEvolveMutation.data.auto_evolution.sovereignty_analysis.sovereignty_score || 0) * 100).toFixed(0)}%
                  </Badge>
                </div>
              </div>
            )}

            {/* Cultural Analysis */}
            {autoEvolveMutation.data.auto_evolution?.cultural_analysis && (
              <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحليل الثقافي:</h5>
                <div className="text-xs text-muted-foreground font-arabic leading-relaxed">
                  {autoEvolveMutation.data.auto_evolution.cultural_analysis.reframed_identity?.ar || 
                   autoEvolveMutation.data.auto_evolution.cultural_analysis.enhanced_identity?.ar ||
                   autoEvolveMutation.data.auto_evolution.cultural_analysis.national_narrative?.ar ||
                   'تم تحليل التطور ثقافياً لضمان توافقه مع الهوية الوطنية'}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Forecast Input Interface Component
const ForecastInputInterface: React.FC = () => {
  const [trendData, setTrendData] = useState({
    year: 2024,
    sector: "تقنية",
    growth_rate: 15,
    indicators: ["ذكاء اصطناعي", "رقمنة", "ابتكار"]
  });
  const [nationalAmbition, setNationalAmbition] = useState({
    next_domain: "الذكاء الاصطناعي السيادي",
    priority_level: "عالي",
    timeline: "2030",
    strategic_goals: ["الريادة التقنية", "الاستقلال الرقمي", "الابتكار الوطني"]
  });

  const forecastInputMutation = useMutation({
    mutationFn: async (data: { trend_data: any, national_ambition: any }) => {
      const response = await fetch('/api/ai-neural/forecast/input', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Forecast input failed');
      return response.json();
    }
  });

  // Predefined sectors and domains
  const sectors = ["تقنية", "طاقة", "صحة", "تعليم", "اقتصاد", "ثقافة", "دفاع", "بيئة"];
  const domains = [
    "الذكاء الاصطناعي السيادي", "الطاقة المتجددة", "التقنيات الحيوية", 
    "الفضاء والاستكشاف", "المدن الذكية", "الأمن السيبراني", 
    "التصنيع المتقدم", "السياحة الرقمية"
  ];
  const priorities = ["عالي", "متوسط", "منخفض"];

  const handleForecast = () => {
    forecastInputMutation.mutate({ 
      trend_data: trendData, 
      national_ambition: nationalAmbition 
    });
  };

  const resetToDefaults = () => {
    setTrendData({
      year: 2024,
      sector: "تقنية",
      growth_rate: 15,
      indicators: ["ذكاء اصطناعي", "رقمنة", "ابتكار"]
    });
    setNationalAmbition({
      next_domain: "الذكاء الاصطناعي السيادي",
      priority_level: "عالي",
      timeline: "2030",
      strategic_goals: ["الريادة التقنية", "الاستقلال الرقمي", "الابتكار الوطني"]
    });
  };

  const addIndicator = (indicator: string) => {
    if (indicator.trim() && !trendData.indicators.includes(indicator.trim())) {
      setTrendData(prev => ({
        ...prev,
        indicators: [...prev.indicators, indicator.trim()]
      }));
    }
  };

  const removeIndicator = (indicator: string) => {
    setTrendData(prev => ({
      ...prev,
      indicators: prev.indicators.filter(i => i !== indicator)
    }));
  };

  const addStrategicGoal = (goal: string) => {
    if (goal.trim() && !nationalAmbition.strategic_goals.includes(goal.trim())) {
      setNationalAmbition(prev => ({
        ...prev,
        strategic_goals: [...prev.strategic_goals, goal.trim()]
      }));
    }
  };

  const removeStrategicGoal = (goal: string) => {
    setNationalAmbition(prev => ({
      ...prev,
      strategic_goals: prev.strategic_goals.filter(g => g !== goal)
    }));
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Target className="w-6 h-6 text-secondary" />
          التنبؤ الذكي للمدخلات
        </CardTitle>
        <CardDescription>
          تحليل الاتجاهات والتنبؤ بالمتطلبات المستقبلية بناءً على الطموحات الوطنية
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* Trend Data Configuration */}
          <div className="space-y-3">
            <h4 className="font-semibold text-sm font-kufi-modern">بيانات الاتجاه:</h4>
            
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-semibold font-arabic">السنة الحالية:</label>
                <Input
                  type="number"
                  min="2020"
                  max="2050"
                  value={trendData.year}
                  onChange={(e) => setTrendData(prev => ({...prev, year: parseInt(e.target.value) || 2024}))}
                  className="font-technical"
                />
              </div>
              <div>
                <label className="text-xs font-semibold font-arabic">معدل النمو (%):</label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  value={trendData.growth_rate}
                  onChange={(e) => setTrendData(prev => ({...prev, growth_rate: parseInt(e.target.value) || 0}))}
                  className="font-technical"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold font-arabic">القطاع:</label>
              <Select value={trendData.sector} onValueChange={(value) => setTrendData(prev => ({...prev, sector: value}))}>
                <SelectTrigger className="font-arabic">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {sectors.map((sector) => (
                    <SelectItem key={sector} value={sector} className="font-arabic">
                      {sector}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-xs font-semibold font-arabic">المؤشرات ({trendData.indicators.length}):</label>
              <div className="max-h-32 overflow-y-auto space-y-1 border rounded p-2">
                {trendData.indicators.map((indicator, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                    <span className="text-xs font-arabic">{indicator}</span>
                    <Button 
                      onClick={() => removeIndicator(indicator)}
                      size="sm"
                      variant="ghost"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* National Ambition Configuration */}
          <div className="space-y-3">
            <h4 className="font-semibold text-sm font-kufi-modern">الطموح الوطني:</h4>
            
            <div>
              <label className="text-xs font-semibold font-arabic">المجال التالي:</label>
              <Select value={nationalAmbition.next_domain} onValueChange={(value) => setNationalAmbition(prev => ({...prev, next_domain: value}))}>
                <SelectTrigger className="font-arabic">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {domains.map((domain) => (
                    <SelectItem key={domain} value={domain} className="font-arabic">
                      {domain}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-semibold font-arabic">مستوى الأولوية:</label>
                <Select value={nationalAmbition.priority_level} onValueChange={(value) => setNationalAmbition(prev => ({...prev, priority_level: value}))}>
                  <SelectTrigger className="font-arabic">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {priorities.map((priority) => (
                      <SelectItem key={priority} value={priority} className="font-arabic">
                        {priority}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs font-semibold font-arabic">الإطار الزمني:</label>
                <Input
                  value={nationalAmbition.timeline}
                  onChange={(e) => setNationalAmbition(prev => ({...prev, timeline: e.target.value}))}
                  className="font-technical"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold font-arabic">الأهداف الاستراتيجية ({nationalAmbition.strategic_goals.length}):</label>
              <div className="max-h-32 overflow-y-auto space-y-1 border rounded p-2">
                {nationalAmbition.strategic_goals.map((goal, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-green-50 dark:bg-green-900/20 rounded">
                    <span className="text-xs font-arabic">{goal}</span>
                    <Button 
                      onClick={() => removeStrategicGoal(goal)}
                      size="sm"
                      variant="ghost"
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            {/* Forecast Preview */}
            <div className="p-3 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded border">
              <div className="text-xs font-semibold mb-1 font-arabic">معاينة التنبؤ:</div>
              <div className="text-xs text-muted-foreground font-arabic">
                🔮 عام {trendData.year + 5} سيتطلب تكيفًا ذكيًا نحو {nationalAmbition.next_domain}
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleForecast}
            disabled={forecastInputMutation.isPending}
            className="flex-1 font-arabic"
          >
            {forecastInputMutation.isPending ? (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" />
                تشغيل التنبؤ الذكي...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Target className="w-4 h-4" />
                تشغيل التنبؤ الذكي
              </div>
            )}
          </Button>
          
          <Button onClick={resetToDefaults} variant="outline" className="font-arabic">
            <RefreshCw className="w-4 h-4 mr-1" />
            إعادة تعيين
          </Button>
        </div>

        {forecastInputMutation.data && (
          <div className="mt-4 p-4 bg-gradient-to-r from-indigo-50 to-cyan-50 dark:from-indigo-900/20 dark:to-cyan-900/20 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern flex items-center gap-2">
              <Target className="w-5 h-5 text-secondary" />
              نتائج التنبؤ الذكي:
            </h4>
            
            {/* Main Forecast Result */}
            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg border mb-4">
              <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التنبؤ الرئيسي:</h5>
              <div className="text-lg font-arabic leading-relaxed">
                {forecastInputMutation.data.forecast_input?.forecast_result || 'غير متوفر'}
              </div>
            </div>

            {/* Forecast Statistics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-blue-600">
                  {forecastInputMutation.data.forecast_input?.forecast_year || 2029}
                </div>
                <div className="text-xs text-muted-foreground">سنة التنبؤ</div>
              </div>

              <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-green-600">
                  {forecastInputMutation.data.forecast_input?.trend_data?.growth_rate || 0}%
                </div>
                <div className="text-xs text-muted-foreground">معدل النمو</div>
              </div>

              <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                <div className="text-sm font-bold text-purple-600 font-arabic">
                  {forecastInputMutation.data.forecast_input?.national_ambition?.priority_level || 'عالي'}
                </div>
                <div className="text-xs text-muted-foreground">مستوى الأولوية</div>
              </div>

              <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg text-center">
                <div className="text-sm font-bold text-orange-600 font-arabic">
                  {forecastInputMutation.data.forecast_input?.trend_data?.sector || 'تقنية'}
                </div>
                <div className="text-xs text-muted-foreground">القطاع</div>
              </div>
            </div>

            {/* Behavioral Forecast */}
            {forecastInputMutation.data.forecast_input?.behavioral_forecast && (
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التنبؤ السلوكي:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {forecastInputMutation.data.forecast_input.behavioral_forecast.predicted_patterns?.ar ||
                   forecastInputMutation.data.forecast_input.behavioral_forecast.trajectory_analysis?.ar ||
                   'تم تحليل المسار السلوكي للتوجه الوطني'}
                </div>
              </div>
            )}

            {/* Future Scenario */}
            {forecastInputMutation.data.forecast_input?.future_scenario && (
              <div className="p-3 bg-cyan-50 dark:bg-cyan-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">السيناريو المستقبلي:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {forecastInputMutation.data.forecast_input.future_scenario.scenario_description?.ar ||
                   forecastInputMutation.data.forecast_input.future_scenario.key_developments?.ar ||
                   'تم محاكاة السيناريو المستقبلي للمملكة'}
                </div>
              </div>
            )}

            {/* Sovereignty Analysis */}
            {forecastInputMutation.data.forecast_input?.sovereignty_analysis && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل السيادة:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {forecastInputMutation.data.forecast_input.sovereignty_analysis.decision_status_ar || 
                   forecastInputMutation.data.forecast_input.sovereignty_analysis.recommendation?.ar ||
                   'تم تحليل التنبؤ وفقاً لمبادئ السيادة الوطنية'}
                </div>
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs">نقاط السيادة:</span>
                  <Badge 
                    variant={forecastInputMutation.data.forecast_input.sovereignty_analysis.sovereignty_score >= 0.6 ? "default" : "secondary"} 
                    className="text-xs"
                  >
                    {((forecastInputMutation.data.forecast_input.sovereignty_analysis.sovereignty_score || 0) * 100).toFixed(0)}%
                  </Badge>
                </div>
              </div>
            )}

            {/* Cultural Analysis */}
            {forecastInputMutation.data.forecast_input?.cultural_analysis && (
              <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحليل الثقافي:</h5>
                <div className="text-xs text-muted-foreground font-arabic leading-relaxed">
                  {forecastInputMutation.data.forecast_input.cultural_analysis.reframed_identity?.ar || 
                   forecastInputMutation.data.forecast_input.cultural_analysis.enhanced_identity?.ar ||
                   forecastInputMutation.data.forecast_input.cultural_analysis.national_narrative?.ar ||
                   'تم تحليل التنبؤ ثقافياً لضمان توافقه مع الهوية الوطنية'}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Glory Injection Interface Component
const GloryInjectionInterface: React.FC = () => {
  const [message, setMessage] = useState('');
  const [vision, setVision] = useState('رؤية 2030');

  const gloryInjectionMutation = useMutation({
    mutationFn: async (data: { message: string, vision: string }) => {
      const response = await fetch('/api/ai-neural/glory/inject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Glory injection failed');
      return response.json();
    }
  });

  // Predefined visions and glory contexts
  const visions = [
    "رؤية 2030", "نيوم المستقبل", "القدية الترفيهية", "المملكة الرقمية",
    "الطاقة المتجددة", "الذكاء الاصطناعي السعودي", "الريادة التقنية",
    "الاستقلال الرقمي", "الابتكار الوطني", "التحول الرقمي"
  ];

  const sampleMessages = [
    "تطوير منصة الذكاء الاصطناعي الوطنية",
    "إطلاق مشروع المدن الذكية",
    "تأسيس مراكز الابتكار التقني",
    "بناء البنية التحتية الرقمية",
    "تطوير الكوادر الوطنية في التقنية",
    "إنشاء منصات التعليم الرقمي"
  ];

  const handleGloryInject = () => {
    if (message.trim()) {
      gloryInjectionMutation.mutate({ 
        message: message.trim(), 
        vision: vision 
      });
    }
  };

  const clearForm = () => {
    setMessage('');
    setVision('رؤية 2030');
  };

  const useSampleMessage = (sample: string) => {
    setMessage(sample);
  };

  const getEnhancementColor = (ratio: number) => {
    if (ratio >= 2) return 'text-green-600';
    if (ratio >= 1.5) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Crown className="w-6 h-6 text-secondary" />
          حقن المجد الوطني
        </CardTitle>
        <CardDescription>
          تعزيز الرسائل بعبارات المجد والفخر الوطني مع ربطها برؤية المملكة المستقبلية
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {/* Message Input */}
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">الرسالة الأصلية:</label>
            <Textarea
              placeholder="أدخل الرسالة التي تريد تعزيزها بالمجد الوطني..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="font-arabic min-h-[100px]"
              rows={4}
            />
            <div className="flex justify-between items-center mt-1">
              <p className="text-xs text-muted-foreground font-arabic">
                أدخل رسالة لتعزيزها بالفخر والمجد الوطني
              </p>
              <span className="text-xs text-muted-foreground">
                {message.length} حرف
              </span>
            </div>
          </div>
          
          {/* Sample Messages */}
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">رسائل مقترحة:</label>
            <div className="flex flex-wrap gap-1">
              {sampleMessages.map((sample, index) => (
                <Button
                  key={index}
                  onClick={() => useSampleMessage(sample)}
                  size="sm"
                  variant="outline"
                  className="text-xs font-arabic"
                >
                  {sample}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Vision Selection */}
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">الرؤية أو السياق:</label>
            <div className="flex flex-wrap gap-2">
              {visions.map((visionOption) => (
                <Button
                  key={visionOption}
                  onClick={() => setVision(visionOption)}
                  size="sm"
                  variant={vision === visionOption ? "default" : "outline"}
                  className="text-sm font-arabic"
                >
                  {visionOption}
                </Button>
              ))}
            </div>
            <Input
              placeholder="أو أدخل رؤية مخصصة"
              value={vision}
              onChange={(e) => setVision(e.target.value)}
              className="font-arabic mt-2"
            />
          </div>

          {/* Preview */}
          {message && vision && (
            <div className="p-3 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 rounded border">
              <div className="text-xs font-semibold mb-1 font-arabic">معاينة حقن المجد:</div>
              <div className="text-sm font-arabic leading-relaxed">
                ⚔️ من أجل {vision}، هذه التغذية ستدفع النموذج نحو المجد: {message}
              </div>
            </div>
          )}
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleGloryInject}
            disabled={gloryInjectionMutation.isPending || !message.trim()}
            className="flex-1 font-arabic"
          >
            {gloryInjectionMutation.isPending ? (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" />
                حقن المجد جاري...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Crown className="w-4 h-4" />
                حقن المجد الوطني
              </div>
            )}
          </Button>
          
          {(message || vision !== 'رؤية 2030') && (
            <Button onClick={clearForm} variant="outline" className="font-arabic">
              <Trash2 className="w-4 h-4 mr-1" />
              مسح
            </Button>
          )}
        </div>

        {gloryInjectionMutation.data && (
          <div className="mt-4 p-4 bg-gradient-to-r from-yellow-50 to-amber-50 dark:from-yellow-900/20 dark:to-amber-900/20 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern flex items-center gap-2">
              <Crown className="w-5 h-5 text-secondary" />
              نتائج حقن المجد:
            </h4>
            
            {/* Glorified Message */}
            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg border mb-4">
              <h5 className="font-semibold mb-2 text-sm font-kufi-modern">الرسالة المُمجدة:</h5>
              <div className="text-base leading-relaxed font-arabic">
                {gloryInjectionMutation.data.glory_injection?.glorified_message || 'غير متوفر'}
              </div>
            </div>

            {/* Statistics */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-blue-600">
                  {gloryInjectionMutation.data.glory_injection?.original_message?.length || 0}
                </div>
                <div className="text-xs text-muted-foreground">أحرف الأصل</div>
              </div>

              <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-green-600">
                  {gloryInjectionMutation.data.glory_injection?.glorified_message?.length || 0}
                </div>
                <div className="text-xs text-muted-foreground">أحرف النهائي</div>
              </div>

              <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                <div className={`text-lg font-bold ${getEnhancementColor(gloryInjectionMutation.data.glory_injection?.message_enhancement_ratio || 0)}`}>
                  {((gloryInjectionMutation.data.glory_injection?.message_enhancement_ratio || 0) * 100).toFixed(0)}%
                </div>
                <div className="text-xs text-muted-foreground">نسبة التعزيز</div>
              </div>
            </div>

            {/* Glory Statements */}
            {gloryInjectionMutation.data.glory_injection?.glory_statements && (
              <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">عبارات المجد:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {gloryInjectionMutation.data.glory_injection.glory_statements.glory_text?.ar ||
                   gloryInjectionMutation.data.glory_injection.glory_statements.statement?.ar ||
                   'تم توليد عبارات المجد والفخر الوطني'}
                </div>
              </div>
            )}

            {/* Emotion Analysis */}
            {gloryInjectionMutation.data.glory_injection?.emotion_analysis && (
              <div className="p-3 bg-pink-50 dark:bg-pink-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل المشاعر:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {gloryInjectionMutation.data.glory_injection.emotion_analysis.arabic_interpretation ||
                   'تم تحليل المشاعر الوطنية والهوية العاطفية'}
                </div>
                
                {gloryInjectionMutation.data.glory_injection.emotion_analysis.dominant_emotion && (
                  <div className="flex justify-between items-center mt-2">
                    <span className="text-xs">المشاعر السائدة:</span>
                    <Badge variant="outline" className="text-xs">
                      {gloryInjectionMutation.data.glory_injection.emotion_analysis.dominant_emotion[0]} 
                      ({(gloryInjectionMutation.data.glory_injection.emotion_analysis.dominant_emotion[1] * 100).toFixed(0)}%)
                    </Badge>
                  </div>
                )}
              </div>
            )}

            {/* Sovereignty Analysis */}
            {gloryInjectionMutation.data.glory_injection?.sovereignty_analysis && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل السيادة:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {gloryInjectionMutation.data.glory_injection.sovereignty_analysis.decision_status_ar || 
                   gloryInjectionMutation.data.glory_injection.sovereignty_analysis.recommendation?.ar ||
                   'تم تحليل حقن المجد وفقاً لمبادئ السيادة الوطنية'}
                </div>
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs">نقاط السيادة:</span>
                  <Badge 
                    variant={gloryInjectionMutation.data.glory_injection.sovereignty_analysis.sovereignty_score >= 0.6 ? "default" : "secondary"} 
                    className="text-xs"
                  >
                    {((gloryInjectionMutation.data.glory_injection.sovereignty_analysis.sovereignty_score || 0) * 100).toFixed(0)}%
                  </Badge>
                </div>
              </div>
            )}

            {/* Cultural Analysis */}
            {gloryInjectionMutation.data.glory_injection?.cultural_analysis && (
              <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحليل الثقافي:</h5>
                <div className="text-xs text-muted-foreground font-arabic leading-relaxed">
                  {gloryInjectionMutation.data.glory_injection.cultural_analysis.reframed_identity?.ar || 
                   gloryInjectionMutation.data.glory_injection.cultural_analysis.enhanced_identity?.ar ||
                   gloryInjectionMutation.data.glory_injection.cultural_analysis.national_narrative?.ar ||
                   'تم تحليل المجد ثقافياً لضمان توافقه مع الهوية الوطنية'}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Rakan Shield Interface Component
const RakanShieldInterface: React.FC = () => {
  const [codeBlock, setCodeBlock] = useState('');
  const [identity, setIdentity] = useState('Rakan🔥');
  const [seedPhrase, setSeedPhrase] = useState('سوط الحارق');

  const rakanShieldMutation = useMutation({
    mutationFn: async (data: { code_block: string, identity: string, seed_phrase: string }) => {
      const response = await fetch('/api/ai-neural/shield/protect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (!response.ok) throw new Error('Rakan Shield protection failed');
      return response.json();
    }
  });

  // Predefined identities and seed phrases
  const identities = ["Rakan🔥", "SovereignAI🛡️", "NationalGuard🇸🇦", "DigitalFalcon🦅", "CyberShield⚔️"];
  const seedPhrases = ["سوط الحارق", "درع السيادة", "حارس الوطن", "نار الحماية", "سيف العدالة"];

  const sampleCodes = [
    "def saudi_algorithm():\n    return 'سيادي لا يُنسخ'",
    "class NationalSecurity:\n    def __init__(self):\n        self.level = 'maximum'",
    "function protectNationalData() {\n    return 'محمي بالسيادة';\n}",
    "const SOVEREIGN_KEY = 'مفتاح_السيادة_الرقمية';",
    "def encrypt_national_secret(data):\n    return f'🔐 {data} 🔐'"
  ];

  const handleProtect = () => {
    if (codeBlock.trim()) {
      rakanShieldMutation.mutate({ 
        code_block: codeBlock.trim(), 
        identity: identity,
        seed_phrase: seedPhrase
      });
    }
  };

  const clearForm = () => {
    setCodeBlock('');
    setIdentity('Rakan🔥');
    setSeedPhrase('سوط الحارق');
  };

  const useSampleCode = (sample: string) => {
    setCodeBlock(sample);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <Card className="digital-glow">
      <CardHeader>
        <CardTitle className="font-kufi-modern flex items-center gap-2">
          <Shield className="w-6 h-6 text-secondary" />
          درع راكان للحماية
        </CardTitle>
        <CardDescription>
          حماية الكود السيادي بالتشفير المتقدم والتوقيع الرقمي مع تفعيل سوط راكان ضد المتسللين
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          {/* Code Block Input */}
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">كتلة الكود المراد حمايتها:</label>
            <Textarea
              placeholder="أدخل الكود الذي تريد حمايته بدرع راكان..."
              value={codeBlock}
              onChange={(e) => setCodeBlock(e.target.value)}
              className="font-mono min-h-[120px]"
              rows={6}
            />
            <div className="flex justify-between items-center mt-1">
              <p className="text-xs text-muted-foreground font-arabic">
                أدخل كود للحماية بالتشفير المتقدم والتوقيع الرقمي
              </p>
              <span className="text-xs text-muted-foreground">
                {codeBlock.length} حرف
              </span>
            </div>
          </div>
          
          {/* Sample Codes */}
          <div>
            <label className="text-sm font-semibold mb-2 block font-arabic">أكواد مقترحة للحماية:</label>
            <div className="grid grid-cols-1 gap-1">
              {sampleCodes.map((sample, index) => (
                <Button
                  key={index}
                  onClick={() => useSampleCode(sample)}
                  size="sm"
                  variant="outline"
                  className="text-xs font-mono text-left justify-start"
                >
                  {sample}
                </Button>
              ))}
            </div>
          </div>
          
          {/* Identity and Seed Phrase */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">هوية الحامي:</label>
              <div className="flex flex-wrap gap-1 mb-2">
                {identities.map((id) => (
                  <Button
                    key={id}
                    onClick={() => setIdentity(id)}
                    size="sm"
                    variant={identity === id ? "default" : "outline"}
                    className="text-xs"
                  >
                    {id}
                  </Button>
                ))}
              </div>
              <Input
                placeholder="أو أدخل هوية مخصصة"
                value={identity}
                onChange={(e) => setIdentity(e.target.value)}
                className="font-technical"
              />
            </div>
            
            <div>
              <label className="text-sm font-semibold mb-2 block font-arabic">عبارة البذرة:</label>
              <div className="flex flex-wrap gap-1 mb-2">
                {seedPhrases.map((seed) => (
                  <Button
                    key={seed}
                    onClick={() => setSeedPhrase(seed)}
                    size="sm"
                    variant={seedPhrase === seed ? "default" : "outline"}
                    className="text-xs font-arabic"
                  >
                    {seed}
                  </Button>
                ))}
              </div>
              <Input
                placeholder="أو أدخل عبارة بذرة مخصصة"
                value={seedPhrase}
                onChange={(e) => setSeedPhrase(e.target.value)}
                className="font-arabic"
              />
            </div>
          </div>

          {/* Protection Preview */}
          {codeBlock && (
            <div className="p-3 bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 rounded border">
              <div className="text-xs font-semibold mb-1 font-arabic">معاينة الحماية:</div>
              <div className="text-xs font-mono bg-black text-green-400 p-2 rounded">
                /*🛡️ RAKAN SEAL 🧬*/<br/>
                # Hash 🔥: {codeBlock.substring(0, 32)}...<br/>
                <br/>
                {codeBlock.substring(0, 50)}...<br/>
                <br/>
                # رمز السيادة: {identity.substring(0, 16)}...
              </div>
            </div>
          )}
        </div>
        
        <div className="flex gap-2">
          <Button
            onClick={handleProtect}
            disabled={rakanShieldMutation.isPending || !codeBlock.trim()}
            className="flex-1 font-arabic"
          >
            {rakanShieldMutation.isPending ? (
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 animate-spin" />
                تفعيل درع راكان...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                تفعيل درع راكان
              </div>
            )}
          </Button>
          
          {(codeBlock || identity !== 'Rakan🔥' || seedPhrase !== 'سوط الحارق') && (
            <Button onClick={clearForm} variant="outline" className="font-arabic">
              <Trash2 className="w-4 h-4 mr-1" />
              مسح
            </Button>
          )}
        </div>

        {rakanShieldMutation.data && (
          <div className="mt-4 p-4 bg-gradient-to-r from-red-50 to-yellow-50 dark:from-red-900/20 dark:to-yellow-900/20 rounded-lg border">
            <h4 className="font-semibold mb-3 font-kufi-modern flex items-center gap-2">
              <Shield className="w-5 h-5 text-secondary" />
              نتائج درع راكان:
            </h4>
            
            {/* Protection Status */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg text-center">
                <div className={`text-lg font-bold ${rakanShieldMutation.data.rakan_shield?.is_valid ? 'text-green-600' : 'text-red-600'}`}>
                  {rakanShieldMutation.data.rakan_shield?.is_valid ? '🛡️ محمي' : '🚫 مخترق'}
                </div>
                <div className="text-xs text-muted-foreground">حالة الحماية</div>
              </div>

              <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg text-center">
                <div className="text-lg font-bold text-blue-600">
                  {rakanShieldMutation.data.rakan_shield?.signature_strength || 0}
                </div>
                <div className="text-xs text-muted-foreground">قوة التوقيع</div>
              </div>

              <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg text-center">
                <div className="text-sm font-bold text-purple-600 font-technical">
                  {rakanShieldMutation.data.rakan_shield?.security_hash?.substring(0, 8) || 'N/A'}...
                </div>
                <div className="text-xs text-muted-foreground">رمز الأمان</div>
              </div>

              <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg text-center">
                <div className="text-sm font-bold text-orange-600">
                  {rakanShieldMutation.data.rakan_shield?.identity || 'N/A'}
                </div>
                <div className="text-xs text-muted-foreground">هوية الحامي</div>
              </div>
            </div>

            {/* Protected Code */}
            <div className="p-3 bg-black text-green-400 rounded-lg mb-4 font-mono text-xs">
              <div className="flex justify-between items-center mb-2">
                <h5 className="font-semibold text-white font-kufi-modern">الكود المحمي:</h5>
                <Button 
                  onClick={() => copyToClipboard(rakanShieldMutation.data.rakan_shield?.protected_code || '')}
                  size="sm"
                  variant="outline"
                  className="text-xs"
                >
                  نسخ
                </Button>
              </div>
              <pre className="whitespace-pre-wrap overflow-x-auto">
                {rakanShieldMutation.data.rakan_shield?.protected_code || 'غير متوفر'}
              </pre>
            </div>

            {/* Validation Status */}
            <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg mb-3">
              <h5 className="font-semibold mb-2 text-sm font-kufi-modern">حالة التحقق:</h5>
              <div className="text-xs font-arabic">
                {rakanShieldMutation.data.rakan_shield?.validation_status || 'غير متوفر'}
              </div>
            </div>

            {/* Sovereignty Analysis */}
            {rakanShieldMutation.data.rakan_shield?.sovereignty_analysis && (
              <div className="p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg mb-3">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">تحليل السيادة:</h5>
                <div className="text-xs text-muted-foreground font-arabic">
                  {rakanShieldMutation.data.rakan_shield.sovereignty_analysis.decision_status_ar || 
                   rakanShieldMutation.data.rakan_shield.sovereignty_analysis.recommendation?.ar ||
                   'تم تحليل الحماية وفقاً لمبادئ السيادة الرقمية'}
                </div>
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs">نقاط السيادة:</span>
                  <Badge 
                    variant={rakanShieldMutation.data.rakan_shield.sovereignty_analysis.sovereignty_score >= 0.6 ? "default" : "secondary"} 
                    className="text-xs"
                  >
                    {((rakanShieldMutation.data.rakan_shield.sovereignty_analysis.sovereignty_score || 0) * 100).toFixed(0)}%
                  </Badge>
                </div>
              </div>
            )}

            {/* Cultural Analysis */}
            {rakanShieldMutation.data.rakan_shield?.cultural_analysis && (
              <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <h5 className="font-semibold mb-2 text-sm font-kufi-modern">التحليل الثقافي:</h5>
                <div className="text-xs text-muted-foreground font-arabic leading-relaxed">
                  {rakanShieldMutation.data.rakan_shield.cultural_analysis.reframed_identity?.ar || 
                   rakanShieldMutation.data.rakan_shield.cultural_analysis.enhanced_identity?.ar ||
                   rakanShieldMutation.data.rakan_shield.cultural_analysis.national_narrative?.ar ||
                   'تم تحليل الحماية ثقافياً لضمان توافقها مع الهوية الوطنية'}
                </div>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
