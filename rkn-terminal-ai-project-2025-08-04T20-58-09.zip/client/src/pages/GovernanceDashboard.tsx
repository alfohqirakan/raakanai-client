import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Scale, 
  Shield, 
  Eye, 
  Heart, 
  BookOpen, 
  Globe, 
  Lock,
  AlertTriangle,
  CheckCircle,
  XCircle,
  TrendingUp,
  BarChart3,
  Clock,
  Lightbulb,
  MapPin,
  Database
} from 'lucide-react';

interface EthicalRule {
  id: string;
  principle: string;
  description: string;
  quranic_reference: string;
  compliance_rate: number;
  violations_count: number;
  severity: 'high' | 'medium' | 'low';
}

interface ComplianceViolation {
  id: string;
  timestamp: string;
  rule_violated: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  description: string;
  auto_corrected: boolean;
}

interface DataFlow {
  id: string;
  source: string;
  destination: string;
  data_type: string;
  size: number;
  location: 'SAUDI_TERRITORY' | 'GCC_REGION' | 'INTERNATIONAL';
  compliant: boolean;
}

interface SovereigntyMetrics {
  data_residency_rate: number;
  sovereignty_score: number;
  total_data_flows: number;
  blocked_violations: number;
}

const GovernanceDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [isMonitoring, setIsMonitoring] = useState(true);

  // Mock data for demonstration
  const ethicalRules: EthicalRule[] = [
    {
      id: 'PRIVACY_001',
      principle: 'الخصوصية',
      description: 'حماية خصوصية المستخدمين وبياناتهم الشخصية',
      quranic_reference: 'لا تجسسوا (الحجرات 12)',
      compliance_rate: 0.95,
      violations_count: 2,
      severity: 'high'
    },
    {
      id: 'TRANSPARENCY_001',
      principle: 'الشفافية',
      description: 'الوضوح في العمليات والقرارات',
      quranic_reference: 'وَلَا تَكْتُمُوا الشَّهَادَةَ (البقرة 283)',
      compliance_rate: 0.92,
      violations_count: 3,
      severity: 'high'
    },
    {
      id: 'JUSTICE_001',
      principle: 'العدالة',
      description: 'المساواة وعدم التمييز في المعاملة',
      quranic_reference: 'إِنَّ اللَّهَ يَأْمُرُ بِالْعَدْلِ (النحل 90)',
      compliance_rate: 0.98,
      violations_count: 1,
      severity: 'high'
    },
    {
      id: 'HONESTY_001',
      principle: 'الصدق',
      description: 'الصدق في المعلومات والتعاملات',
      quranic_reference: 'كُونُوا مَعَ الصَّادِقِينَ (التوبة 119)',
      compliance_rate: 0.94,
      violations_count: 2,
      severity: 'high'
    }
  ];

  const recentViolations: ComplianceViolation[] = [
    {
      id: 'VIO_001',
      timestamp: '2025-08-03T18:15:00Z',
      rule_violated: 'PRIVACY_001',
      severity: 'MEDIUM',
      description: 'محاولة الوصول لبيانات بدون موافقة صريحة',
      auto_corrected: true
    },
    {
      id: 'VIO_002',
      timestamp: '2025-08-03T17:45:00Z',
      rule_violated: 'TRANSPARENCY_001',
      severity: 'HIGH',
      description: 'عدم توفير شرح واضح للعملية',
      auto_corrected: false
    },
    {
      id: 'VIO_003',
      timestamp: '2025-08-03T16:30:00Z',
      rule_violated: 'HONESTY_001',
      severity: 'LOW',
      description: 'معلومات تحتاج تحقق إضافي',
      auto_corrected: true
    }
  ];

  const sovereigntyMetrics: SovereigntyMetrics = {
    data_residency_rate: 0.98,
    sovereignty_score: 0.96,
    total_data_flows: 1247,
    blocked_violations: 23
  };

  const dataFlows: DataFlow[] = [
    {
      id: 'FLOW_001',
      source: 'riyadh-server-01.sa',
      destination: 'jeddah-dc-01.sa',
      data_type: 'البيانات الشخصية',
      size: 1024000,
      location: 'SAUDI_TERRITORY',
      compliant: true
    },
    {
      id: 'FLOW_002',
      source: 'app-server.sa',
      destination: 'backup.kuwait.kw',
      data_type: 'البيانات العامة',
      size: 512000,
      location: 'GCC_REGION',
      compliant: true
    },
    {
      id: 'FLOW_003',
      source: 'financial-system.sa',
      destination: 'aws-eu-west-1.com',
      data_type: 'البيانات المالية',
      size: 2048000,
      location: 'INTERNATIONAL',
      compliant: false
    }
  ];

  const getSeverityColor = (severity: string): string => {
    const colors = {
      CRITICAL: 'bg-red-600',
      HIGH: 'bg-red-500',
      MEDIUM: 'bg-yellow-500',
      LOW: 'bg-blue-500',
      high: 'border-red-500 text-red-700',
      medium: 'border-yellow-500 text-yellow-700',
      low: 'border-blue-500 text-blue-700'
    };
    return colors[severity as keyof typeof colors] || 'bg-gray-500';
  };

  const getLocationIcon = (location: string) => {
    switch (location) {
      case 'SAUDI_TERRITORY':
        return <MapPin className="h-4 w-4 text-green-600" />;
      case 'GCC_REGION':
        return <MapPin className="h-4 w-4 text-yellow-600" />;
      case 'INTERNATIONAL':
        return <MapPin className="h-4 w-4 text-red-600" />;
      default:
        return <MapPin className="h-4 w-4 text-gray-600" />;
    }
  };

  const getLocationText = (location: string): string => {
    switch (location) {
      case 'SAUDI_TERRITORY':
        return 'الأراضي السعودية';
      case 'GCC_REGION':
        return 'دول مجلس التعاون';
      case 'INTERNATIONAL':
        return 'دولي';
      default:
        return 'غير محدد';
    }
  };

  const MetricCard: React.FC<{
    title: string;
    value: number;
    icon: React.ReactNode;
    trend?: number;
    suffix?: string;
    description?: string;
  }> = ({ title, value, icon, trend, suffix = '%', description }) => (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl font-bold">
            {suffix === '%' ? (value * 100).toFixed(1) : value.toLocaleString()}{suffix}
          </p>
          {trend !== undefined && (
            <p className={`text-sm flex items-center ${trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              <TrendingUp className="h-4 w-4 mr-1" />
              {trend >= 0 ? '+' : ''}{(trend * 100).toFixed(1)}%
            </p>
          )}
          {description && (
            <p className="text-xs text-muted-foreground mt-1">{description}</p>
          )}
        </div>
        <div className="text-2xl text-muted-foreground">
          {icon}
        </div>
      </div>
    </Card>
  );

  const RuleCard: React.FC<{ rule: EthicalRule }> = ({ rule }) => (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="font-medium">{rule.principle}</h4>
          <Badge variant="outline" className={getSeverityColor(rule.severity)}>
            {rule.severity === 'high' ? 'عالي' : rule.severity === 'medium' ? 'متوسط' : 'منخفض'}
          </Badge>
        </div>
        
        <p className="text-sm text-muted-foreground">{rule.description}</p>
        
        <div className="p-2 bg-muted/50 rounded text-xs">
          <BookOpen className="h-3 w-3 inline mr-1" />
          {rule.quranic_reference}
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>معدل الامتثال</span>
            <span>{(rule.compliance_rate * 100).toFixed(1)}%</span>
          </div>
          <Progress value={rule.compliance_rate * 100} className="h-2" />
          
          <div className="flex items-center justify-between text-sm">
            <span>المخالفات</span>
            <span className="text-red-600">{rule.violations_count}</span>
          </div>
        </div>
      </div>
    </Card>
  );

  const ViolationCard: React.FC<{ violation: ComplianceViolation }> = ({ violation }) => (
    <Card className="p-4">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <Badge className={getSeverityColor(violation.severity)} variant="outline">
              {violation.severity}
            </Badge>
            <span className="text-sm text-muted-foreground">
              {new Date(violation.timestamp).toLocaleString('ar')}
            </span>
          </div>
          
          <p className="text-sm font-medium mb-1">{violation.rule_violated}</p>
          <p className="text-sm text-muted-foreground">{violation.description}</p>
          
          <div className="flex items-center gap-2 mt-2">
            {violation.auto_corrected ? (
              <div className="flex items-center text-green-600 text-xs">
                <CheckCircle className="h-3 w-3 mr-1" />
                تم التصحيح التلقائي
              </div>
            ) : (
              <div className="flex items-center text-red-600 text-xs">
                <XCircle className="h-3 w-3 mr-1" />
                يتطلب تدخل يدوي
              </div>
            )}
          </div>
        </div>
      </div>
    </Card>
  );

  const DataFlowCard: React.FC<{ flow: DataFlow }> = ({ flow }) => (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-medium">{flow.id}</span>
          <div className="flex items-center gap-2">
            {getLocationIcon(flow.location)}
            {flow.compliant ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <XCircle className="h-4 w-4 text-red-600" />
            )}
          </div>
        </div>
        
        <div className="space-y-1 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">المصدر:</span>
            <span>{flow.source}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">الوجهة:</span>
            <span>{flow.destination}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">نوع البيانات:</span>
            <span>{flow.data_type}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">الحجم:</span>
            <span>{(flow.size / 1024).toFixed(0)} KB</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">الموقع:</span>
            <span>{getLocationText(flow.location)}</span>
          </div>
        </div>
        
        <div className="pt-2 border-t">
          <Badge variant={flow.compliant ? "default" : "destructive"}>
            {flow.compliant ? 'ممتثل' : 'غير ممتثل'}
          </Badge>
        </div>
      </div>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-900 dark:to-indigo-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Scale className="h-8 w-8 text-blue-600 mr-3" />
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                دستور الذكاء الاصطناعي
              </h1>
              <p className="text-muted-foreground">
                Saudi AI Governance - الضمير الأخلاقي للنظام
              </p>
            </div>
          </div>
          
          {/* Status Indicators */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className={`w-3 h-3 rounded-full ${isMonitoring ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-sm">
                {isMonitoring ? 'المراقبة نشطة' : 'المراقبة متوقفة'}
              </span>
            </div>
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setIsMonitoring(!isMonitoring)}
            >
              {isMonitoring ? 'إيقاف المراقبة' : 'بدء المراقبة'}
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="ethics">الأخلاقيات</TabsTrigger>
            <TabsTrigger value="sovereignty">السيادة الرقمية</TabsTrigger>
            <TabsTrigger value="compliance">الامتثال</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="الامتثال الأخلاقي العام"
                value={0.946}
                icon={<Scale />}
                trend={0.023}
                description="متوسط جميع المبادئ"
              />
              <MetricCard
                title="السيادة الرقمية"
                value={sovereigntyMetrics.sovereignty_score}
                icon={<Shield />}
                trend={0.012}
                description="نقاط السيادة"
              />
              <MetricCard
                title="إقامة البيانات"
                value={sovereigntyMetrics.data_residency_rate}
                icon={<MapPin />}
                trend={0.008}
                description="داخل الحدود"
              />
              <MetricCard
                title="الانتهاكات المحجوبة"
                value={sovereigntyMetrics.blocked_violations}
                icon={<Lock />}
                suffix=""
                description="آخر 30 يوم"
              />
            </div>

            {/* Governance Principles */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BookOpen className="h-5 w-5 mr-2" />
                  المبادئ الأساسية للحوكمة
                </CardTitle>
                <CardDescription>
                  القواعد الأخلاقية المستمدة من القرآن والسنة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                    <div className="flex items-center mb-2">
                      <Eye className="h-5 w-5 text-blue-600 mr-2" />
                      <span className="font-medium">الخصوصية</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      "لا تجسسوا" (الحجرات 12)
                    </p>
                    <p className="text-xs">
                      حماية خصوصية المستخدمين وبياناتهم الشخصية
                    </p>
                  </div>
                  
                  <div className="p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                    <div className="flex items-center mb-2">
                      <Eye className="h-5 w-5 text-green-600 mr-2" />
                      <span className="font-medium">الشفافية</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      "وَلَا تَكْتُمُوا الشَّهَادَةَ" (البقرة 283)
                    </p>
                    <p className="text-xs">
                      الوضوح في العمليات والقرارات
                    </p>
                  </div>
                  
                  <div className="p-4 rounded-lg bg-purple-50 dark:bg-purple-900/20">
                    <div className="flex items-center mb-2">
                      <Scale className="h-5 w-5 text-purple-600 mr-2" />
                      <span className="font-medium">العدالة</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      "إن الله يأمر بالعدل" (النحل 90)
                    </p>
                    <p className="text-xs">
                      المساواة وعدم التمييز في المعاملة
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2" />
                  التنبيهات الأخيرة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentViolations.slice(0, 3).map((violation) => (
                    <Alert key={violation.id}>
                      <AlertTriangle className="h-4 w-4" />
                      <AlertDescription>
                        <div className="flex items-center justify-between">
                          <span>{violation.description}</span>
                          <Badge className={getSeverityColor(violation.severity)}>
                            {violation.severity}
                          </Badge>
                        </div>
                      </AlertDescription>
                    </Alert>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Ethics Tab */}
          <TabsContent value="ethics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Heart className="h-5 w-5 mr-2" />
                  القواعد الأخلاقية النشطة
                </CardTitle>
                <CardDescription>
                  المبادئ الأخلاقية المطبقة في النظام
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {ethicalRules.map((rule) => (
                    <RuleCard key={rule.id} rule={rule} />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Compliance Violations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2" />
                  المخالفات الأخيرة
                </CardTitle>
                <CardDescription>
                  آخر المخالفات الأخلاقية المكتشفة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {recentViolations.map((violation) => (
                    <ViolationCard key={violation.id} violation={violation} />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sovereignty Tab */}
          <TabsContent value="sovereignty" className="space-y-6">
            {/* Data Sovereignty Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="إقامة البيانات"
                value={sovereigntyMetrics.data_residency_rate}
                icon={<Database />}
                description="نسبة البيانات داخل الحدود"
              />
              <MetricCard
                title="تدفقات البيانات"
                value={sovereigntyMetrics.total_data_flows}
                icon={<Globe />}
                suffix=""
                description="إجمالي التدفقات المراقبة"
              />
              <MetricCard
                title="الانتهاكات المحجوبة"
                value={sovereigntyMetrics.blocked_violations}
                icon={<Shield />}
                suffix=""
                description="محاولات نقل غير مصرح"
              />
              <MetricCard
                title="نقاط السيادة"
                value={sovereigntyMetrics.sovereignty_score}
                icon={<Lock />}
                description="مؤشر السيادة الرقمية"
              />
            </div>

            {/* Data Location Policy */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  سياسة موقع البيانات
                </CardTitle>
                <CardDescription>
                  DataLocationPolicy.enforce("SAUDI_BORDERS") - نشطة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Alert>
                    <Shield className="h-4 w-4" />
                    <AlertDescription>
                      <strong>السياسة النشطة:</strong> جميع البيانات يجب أن تبقى داخل الحدود السعودية
                    </AlertDescription>
                  </Alert>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 rounded-lg border border-green-200 bg-green-50 dark:bg-green-900/20">
                      <div className="flex items-center mb-2">
                        <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                        <span className="font-medium">الأراضي السعودية</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        جميع أنواع البيانات مسموحة
                      </p>
                      <p className="text-xs mt-1">
                        مراكز البيانات: الرياض، جدة، الدمام
                      </p>
                    </div>
                    
                    <div className="p-4 rounded-lg border border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20">
                      <div className="flex items-center mb-2">
                        <AlertTriangle className="h-5 w-5 text-yellow-600 mr-2" />
                        <span className="font-medium">دول مجلس التعاون</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        البيانات العامة والتقنية فقط
                      </p>
                      <p className="text-xs mt-1">
                        شروط خاصة للضرورة
                      </p>
                    </div>
                    
                    <div className="p-4 rounded-lg border border-red-200 bg-red-50 dark:bg-red-900/20">
                      <div className="flex items-center mb-2">
                        <XCircle className="h-5 w-5 text-red-600 mr-2" />
                        <span className="font-medium">المواقع الدولية</span>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        نقل البيانات محظور
                      </p>
                      <p className="text-xs mt-1">
                        يتم حجب جميع المحاولات
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Data Flows */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="h-5 w-5 mr-2" />
                  تدفقات البيانات الحديثة
                </CardTitle>
                <CardDescription>
                  آخر محاولات نقل البيانات
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {dataFlows.map((flow) => (
                    <DataFlowCard key={flow.id} flow={flow} />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Compliance Tab */}
          <TabsContent value="compliance" className="space-y-6">
            {/* Compliance Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="p-6">
                <div className="text-center">
                  <BarChart3 className="h-8 w-8 mx-auto text-blue-600 mb-2" />
                  <h3 className="font-semibold mb-1">معدل الامتثال العام</h3>
                  <p className="text-3xl font-bold text-blue-600">94.6%</p>
                  <p className="text-sm text-muted-foreground">متوسط جميع المبادئ</p>
                </div>
              </Card>
              
              <Card className="p-6">
                <div className="text-center">
                  <Clock className="h-8 w-8 mx-auto text-green-600 mb-2" />
                  <h3 className="font-semibold mb-1">المراجعات اليومية</h3>
                  <p className="text-3xl font-bold text-green-600">1,247</p>
                  <p className="text-sm text-muted-foreground">قرار تم مراجعته</p>
                </div>
              </Card>
              
              <Card className="p-6">
                <div className="text-center">
                  <Shield className="h-8 w-8 mx-auto text-purple-600 mb-2" />
                  <h3 className="font-semibold mb-1">التصحيحات التلقائية</h3>
                  <p className="text-3xl font-bold text-purple-600">89.2%</p>
                  <p className="text-sm text-muted-foreground">نسبة الحل التلقائي</p>
                </div>
              </Card>
            </div>

            {/* Recommendations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Lightbulb className="h-5 w-5 mr-2" />
                  التوصيات الأخلاقية
                </CardTitle>
                <CardDescription>
                  توصيات تحسين الامتثال والحوكمة
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    {
                      priority: 'عالية',
                      title: 'تعزيز آليات الخصوصية',
                      description: 'تحسين آليات حماية البيانات الشخصية وضمان الموافقة الصريحة',
                      color: 'red'
                    },
                    {
                      priority: 'متوسطة',
                      title: 'تطوير الشفافية',
                      description: 'زيادة وضوح العمليات وتوفير شروحات أفضل للمستخدمين',
                      color: 'yellow'
                    },
                    {
                      priority: 'منخفضة',
                      title: 'تحسين التوثيق',
                      description: 'تطوير التوثيق الأخلاقي وإجراءات المراجعة',
                      color: 'green'
                    }
                  ].map((rec, idx) => (
                    <div key={idx} className="flex items-start p-4 rounded-lg border">
                      <Badge 
                        variant="outline" 
                        className={`mr-3 ${
                          rec.color === 'red' ? 'border-red-500 text-red-700' :
                          rec.color === 'yellow' ? 'border-yellow-500 text-yellow-700' :
                          'border-green-500 text-green-700'
                        }`}
                      >
                        {rec.priority}
                      </Badge>
                      <div>
                        <h4 className="font-medium mb-1">{rec.title}</h4>
                        <p className="text-sm text-muted-foreground">{rec.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default GovernanceDashboard;