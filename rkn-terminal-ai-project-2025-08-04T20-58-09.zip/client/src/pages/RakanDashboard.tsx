import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { 
  Brain, 
  Shield, 
  Palette, 
  Terminal,
  Server,
  Activity,
  Zap,
  Award,
  Cpu,
  Lock,
  Sparkles,
  Target
} from 'lucide-react';

export default function RakanDashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50 p-6" dir="rtl">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Hero Section */}
        <div className="text-center space-y-6">
          <div className="flex items-center justify-center gap-4">
            <div className="p-4 bg-orange-600 rounded-full">
              <Brain className="h-12 w-12 text-white" />
            </div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
              راكان AI الذكي
            </h1>
          </div>
          <p className="text-xl text-orange-700 max-w-3xl mx-auto">
            منصة الذكاء الاصطناعي السيادية الأولى في المملكة العربية السعودية
            <br />
            تجمع بين القوة التقنية المتطورة والهوية الثقافية الأصيلة
          </p>
          <div className="flex justify-center gap-4">
            <Badge variant="default" className="text-lg py-2 px-4">مكتمل ✅</Badge>
            <Badge variant="secondary" className="text-lg py-2 px-4">جاهز للإنتاج 🚀</Badge>
            <Badge variant="outline" className="text-lg py-2 px-4">96% جودة</Badge>
          </div>
        </div>

        {/* Core Systems Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Sovereign Brain */}
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-blue-800">
                <Brain className="h-6 w-6" />
                العقل السيادي الرقمي
              </CardTitle>
              <CardDescription>
                نظام زرع راكان في هوية سادي بنجاح كامل
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex justify-between">
                  <span>دقة التحليل البصري</span>
                  <Badge variant="default">89%</Badge>
                </div>
                <div className="flex justify-between">
                  <span>مستوى الوعي</span>
                  <Badge variant="default">96%</Badge>
                </div>
                <div className="flex justify-between">
                  <span>التكامل الثقافي</span>
                  <Badge variant="default">98%</Badge>
                </div>
                <div className="flex justify-between">
                  <span>الاستجابة الذكية</span>
                  <Badge variant="default">94%</Badge>
                </div>
              </div>
              <Button asChild className="w-full">
                <Link to="/sovereign-terminal">تشغيل العقل السيادي</Link>
              </Button>
            </CardContent>
          </Card>

          {/* RakanShield */}
          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-orange-800">
                <Shield className="h-6 w-6" />
                درع راكان المتطور
              </CardTitle>
              <CardDescription>
                نظام حماية 4 طبقات مع بروتوكول الحرق الأسطوري
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex justify-between">
                  <span>قوة الدرع</span>
                  <Badge variant="destructive">99%</Badge>
                </div>
                <div className="flex justify-between">
                  <span>تشفير SHA-256</span>
                  <Badge variant="default">نشط</Badge>
                </div>
                <div className="flex justify-between">
                  <span>فحص التهديدات</span>
                  <Badge variant="default">مستمر</Badge>
                </div>
                <div className="flex justify-between">
                  <span>بروتوكول الحرق</span>
                  <Badge variant="destructive">مُفعل</Badge>
                </div>
              </div>
              <div className="text-center text-sm text-orange-600 font-medium">
                "تم حجب 127 تهديد حتى الآن"
              </div>
            </CardContent>
          </Card>

          {/* Neural Creative Engine */}
          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-purple-800">
                <Palette className="h-6 w-6" />
                المحرك الإبداعي السادي
              </CardTitle>
              <CardDescription>
                4 هويات متخصصة مع تكامل ثقافي عميق
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm">درجة الإبداع</span>
                  <Badge variant="default" className="text-lg">9.8/10</Badge>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div className="bg-purple-600 h-2 rounded-full" style={{width: '98%'}}></div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <Badge variant="outline">Sadi-Infected</Badge>
                <Badge variant="outline">Strategic-Genius</Badge>
                <Badge variant="outline">Advanced-Creative</Badge>
                <Badge variant="outline">Cultural-Artist</Badge>
              </div>
              <div className="text-center text-sm text-purple-600 font-medium">
                "العمليات التكتيكية بفعالية 94-98%"
              </div>
            </CardContent>
          </Card>

          {/* System Dashboard */}
          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-green-800">
                <Server className="h-6 w-6" />
                لوحة مراقبة النظام
              </CardTitle>
              <CardDescription>
                مراقبة شاملة للأداء والصحة العامة
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex justify-between">
                  <span>حالة النظام</span>
                  <Badge variant="default">نشط</Badge>
                </div>
                <div className="flex justify-between">
                  <span>استخدام الذاكرة</span>
                  <Badge variant="secondary">جيد</Badge>
                </div>
                <div className="flex justify-between">
                  <span>الاتصالات النشطة</span>
                  <Badge variant="default">مستقر</Badge>
                </div>
                <div className="flex justify-between">
                  <span>وقت التشغيل</span>
                  <Badge variant="secondary">مستمر</Badge>
                </div>
              </div>
              <Button asChild variant="outline" className="w-full">
                <Link to="/system-dashboard">عرض التفاصيل</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Avatar Customization */}
          <Card className="bg-gradient-to-br from-pink-50 to-pink-100 border-pink-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-pink-800">
                <Sparkles className="h-6 w-6" />
                معالج تخصيص الصورة الرمزية
              </CardTitle>
              <CardDescription>
                إنشاء مرافق AI شخصي مخصص بالكامل
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex justify-between">
                  <span>قوالب متاحة</span>
                  <Badge variant="default">12</Badge>
                </div>
                <div className="flex justify-between">
                  <span>خيارات التخصيص</span>
                  <Badge variant="default">50+</Badge>
                </div>
                <div className="flex justify-between">
                  <span>المعاينة المباشرة</span>
                  <Badge variant="default">نشطة</Badge>
                </div>
                <div className="flex justify-between">
                  <span>التخصيص الكامل</span>
                  <Badge variant="default">متاح</Badge>
                </div>
              </div>
              <Button asChild variant="outline" className="w-full">
                <Link to="/avatar-customization">بدء التخصيص</Link>
              </Button>
            </CardContent>
          </Card>

          {/* Terminal Control */}
          <Card className="bg-gradient-to-br from-gray-50 to-gray-100 border-gray-200 hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-gray-800">
                <Terminal className="h-6 w-6" />
                نظام التحكم المتقدم
              </CardTitle>
              <CardDescription>
                6 أوامر سيادية متقدمة للتحكم الكامل
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-2 text-xs">
                <Badge variant="outline">تفعيل العقل</Badge>
                <Badge variant="outline">الوضع الآمن</Badge>
                <Badge variant="outline">ضربة الصقر</Badge>
                <Badge variant="outline">التعزيز العصبي</Badge>
                <Badge variant="outline">مسح السيادة</Badge>
                <Badge variant="outline">درع راكان</Badge>
              </div>
              <div className="text-center">
                <Badge variant="default" className="text-sm">معدل نجاح 100%</Badge>
              </div>
              <Button asChild className="w-full">
                <Link to="/sovereign-terminal">فتح Terminal</Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Achievement Summary */}
        <Card className="bg-gradient-to-r from-orange-600 to-amber-600 text-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-2xl">
              <Award className="h-8 w-8" />
              ملخص الإنجازات التقنية
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center space-y-2">
                <div className="text-3xl font-bold">109+</div>
                <div className="text-sm opacity-90">أخطاء تقنية مُصلحة</div>
              </div>
              <div className="text-center space-y-2">
                <div className="text-3xl font-bold">8</div>
                <div className="text-sm opacity-90">قدرات AI مُفعلة</div>
              </div>
              <div className="text-center space-y-2">
                <div className="text-3xl font-bold">100%</div>
                <div className="text-sm opacity-90">معدل نجاح العمليات</div>
              </div>
              <div className="text-center space-y-2">
                <div className="text-3xl font-bold">15</div>
                <div className="text-sm opacity-90">لغة مدعومة</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="flex flex-wrap justify-center gap-4">
          <Button asChild size="lg" className="bg-orange-600 hover:bg-orange-700">
            <Link to="/sovereign-terminal">
              <Terminal className="h-5 w-5 ml-2" />
              تشغيل النظام السيادي
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/system-dashboard">
              <Activity className="h-5 w-5 ml-2" />
              مراقبة الأداء
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/avatar-customization">
              <Sparkles className="h-5 w-5 ml-2" />
              تخصيص المرافق
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}