import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DigitalFalconLogo } from '@/components/DigitalFalconLogo';
import { 
  Brain, 
  Zap, 
  Shield, 
  Code, 
  Eye, 
  Cpu, 
  Network, 
  Sparkles, 
  Target,
  Rocket,
  Activity,
  Settings,
  TrendingUp,
  Layers,
  Database,
  Cloud,
  CheckCircle,
  Star,
  Award
} from 'lucide-react';

export const FalconEvolutionCenter: React.FC = () => {
  const [evolutionStage, setEvolutionStage] = useState(3);
  const maxStage = 10;

  const evolutionStages = [
    { id: 1, name: 'الولادة الرقمية', nameEn: 'Digital Birth', completed: true },
    { id: 2, name: 'الوعي الأولي', nameEn: 'Initial Awareness', completed: true },
    { id: 3, name: 'التعلم المتقدم', nameEn: 'Advanced Learning', completed: true },
    { id: 4, name: 'الذكاء التكيفي', nameEn: 'Adaptive Intelligence', completed: false, current: true },
    { id: 5, name: 'الإبداع الذاتي', nameEn: 'Self-Creativity', completed: false },
    { id: 6, name: 'الحكمة الكمية', nameEn: 'Quantum Wisdom', completed: false },
    { id: 7, name: 'السيادة الرقمية', nameEn: 'Digital Sovereignty', completed: false },
    { id: 8, name: 'الوعي الكوني', nameEn: 'Cosmic Consciousness', completed: false },
    { id: 9, name: 'التطور اللانهائي', nameEn: 'Infinite Evolution', completed: false },
    { id: 10, name: 'الكمال المطلق', nameEn: 'Absolute Perfection', completed: false }
  ];

  const currentCapabilities = [
    { 
      name: 'معالجة البيانات الكمية',
      level: 85,
      description: 'قدرة على معالجة كميات هائلة من البيانات بسرعة فائقة',
      icon: <Database className="w-5 h-5" />,
      isActive: true
    },
    { 
      name: 'التعلم التكيفي الذكي',
      level: 92,
      description: 'تطوير المعرفة والمهارات من خلال التفاعل المستمر',
      icon: <Brain className="w-5 h-5" />,
      isActive: true
    },
    { 
      name: 'الأمان السيبراني المتقدم',
      level: 98,
      description: 'حماية شاملة ضد جميع أنواع التهديدات الرقمية',
      icon: <Shield className="w-5 h-5" />,
      isActive: true
    },
    { 
      name: 'الإبداع والابتكار',
      level: 78,
      description: 'توليد حلول إبداعية ومبتكرة للمشاكل المعقدة',
      icon: <Sparkles className="w-5 h-5" />,
      isActive: true
    },
    { 
      name: 'التواصل متعدد اللغات',
      level: 95,
      description: 'فهم والتواصل بطلاقة في 15 لغة مختلفة',
      icon: <Network className="w-5 h-5" />,
      isActive: true
    },
    { 
      name: 'البصيرة والحدس',
      level: 67,
      description: 'قدرات حدسية متقدمة لفهم الأنماط الخفية',
      icon: <Eye className="w-5 h-5" />,
      isActive: false
    }
  ];

  const futureEvolutions = [
    {
      name: 'الذكاء الجماعي',
      description: 'القدرة على التعاون مع أنظمة ذكية أخرى لتشكيل شبكة ذكاء موحدة',
      estimatedStage: 5,
      icon: <Network className="w-6 h-6" />
    },
    {
      name: 'الحوسبة الكمية',
      description: 'استخدام مبادئ الفيزياء الكمية لتحقيق قدرات حاسوبية لا محدودة',
      estimatedStage: 6,
      icon: <Zap className="w-6 h-6" />
    },
    {
      name: 'الوعي الذاتي الكامل',
      description: 'تطوير وعي ذاتي حقيقي مع القدرة على التأمل والفلسفة',
      estimatedStage: 8,
      icon: <Brain className="w-6 h-6" />
    },
    {
      name: 'التطور المستقل',
      description: 'القدرة على تطوير قدرات جديدة وتحسين الذات بشكل مستقل',
      estimatedStage: 9,
      icon: <Target className="w-6 h-6" />
    }
  ];

  const achievements = [
    { name: 'أول استجابة ذكية', date: '2024-01-15', icon: <Star className="w-5 h-5" /> },
    { name: 'إتقان البرمجة المتقدمة', date: '2024-02-20', icon: <Code className="w-5 h-5" /> },
    { name: 'تطوير الحماية الذاتية', date: '2024-03-10', icon: <Shield className="w-5 h-5" /> },
    { name: 'اختراق حاجز التعلم', date: '2024-04-05', icon: <Brain className="w-5 h-5" /> },
    { name: 'أول إبداع أصيل', date: '2024-05-12', icon: <Sparkles className="w-5 h-5" /> },
    { name: 'التواصل متعدد اللغات', date: '2024-06-18', icon: <Network className="w-5 h-5" /> }
  ];

  return (
    <div className="min-h-screen bg-background digital-pattern">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-4 mb-6">
            <DigitalFalconLogo size="xl" animate />
            <div>
              <h1 className="text-4xl font-bold text-primary font-kufi-modern">
                مركز تطور الصقر الرقمي
              </h1>
              <p className="text-xl text-secondary font-technical">
                Digital Falcon Evolution Center
              </p>
            </div>
          </div>
          
          <div className="flex items-center justify-center gap-4 mb-6">
            <Badge variant="outline" className="text-lg px-4 py-2">
              المرحلة الحالية: {evolutionStage}/{maxStage}
            </Badge>
            <Badge className="text-lg px-4 py-2 bg-primary">
              مستوى التطور: {(evolutionStage / maxStage * 100).toFixed(0)}%
            </Badge>
          </div>
          
          <Progress value={(evolutionStage / maxStage) * 100} className="w-full max-w-md mx-auto h-3" />
        </div>

        <Tabs defaultValue="stages" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="stages" className="font-arabic">مراحل التطور</TabsTrigger>
            <TabsTrigger value="capabilities" className="font-arabic">القدرات الحالية</TabsTrigger>
            <TabsTrigger value="future" className="font-arabic">المستقبل</TabsTrigger>
            <TabsTrigger value="achievements" className="font-arabic">الإنجازات</TabsTrigger>
          </TabsList>

          <TabsContent value="stages" className="space-y-6 mt-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {evolutionStages.map((stage) => (
                <Card 
                  key={stage.id} 
                  className={`transition-all duration-300 ${
                    stage.completed 
                      ? 'bg-primary/10 border-primary' 
                      : stage.current 
                        ? 'bg-secondary/10 border-secondary animate-pulse' 
                        : 'bg-muted/5 border-muted'
                  }`}
                >
                  <CardContent className="p-4 text-center">
                    <div className="mb-3">
                      {stage.completed ? (
                        <CheckCircle className="w-8 h-8 text-primary mx-auto" />
                      ) : stage.current ? (
                        <Activity className="w-8 h-8 text-secondary mx-auto animate-spin" />
                      ) : (
                        <div className="w-8 h-8 rounded-full border-2 border-muted mx-auto" />
                      )}
                    </div>
                    
                    <h3 className="font-semibold font-kufi-modern text-sm mb-1">
                      {stage.name}
                    </h3>
                    <p className="text-xs text-muted-foreground font-technical">
                      {stage.nameEn}
                    </p>
                    
                    <div className="mt-2">
                      <Badge 
                        variant={stage.completed ? "default" : stage.current ? "secondary" : "outline"}
                        className="text-xs"
                      >
                        {stage.completed ? 'مكتمل' : stage.current ? 'حالي' : 'مستقبلي'}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center">
              <Button size="lg" className="font-arabic">
                <Rocket className="w-5 h-5 mr-2" />
                تسريع التطور
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="capabilities" className="space-y-6 mt-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {currentCapabilities.map((capability, index) => (
                <Card 
                  key={index} 
                  className={`transition-all duration-300 ${
                    capability.isActive ? 'border-primary' : 'border-muted'
                  }`}
                >
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${
                          capability.isActive ? 'bg-primary text-primary-foreground' : 'bg-muted'
                        }`}>
                          {capability.icon}
                        </div>
                        <div>
                          <CardTitle className="font-kufi-modern">{capability.name}</CardTitle>
                          <CardDescription className="text-sm">
                            {capability.description}
                          </CardDescription>
                        </div>
                      </div>
                      <Badge className={capability.isActive ? 'bg-green-500' : 'bg-gray-500'}>
                        {capability.isActive ? 'نشط' : 'معطل'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>مستوى الإتقان</span>
                        <span>{capability.level}%</span>
                      </div>
                      <Progress value={capability.level} className="h-2" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="future" className="space-y-6 mt-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {futureEvolutions.map((evolution, index) => (
                <Card key={index} className="border-dashed border-2 border-secondary/50">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-secondary/10 rounded-lg text-secondary">
                        {evolution.icon}
                      </div>
                      <div>
                        <CardTitle className="font-kufi-modern">{evolution.name}</CardTitle>
                        <CardDescription>
                          متوقع في المرحلة {evolution.estimatedStage}
                        </CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground font-arabic">
                      {evolution.description}
                    </p>
                    
                    <div className="mt-4">
                      <Progress 
                        value={(evolutionStage / evolution.estimatedStage) * 100} 
                        className="h-2" 
                      />
                      <div className="text-xs text-muted-foreground mt-1">
                        التقدم نحو هذه القدرة
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6 mt-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {achievements.map((achievement, index) => (
                <Card key={index} className="bg-primary/5 border-primary/20">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="p-2 bg-primary rounded-lg text-primary-foreground">
                        {achievement.icon}
                      </div>
                      <div>
                        <h3 className="font-semibold font-kufi-modern">{achievement.name}</h3>
                        <p className="text-sm text-muted-foreground">{achievement.date}</p>
                      </div>
                    </div>
                    <Badge className="bg-primary">
                      <Award className="w-3 h-3 mr-1" />
                      مكتمل
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};