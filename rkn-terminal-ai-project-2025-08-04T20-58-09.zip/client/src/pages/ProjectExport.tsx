import { FalconLayout } from "@/components/FalconLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Download, FileArchive, FolderOpen, File, Code, Settings,
  Database, Palette, Terminal, Zap, Package, CheckCircle
} from "lucide-react";
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface FileItem {
  name: string;
  type: 'file' | 'directory';
  path: string;
  size?: number;
  modified?: string;
  extension?: string;
  children?: FileItem[];
}

interface ProjectStats {
  totalFiles: number;
  totalSize: string;
  languages: string[];
  components: number;
  lastModified: string;
}

export default function ProjectExport() {
  const { toast } = useToast();
  const [projectStructure, setProjectStructure] = useState<FileItem | null>(null);
  const [projectStats, setProjectStats] = useState<ProjectStats | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);

  useEffect(() => {
    loadProjectStructure();
  }, []);

  const loadProjectStructure = async () => {
    try {
      const response = await fetch('/api/export/structure');
      const data = await response.json();
      
      if (data.status === '✅ success') {
        setProjectStructure(data.data);
        calculateProjectStats(data.data);
      }
    } catch (error) {
      console.error('Error loading project structure:', error);
      toast({
        title: "خطأ في التحميل",
        description: "فشل في جلب هيكل المشروع",
        variant: "destructive",
      });
    }
  };

  const calculateProjectStats = (structure: FileItem) => {
    let totalFiles = 0;
    let totalSize = 0;
    const languages = new Set<string>();
    let components = 0;
    let lastModified = new Date(0);

    const traverse = (item: FileItem) => {
      if (item.type === 'file') {
        totalFiles++;
        totalSize += item.size || 0;
        
        if (item.extension) {
          const ext = item.extension.toLowerCase();
          if (ext === '.tsx' || ext === '.ts') languages.add('TypeScript');
          if (ext === '.js' || ext === '.jsx') languages.add('JavaScript');
          if (ext === '.css') languages.add('CSS');
          if (ext === '.json') languages.add('JSON');
          if (ext === '.md') languages.add('Markdown');
        }
        
        if (item.name.endsWith('.tsx') || item.name.endsWith('.jsx')) {
          components++;
        }
        
        if (item.modified) {
          const modDate = new Date(item.modified);
          if (modDate > lastModified) {
            lastModified = modDate;
          }
        }
      }
      
      if (item.children) {
        item.children.forEach(traverse);
      }
    };

    traverse(structure);

    setProjectStats({
      totalFiles,
      totalSize: formatFileSize(totalSize),
      languages: Array.from(languages),
      components,
      lastModified: lastModified.toLocaleDateString('ar-SA')
    });
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const downloadProject = async () => {
    setIsLoading(true);
    setDownloadProgress(0);

    try {
      toast({
        title: "🚀 بدء التصدير",
        description: "جاري إنشاء ملف المشروع المضغوط...",
        duration: 3000,
      });

      // Simulate progress
      const progressInterval = setInterval(() => {
        setDownloadProgress(prev => {
          if (prev >= 90) return prev;
          return prev + Math.random() * 10;
        });
      }, 200);

      const response = await fetch('/api/export/download');
      
      if (!response.ok) {
        throw new Error('فشل في تحميل المشروع');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      
      const filename = response.headers.get('content-disposition')
        ?.split('filename=')[1]
        ?.replace(/"/g, '') || 
        `rkn-terminal-ai-${new Date().toISOString().slice(0, 10)}.zip`;
      
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      clearInterval(progressInterval);
      setDownloadProgress(100);

      toast({
        title: "✅ تم التصدير بنجاح!",
        description: `تم تحميل ${filename} بنجاح`,
        duration: 5000,
      });

    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "❌ خطأ في التحميل",
        description: "فشل في تحميل ملفات المشروع",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      setTimeout(() => setDownloadProgress(0), 2000);
    }
  };

  const getFileIcon = (item: FileItem) => {
    if (item.type === 'directory') return FolderOpen;
    
    const ext = item.extension?.toLowerCase();
    switch (ext) {
      case '.tsx':
      case '.ts':
      case '.jsx':
      case '.js':
        return Code;
      case '.json':
        return Settings;
      case '.css':
        return Palette;
      case '.md':
        return File;
      default:
        return File;
    }
  };

  const renderFileTree = (item: FileItem, level = 0) => {
    const Icon = getFileIcon(item);
    
    return (
      <div key={item.path} className="space-y-1">
        <div 
          className="flex items-center space-x-2 rtl:space-x-reverse py-1 px-2 rounded hover:bg-muted/50 transition-colors"
          style={{ paddingRight: `${level * 20 + 8}px` }}
        >
          <Icon size={16} className={`${item.type === 'directory' ? 'text-blue-500' : 'text-muted-foreground'}`} />
          <span className="text-sm font-mono">{item.name}</span>
          {item.type === 'file' && item.size && (
            <Badge variant="outline" className="text-xs ml-auto">
              {formatFileSize(item.size)}
            </Badge>
          )}
        </div>
        {item.children && (
          <div>
            {item.children.map(child => renderFileTree(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <FalconLayout 
      title="تصدير المشروع"
      subtitle="📁 تحميل ملفات المشروع كاملة في مجلد مضغوط"
    >
      {/* Export Header */}
      <Card className="mb-6 falcon-gradient border-primary/30 falcon-shadow">
        <CardContent className="p-6">
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-4 rtl:space-x-reverse">
              <FileArchive size={48} className="text-primary-foreground" />
              <div className="text-right rtl:text-right">
                <h2 className="text-2xl font-bold font-amiri text-primary-foreground">
                  📦 تصدير مشروع راكان الذكي
                </h2>
                <p className="text-primary-foreground/90 font-scheherazade">
                  احصل على نسخة كاملة من المشروع مع جميع الملفات والمكونات
                </p>
              </div>
            </div>
            
            <Button
              onClick={downloadProject}
              disabled={isLoading}
              size="lg"
              className="bg-white text-primary hover:bg-white/90 font-bold"
            >
              <Download className="ml-2 rtl:mr-2 rtl:ml-0" size={20} />
              {isLoading ? 'جاري التصدير...' : 'تحميل المشروع كاملاً'}
            </Button>
            
            {isLoading && downloadProgress > 0 && (
              <div className="space-y-2 max-w-md mx-auto">
                <div className="flex justify-between text-sm text-primary-foreground">
                  <span>التقدم</span>
                  <span>{downloadProgress.toFixed(0)}%</span>
                </div>
                <Progress value={downloadProgress} className="h-2" />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Project Statistics */}
      {projectStats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="border-primary/20 falcon-shadow">
            <CardContent className="p-4 text-center">
              <File className="w-8 h-8 text-blue-500 mx-auto mb-2" />
              <div className="font-bold text-lg font-arabic">إجمالي الملفات</div>
              <div className="text-2xl font-mono text-primary">{projectStats.totalFiles}</div>
            </CardContent>
          </Card>

          <Card className="border-primary/20 falcon-shadow">
            <CardContent className="p-4 text-center">
              <Package className="w-8 h-8 text-green-500 mx-auto mb-2" />
              <div className="font-bold text-lg font-arabic">حجم المشروع</div>
              <div className="text-2xl font-mono text-primary">{projectStats.totalSize}</div>
            </CardContent>
          </Card>

          <Card className="border-primary/20 falcon-shadow">
            <CardContent className="p-4 text-center">
              <Code className="w-8 h-8 text-purple-500 mx-auto mb-2" />
              <div className="font-bold text-lg font-arabic">المكونات</div>
              <div className="text-2xl font-mono text-primary">{projectStats.components}</div>
            </CardContent>
          </Card>

          <Card className="border-primary/20 falcon-shadow">
            <CardContent className="p-4 text-center">
              <CheckCircle className="w-8 h-8 text-orange-500 mx-auto mb-2" />
              <div className="font-bold text-lg font-arabic">آخر تحديث</div>
              <div className="text-sm font-mono text-primary">{projectStats.lastModified}</div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Languages and Technologies */}
      {projectStats && (
        <Card className="mb-6 border-primary/20 falcon-shadow">
          <CardHeader>
            <CardTitle className="font-amiri">التقنيات المستخدمة</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {projectStats.languages.map(lang => (
                <Badge key={lang} variant="secondary" className="font-arabic">
                  {lang}
                </Badge>
              ))}
              <Badge variant="secondary" className="font-arabic">React</Badge>
              <Badge variant="secondary" className="font-arabic">Vite</Badge>
              <Badge variant="secondary" className="font-arabic">Tailwind CSS</Badge>
              <Badge variant="secondary" className="font-arabic">shadcn/ui</Badge>
              <Badge variant="secondary" className="font-arabic">Express.js</Badge>
              <Badge variant="secondary" className="font-arabic">PostgreSQL</Badge>
              <Badge variant="secondary" className="font-arabic">OpenAI GPT-4o</Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Project Structure */}
      <Card className="border-primary/20 falcon-shadow">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 rtl:space-x-reverse font-amiri">
            <FolderOpen className="w-5 h-5" />
            <span>هيكل المشروع</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-h-96 overflow-y-auto bg-muted/20 p-4 rounded-lg">
            {projectStructure ? (
              <div className="space-y-1">
                {projectStructure.children?.map(item => renderFileTree(item))}
              </div>
            ) : (
              <div className="text-center text-muted-foreground">
                جاري تحميل هيكل المشروع...
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </FalconLayout>
  );
}