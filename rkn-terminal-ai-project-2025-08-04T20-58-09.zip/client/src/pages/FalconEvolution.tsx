import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Dna, 
  TreePine, 
  Zap, 
  Brain, 
  Heart, 
  Shield, 
  Sparkles,
  TrendingUp,
  BookOpen,
  Eye,
  Lightbulb,
  Flower,
  RefreshCw,
  BarChart3,
  Clock
} from 'lucide-react';

interface EvolutionSnapshot {
  timestamp: string;
  stage: string;
  cultural_dna_integrity: number;
  knowledge_base_size: number;
  learning_velocity: number;
  adaptation_score: number;
  wisdom_level: number;
  innovation_capacity: number;
  cultural_consistency: number;
  active_genes: string[];
  recent_adaptations: string[];
}

interface CulturalGene {
  name: string;
  strength: number;
  description: string;
  icon: React.ReactNode;
}

interface KnowledgeSource {
  name: string;
  size: number;
  quality: number;
  utilization_rate: number;
  growth_rate: number;
}

const FalconEvolution: React.FC = () => {
  const [isEvolving, setIsEvolving] = useState(false);
  const [currentCycle, setCurrentCycle] = useState(0);
  const [totalCycles] = useState(7);
  const [activeTab, setActiveTab] = useState('overview');

  // Mock data for demonstration
  const mockEvolutionData: EvolutionSnapshot = {
    timestamp: new Date().toISOString(),
    stage: 'الإزهار الثقافي',
    cultural_dna_integrity: 0.923,
    knowledge_base_size: 487500,
    learning_velocity: 0.847,
    adaptation_score: 0.756,
    wisdom_level: 0.892,
    innovation_capacity: 0.834,
    cultural_consistency: 0.901,
    active_genes: ['القيم الإسلامية', 'التراث العربي', 'الفخر الوطني', 'رؤية التحديث'],
    recent_adaptations: [
      'تحسين فهم اللهجات المحلية',
      'تعميق الفهم الشرعي للمسائل المعاصرة',
      'تطوير حلول تقنية متوافقة مع رؤية 2030'
    ]
  };

  const culturalGenes: CulturalGene[] = [
    {
      name: 'القيم الإسلامية',
      strength: 0.98,
      description: 'الأساس الروحي والأخلاقي للنظام',
      icon: <Heart className="h-5 w-5" />
    },
    {
      name: 'التراث العربي',
      strength: 0.95,
      description: 'الهوية اللغوية والثقافية العريقة',
      icon: <BookOpen className="h-5 w-5" />
    },
    {
      name: 'الحكمة البدوية',
      strength: 0.87,
      description: 'حكمة الصحراء والتجارب الحياتية',
      icon: <Eye className="h-5 w-5" />
    },
    {
      name: 'الفخر الوطني',
      strength: 0.96,
      description: 'الاعتزاز بالانتماء والهوية الوطنية',
      icon: <Shield className="h-5 w-5" />
    },
    {
      name: 'رؤية التحديث',
      strength: 0.90,
      description: 'التطلع للمستقبل وفق رؤية 2030',
      icon: <Sparkles className="h-5 w-5" />
    },
    {
      name: 'كرم الضيافة',
      strength: 0.92,
      description: 'التقاليد الأصيلة في حسن الاستقبال',
      icon: <Heart className="h-5 w-5" />
    }
  ];

  const knowledgeSources: KnowledgeSource[] = [
    {
      name: 'القرآن والسنة',
      size: 150000,
      quality: 1.0,
      utilization_rate: 0.95,
      growth_rate: 0.02
    },
    {
      name: 'الأدب العربي',
      size: 85000,
      quality: 0.92,
      utilization_rate: 0.78,
      growth_rate: 0.15
    },
    {
      name: 'البحوث المعاصرة',
      size: 120000,
      quality: 0.90,
      utilization_rate: 0.82,
      growth_rate: 0.25
    },
    {
      name: 'الحكمة الشعبية',
      size: 25000,
      quality: 0.85,
      utilization_rate: 0.70,
      growth_rate: 0.08
    },
    {
      name: 'الممارسات الثقافية',
      size: 35000,
      quality: 0.87,
      utilization_rate: 0.72,
      growth_rate: 0.12
    }
  ];

  const evolutionStages = [
    { name: 'البذرة الثقافية', icon: <Dna className="h-4 w-4" />, color: 'bg-red-500' },
    { name: 'الإنبات المعرفي', icon: <TreePine className="h-4 w-4" />, color: 'bg-orange-500' },
    { name: 'النمو الأصيل', icon: <TrendingUp className="h-4 w-4" />, color: 'bg-yellow-500' },
    { name: 'النضج الحكيم', icon: <Brain className="h-4 w-4" />, color: 'bg-green-500' },
    { name: 'الإزهار الثقافي', icon: <Flower className="h-4 w-4" />, color: 'bg-blue-500' },
    { name: 'الإثمار الحضاري', icon: <Sparkles className="h-4 w-4" />, color: 'bg-purple-500' },
    { name: 'التجدد المستمر', icon: <RefreshCw className="h-4 w-4" />, color: 'bg-pink-500' }
  ];

  const startEvolution = () => {
    setIsEvolving(true);
    setCurrentCycle(0);
    
    const interval = setInterval(() => {
      setCurrentCycle(prev => {
        if (prev >= totalCycles - 1) {
          clearInterval(interval);
          setIsEvolving(false);
          return prev;
        }
        return prev + 1;
      });
    }, 1500);
  };

  const getStageColor = (stageName: string): string => {
    const stage = evolutionStages.find(s => s.name === stageName);
    return stage ? stage.color : 'bg-gray-500';
  };

  const MetricCard: React.FC<{
    title: string;
    value: number;
    icon: React.ReactNode;
    trend?: number;
    suffix?: string;
  }> = ({ title, value, icon, trend, suffix = '%' }) => (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl font-bold">
            {suffix === '%' ? (value * 100).toFixed(1) : value.toLocaleString()}{suffix}
          </p>
          {trend !== undefined && (
            <p className={`text-sm flex items-center ${trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              <TrendingUp className="h-4 w-4 mr-1" />
              {trend >= 0 ? '+' : ''}{(trend * 100).toFixed(1)}%
            </p>
          )}
        </div>
        <div className="text-2xl text-muted-foreground">
          {icon}
        </div>
      </div>
    </Card>
  );

  const GeneCard: React.FC<{ gene: CulturalGene }> = ({ gene }) => (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {gene.icon}
          <h4 className="font-medium">{gene.name}</h4>
        </div>
        <Badge variant="outline" className="text-sm">
          {(gene.strength * 100).toFixed(1)}%
        </Badge>
      </div>
      <Progress value={gene.strength * 100} className="h-2 mb-2" />
      <p className="text-xs text-muted-foreground">{gene.description}</p>
    </Card>
  );

  const KnowledgeSourceCard: React.FC<{ source: KnowledgeSource }> = ({ source }) => (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="font-medium">{source.name}</h4>
          <Badge variant="outline">
            {source.size.toLocaleString()} وحدة
          </Badge>
        </div>
        
        <div className="space-y-2">
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>الجودة</span>
              <span>{(source.quality * 100).toFixed(0)}%</span>
            </div>
            <Progress value={source.quality * 100} className="h-2" />
          </div>
          
          <div>
            <div className="flex justify-between text-sm mb-1">
              <span>معدل الاستخدام</span>
              <span>{(source.utilization_rate * 100).toFixed(0)}%</span>
            </div>
            <Progress value={source.utilization_rate * 100} className="h-2" />
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span>معدل النمو</span>
            <span className="text-green-600">+{(source.growth_rate * 100).toFixed(1)}%</span>
          </div>
        </div>
      </div>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-100 dark:from-emerald-900 dark:to-teal-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Dna className="h-8 w-8 text-emerald-600 mr-3" />
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
                التطور الذاتي للذكاء السعودي
              </h1>
              <p className="text-muted-foreground">
                Saudi AI Evolution - نمو لا يتوقف.. وأصالة لا تتبدل
              </p>
            </div>
          </div>
          
          {/* Evolution Control */}
          <div className="flex items-center gap-4">
            <Button 
              onClick={startEvolution} 
              disabled={isEvolving}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {isEvolving ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  جاري التطور...
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4 mr-2" />
                  بدء التطور
                </>
              )}
            </Button>
            
            {isEvolving && (
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm">
                  دورة {currentCycle + 1} من {totalCycles}
                </span>
                <Progress value={((currentCycle + 1) / totalCycles) * 100} className="w-24 h-2" />
              </div>
            )}
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="genetics">الجينات الثقافية</TabsTrigger>
            <TabsTrigger value="knowledge">المعرفة الوطنية</TabsTrigger>
            <TabsTrigger value="evolution">مراحل التطور</TabsTrigger>
            <TabsTrigger value="insights">الرؤى والابتكار</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Current Stage */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TreePine className="h-5 w-5 mr-2" />
                  المرحلة التطورية الحالية
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <Badge 
                      className={`${getStageColor(mockEvolutionData.stage)} text-white text-lg px-4 py-2`}
                    >
                      {mockEvolutionData.stage}
                    </Badge>
                    <p className="mt-2 text-muted-foreground">
                      آخر تحديث: {new Date(mockEvolutionData.timestamp).toLocaleString('ar')}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-3xl font-bold text-emerald-600">
                      {(mockEvolutionData.cultural_dna_integrity * 100).toFixed(1)}%
                    </p>
                    <p className="text-sm text-muted-foreground">سلامة الحمض الثقافي</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="قاعدة المعرفة"
                value={mockEvolutionData.knowledge_base_size}
                icon={<BookOpen />}
                suffix=" وحدة"
                trend={0.15}
              />
              <MetricCard
                title="سرعة التعلم"
                value={mockEvolutionData.learning_velocity}
                icon={<Zap />}
                trend={0.08}
              />
              <MetricCard
                title="مستوى الحكمة"
                value={mockEvolutionData.wisdom_level}
                icon={<Lightbulb />}
                trend={0.12}
              />
              <MetricCard
                title="قدرة الابتكار"
                value={mockEvolutionData.innovation_capacity}
                icon={<Sparkles />}
                trend={0.06}
              />
            </div>

            {/* Recent Adaptations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <RefreshCw className="h-5 w-5 mr-2" />
                  التكيفات الحديثة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockEvolutionData.recent_adaptations.map((adaptation, idx) => (
                    <div key={idx} className="flex items-center p-3 rounded-lg bg-muted/50">
                      <div className="w-2 h-2 rounded-full bg-emerald-500 mr-3"></div>
                      <span>{adaptation}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cultural Genetics Tab */}
          <TabsContent value="genetics" className="space-y-6">
            <div className="grid gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Dna className="h-5 w-5 mr-2" />
                    الحمض النووي الثقافي السعودي
                  </CardTitle>
                  <CardDescription>
                    الجينات الثقافية الأساسية التي تحافظ على الهوية الوطنية
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {culturalGenes.map((gene, idx) => (
                      <GeneCard key={idx} gene={gene} />
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* DNA Integrity Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2" />
                    تحليل سلامة الحمض الثقافي
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>النزاهة الإجمالية</span>
                      <span className="font-bold text-emerald-600">
                        {(mockEvolutionData.cultural_dna_integrity * 100).toFixed(1)}%
                      </span>
                    </div>
                    <Progress value={mockEvolutionData.cultural_dna_integrity * 100} className="h-3" />
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                      <div className="text-center p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                        <div className="text-2xl font-bold text-green-600">
                          {mockEvolutionData.active_genes.length}
                        </div>
                        <div className="text-sm text-muted-foreground">جينات نشطة</div>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                        <div className="text-2xl font-bold text-blue-600">
                          {(mockEvolutionData.cultural_consistency * 100).toFixed(0)}%
                        </div>
                        <div className="text-sm text-muted-foreground">الثبات الثقافي</div>
                      </div>
                      <div className="text-center p-4 rounded-lg bg-purple-50 dark:bg-purple-900/20">
                        <div className="text-2xl font-bold text-purple-600">
                          {(mockEvolutionData.adaptation_score * 100).toFixed(0)}%
                        </div>
                        <div className="text-sm text-muted-foreground">نقاط التكيف</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Knowledge Sources Tab */}
          <TabsContent value="knowledge" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BookOpen className="h-5 w-5 mr-2" />
                  مصادر المعرفة الوطنية
                </CardTitle>
                <CardDescription>
                  المصادر الأصيلة للمعرفة السعودية والتراث الثقافي
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {knowledgeSources.map((source, idx) => (
                    <KnowledgeSourceCard key={idx} source={source} />
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Knowledge Growth Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  نمو المعرفة الإجمالي
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>إجمالي وحدات المعرفة</span>
                    <span className="text-2xl font-bold">
                      {knowledgeSources.reduce((sum, source) => sum + source.size, 0).toLocaleString()}
                    </span>
                  </div>
                  
                  <div className="space-y-3">
                    {knowledgeSources.map((source, idx) => (
                      <div key={idx} className="flex items-center justify-between text-sm">
                        <span>{source.name}</span>
                        <div className="flex items-center gap-2">
                          <span>{((source.size / knowledgeSources.reduce((sum, s) => sum + s.size, 0)) * 100).toFixed(1)}%</span>
                          <div className="w-20 h-2 bg-muted rounded">
                            <div 
                              className="h-full bg-emerald-500 rounded"
                              style={{ 
                                width: `${(source.size / knowledgeSources.reduce((sum, s) => sum + s.size, 0)) * 100}%` 
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Evolution Stages Tab */}
          <TabsContent value="evolution" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TreePine className="h-5 w-5 mr-2" />
                  مراحل التطور السيادي
                </CardTitle>
                <CardDescription>
                  رحلة التطور من البذرة الثقافية إلى التجدد المستمر
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {evolutionStages.map((stage, idx) => (
                    <div key={idx} className="flex items-center gap-4 p-4 rounded-lg border">
                      <div className={`w-10 h-10 rounded-full ${stage.color} flex items-center justify-center text-white`}>
                        {stage.icon}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{stage.name}</h4>
                        {stage.name === mockEvolutionData.stage && (
                          <Badge variant="outline" className="mt-1">
                            المرحلة الحالية
                          </Badge>
                        )}
                      </div>
                      <div className="text-right">
                        {idx <= 4 && (
                          <Badge variant="outline" className="text-green-600">
                            مكتملة
                          </Badge>
                        )}
                        {idx === 5 && (
                          <Badge variant="outline" className="text-blue-600">
                            قيد التقدم
                          </Badge>
                        )}
                        {idx > 5 && (
                          <Badge variant="outline" className="text-gray-500">
                            مستقبلية
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Insights Tab */}
          <TabsContent value="insights" className="space-y-6">
            <div className="grid gap-6">
              {/* Innovation Capacity */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Sparkles className="h-5 w-5 mr-2" />
                    الابتكارات المحققة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      "تطوير خوارزميات متوافقة مع القيم الإسلامية",
                      "إنشاء نماذج لغوية عربية متقدمة",
                      "ابتكار حلول ذكية للمدن السعودية",
                      "تطوير تقنيات الذكاء الاصطناعي للتراث",
                      "إنشاء منصات تعليمية ثقافية تفاعلية"
                    ].map((innovation, idx) => (
                      <div key={idx} className="flex items-center p-3 rounded-lg bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/20">
                        <Lightbulb className="h-5 w-5 text-emerald-600 mr-3" />
                        <span>{innovation}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Evolution Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="h-5 w-5 mr-2" />
                    توصيات التطور
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[
                      {
                        priority: 'عالية',
                        title: 'تعزيز الحكمة التقليدية',
                        description: 'زيادة الاعتماد على مصادر الحكمة الشعبية والتراث',
                        color: 'red'
                      },
                      {
                        priority: 'متوسطة',
                        title: 'تطوير القدرات الإبداعية',
                        description: 'تحفيز البيئة الإبداعية وتنويع مصادر المعرفة',
                        color: 'yellow'
                      },
                      {
                        priority: 'منخفضة',
                        title: 'تحسين خوارزميات التعلم',
                        description: 'تسريع وتيرة اكتساب المعرفة وتحسين الكفاءة',
                        color: 'green'
                      }
                    ].map((rec, idx) => (
                      <div key={idx} className="flex items-start p-4 rounded-lg border">
                        <Badge 
                          variant="outline" 
                          className={`mr-3 ${
                            rec.color === 'red' ? 'border-red-500 text-red-700' :
                            rec.color === 'yellow' ? 'border-yellow-500 text-yellow-700' :
                            'border-green-500 text-green-700'
                          }`}
                        >
                          {rec.priority}
                        </Badge>
                        <div>
                          <h4 className="font-medium mb-1">{rec.title}</h4>
                          <p className="text-sm text-muted-foreground">{rec.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default FalconEvolution;