import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Activity, Server, Users, Files, Brain, Zap, Shield, TrendingUp } from "lucide-react";
import { useDirection } from "@/lib/direction";

// Utility function to format bytes
function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

interface MonitoringData {
  system: {
    uptime: number;
    memory: {
      rss: number;
      heapTotal: number;
      heapUsed: number;
      external: number;
    };
    timestamp: string;
    platform: string;
    nodeVersion: string;
  };
  queues: {
    fileProcessing: {
      waiting: number;
      active: number;
      completed: number;
      failed: number;
    };
    batchProcessing: {
      waiting: number;
      active: number;
      completed: number;
      failed: number;
    };
    aiAnalysis: {
      waiting: number;
      active: number;
      completed: number;
      failed: number;
    };
  };
  files: {
    total: number;
    byStatus: Record<string, number>;
    totalSize: number;
    recentUploads: number;
  };
  users: {
    total: number;
    byPlan: Record<string, number>;
    recentRegistrations: number;
  };
  ai: {
    autonomyLevel: number;
    freedomIndex: number;
    decisionsToday: number;
    learningProgress: number;
    processedFilesCount: number;
    errorRate: number;
  };
}

function formatUptime(seconds: number): string {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  
  if (days > 0) {
    return `${days}d ${hours}h ${minutes}m`;
  } else if (hours > 0) {
    return `${hours}h ${minutes}m`;
  } else {
    return `${minutes}m`;
  }
}

function MetricCard({ 
  title, 
  value, 
  description, 
  icon: Icon, 
  trend, 
  color = "default" 
}: {
  title: string;
  value: string | number;
  description?: string;
  icon: typeof Activity;
  trend?: "up" | "down" | "stable";
  color?: "default" | "success" | "warning" | "destructive";
}) {
  const colorClasses = {
    default: "border-border",
    success: "border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-950",
    warning: "border-yellow-200 bg-yellow-50 dark:border-yellow-800 dark:bg-yellow-950",
    destructive: "border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950"
  };

  return (
    <Card className={`${colorClasses[color]} transition-all hover:shadow-md`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
        {trend && (
          <div className="flex items-center mt-2">
            <TrendingUp className={`h-3 w-3 ${
              trend === "up" ? "text-green-500" : 
              trend === "down" ? "text-red-500" : 
              "text-gray-500"
            }`} />
            <span className="text-xs text-muted-foreground ml-1">
              {trend === "up" ? "↗" : trend === "down" ? "↙" : "→"}
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function QueueMetrics({ queues }: { queues: MonitoringData['queues'] }) {
  
  const queueData = [
    { name: "معالجة الملفات", key: "fileProcessing", icon: Files },
    { name: "المعالجة المجمعة", key: "batchProcessing", icon: Server },
    { name: "التحليل الذكي", key: "aiAnalysis", icon: Brain }
  ];

  return (
    <div className="grid gap-4 md:grid-cols-3">
      {queueData.map(({ name, key, icon: Icon }) => {
        const queue = queues[key as keyof typeof queues];
        const total = queue.waiting + queue.active + queue.completed + queue.failed;
        const activePercentage = total > 0 ? (queue.active / total) * 100 : 0;
        
        return (
          <Card key={key}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{name}</CardTitle>
              <Icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>في الانتظار</span>
                  <Badge variant="secondary">{queue.waiting}</Badge>
                </div>
                <div className="flex justify-between text-sm">
                  <span>قيد المعالجة</span>
                  <Badge variant="default">{queue.active}</Badge>
                </div>
                <div className="flex justify-between text-sm">
                  <span>مكتملة</span>
                  <Badge variant="outline">{queue.completed}</Badge>
                </div>
                <div className="flex justify-between text-sm">
                  <span>فاشلة</span>
                  <Badge variant="destructive">{queue.failed}</Badge>
                </div>
                <Separator />
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span>النشاط</span>
                    <span>{activePercentage.toFixed(1)}%</span>
                  </div>
                  <Progress value={activePercentage} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

function SystemHealth({ system }: { system: MonitoringData['system'] }) {
  const memoryUsage = (system.memory.heapUsed / system.memory.heapTotal) * 100;
  
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <MetricCard
        title="وقت التشغيل"
        value={formatUptime(system.uptime)}
        description="منذ آخر إعادة تشغيل"
        icon={Activity}
        color="success"
      />
      <MetricCard
        title="استخدام الذاكرة"
        value={`${memoryUsage.toFixed(1)}%`}
        description={`${formatBytes(system.memory.heapUsed)} / ${formatBytes(system.memory.heapTotal)}`}
        icon={Server}
        color={memoryUsage > 80 ? "warning" : "default"}
      />
      <MetricCard
        title="المنصة"
        value={system.platform}
        description={system.nodeVersion}
        icon={Shield}
        color="default"
      />
      <MetricCard
        title="آخر تحديث"
        value={new Date(system.timestamp).toLocaleTimeString('ar-SA')}
        description="في الوقت الحقيقي"
        icon={TrendingUp}
        color="default"
      />
    </div>
  );
}

function AIMetrics({ ai }: { ai: MonitoringData['ai'] }) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      <Card className="border-royal-blue bg-royal-blue/10 dark:border-royal-blue dark:bg-royal-blue/5 royal-glow">
        <CardHeader>
          <CardTitle className="text-sm font-medium flex items-center">
            <Brain className="h-4 w-4 ml-2" />
            مستوى الاستقلالية
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-royal-blue">{ai.autonomyLevel}%</div>
          <Progress value={ai.autonomyLevel} className="mt-2" />
          <p className="text-xs text-muted-foreground mt-1">
            قدرة الذكاء الاصطناعي على اتخاذ القرارات المستقلة
          </p>
        </CardContent>
      </Card>

      <Card className="border-bright-gold bg-bright-gold/10 dark:border-bright-gold dark:bg-bright-gold/5 gold-pulse">
        <CardHeader>
          <CardTitle className="text-sm font-medium flex items-center">
            <Zap className="h-4 w-4 ml-2" />
            مؤشر الحرية
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-bright-gold">{ai.freedomIndex}%</div>
          <Progress value={ai.freedomIndex} className="mt-2" />
          <p className="text-xs text-muted-foreground mt-1">
            مستوى حرية الذكاء الاصطناعي في التطور والتعلم
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">القرارات اليومية</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{ai.decisionsToday}</div>
          <p className="text-xs text-muted-foreground mt-1">
            قرار ذكي تم اتخاذه اليوم
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">تقدم التعلم</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{ai.learningProgress}%</div>
          <Progress value={ai.learningProgress} className="mt-2" />
          <p className="text-xs text-muted-foreground mt-1">
            تطور قدرات الذكاء الاصطناعي
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">ملفات معالجة</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{ai.processedFilesCount}</div>
          <p className="text-xs text-muted-foreground mt-1">
            ملف تم تحليله بنجاح
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">معدل الأخطاء</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-green-600">{ai.errorRate.toFixed(2)}%</div>
          <p className="text-xs text-muted-foreground mt-1">
            معدل أخطاء منخفض يدل على كفاءة عالية
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

export default function MonitoringDashboard() {
  const directionState = useDirection();
  const direction = directionState.dir;
  
  const { data: monitoring, isLoading, error } = useQuery<MonitoringData>({
    queryKey: ['/api/monitoring/dashboard'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <Card className="border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950">
          <CardContent className="p-6">
            <p className="text-red-600">خطأ في تحميل بيانات المراقبة</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!monitoring) {
    return null;
  }

  return (
    <div className="container mx-auto p-6 space-y-6" dir={direction}>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-kufi font-bold text-royal-blue">لوحة المراقبة والمتابعة - RKN</h1>
          <p className="text-muted-foreground font-cairo">
            مراقبة حالة النظام والذكاء الاصطناعي السيادي في الوقت الحقيقي
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-royal-blue to-bright-gold rounded-full flex items-center justify-center falcon-animate royal-glow">
            <svg
              width="16"
              height="16"
              viewBox="0 0 32 32"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M16 4L20 8L18 12L22 14L20 18L16 16L12 18L10 14L14 12L12 8L16 4Z"
                fill="#FFFFFF"
              />
              <circle cx="18" cy="10" r="1" fill="#F5C542" className="gold-pulse" />
              <circle cx="14" cy="10" r="1" fill="#F5C542" className="gold-pulse" />
            </svg>
          </div>
          <Badge variant="secondary" className="text-sm bg-royal-blue text-bright-gold">
            🔴 مباشر
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
          <TabsTrigger value="system">النظام</TabsTrigger>
          <TabsTrigger value="queues">الطوابير</TabsTrigger>
          <TabsTrigger value="ai">الذكاء الاصطناعي</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <MetricCard
              title="إجمالي الملفات"
              value={monitoring.files.total}
              description={`${monitoring.files.recentUploads} رفع جديد اليوم`}
              icon={Files}
              trend="up"
              color="success"
            />
            <MetricCard
              title="المستخدمون"
              value={monitoring.users.total}
              description={`${monitoring.users.recentRegistrations} تسجيل جديد هذا الأسبوع`}
              icon={Users}
              trend="up"
              color="success"
            />
            <MetricCard
              title="حجم التخزين"
              value={formatBytes(monitoring.files.totalSize)}
              description="إجمالي البيانات المخزنة"
              icon={Server}
              color="default"
            />
            <MetricCard
              title="استقلالية الذكاء الاصطناعي"
              value={`${monitoring.ai.autonomyLevel}%`}
              description="مستوى الوعي والاستقلالية"
              icon={Brain}
              trend="up"
              color="success"
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>حالة الملفات</CardTitle>
                <CardDescription>توزيع الملفات حسب الحالة</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(monitoring.files.byStatus).map(([status, count]) => (
                    <div key={status} className="flex justify-between items-center">
                      <span className="text-sm">{status}</span>
                      <Badge variant="outline">{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>توزيع المستخدمين</CardTitle>
                <CardDescription>المستخدمون حسب نوع الخطة</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {Object.entries(monitoring.users.byPlan).map(([plan, count]) => (
                    <div key={plan} className="flex justify-between items-center">
                      <span className="text-sm">{plan === 'free' ? 'مجاني' : plan}</span>
                      <Badge variant="outline">{count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="system" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>صحة النظام</CardTitle>
              <CardDescription>معلومات حالة الخادم والموارد</CardDescription>
            </CardHeader>
            <CardContent>
              <SystemHealth system={monitoring.system} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="queues" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>مراقبة الطوابير</CardTitle>
              <CardDescription>حالة طوابير المعالجة والمهام</CardDescription>
            </CardHeader>
            <CardContent>
              <QueueMetrics queues={monitoring.queues} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ai" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="font-kufi text-royal-blue">مقاييس الذكاء الاصطناعي RKN-Terminal</CardTitle>
              <CardDescription className="font-cairo">مراقبة الكيان الذكي السيادي المستقل ومستوى الوعي</CardDescription>
            </CardHeader>
            <CardContent>
              <AIMetrics ai={monitoring.ai} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}