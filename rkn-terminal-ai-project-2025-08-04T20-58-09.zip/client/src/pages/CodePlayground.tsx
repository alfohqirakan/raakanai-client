import { useEffect, useRef, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import MultilingualChat from '@/components/MultilingualChat';
import MultilingualDemo from '@/components/MultilingualDemo';

// Monaco Editor types
declare global {
  interface Window {
    monaco: any;
    require: any;
    Terminal: any;
    FitAddon: any;
  }
}

export default function CodePlayground() {
  const editorRef = useRef<HTMLDivElement>(null);
  const terminalRef = useRef<HTMLDivElement>(null);
  const promptRef = useRef<HTMLTextAreaElement>(null);
  const langRef = useRef<HTMLSelectElement>(null);
  const complexityRef = useRef<HTMLSelectElement>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState('editor');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isExecuting, setIsExecuting] = useState(false);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [systemStats, setSystemStats] = useState({
    memory: 64,
    cpu: 42,
    status: 'متصل'
  });
  
  let editor: any = null;
  let terminal: any = null;

  useEffect(() => {
    // Load Monaco Editor
    const script1 = document.createElement('script');
    script1.src = 'https://cdn.jsdelivr.net/npm/monaco-editor@0.34.1/min/vs/loader.js';
    document.head.appendChild(script1);

    // Load XTerm and FitAddon
    const script2 = document.createElement('script');
    script2.src = 'https://cdn.jsdelivr.net/npm/xterm@5.4.0/lib/xterm.min.js';
    document.head.appendChild(script2);

    const script3 = document.createElement('script');
    script3.src = 'https://cdn.jsdelivr.net/npm/xterm-addon-fit@0.8.0/lib/xterm-addon-fit.min.js';
    document.head.appendChild(script3);

    // Load XTerm CSS
    const link = document.createElement('link');
    link.href = 'https://cdn.jsdelivr.net/npm/xterm@5.4.0/css/xterm.min.css';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    // Load Tajawal font
    const fontLink = document.createElement('link');
    fontLink.href = 'https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&display=swap';
    fontLink.rel = 'stylesheet';
    document.head.appendChild(fontLink);

    script1.onload = () => {
      script2.onload = () => {
        script3.onload = () => {
          initializeEditor();
          initializeTerminal();
        };
      };
    };

    return () => {
      document.head.removeChild(script1);
      document.head.removeChild(script2);
      document.head.removeChild(script3);
      document.head.removeChild(link);
      document.head.removeChild(fontLink);
    };
  }, []);

  const initializeEditor = () => {
    if (!window.require || !editorRef.current) return;
    
    window.require.config({ 
      paths: { vs: 'https://cdn.jsdelivr.net/npm/monaco-editor@0.34.1/min/vs' } 
    });
    
    window.require(["vs/editor/editor.main"], function () {
      if (editorRef.current) {
        editor = window.monaco.editor.create(editorRef.current, {
          value: `# مرحباً بك في محرر RKN-Terminal AI
# اكتب كودك هنا أو استخدم زر "توليد الكود" لإنشاء كود بالذكاء الاصطناعي

def hello_rakan():
    """
    دالة ترحيب من راكان AI
    """
    message = "مرحباً من RKN-Terminal AI!"
    print(message)
    
    # عرض معلومات النظام
    info = {
        "النظام": "راكان الذكاء السيادي",
        "الإصدار": "2025.1",
        "المطور": "المهندس راكان قاسم الفهيقي"
    }
    
    for key, value in info.items():
        print(f"{key}: {value}")
    
    return "تم التنفيذ بنجاح ✅"

# تنفيذ الدالة
result = hello_rakan()
print(f"النتيجة: {result}")`,
          language: "python",
          theme: "vs-dark",
          fontSize: 16,
          minimap: { enabled: false },
          automaticLayout: true,
          wordWrap: 'on',
          lineNumbers: 'on',
          folding: true,
          bracketMatching: 'always'
        });
      }
    });
  };

  const initializeTerminal = () => {
    if (!window.Terminal || !window.FitAddon || !terminalRef.current) return;
    
    terminal = new window.Terminal({
      fontSize: 14,
      cursorBlink: true,
      theme: {
        background: '#0C0C0C',
        foreground: '#FFFFFF',
        cursor: '#FFD700',
        selection: 'rgba(255, 215, 0, 0.3)',
        brightGreen: '#00ff00',
        brightYellow: '#FFD700',
        brightCyan: '#00FFFF'
      }
    });
    
    const fitAddon = new window.FitAddon();
    terminal.loadAddon(fitAddon);
    
    terminal.open(terminalRef.current);
    fitAddon.fit();
    
    terminal.writeln('⚡ RKN-Terminal AI - النسخة المحسنة');
    terminal.writeln('----------------------------------------------------');
    terminal.writeln('مرحباً ' + (user?.username || 'مطور') + '، أهلاً بك في محرر الأكواد الذكي');
    terminal.writeln('اكتب "مساعدة" للحصول على قائمة الأوامر المتاحة');
    terminal.writeln('----------------------------------------------------');
    terminal.write('$ ');
    
    // Handle terminal input
    terminal.onData((data: string) => {
      if (data === '\r') { // Enter
        terminal.write('\r\n$ ');
      } else if (data === '\u007F') { // Backspace
        terminal.write('\b \b');
      } else if (data === 'مساعدة') {
        terminal.write('\r\n--- الأوامر المتاحة ---\r\n');
        terminal.write('توليد - توليد كود جديد\r\n');
        terminal.write('تنفيذ - تنفيذ الكود الحالي\r\n');
        terminal.write('تقييم - تقييم جودة الكود\r\n');
        terminal.write('مسح - مسح الطرفية\r\n');
        terminal.write('$ ');
      } else {
        terminal.write(data);
      }
    });
  };

  const generateCode = async () => {
    if (!promptRef.current || !langRef.current) return;
    
    const prompt = promptRef.current.value;
    const lang = langRef.current.value;
    const complexity = complexityRef.current?.value || 'intermediate';
    
    if (!prompt.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى كتابة وصف دقيق للكود المطلوب",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    
    try {
      terminal?.write('\r\n\x1b[33m🪄 جاري توليد الكود باستخدام الذكاء الاصطناعي...\x1b[0m\r\n');
      terminal?.write(`اللغة: ${lang} | المستوى: ${complexity}\r\n`);
      
      const enhancedPrompt = `${prompt} (مستوى التعقيد: ${complexity})`;
      
      const response = await fetch('/api/ai/generate-code', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token') || ''}`
        },
        credentials: 'include',
        body: JSON.stringify({ prompt: enhancedPrompt, language: lang })
      });

      const data = await response.json();
      
      if (data.status === '✅ success' && data.data?.generatedCode) {
        editor?.setValue(data.data.generatedCode);
        terminal?.write(`\x1b[32m✓ تم توليد الكود بنجاح للغة ${lang}\x1b[0m\r\n`);
        terminal?.write('$ ');
        toast({
          title: "تم توليد الكود",
          description: "تم إنشاء الكود بنجاح باستخدام الذكاء الاصطناعي"
        });
      } else {
        terminal?.write(`\x1b[31m❌ فشل في التوليد: ${data.message || 'خطأ غير معروف'}\x1b[0m\r\n$ `);
        throw new Error(data.message || 'فشل في توليد الكود');
      }
    } catch (error) {
      console.error('Code generation error:', error);
      terminal?.write('\x1b[31m❌ خطأ في الاتصال بخدمة الذكاء الاصطناعي\x1b[0m\r\n$ ');
      toast({
        title: "خطأ في التوليد",
        description: "فشل في توليد الكود. يرجى المحاولة مرة أخرى",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const runCode = async () => {
    if (!editor || !langRef.current) return;
    
    const code = editor.getValue();
    const lang = langRef.current.value;
    
    if (!code.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى كتابة كود للتنفيذ",
        variant: "destructive"
      });
      return;
    }

    setIsExecuting(true);
    
    try {
      terminal?.write('\r\n\x1b[33m--- بدء التنفيذ ---\x1b[0m\r\n');
      terminal?.write('🚀 جاري تحليل وتنفيذ الكود...\r\n');
      terminal?.write('⚠️ ملاحظة: هذه محاكاة آمنة للتنفيذ\r\n');
      
      const response = await fetch('/api/ai/execute-code', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token') || ''}`
        },
        credentials: 'include',
        body: JSON.stringify({ code, language: lang })
      });

      const data = await response.json();
      
      if (data.status === '✅ success') {
        const output = data.data?.output || 'تم التنفيذ بنجاح';
        terminal?.write(`\r\n\x1b[32m✓ نتيجة المحاكاة:\x1b[0m\r\n${output}\r\n`);
        if (data.data?.executionNote) {
          terminal?.write(`\r\n📝 ${data.data.executionNote}\r\n`);
        }
        terminal?.write('\x1b[33m--- انتهى التنفيذ بنجاح ---\x1b[0m\r\n$ ');
      } else {
        terminal?.write(`\x1b[31m❌ خطأ: ${data.message}\x1b[0m\r\n$ `);
      }
    } catch (error) {
      console.error('Code execution error:', error);
      terminal?.write('\x1b[31m❌ فشل في تحليل الكود\x1b[0m\r\n$ ');
    } finally {
      setIsExecuting(false);
    }
  };

  const evaluateCode = async () => {
    if (!editor) return;
    
    const code = editor.getValue();
    
    if (!code.trim()) {
      toast({
        title: "خطأ",
        description: "يرجى كتابة كود للتقييم",
        variant: "destructive"
      });
      return;
    }

    setIsEvaluating(true);
    
    try {
      terminal?.write('\r\n\x1b[36m--- تقرير التقييم ---\x1b[0m\r\n');
      terminal?.write('🔍 جاري تقييم جودة الكود...\r\n');
      
      const response = await fetch('/api/ai/evaluate-code', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token') || ''}`
        },
        credentials: 'include',
        body: JSON.stringify({ code })
      });

      const data = await response.json();
      
      if (data.status === '✅ success' && data.data?.evaluation) {
        // Show quick evaluation in terminal
        const codeLength = code.length;
        terminal?.write('\r\n');
        if (codeLength > 200) {
          terminal?.write('✓ جودة الكود: جيدة\r\n');
          terminal?.write('✓ قابلية القراءة: ممتازة\r\n');
          terminal?.write('⚠ التعقيد: يمكن تبسيط بعض الأجزاء\r\n');
          terminal?.write('✓ الأمان: لا توجد مشاكل أمنية واضحة\r\n');
        } else {
          terminal?.write('✓ جودة الكود: مقبولة\r\n');
          terminal?.write('✓ قابلية القراءة: جيدة\r\n');
          terminal?.write('✓ التعقيد: بسيط\r\n');
          terminal?.write('✓ الأمان: لا توجد مشاكل أمنية\r\n');
        }
        
        const evaluation = `# تقييم الكود - RKN-Terminal AI
# ${new Date().toLocaleString('ar-SA')}
# ========================================

${data.data.evaluation}

# ========================================
# الكود الأصلي:
# ========================================
${code}`;
        
        editor.setValue(evaluation);
        terminal?.write('\x1b[36m--- نهاية التقرير ---\x1b[0m\r\n');
        terminal?.write('\x1b[32m✓ تم إنجاز التقييم الشامل وعرضه في المحرر\x1b[0m\r\n$ ');
        toast({
          title: "تم التقييم",
          description: "تم تقييم الكود بنجاح"
        });
      } else {
        terminal?.write(`\x1b[31m❌ فشل التقييم: ${data.message || 'خطأ غير معروف'}\x1b[0m\r\n$ `);
        throw new Error(data.message || 'فشل في تقييم الكود');
      }
    } catch (error) {
      console.error('Code evaluation error:', error);
      terminal?.write('\x1b[31m❌ خطأ في خدمة تقييم الكود\x1b[0m\r\n$ ');
      toast({
        title: "خطأ في التقييم",
        description: "فشل في تقييم الكود. يرجى المحاولة مرة أخرى",
        variant: "destructive"
      });
    } finally {
      setIsEvaluating(false);
    }
  };

  const copyCode = () => {
    if (!editor) return;
    
    const code = editor.getValue();
    navigator.clipboard.writeText(code).then(() => {
      terminal?.write('\r\n\x1b[32m✓ تم نسخ الكود إلى الحافظة\x1b[0m\r\n$ ');
      toast({
        title: "تم النسخ",
        description: "تم نسخ الكود إلى الحافظة"
      });
    });
  };

  const clearAll = () => {
    if (editor) {
      editor.setValue('# اكتب كودك هنا...');
    }
    if (terminal) {
      terminal.clear();
      terminal.write('$ ');
    }
    if (promptRef.current) {
      promptRef.current.value = '';
    }
    toast({
      title: "تم المسح",
      description: "تم مسح جميع المحتويات"
    });
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden text-white"
         style={{
           fontFamily: 'Tajawal, sans-serif',
           background: 'radial-gradient(circle at center, #0a1929 0%, #07121f 70%, #050e18 100%)'
         }}>
      
      {/* Header */}
      <header className="bg-gradient-to-r from-[#001e3c] to-[#000d1a] border-b border-yellow-500 py-3 px-6 flex justify-between items-center">
        <div className="flex items-center">
          <div className="bg-gray-800 border-2 border-yellow-500 rounded-lg w-12 h-12 flex items-center justify-center mr-3">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#FFD700" className="w-8 h-8">
              <path d="M5.223 2.25c-.497 0-.974.198-1.325.55l-1.3 1.298A3.75 3.75 0 007.5 9.75c.627.47 1.406.75 2.25.75.844 0 1.624-.28 2.25-.75.626.47 1.406.75 2.25.75.844 0 1.623-.28 2.25-.75a3.75 3.75 0 004.902-5.652l-1.3-1.299a1.875 1.875 0 00-1.325-.549H5.223z" />
              <path fillRule="evenodd" d="M3 20.25v-8.755c1.42.674 3.08.673 4.5 0A5.234 5.234 0 009.75 12c.804 0 1.568-.182 2.25-.506a5.234 5.234 0 002.25.506c.804 0 1.567-.182 2.25-.506 1.42.674 3.08.675 4.5.001v8.755h.75a.75.75 0 010 1.5H2.25a.75.75 0 010-1.5H3zm3-6a.75.75 0 01.75-.75h3a.75.75 0 01.75.75v3a.75.75 0 01-.75.75h-3a.75.75 0 01-.75-.75v-3zm8.25-.75a.75.75 0 00-.75.75v5.25a.75.75 0 001.5 0V14a.75.75 0 00-.75-.75z" clipRule="evenodd" />
            </svg>
          </div>
          <div>
            <h1 className="text-2xl font-bold" style={{ textShadow: '0 0 8px rgba(255, 215, 0, 0.7)' }}>
              RKN-Terminal AI
            </h1>
            <div className="flex items-center text-sm text-yellow-300">
              <span>{systemStats.status}</span>
              <span className="w-2.5 h-2.5 bg-green-400 rounded-full ml-2 animate-pulse"
                    style={{ boxShadow: '0 0 8px #00ff00' }}></span>
            </div>
          </div>
        </div>
        <div className="flex space-x-3 rtl:space-x-reverse">
          <button 
            onClick={copyCode}
            className="px-4 py-2 bg-blue-800 rounded-lg hover:bg-blue-700 transition flex items-center"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
            حفظ الكود
          </button>
          <button className="px-4 py-2 bg-[#0C2D48] rounded-lg hover:bg-[#145DA0] transition flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
              <path d="M5 4a1 1 0 00-2 0v7.268a2 2 0 000 3.464V16a1 1 0 102 0v-1.268a2 2 0 000-3.464V4zM11 4a1 1 0 10-2 0v1.268a2 2 0 000 3.464V16a1 1 0 102 0V8.732a2 2 0 000-3.464V4zM16 3a1 1 0 011 1v7.268a2 2 0 010 3.464V16a1 1 0 11-2 0v-1.268a2 2 0 010-3.464V4a1 1 0 011-1z" />
            </svg>
            الإعدادات
          </button>
        </div>
      </header>
      
      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden"
           style={{
             backgroundImage: 'radial-gradient(circle at center, rgba(0, 180, 216, 0.05) 0%, transparent 70%), linear-gradient(to right, rgba(255, 215, 0, 0.03) 1px, transparent 1px), linear-gradient(to bottom, rgba(255, 215, 0, 0.03) 1px, transparent 1px)',
             backgroundSize: '100% 100%, 30px 30px, 30px 30px'
           }}>
        
        {/* Editor Panel */}
        <div className="w-2/3 h-full flex flex-col relative">
          <div className="flex bg-[#001e3c] border-b border-yellow-500 px-4">
            <button 
              className={`px-4 py-2 ${activeTab === 'editor' ? 'text-yellow-300 border-b-2 border-yellow-500' : 'text-gray-400 hover:text-yellow-300'}`}
              onClick={() => setActiveTab('editor')}
            >
              المحرر
            </button>
            <button 
              className={`px-4 py-2 ${activeTab === 'docs' ? 'text-yellow-300 border-b-2 border-yellow-500' : 'text-gray-400 hover:text-yellow-300'}`}
              onClick={() => setActiveTab('docs')}
            >
              التوثيق
            </button>
            <button 
              className={`px-4 py-2 ${activeTab === 'examples' ? 'text-yellow-300 border-b-2 border-yellow-500' : 'text-gray-400 hover:text-yellow-300'}`}
              onClick={() => setActiveTab('examples')}
            >
              الأمثلة
            </button>
            <button 
              className={`px-4 py-2 ${activeTab === 'multilingual' ? 'text-yellow-300 border-b-2 border-yellow-500' : 'text-gray-400 hover:text-yellow-300'}`}
              onClick={() => setActiveTab('multilingual')}
            >
              🌍 متعدد اللغات
            </button>
            <button 
              className={`px-4 py-2 ${activeTab === 'demo' ? 'text-yellow-300 border-b-2 border-yellow-500' : 'text-gray-400 hover:text-yellow-300'}`}
              onClick={() => setActiveTab('demo')}
            >
              🧪 عرض توضيحي
            </button>
          </div>
          {activeTab === 'editor' && <div ref={editorRef} className="flex-1"></div>}
          {activeTab === 'docs' && (
            <div className="flex-1 p-6 bg-[#0a1929] overflow-y-auto">
              <div className="prose prose-invert max-w-none">
                <h1 className="text-yellow-400">📚 دليل RKN-Terminal AI</h1>
                <h2 className="text-yellow-300">🚀 البدء السريع</h2>
                <ul className="text-gray-300">
                  <li>اكتب وصف الكود المطلوب في المربع الجانبي</li>
                  <li>اختر لغة البرمجة ومستوى التعقيد</li>
                  <li>اضغط "توليد الكود" لإنشاء الكود بالذكاء الاصطناعي</li>
                  <li>استخدم "تنفيذ" لمحاكاة تشغيل الكود</li>
                  <li>استخدم "تقييم" للحصول على تقرير جودة مفصل</li>
                </ul>
                <h2 className="text-yellow-300">🎯 نصائح للحصول على أفضل النتائج</h2>
                <ul className="text-gray-300">
                  <li>كن محدداً في وصف المتطلبات</li>
                  <li>اذكر المدخلات والمخرجات المطلوبة</li>
                  <li>حدد أي مكتبات أو frameworks مطلوبة</li>
                  <li>اختر مستوى التعقيد المناسب لخبرتك</li>
                </ul>
                <h2 className="text-yellow-300">🌍 الدعم متعدد اللغات</h2>
                <p className="text-gray-300">
                  يدعم RKN-Terminal AI التواصل بـ 15 لغة مختلفة من خلال تبويب "متعدد اللغات"
                </p>
              </div>
            </div>
          )}
          {activeTab === 'examples' && (
            <div className="flex-1 p-6 bg-[#0a1929] overflow-y-auto">
              <div className="space-y-6">
                <h1 className="text-2xl font-bold text-yellow-400">📝 أمثلة تطبيقية</h1>
                <div className="grid gap-4">
                  <div className="bg-black/30 p-4 rounded-lg border border-yellow-500/30">
                    <h3 className="text-yellow-300 font-bold mb-2">حاسبة بسيطة</h3>
                    <p className="text-gray-300 mb-2">مثال: "اكتب دالة حاسبة تقوم بالعمليات الأساسية الأربع"</p>
                    <code className="text-green-400 text-sm">Python • مستوى مبتدئ</code>
                  </div>
                  <div className="bg-black/30 p-4 rounded-lg border border-yellow-500/30">
                    <h3 className="text-yellow-300 font-bold mb-2">API client</h3>
                    <p className="text-gray-300 mb-2">مثال: "اكتب كود JavaScript لجلب البيانات من API واستعراضها"</p>
                    <code className="text-blue-400 text-sm">JavaScript • مستوى متوسط</code>
                  </div>
                  <div className="bg-black/30 p-4 rounded-lg border border-yellow-500/30">
                    <h3 className="text-yellow-300 font-bold mb-2">قاعدة بيانات</h3>
                    <p className="text-gray-300 mb-2">مثال: "اكتب استعلامات SQL لإنشاء جدول المستخدمين وإدارته"</p>
                    <code className="text-purple-400 text-sm">SQL • مستوى متقدم</code>
                  </div>
                </div>
              </div>
            </div>
          )}
          {activeTab === 'multilingual' && (
            <div className="flex-1">
              <MultilingualChat />
            </div>
          )}
          {activeTab === 'demo' && (
            <div className="flex-1">
              <MultilingualDemo />
            </div>
          )}
        </div>
        
        {/* Control Panel */}
        <div className="w-1/3 h-full flex flex-col border-l border-yellow-500"
             style={{
               background: 'rgba(0, 30, 60, 0.85)',
               backdropFilter: 'blur(10px)'
             }}>
          <div className="p-6 flex flex-col space-y-6">
            <div>
              <h2 className="text-xl font-bold text-yellow-400 mb-2">طلب الذكاء الاصطناعي</h2>
              <textarea 
                ref={promptRef}
                rows={4} 
                placeholder="اكتب وصفًا دقيقًا للكود الذي تريد إنشاءه..."
                className="w-full p-4 bg-[#0a1929] rounded-lg text-white border border-yellow-600 focus:border-yellow-400 focus:ring-1 focus:ring-yellow-500 transition resize-none"
                style={{ scrollbarWidth: 'thin', scrollbarColor: '#FFD700 rgba(0, 30, 60, 0.5)' }}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-yellow-300 mb-2">لغة البرمجة</label>
                <select 
                  ref={langRef}
                  className="w-full bg-[#0a1929] text-white p-3 rounded-lg border border-yellow-500 focus:border-yellow-400 focus:ring-1 focus:ring-yellow-500 transition"
                >
                  <option value="python">Python</option>
                  <option value="javascript">JavaScript</option>
                  <option value="typescript">TypeScript</option>
                  <option value="html">HTML</option>
                  <option value="css">CSS</option>
                  <option value="java">Java</option>
                  <option value="csharp">C#</option>
                  <option value="php">PHP</option>
                </select>
              </div>
              
              <div>
                <label className="block text-yellow-300 mb-2">مستوى التعقيد</label>
                <select 
                  ref={complexityRef}
                  className="w-full bg-[#0a1929] text-white p-3 rounded-lg border border-yellow-500 focus:border-yellow-400 focus:ring-1 focus:ring-yellow-500 transition"
                >
                  <option value="beginner">مبتدئ</option>
                  <option value="intermediate">متوسط</option>
                  <option value="advanced">متقدم</option>
                  <option value="expert">خبير</option>
                </select>
              </div>
            </div>
            
            <div className="grid grid-cols-3 gap-3">
              <button 
                onClick={generateCode}
                disabled={isGenerating}
                className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-black font-bold py-3 rounded-lg flex items-center justify-center transition hover:shadow-lg hover:shadow-yellow-500/30 disabled:opacity-50"
              >
                {isGenerating ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-black"></div>
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 01-.945-1.067c-.328-.68-.398-1.534-.398-2.654A1 1 0 005.05 6.05 6.981 6.981 0 003 11a7 7 0 1011.95-4.95c-.592-.591-.98-.985-1.348-1.467-.363-.476-.724-1.063-1.207-2.03zM12.12 15.12A3 3 0 017 13s.879.5 2.5.5c0-1 .5-4 1.25-4.5.5 1 .786 1.293 1.371 1.879A2.99 2.99 0 0113 13a2.99 2.99 0 01-.879 2.121z" clipRule="evenodd" />
                    </svg>
                    توليد الكود
                  </>
                )}
              </button>
              
              <button 
                onClick={runCode}
                disabled={isExecuting}
                className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-bold py-3 rounded-lg flex items-center justify-center transition hover:shadow-lg hover:shadow-cyan-500/30 disabled:opacity-50"
              >
                {isExecuting ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                    </svg>
                    تنفيذ
                  </>
                )}
              </button>
              
              <button 
                onClick={evaluateCode}
                disabled={isEvaluating}
                className="bg-gradient-to-r from-purple-500 to-indigo-700 text-white font-bold py-3 rounded-lg flex items-center justify-center transition hover:shadow-lg hover:shadow-purple-500/30 disabled:opacity-50"
              >
                {isEvaluating ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  <>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                    </svg>
                    تقييم
                  </>
                )}
              </button>
            </div>
            
            <div className="flex space-x-3 rtl:space-x-reverse">
              <button 
                onClick={copyCode}
                className="flex-1 bg-[#0C2D48] py-2.5 rounded-lg border border-yellow-500 hover:bg-[#145DA0] transition flex items-center justify-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M8 3a1 1 0 011-1h2a1 1 0 110 2H9a1 1 0 01-1-1z" />
                  <path d="M6 3a2 2 0 00-2 2v11a2 2 0 002 2h8a2 2 0 002-2V5a2 2 0 00-2-2 3 3 0 01-3 3H9a3 3 0 01-3-3z" />
                </svg>
                نسخ الكود
              </button>
              <button 
                onClick={clearAll}
                className="flex-1 bg-[#0C2D48] py-2.5 rounded-lg border border-yellow-500 hover:bg-[#145DA0] transition flex items-center justify-center"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 ml-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                مسح الكل
              </button>
            </div>
          </div>
          
          <div className="flex-1 flex flex-col border-t border-yellow-500">
            <div className="bg-[#001e3c] px-4 py-2 flex items-center justify-between">
              <h3 className="font-bold text-yellow-300">الطرفية</h3>
              <div className="flex space-x-2 rtl:space-x-reverse">
                <button 
                  onClick={() => terminal?.clear()}
                  className="text-gray-400 hover:text-yellow-300 p-1"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
            <div ref={terminalRef} className="flex-1 bg-black p-2"></div>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="bg-[#001e3c] border-t border-yellow-500 py-2 px-6 flex justify-between text-sm text-gray-400">
        <div>RKN-Terminal AI v2.0 - النسخة المحسنة</div>
        <div className="flex space-x-4 rtl:space-x-reverse">
          <span>الحالة: <span className="text-green-400">{systemStats.status}</span></span>
          <span>الذاكرة: <span className="text-yellow-300">{systemStats.memory}%</span></span>
          <span>وحدة المعالجة: <span className="text-yellow-300">{systemStats.cpu}%</span></span>
        </div>
      </footer>
    </div>
  );
}