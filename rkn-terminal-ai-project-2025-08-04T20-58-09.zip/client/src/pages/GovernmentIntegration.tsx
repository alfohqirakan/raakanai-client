import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Network, 
  Shield, 
  Lock, 
  Globe, 
  Building2, 
  Zap,
  AlertTriangle,
  CheckCircle,
  XCircle,
  TrendingUp,
  BarChart3,
  Activity,
  Database,
  Cpu,
  Wifi,
  Server,
  Eye,
  Settings,
  MapPin,
  Users
} from 'lucide-react';

interface GovernmentEntity {
  id: string;
  name: string;
  nameEn: string;
  zone: 'NATIONAL_SECURITY' | 'GOVERNMENT_SERVICES' | 'ECONOMIC' | 'SOCIAL_SERVICES' | 'PUBLIC';
  clearance: 'TOP_SECRET' | 'SECRET' | 'CONFIDENTIAL' | 'RESTRICTED' | 'INTERNAL' | 'PUBLIC';
  location: string;
  status: 'active' | 'inactive' | 'maintenance';
  connections: number;
  processingCapacity: number;
}

interface ConnectionStatus {
  id: string;
  fromEntity: string;
  toEntity: string;
  integrationLevel: 'FULL' | 'PARTIAL' | 'READ_ONLY' | 'SECURE_CHANNEL' | 'EMERGENCY_ONLY';
  securityClassification: string;
  isEncrypted: boolean;
  dataVolume: number;
  lastActive: string;
  complianceScore: number;
}

interface SovereigntyMetrics {
  totalEntities: number;
  activeConnections: number;
  dataSovereigntyScore: number;
  securityComplianceRate: number;
  integrationEfficiency: number;
  crossEntityTransactions: number;
  blockedViolations: number;
}

const GovernmentIntegration: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [isMonitoring, setIsMonitoring] = useState(true);
  const [emergencyMode, setEmergencyMode] = useState(false);

  // Mock data for demonstration
  const entities: GovernmentEntity[] = [
    {
      id: 'MOI',
      name: 'وزارة الداخلية',
      nameEn: 'Ministry of Interior',
      zone: 'NATIONAL_SECURITY',
      clearance: 'SECRET',
      location: 'الرياض - مجمع الوزارات',
      status: 'active',
      connections: 12,
      processingCapacity: 10000
    },
    {
      id: 'MOD',
      name: 'وزارة الدفاع',
      nameEn: 'Ministry of Defense',
      zone: 'NATIONAL_SECURITY',
      clearance: 'SECRET',
      location: 'الرياض - منطقة الملك عبدالعزيز العسكرية',
      status: 'active',
      connections: 8,
      processingCapacity: 15000
    },
    {
      id: 'MOF',
      name: 'وزارة المالية',
      nameEn: 'Ministry of Finance',
      zone: 'ECONOMIC',
      clearance: 'CONFIDENTIAL',
      location: 'الرياض - مركز الملك عبدالله المالي',
      status: 'active',
      connections: 15,
      processingCapacity: 12000
    },
    {
      id: 'MOH',
      name: 'وزارة الصحة',
      nameEn: 'Ministry of Health',
      zone: 'SOCIAL_SERVICES',
      clearance: 'RESTRICTED',
      location: 'الرياض - مجمع الوزارات',
      status: 'active',
      connections: 10,
      processingCapacity: 8000
    },
    {
      id: 'ARAMCO',
      name: 'أرامكو السعودية',
      nameEn: 'Saudi Aramco',
      zone: 'ECONOMIC',
      clearance: 'CONFIDENTIAL',
      location: 'الظهران - مقر أرامكو',
      status: 'active',
      connections: 6,
      processingCapacity: 20000
    },
    {
      id: 'NEOM',
      name: 'نيوم',
      nameEn: 'NEOM',
      zone: 'ECONOMIC',
      clearance: 'RESTRICTED',
      location: 'تبوك - مدينة نيوم المستقبلية',
      status: 'active',
      connections: 4,
      processingCapacity: 25000
    }
  ];

  const connections: ConnectionStatus[] = [
    {
      id: 'CONN_001',
      fromEntity: 'وزارة الداخلية',
      toEntity: 'وزارة الصحة',
      integrationLevel: 'PARTIAL',
      securityClassification: 'CONFIDENTIAL',
      isEncrypted: true,
      dataVolume: 1024000,
      lastActive: '2025-08-03T18:30:00Z',
      complianceScore: 0.95
    },
    {
      id: 'CONN_002',
      fromEntity: 'وزارة المالية',
      toEntity: 'البنك المركزي السعودي',
      integrationLevel: 'SECURE_CHANNEL',
      securityClassification: 'SECRET',
      isEncrypted: true,
      dataVolume: 2048000,
      lastActive: '2025-08-03T18:25:00Z',
      complianceScore: 0.98
    },
    {
      id: 'CONN_003',
      fromEntity: 'نيوم',
      toEntity: 'صندوق الاستثمارات العامة',
      integrationLevel: 'SECURE_CHANNEL',
      securityClassification: 'RESTRICTED',
      isEncrypted: true,
      dataVolume: 512000,
      lastActive: '2025-08-03T18:20:00Z',
      complianceScore: 0.92
    }
  ];

  const metrics: SovereigntyMetrics = {
    totalEntities: 24,
    activeConnections: 47,
    dataSovereigntyScore: 0.96,
    securityComplianceRate: 0.94,
    integrationEfficiency: 0.89,
    crossEntityTransactions: 1847,
    blockedViolations: 12
  };

  const getZoneColor = (zone: string): string => {
    const colors = {
      NATIONAL_SECURITY: 'bg-red-100 text-red-800 border-red-200',
      GOVERNMENT_SERVICES: 'bg-blue-100 text-blue-800 border-blue-200',
      ECONOMIC: 'bg-green-100 text-green-800 border-green-200',
      SOCIAL_SERVICES: 'bg-purple-100 text-purple-800 border-purple-200',
      PUBLIC: 'bg-gray-100 text-gray-800 border-gray-200'
    };
    return colors[zone as keyof typeof colors] || colors.PUBLIC;
  };

  const getZoneName = (zone: string): string => {
    const names = {
      NATIONAL_SECURITY: 'الأمن الوطني',
      GOVERNMENT_SERVICES: 'الخدمات الحكومية',
      ECONOMIC: 'الاقتصادية',
      SOCIAL_SERVICES: 'الخدمات الاجتماعية',
      PUBLIC: 'العامة'
    };
    return names[zone as keyof typeof names] || 'غير محدد';
  };

  const getClearanceColor = (clearance: string): string => {
    const colors = {
      TOP_SECRET: 'bg-red-600',
      SECRET: 'bg-red-500',
      CONFIDENTIAL: 'bg-orange-500',
      RESTRICTED: 'bg-yellow-500',
      INTERNAL: 'bg-blue-500',
      PUBLIC: 'bg-green-500'
    };
    return colors[clearance as keyof typeof colors] || 'bg-gray-500';
  };

  const getIntegrationLevelText = (level: string): string => {
    const levels = {
      FULL: 'تكامل كامل',
      PARTIAL: 'تكامل جزئي',
      READ_ONLY: 'قراءة فقط',
      SECURE_CHANNEL: 'قناة آمنة',
      EMERGENCY_ONLY: 'طوارئ فقط'
    };
    return levels[level as keyof typeof levels] || 'غير محدد';
  };

  const MetricCard: React.FC<{
    title: string;
    value: number;
    icon: React.ReactNode;
    trend?: number;
    suffix?: string;
    description?: string;
  }> = ({ title, value, icon, trend, suffix = '%', description }) => (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl font-bold">
            {suffix === '%' ? (value * 100).toFixed(1) : value.toLocaleString()}{suffix}
          </p>
          {trend !== undefined && (
            <p className={`text-sm flex items-center ${trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              <TrendingUp className="h-4 w-4 mr-1" />
              {trend >= 0 ? '+' : ''}{(trend * 100).toFixed(1)}%
            </p>
          )}
          {description && (
            <p className="text-xs text-muted-foreground mt-1">{description}</p>
          )}
        </div>
        <div className="text-2xl text-muted-foreground">
          {icon}
        </div>
      </div>
    </Card>
  );

  const EntityCard: React.FC<{ entity: GovernmentEntity }> = ({ entity }) => (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium">{entity.name}</h4>
            <p className="text-sm text-muted-foreground">{entity.nameEn}</p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={getZoneColor(entity.zone)}>
              {getZoneName(entity.zone)}
            </Badge>
            {entity.status === 'active' ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <XCircle className="h-4 w-4 text-red-600" />
            )}
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm">
            <Shield className="h-4 w-4" />
            <span>التصريح:</span>
            <div className={`w-3 h-3 rounded-full ${getClearanceColor(entity.clearance)}`}></div>
            <span>{entity.clearance}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            <MapPin className="h-4 w-4" />
            <span>{entity.location}</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            <Network className="h-4 w-4" />
            <span>{entity.connections} اتصال نشط</span>
          </div>
          
          <div className="flex items-center gap-2 text-sm">
            <Cpu className="h-4 w-4" />
            <span>قدرة المعالجة: {entity.processingCapacity.toLocaleString()}</span>
          </div>
        </div>
        
        <div className="pt-2 border-t">
          <div className="flex justify-between text-sm">
            <span>كفاءة التشغيل</span>
            <span>{Math.min(100, (entity.processingCapacity / 200)).toFixed(0)}%</span>
          </div>
          <Progress value={Math.min(100, (entity.processingCapacity / 200))} className="h-2 mt-1" />
        </div>
      </div>
    </Card>
  );

  const ConnectionCard: React.FC<{ connection: ConnectionStatus }> = ({ connection }) => (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-medium">{connection.id}</span>
          <div className="flex items-center gap-2">
            {connection.isEncrypted && <Lock className="h-4 w-4 text-green-600" />}
            <Badge variant="outline">
              {getIntegrationLevelText(connection.integrationLevel)}
            </Badge>
          </div>
        </div>
        
        <div className="space-y-1 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">من:</span>
            <span>{connection.fromEntity}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">إلى:</span>
            <span>{connection.toEntity}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">التصنيف الأمني:</span>
            <span>{connection.securityClassification}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">حجم البيانات:</span>
            <span>{(connection.dataVolume / 1024).toFixed(0)} KB</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">آخر نشاط:</span>
            <span>{new Date(connection.lastActive).toLocaleTimeString('ar')}</span>
          </div>
        </div>
        
        <div className="pt-2 border-t">
          <div className="flex justify-between text-sm">
            <span>نقاط الامتثال</span>
            <span>{(connection.complianceScore * 100).toFixed(1)}%</span>
          </div>
          <Progress value={connection.complianceScore * 100} className="h-2 mt-1" />
        </div>
      </div>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-blue-900 dark:to-indigo-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <Network className="h-8 w-8 text-blue-600 mr-3" />
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                محرك التكامل الحكومي
              </h1>
              <p className="text-muted-foreground">
                Saudi Government Integration - الشبكة العصبية الرقمية للمؤسسات الوطنية
              </p>
            </div>
          </div>
          
          {/* Status and Controls */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className={`w-3 h-3 rounded-full ${isMonitoring ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <span className="text-sm">
                  {isMonitoring ? 'المراقبة نشطة' : 'المراقبة متوقفة'}
                </span>
              </div>
              
              {emergencyMode && (
                <Alert className="p-2 border-red-200 bg-red-50">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    بروتوكول الطوارئ مفعل
                  </AlertDescription>
                </Alert>
              )}
            </div>
            
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setIsMonitoring(!isMonitoring)}
              >
                {isMonitoring ? 'إيقاف المراقبة' : 'بدء المراقبة'}
              </Button>
              
              <Button 
                variant={emergencyMode ? "destructive" : "secondary"}
                size="sm"
                onClick={() => setEmergencyMode(!emergencyMode)}
              >
                {emergencyMode ? 'إلغاء الطوارئ' : 'بروتوكول الطوارئ'}
              </Button>
            </div>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="entities">الجهات الحكومية</TabsTrigger>
            <TabsTrigger value="connections">الاتصالات</TabsTrigger>
            <TabsTrigger value="sovereignty">السيادة الرقمية</TabsTrigger>
            <TabsTrigger value="monitoring">المراقبة</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="السيادة الرقمية"
                value={metrics.dataSovereigntyScore}
                icon={<Shield />}
                trend={0.018}
                description="نقاط السيادة الرقمية"
              />
              <MetricCard
                title="الامتثال الأمني"
                value={metrics.securityComplianceRate}
                icon={<Lock />}
                trend={0.025}
                description="معدل الامتثال الأمني"
              />
              <MetricCard
                title="كفاءة التكامل"
                value={metrics.integrationEfficiency}
                icon={<Network />}
                trend={0.012}
                description="كفاءة الشبكة الحكومية"
              />
              <MetricCard
                title="المعاملات"
                value={metrics.crossEntityTransactions}
                icon={<Activity />}
                suffix=""
                description="المعاملات بين الجهات"
              />
            </div>

            {/* Network Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="h-5 w-5 mr-2" />
                  الشبكة الحكومية الوطنية
                </CardTitle>
                <CardDescription>
                  نظرة عامة على الشبكة العصبية الرقمية للمؤسسات الحكومية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                    <Building2 className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                    <p className="text-2xl font-bold">{metrics.totalEntities}</p>
                    <p className="text-sm text-muted-foreground">جهة حكومية متصلة</p>
                  </div>
                  
                  <div className="text-center p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                    <Wifi className="h-8 w-8 text-green-600 mx-auto mb-2" />
                    <p className="text-2xl font-bold">{metrics.activeConnections}</p>
                    <p className="text-sm text-muted-foreground">اتصال آمن نشط</p>
                  </div>
                  
                  <div className="text-center p-4 rounded-lg bg-purple-50 dark:bg-purple-900/20">
                    <Shield className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                    <p className="text-2xl font-bold">{metrics.blockedViolations}</p>
                    <p className="text-sm text-muted-foreground">انتهاك محجوب</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Sovereignty Zones */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  مناطق السيادة الرقمية
                </CardTitle>
                <CardDescription>
                  التوزيع الجغرافي للبيانات الحكومية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    { zone: 'NATIONAL_SECURITY', entities: 5, description: 'أعلى مستوى حماية' },
                    { zone: 'GOVERNMENT_SERVICES', entities: 8, description: 'خدمات المواطنين' },
                    { zone: 'ECONOMIC', entities: 6, description: 'القطاع الاقتصادي' },
                    { zone: 'SOCIAL_SERVICES', entities: 3, description: 'الخدمات الاجتماعية' },
                    { zone: 'PUBLIC', entities: 2, description: 'المعلومات العامة' }
                  ].map((item) => (
                    <div key={item.zone} className={`p-4 rounded-lg border ${getZoneColor(item.zone)}`}>
                      <h4 className="font-medium mb-1">{getZoneName(item.zone)}</h4>
                      <p className="text-sm opacity-80 mb-2">{item.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold">{item.entities}</span>
                        <span className="text-sm">جهة</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Entities Tab */}
          <TabsContent value="entities" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building2 className="h-5 w-5 mr-2" />
                  الجهات الحكومية المتصلة
                </CardTitle>
                <CardDescription>
                  عقد الشبكة الحكومية الوطنية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {entities.map((entity) => (
                    <EntityCard key={entity.id} entity={entity} />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Connections Tab */}
          <TabsContent value="connections" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Network className="h-5 w-5 mr-2" />
                  الاتصالات الحكومية النشطة
                </CardTitle>
                <CardDescription>
                  شرايين الاتصال بين المؤسسات الوطنية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {connections.map((connection) => (
                    <ConnectionCard key={connection.id} connection={connection} />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sovereignty Tab */}
          <TabsContent value="sovereignty" className="space-y-6">
            {/* Data Sovereignty Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="السيادة الرقمية"
                value={metrics.dataSovereigntyScore}
                icon={<Shield />}
                description="نقاط السيادة الرقمية"
              />
              <MetricCard
                title="البيانات المحمية"
                value={0.98}
                icon={<Database />}
                description="نسبة البيانات داخل الحدود"
              />
              <MetricCard
                title="التشفير"
                value={metrics.securityComplianceRate}
                icon={<Lock />}
                description="معدل التشفير الآمن"
              />
              <MetricCard
                title="الانتهاكات المحجوبة"
                value={metrics.blockedViolations}
                icon={<XCircle />}
                suffix=""
                description="محاولات انتهاك محجوبة"
              />
            </div>

            {/* Digital Sovereignty Policy */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="h-5 w-5 mr-2" />
                  سياسة السيادة الرقمية
                </CardTitle>
                <CardDescription>
                  ضمان بقاء جميع البيانات الحكومية داخل الحدود الوطنية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <Alert>
                    <Shield className="h-4 w-4" />
                    <AlertDescription>
                      <strong>السياسة النشطة:</strong> جميع البيانات الحكومية يجب أن تبقى داخل الحدود السعودية
                    </AlertDescription>
                  </Alert>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg border border-green-200 bg-green-50 dark:bg-green-900/20">
                      <div className="flex items-center mb-2">
                        <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                        <span className="font-medium">المناطق المعتمدة</span>
                      </div>
                      <ul className="text-sm space-y-1">
                        <li>• الرياض - مركز الحكومة الإلكترونية</li>
                        <li>• جدة - مركز البيانات الغربي</li>
                        <li>• الدمام - مركز البيانات الشرقي</li>
                        <li>• نيوم - مركز المستقبل الرقمي</li>
                      </ul>
                    </div>
                    
                    <div className="p-4 rounded-lg border border-red-200 bg-red-50 dark:bg-red-900/20">
                      <div className="flex items-center mb-2">
                        <XCircle className="h-5 w-5 text-red-600 mr-2" />
                        <span className="font-medium">المناطق المحظورة</span>
                      </div>
                      <ul className="text-sm space-y-1">
                        <li>• جميع الخوادم الخارجية</li>
                        <li>• مراكز البيانات الدولية</li>
                        <li>• الخدمات السحابية الأجنبية</li>
                        <li>• الشبكات غير المعتمدة</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Monitoring Tab */}
          <TabsContent value="monitoring" className="space-y-6">
            {/* Real-time Monitoring */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="p-6">
                <div className="text-center">
                  <Activity className="h-8 w-8 mx-auto text-blue-600 mb-2" />
                  <h3 className="font-semibold mb-1">المراقبة المستمرة</h3>
                  <p className="text-2xl font-bold text-blue-600">24/7</p>
                  <p className="text-sm text-muted-foreground">نشطة</p>
                </div>
              </Card>
              
              <Card className="p-6">
                <div className="text-center">
                  <Eye className="h-8 w-8 mx-auto text-green-600 mb-2" />
                  <h3 className="font-semibold mb-1">كشف التهديدات</h3>
                  <p className="text-2xl font-bold text-green-600">97.8%</p>
                  <p className="text-sm text-muted-foreground">دقة الكشف</p>
                </div>
              </Card>
              
              <Card className="p-6">
                <div className="text-center">
                  <Zap className="h-8 w-8 mx-auto text-purple-600 mb-2" />
                  <h3 className="font-semibold mb-1">الاستجابة التلقائية</h3>
                  <p className="text-2xl font-bold text-purple-600">2.3s</p>
                  <p className="text-sm text-muted-foreground">متوسط الاستجابة</p>
                </div>
              </Card>
            </div>

            {/* Cyber Defense Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="h-5 w-5 mr-2" />
                  حالة الدفاع السيبراني
                </CardTitle>
                <CardDescription>
                  أنظمة الحماية النشطة للشبكة الحكومية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {[
                    { name: 'كشف التهديدات', status: true, description: 'مراقبة مستمرة للتهديدات' },
                    { name: 'منع الاختراق', status: true, description: 'حماية ضد محاولات الاختراق' },
                    { name: 'منع تسريب البيانات', status: true, description: 'حماية البيانات الحساسة' },
                    { name: 'التحليل الفوري', status: true, description: 'تحليل التهديدات بالوقت الفعلي' },
                    { name: 'الاستجابة التلقائية', status: true, description: 'إجراءات حماية تلقائية' },
                    { name: 'النسخ الاحتياطي', status: true, description: 'نسخ احتياطية آمنة' }
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 rounded-lg border">
                      <div>
                        <h4 className="font-medium">{item.name}</h4>
                        <p className="text-sm text-muted-foreground">{item.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {item.status ? (
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        ) : (
                          <XCircle className="h-5 w-5 text-red-600" />
                        )}
                        <span className={`text-sm ${item.status ? 'text-green-600' : 'text-red-600'}`}>
                          {item.status ? 'نشط' : 'متوقف'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default GovernmentIntegration;