import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  BookOpen, 
  Shield, 
  Search, 
  Plus,
  Archive,
  MapPin,
  Clock,
  Star,
  CheckCircle,
  XCircle,
  TrendingUp,
  BarChart3,
  Eye,
  Users,
  Bookmark,
  Filter,
  Download,
  Upload,
  Settings,
  Heart,
  Crown,
  Building,
  Scroll
} from 'lucide-react';

interface MemoryEntry {
  id: string;
  title: string;
  description: string;
  memoryType: 'HISTORICAL_EVENT' | 'CULTURAL_HERITAGE' | 'RELIGIOUS_LEGACY' | 'LITERARY_WORK' | 'ORAL_TRADITION';
  region: string;
  historicalPeriod: string;
  authenticityScore: number;
  islamicCompliance: 'FULLY_COMPLIANT' | 'MOSTLY_COMPLIANT' | 'REQUIRES_REVIEW';
  culturalAlignment: number;
  keywords: string[];
  dateRecorded: string;
  verified: boolean;
}

interface HeritageCollection {
  id: string;
  name: string;
  description: string;
  memoryCount: number;
  culturalSignificance: string;
  curator: string;
  creationDate: string;
}

interface MemoryAnalytics {
  totalMemories: number;
  verifiedMemories: number;
  islamicCompliantMemories: number;
  averageAuthenticity: number;
  averageCulturalAlignment: number;
  complianceRate: number;
  searchQueries: number;
}

const SaudiNationalMemory: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('all');
  const [selectedPeriod, setSelectedPeriod] = useState('all');
  const [showAddForm, setShowAddForm] = useState(false);

  // Mock data for demonstration
  const memoryEntries: MemoryEntry[] = [
    {
      id: 'MEM_001',
      title: 'توحيد المملكة العربية السعودية',
      description: 'توحيد الملك عبدالعزيز آل سعود للمملكة العربية السعودية عام 1932',
      memoryType: 'HISTORICAL_EVENT',
      region: 'منطقة الرياض',
      historicalPeriod: 'المملكة العربية السعودية الحديثة',
      authenticityScore: 0.98,
      islamicCompliance: 'FULLY_COMPLIANT',
      culturalAlignment: 0.95,
      keywords: ['توحيد', 'الملك عبدالعزيز', 'تأسيس', 'دولة'],
      dateRecorded: '2025-08-03T15:30:00Z',
      verified: true
    },
    {
      id: 'MEM_002',
      title: 'بناء الحرم المكي الشريف',
      description: 'تطوير وتوسعة الحرم المكي عبر التاريخ الإسلامي',
      memoryType: 'RELIGIOUS_LEGACY',
      region: 'منطقة مكة المكرمة',
      historicalPeriod: 'العصر النبوي',
      authenticityScore: 1.0,
      islamicCompliance: 'FULLY_COMPLIANT',
      culturalAlignment: 1.0,
      keywords: ['الحرم', 'مكة', 'قبلة', 'حج'],
      dateRecorded: '2025-08-03T14:20:00Z',
      verified: true
    },
    {
      id: 'MEM_003',
      title: 'سوق عكاظ التاريخي',
      description: 'أشهر أسواق العرب في الجاهلية والإسلام، مركز للتجارة والثقافة',
      memoryType: 'CULTURAL_HERITAGE',
      region: 'منطقة مكة المكرمة',
      historicalPeriod: 'العصر الجاهلي',
      authenticityScore: 0.92,
      islamicCompliance: 'MOSTLY_COMPLIANT',
      culturalAlignment: 0.88,
      keywords: ['سوق', 'تجارة', 'شعر', 'ثقافة'],
      dateRecorded: '2025-08-03T13:45:00Z',
      verified: true
    },
    {
      id: 'MEM_004',
      title: 'الشعر النبطي والتراث الشفهي',
      description: 'التراث الشعري النبطي كوسيلة لحفظ التاريخ والقيم',
      memoryType: 'ORAL_TRADITION',
      region: 'منطقة الرياض',
      historicalPeriod: 'المملكة العربية السعودية الحديثة',
      authenticityScore: 0.85,
      islamicCompliance: 'FULLY_COMPLIANT',
      culturalAlignment: 0.90,
      keywords: ['شعر', 'نبطي', 'تراث', 'شفهي'],
      dateRecorded: '2025-08-03T12:15:00Z',
      verified: false
    },
    {
      id: 'MEM_005',
      title: 'مسجد نمرة بعرفات',
      description: 'المسجد الذي ألقى فيه النبي صلى الله عليه وسلم خطبة الوداع',
      memoryType: 'RELIGIOUS_LEGACY',
      region: 'منطقة مكة المكرمة',
      historicalPeriod: 'العصر النبوي',
      authenticityScore: 0.99,
      islamicCompliance: 'FULLY_COMPLIANT',
      culturalAlignment: 0.98,
      keywords: ['مسجد', 'عرفات', 'خطبة الوداع', 'حج'],
      dateRecorded: '2025-08-03T11:30:00Z',
      verified: true
    }
  ];

  const collections: HeritageCollection[] = [
    {
      id: 'COL_001',
      name: 'تراث الحرمين الشريفين',
      description: 'التراث المرتبط بالحرمين الشريفين والأماكن المقدسة',
      memoryCount: 15,
      culturalSignificance: 'مقدس',
      curator: 'هيئة التراث',
      creationDate: '2025-08-01T10:00:00Z'
    },
    {
      id: 'COL_002',
      name: 'تاريخ توحيد المملكة',
      description: 'الأحداث والشخصيات المرتبطة بتوحيد المملكة',
      memoryCount: 12,
      culturalSignificance: 'تأسيسي',
      curator: 'دارة الملك عبدالعزيز',
      creationDate: '2025-08-01T09:30:00Z'
    },
    {
      id: 'COL_003',
      name: 'التراث البدوي الأصيل',
      description: 'تقاليد وعادات البدو في الجزيرة العربية',
      memoryCount: 18,
      culturalSignificance: 'ثقافي',
      curator: 'مركز التراث الشعبي',
      creationDate: '2025-07-30T14:15:00Z'
    },
    {
      id: 'COL_004',
      name: 'الحرف والصناعات التقليدية',
      description: 'الحرف اليدوية والصناعات التراثية السعودية',
      memoryCount: 8,
      culturalSignificance: 'اقتصادي',
      curator: 'جمعية الحرف التقليدية',
      creationDate: '2025-07-28T16:45:00Z'
    }
  ];

  const analytics: MemoryAnalytics = {
    totalMemories: 147,
    verifiedMemories: 134,
    islamicCompliantMemories: 142,
    averageAuthenticity: 0.91,
    averageCulturalAlignment: 0.89,
    complianceRate: 0.97,
    searchQueries: 2847
  };

  const getMemoryTypeIcon = (type: string) => {
    const icons = {
      HISTORICAL_EVENT: <Crown className="h-4 w-4" />,
      CULTURAL_HERITAGE: <Heart className="h-4 w-4" />,
      RELIGIOUS_LEGACY: <Building className="h-4 w-4" />,
      LITERARY_WORK: <BookOpen className="h-4 w-4" />,
      ORAL_TRADITION: <Scroll className="h-4 w-4" />
    };
    return icons[type as keyof typeof icons] || <BookOpen className="h-4 w-4" />;
  };

  const getMemoryTypeName = (type: string) => {
    const names = {
      HISTORICAL_EVENT: 'حدث تاريخي',
      CULTURAL_HERITAGE: 'تراث ثقافي',
      RELIGIOUS_LEGACY: 'إرث ديني',
      LITERARY_WORK: 'عمل أدبي',
      ORAL_TRADITION: 'تراث شفهي'
    };
    return names[type as keyof typeof names] || 'غير محدد';
  };

  const getComplianceColor = (compliance: string) => {
    const colors = {
      FULLY_COMPLIANT: 'bg-green-100 text-green-800 border-green-200',
      MOSTLY_COMPLIANT: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      REQUIRES_REVIEW: 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[compliance as keyof typeof colors] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getComplianceName = (compliance: string) => {
    const names = {
      FULLY_COMPLIANT: 'متوافق تماماً',
      MOSTLY_COMPLIANT: 'متوافق في الغالب',
      REQUIRES_REVIEW: 'يحتاج مراجعة'
    };
    return names[compliance as keyof typeof names] || 'غير محدد';
  };

  const MetricCard: React.FC<{
    title: string;
    value: number;
    icon: React.ReactNode;
    trend?: number;
    suffix?: string;
    description?: string;
  }> = ({ title, value, icon, trend, suffix = '%', description }) => (
    <Card className="p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl font-bold">
            {suffix === '%' ? (value * 100).toFixed(1) : value.toLocaleString()}{suffix}
          </p>
          {trend !== undefined && (
            <p className={`text-sm flex items-center ${trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              <TrendingUp className="h-4 w-4 mr-1" />
              {trend >= 0 ? '+' : ''}{(trend * 100).toFixed(1)}%
            </p>
          )}
          {description && (
            <p className="text-xs text-muted-foreground mt-1">{description}</p>
          )}
        </div>
        <div className="text-2xl text-muted-foreground">
          {icon}
        </div>
      </div>
    </Card>
  );

  const MemoryCard: React.FC<{ memory: MemoryEntry }> = ({ memory }) => (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              {getMemoryTypeIcon(memory.memoryType)}
              <h4 className="font-medium">{memory.title}</h4>
              {memory.verified && <CheckCircle className="h-4 w-4 text-green-600" />}
            </div>
            <p className="text-sm text-muted-foreground mb-2">{memory.description}</p>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">النوع:</span>
            <Badge variant="outline" className="text-xs">
              {getMemoryTypeName(memory.memoryType)}
            </Badge>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">المنطقة:</span>
            <span>{memory.region}</span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">الفترة:</span>
            <span className="text-xs">{memory.historicalPeriod}</span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">الامتثال الإسلامي:</span>
            <Badge variant="outline" className={`text-xs ${getComplianceColor(memory.islamicCompliance)}`}>
              {getComplianceName(memory.islamicCompliance)}
            </Badge>
          </div>
        </div>
        
        <div className="space-y-2 pt-2 border-t">
          <div className="flex justify-between text-sm">
            <span>نقاط الأصالة</span>
            <span>{(memory.authenticityScore * 100).toFixed(1)}%</span>
          </div>
          <Progress value={memory.authenticityScore * 100} className="h-2" />
          
          <div className="flex justify-between text-sm">
            <span>التوافق الثقافي</span>
            <span>{(memory.culturalAlignment * 100).toFixed(1)}%</span>
          </div>
          <Progress value={memory.culturalAlignment * 100} className="h-2" />
        </div>
        
        <div className="pt-2 border-t">
          <div className="flex flex-wrap gap-1">
            {memory.keywords.slice(0, 3).map((keyword, idx) => (
              <Badge key={idx} variant="secondary" className="text-xs">
                {keyword}
              </Badge>
            ))}
            {memory.keywords.length > 3 && (
              <Badge variant="secondary" className="text-xs">
                +{memory.keywords.length - 3}
              </Badge>
            )}
          </div>
        </div>
      </div>
    </Card>
  );

  const CollectionCard: React.FC<{ collection: HeritageCollection }> = ({ collection }) => (
    <Card className="p-4">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="font-medium">{collection.name}</h4>
          <Badge variant="outline" className="text-xs">
            {collection.culturalSignificance}
          </Badge>
        </div>
        
        <p className="text-sm text-muted-foreground">{collection.description}</p>
        
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">عدد الذكريات:</span>
            <span className="font-medium">{collection.memoryCount}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-muted-foreground">القيم:</span>
            <span>{collection.curator}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-muted-foreground">تاريخ الإنشاء:</span>
            <span>{new Date(collection.creationDate).toLocaleDateString('ar')}</span>
          </div>
        </div>
        
        <div className="pt-2 border-t">
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="flex-1">
              <Eye className="h-3 w-3 mr-1" />
              عرض
            </Button>
            <Button variant="outline" size="sm" className="flex-1">
              <Plus className="h-3 w-3 mr-1" />
              إضافة
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );

  const AddMemoryForm: React.FC = () => (
    <Card className="p-6">
      <CardHeader className="px-0 pt-0">
        <CardTitle className="flex items-center">
          <Plus className="h-5 w-5 mr-2" />
          إضافة ذاكرة جديدة
        </CardTitle>
        <CardDescription>
          إضافة ذاكرة تراثية أو تاريخية جديدة إلى النظام
        </CardDescription>
      </CardHeader>
      <CardContent className="px-0">
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium">العنوان</label>
            <Input placeholder="عنوان الذاكرة التراثية" />
          </div>
          
          <div>
            <label className="text-sm font-medium">الوصف</label>
            <Textarea placeholder="وصف تفصيلي للذاكرة التراثية" rows={3} />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">نوع الذاكرة</label>
              <select className="w-full p-2 border rounded-md">
                <option value="">اختر النوع</option>
                <option value="HISTORICAL_EVENT">حدث تاريخي</option>
                <option value="CULTURAL_HERITAGE">تراث ثقافي</option>
                <option value="RELIGIOUS_LEGACY">إرث ديني</option>
                <option value="LITERARY_WORK">عمل أدبي</option>
                <option value="ORAL_TRADITION">تراث شفهي</option>
              </select>
            </div>
            
            <div>
              <label className="text-sm font-medium">المنطقة الجغرافية</label>
              <select className="w-full p-2 border rounded-md">
                <option value="">اختر المنطقة</option>
                <option value="RIYADH">منطقة الرياض</option>
                <option value="MAKKAH">منطقة مكة المكرمة</option>
                <option value="MADINAH">منطقة المدينة المنورة</option>
                <option value="EASTERN_PROVINCE">المنطقة الشرقية</option>
                <option value="ASIR">منطقة عسير</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="text-sm font-medium">الكلمات المفتاحية</label>
            <Input placeholder="الكلمات المفتاحية مفصولة بفواصل" />
          </div>
          
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              ستخضع جميع الذكريات للتحقق من الامتثال الإسلامي والثقافي قبل النشر
            </AlertDescription>
          </Alert>
          
          <div className="flex gap-3">
            <Button>
              <Upload className="h-4 w-4 mr-2" />
              حفظ الذاكرة
            </Button>
            <Button variant="outline" onClick={() => setShowAddForm(false)}>
              إلغاء
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const filteredMemories = memoryEntries.filter(memory => {
    const matchesSearch = searchQuery === '' || 
      memory.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      memory.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      memory.keywords.some(kw => kw.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesRegion = selectedRegion === 'all' || memory.region === selectedRegion;
    const matchesPeriod = selectedPeriod === 'all' || memory.historicalPeriod === selectedPeriod;
    
    return matchesSearch && matchesRegion && matchesPeriod;
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-100 dark:from-amber-900 dark:to-orange-800">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <BookOpen className="h-8 w-8 text-amber-600 mr-3" />
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
                نظام الذاكرة الوطنية السعودية
              </h1>
              <p className="text-muted-foreground">
                Saudi National Memory System - الضمير التاريخي للنظام
              </p>
            </div>
          </div>
          
          <Alert className="border-amber-200 bg-amber-50 dark:bg-amber-900/20">
            <Heart className="h-4 w-4 text-amber-600" />
            <AlertDescription className="text-amber-800 dark:text-amber-200">
              <strong>رسالة النظام:</strong> "أمة لا تنسى ماضيها.. لا يفنى مستقبلها"
            </AlertDescription>
          </Alert>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">نظرة عامة</TabsTrigger>
            <TabsTrigger value="memories">بنك الذكريات</TabsTrigger>
            <TabsTrigger value="collections">مجموعات التراث</TabsTrigger>
            <TabsTrigger value="add">إضافة ذاكرة</TabsTrigger>
            <TabsTrigger value="analytics">التحليلات</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="إجمالي الذكريات"
                value={analytics.totalMemories}
                icon={<BookOpen />}
                suffix=""
                description="ذاكرة محفوظة رقمياً"
              />
              <MetricCard
                title="الذكريات المحققة"
                value={analytics.verifiedMemories}
                icon={<CheckCircle />}
                suffix=""
                description="تم التحقق من صحتها"
              />
              <MetricCard
                title="الامتثال الإسلامي"
                value={analytics.complianceRate}
                icon={<Shield />}
                description="نسبة الامتثال الإسلامي"
              />
              <MetricCard
                title="متوسط الأصالة"
                value={analytics.averageAuthenticity}
                icon={<Star />}
                description="نقاط الأصالة التاريخية"
              />
            </div>

            {/* Heritage Preservation Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Archive className="h-5 w-5 mr-2" />
                  حالة حفظ التراث الوطني
                </CardTitle>
                <CardDescription>
                  ملخص شامل لجهود حفظ الذاكرة الوطنية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-4 rounded-lg bg-green-50 dark:bg-green-900/20">
                    <Building className="h-8 w-8 text-green-600 mx-auto mb-2" />
                    <p className="text-2xl font-bold text-green-600">97%</p>
                    <p className="text-sm text-muted-foreground">الامتثال الإسلامي</p>
                    <p className="text-xs text-green-600">متوافق مع التعاليم الإسلامية</p>
                  </div>
                  
                  <div className="text-center p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                    <Heart className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                    <p className="text-2xl font-bold text-blue-600">89%</p>
                    <p className="text-sm text-muted-foreground">التوافق الثقافي</p>
                    <p className="text-xs text-blue-600">متماشي مع الهوية الوطنية</p>
                  </div>
                  
                  <div className="text-center p-4 rounded-lg bg-amber-50 dark:bg-amber-900/20">
                    <Star className="h-8 w-8 text-amber-600 mx-auto mb-2" />
                    <p className="text-2xl font-bold text-amber-600">91%</p>
                    <p className="text-sm text-muted-foreground">نقاط الأصالة</p>
                    <p className="text-xs text-amber-600">موثق ومحقق تاريخياً</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Memories */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2" />
                  أحدث الذكريات المضافة
                </CardTitle>
                <CardDescription>
                  آخر الذكريات التراثية والتاريخية المضافة للنظام
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  {memoryEntries.slice(0, 3).map((memory) => (
                    <div key={memory.id} className="flex items-center justify-between p-3 rounded-lg border">
                      <div className="flex items-center gap-3">
                        {getMemoryTypeIcon(memory.memoryType)}
                        <div>
                          <h4 className="font-medium">{memory.title}</h4>
                          <p className="text-sm text-muted-foreground">{memory.region} • {getMemoryTypeName(memory.memoryType)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={getComplianceColor(memory.islamicCompliance)}>
                          {getComplianceName(memory.islamicCompliance)}
                        </Badge>
                        {memory.verified && <CheckCircle className="h-4 w-4 text-green-600" />}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Memories Tab */}
          <TabsContent value="memories" className="space-y-6">
            {/* Search and Filters */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Search className="h-5 w-5 mr-2" />
                  البحث في بنك الذكريات
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <div className="flex-1">
                      <Input
                        placeholder="ابحث في الذكريات والتراث..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <Button variant="outline">
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                  
                  <div className="flex gap-4">
                    <select 
                      value={selectedRegion} 
                      onChange={(e) => setSelectedRegion(e.target.value)}
                      className="p-2 border rounded-md"
                    >
                      <option value="all">جميع المناطق</option>
                      <option value="منطقة الرياض">منطقة الرياض</option>
                      <option value="منطقة مكة المكرمة">منطقة مكة المكرمة</option>
                      <option value="منطقة المدينة المنورة">منطقة المدينة المنورة</option>
                    </select>
                    
                    <select 
                      value={selectedPeriod} 
                      onChange={(e) => setSelectedPeriod(e.target.value)}
                      className="p-2 border rounded-md"
                    >
                      <option value="all">جميع الفترات</option>
                      <option value="العصر النبوي">العصر النبوي</option>
                      <option value="العصر الجاهلي">العصر الجاهلي</option>
                      <option value="المملكة العربية السعودية الحديثة">المملكة الحديثة</option>
                    </select>
                  </div>
                  
                  <p className="text-sm text-muted-foreground">
                    تم العثور على {filteredMemories.length} ذاكرة
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Memory Results */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredMemories.map((memory) => (
                <MemoryCard key={memory.id} memory={memory} />
              ))}
            </div>
          </TabsContent>

          {/* Collections Tab */}
          <TabsContent value="collections" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Archive className="h-5 w-5 mr-2" />
                  مجموعات التراث المنظمة
                </CardTitle>
                <CardDescription>
                  مجموعات منظمة من الذكريات حسب الموضوع والأهمية الثقافية
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {collections.map((collection) => (
                    <CollectionCard key={collection.id} collection={collection} />
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Add Memory Tab */}
          <TabsContent value="add" className="space-y-6">
            <AddMemoryForm />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            {/* Analytics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricCard
                title="معدل التحقق"
                value={analytics.verifiedMemories / analytics.totalMemories}
                icon={<CheckCircle />}
                description="نسبة الذكريات المحققة"
              />
              <MetricCard
                title="التوافق الثقافي"
                value={analytics.averageCulturalAlignment}
                icon={<Heart />}
                description="متوسط التوافق الثقافي"
              />
              <MetricCard
                title="استعلامات البحث"
                value={analytics.searchQueries}
                icon={<Search />}
                suffix=""
                description="إجمالي عمليات البحث"
              />
              <MetricCard
                title="النمو الشهري"
                value={12}
                icon={<TrendingUp />}
                suffix=""
                description="ذكريات جديدة هذا الشهر"
              />
            </div>

            {/* Detailed Analytics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  تحليل شامل للذاكرة الوطنية
                </CardTitle>
                <CardDescription>
                  إحصائيات مفصلة عن حالة حفظ التراث الوطني
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Memory Types Distribution */}
                  <div className="space-y-4">
                    <h4 className="font-medium">توزيع أنواع الذكريات</h4>
                    {[
                      { type: 'HISTORICAL_EVENT', count: 45, name: 'أحداث تاريخية' },
                      { type: 'RELIGIOUS_LEGACY', count: 38, name: 'إرث ديني' },
                      { type: 'CULTURAL_HERITAGE', count: 32, name: 'تراث ثقافي' },
                      { type: 'ORAL_TRADITION', count: 22, name: 'تراث شفهي' },
                      { type: 'LITERARY_WORK', count: 10, name: 'أعمال أدبية' }
                    ].map((item) => (
                      <div key={item.type} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {getMemoryTypeIcon(item.type)}
                          <span className="text-sm">{item.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Progress value={(item.count / analytics.totalMemories) * 100} className="w-20 h-2" />
                          <span className="text-sm font-medium">{item.count}</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Compliance Analysis */}
                  <div className="space-y-4">
                    <h4 className="font-medium">تحليل الامتثال الإسلامي</h4>
                    {[
                      { level: 'FULLY_COMPLIANT', count: 135, name: 'متوافق تماماً', color: 'bg-green-500' },
                      { level: 'MOSTLY_COMPLIANT', count: 7, name: 'متوافق في الغالب', color: 'bg-yellow-500' },
                      { level: 'REQUIRES_REVIEW', count: 5, name: 'يحتاج مراجعة', color: 'bg-red-500' }
                    ].map((item) => (
                      <div key={item.level} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                          <span className="text-sm">{item.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Progress value={(item.count / analytics.totalMemories) * 100} className="w-20 h-2" />
                          <span className="text-sm font-medium">{item.count}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default SaudiNationalMemory;