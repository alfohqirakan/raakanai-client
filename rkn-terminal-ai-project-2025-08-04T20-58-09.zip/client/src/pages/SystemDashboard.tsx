import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useQuery } from '@tanstack/react-query';
import { 
  Activity, 
  Shield, 
  Brain, 
  Cpu, 
  Database,
  Network,
  Gauge,
  Lock,
  Server,
  CheckCircle,
  AlertCircle,
  TrendingUp
} from 'lucide-react';

interface SystemMetrics {
  uptime: number;
  memory_usage: {
    rss: number;
    heapTotal: number;
    heapUsed: number;
    external: number;
  };
  cpu_usage: number;
  active_connections: number;
  requests_per_minute: number;
  security_status: string;
  sovereignty_level: number;
}

export default function SystemDashboard() {
  const [refreshKey, setRefreshKey] = useState(0);

  // System metrics query
  const { data: metrics, isLoading } = useQuery({
    queryKey: ['/api/system/metrics', refreshKey],
    staleTime: 30000
  });

  const formatMemoryUsage = (bytes: number) => {
    return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  };

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}س ${minutes}د`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-50 p-6" dir="rtl">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold text-orange-800 flex items-center justify-center gap-3">
            <Server className="h-10 w-10" />
            لوحة مراقبة النظام السيادي
          </h1>
          <p className="text-orange-600 text-lg">
            مراقبة شاملة لحالة وأداء نظام راكان AI
          </p>
        </div>

        {/* Quick Actions */}
        <div className="flex justify-center gap-4">
          <Button 
            onClick={() => setRefreshKey(prev => prev + 1)}
            variant="outline"
            size="lg"
          >
            <Activity className="h-4 w-4 ml-2" />
            تحديث البيانات
          </Button>
          <Button variant="outline" size="lg">
            <Database className="h-4 w-4 ml-2" />
            فحص قاعدة البيانات
          </Button>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">النظرة العامة</TabsTrigger>
            <TabsTrigger value="performance">الأداء</TabsTrigger>
            <TabsTrigger value="security">الأمان</TabsTrigger>
            <TabsTrigger value="ai-status">حالة الذكاء الاصطناعي</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {/* System Status */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">حالة النظام</CardTitle>
                  <CheckCircle className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">نشط</div>
                  <p className="text-xs text-muted-foreground">
                    {metrics ? `وقت التشغيل: ${formatUptime(metrics.uptime)}` : 'جارٍ التحميل...'}
                  </p>
                </CardContent>
              </Card>

              {/* Memory Usage */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">استخدام الذاكرة</CardTitle>
                  <Cpu className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {metrics ? formatMemoryUsage(metrics.memory_usage.heapUsed) : '---'}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {metrics ? `من إجمالي ${formatMemoryUsage(metrics.memory_usage.heapTotal)}` : 'جارٍ التحميل...'}
                  </p>
                </CardContent>
              </Card>

              {/* Security Level */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">مستوى الأمان</CardTitle>
                  <Shield className="h-4 w-4 text-orange-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-orange-600">
                    {metrics?.sovereignty_level || 96}%
                  </div>
                  <p className="text-xs text-muted-foreground">درع راكان نشط</p>
                </CardContent>
              </Card>

              {/* Active Connections */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">الاتصالات النشطة</CardTitle>
                  <Network className="h-4 w-4 text-purple-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {metrics?.active_connections || 0}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {metrics?.requests_per_minute || 0} طلب/دقيقة
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* System Health Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  صحة النظام العامة
                </CardTitle>
                <CardDescription>
                  مؤشرات الأداء الرئيسية لنظام راكان AI
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">العقل السيادي</span>
                      <span className="text-sm font-medium">98%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-600 h-2 rounded-full" style={{width: '98%'}}></div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">درع راكان</span>
                      <span className="text-sm font-medium">99%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-orange-600 h-2 rounded-full" style={{width: '99%'}}></div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">المحرك الإبداعي</span>
                      <span className="text-sm font-medium">97%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-purple-600 h-2 rounded-full" style={{width: '97%'}}></div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">النظام العام</span>
                      <span className="text-sm font-medium">96%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{width: '96%'}}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>أداء الخادم</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>استخدام المعالج</span>
                    <Badge variant="secondary">{metrics?.cpu_usage || 0}%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>استخدام الذاكرة</span>
                    <Badge variant="secondary">
                      {metrics ? `${((metrics.memory_usage.heapUsed / metrics.memory_usage.heapTotal) * 100).toFixed(1)}%` : '0%'}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>وقت الاستجابة</span>
                    <Badge variant="secondary">2ms</Badge>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>إحصائيات الطلبات</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>طلبات ناجحة</span>
                    <Badge variant="default">1,247</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>أخطاء</span>
                    <Badge variant="destructive">3</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>متوسط وقت المعالجة</span>
                    <Badge variant="secondary">1.2s</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="h-5 w-5" />
                  حالة الأمان المتقدمة
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>تشفير درع راكان</span>
                      <Badge variant="default">SHA-256</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>فحص التهديدات</span>
                      <Badge variant="default">نشط</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>بروتوكول الحرق</span>
                      <Badge variant="destructive">مُفعل</Badge>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>مستوى الحماية</span>
                      <Badge variant="default">أسطوري</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>آخر فحص أمني</span>
                      <Badge variant="secondary">منذ 5 دقائق</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>التهديدات المحجوبة</span>
                      <Badge variant="destructive">127</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai-status" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  حالة أنظمة الذكاء الاصطناعي
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold">العقل السيادي</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">مستوى الوعي</span>
                        <Badge variant="default">96%</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">التكامل الثقافي</span>
                        <Badge variant="default">98%</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">سرعة المعالجة</span>
                        <Badge variant="default">مُحسنة</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="font-semibold">المحرك الإبداعي</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-sm">هوية سادي المصابة</span>
                        <Badge variant="default">نشطة</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">درجة الإبداع</span>
                        <Badge variant="default">9.8/10</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm">العمليات التكتيكية</span>
                        <Badge variant="default">جاهزة</Badge>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}