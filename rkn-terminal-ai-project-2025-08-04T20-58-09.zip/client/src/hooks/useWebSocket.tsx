/**
 * RKN-Terminal AI WebSocket Hook
 * خطاف التواصل الفوري لمنصة راكان الذكاء السيادي
 */

import { useEffect, useState, useCallback, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { useAuth } from './useAuth';

interface WebSocketState {
  isConnected: boolean;
  isConnecting: boolean;
  error: string | null;
  lastMessage: any;
  connectionId: string | null;
}

interface ChatMessage {
  id: string;
  fileId: string;
  userId: number;
  username: string;
  message: string;
  timestamp: Date;
  type: 'user' | 'assistant';
}

interface AnalysisProgress {
  fileId: string;
  progress: number;
  stage: string;
  message: string;
  timestamp: Date;
}

interface UseWebSocketReturn {
  // Connection state
  state: WebSocketState;
  socket: Socket | null;
  
  // Room management
  joinFileRoom: (fileId: string) => void;
  leaveFileRoom: (fileId: string) => void;
  
  // Messaging
  sendChatMessage: (fileId: string, message: string) => void;
  
  // Event listeners
  onChatMessage: (callback: (message: ChatMessage) => void) => void;
  onAnalysisProgress: (callback: (progress: AnalysisProgress) => void) => void;
  onAnalysisComplete: (callback: (result: any) => void) => void;
  onNotification: (callback: (notification: any) => void) => void;
  onUserJoinedRoom: (callback: (user: any) => void) => void;
  onUserLeftRoom: (callback: (user: any) => void) => void;
  
  // Utility functions
  disconnect: () => void;
  reconnect: () => void;
  getConnectionStats: () => Promise<any>;
}

export function useWebSocket(): UseWebSocketReturn {
  const [state, setState] = useState<WebSocketState>({
    isConnected: false,
    isConnecting: false,
    error: null,
    lastMessage: null,
    connectionId: null
  });

  const { user } = useAuth();
  const socketRef = useRef<Socket | null>(null);
  const eventCallbacksRef = useRef<Map<string, Function[]>>(new Map());

  // Initialize socket connection
  const initializeSocket = useCallback(() => {
    if (!user || socketRef.current) return;

    setState(prev => ({ ...prev, isConnecting: true, error: null }));

    try {
      const socket = io({
        transports: ['websocket', 'polling'],
        timeout: 30000,
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
        forceNew: false
      });

      socketRef.current = socket;

      // Connection event handlers
      socket.on('connect', () => {
        console.log('🔗 اتصال WebSocket نجح:', socket.id);
        setState(prev => ({
          ...prev,
          isConnected: true,
          isConnecting: false,
          error: null,
          connectionId: socket.id
        }));

        // Authenticate user with socket
        if (user) {
          socket.emit('authenticate', {
            userId: user.id,
            username: user.username
          });
        }
      });

      socket.on('disconnect', (reason) => {
        console.log('🔌 انقطاع WebSocket:', reason);
        setState(prev => ({
          ...prev,
          isConnected: false,
          isConnecting: false,
          connectionId: null
        }));
      });

      socket.on('connect_error', (error) => {
        console.error('❌ خطأ في اتصال WebSocket:', error);
        setState(prev => ({
          ...prev,
          isConnected: false,
          isConnecting: false,
          error: error.message || 'فشل في الاتصال'
        }));
      });

      // Authentication response
      socket.on('authenticated', (data) => {
        console.log('✅ تم تسجيل الدخول في النظام الفوري:', data);
      });

      // Chat message events
      socket.on('chatMessage', (message: ChatMessage) => {
        setState(prev => ({ ...prev, lastMessage: message }));
        triggerCallbacks('chatMessage', message);
      });

      // Analysis progress events
      socket.on('analysisProgress', (progress: AnalysisProgress) => {
        console.log(`📊 تقدم التحليل: ${progress.progress}% - ${progress.stage}`);
        triggerCallbacks('analysisProgress', progress);
      });

      // Analysis completion events
      socket.on('analysisComplete', (result) => {
        console.log('✅ اكتمل التحليل للملف:', result.fileId);
        triggerCallbacks('analysisComplete', result);
      });

      // Room events
      socket.on('userJoinedRoom', (user) => {
        console.log(`👤 انضم ${user.username} إلى الغرفة`);
        triggerCallbacks('userJoinedRoom', user);
      });

      socket.on('userLeftRoom', (user) => {
        console.log(`👋 غادر ${user.username} الغرفة`);
        triggerCallbacks('userLeftRoom', user);
      });

      socket.on('roomParticipants', (data) => {
        console.log(`📁 مشاركو الغرفة:`, data.participants);
        triggerCallbacks('roomParticipants', data);
      });

      // General notifications
      socket.on('notification', (notification) => {
        console.log('📢 إشعار:', notification);
        triggerCallbacks('notification', notification);
      });

      // Error handling
      socket.on('error', (error) => {
        console.error('❌ خطأ WebSocket:', error);
        setState(prev => ({ ...prev, error: error.message }));
      });

    } catch (error) {
      console.error('❌ فشل في تهيئة WebSocket:', error);
      setState(prev => ({
        ...prev,
        isConnecting: false,
        error: error instanceof Error ? error.message : 'خطأ غير معروف'
      }));
    }
  }, [user]);

  // Trigger event callbacks
  const triggerCallbacks = useCallback((event: string, data: any) => {
    const callbacks = eventCallbacksRef.current.get(event) || [];
    callbacks.forEach(callback => {
      try {
        callback(data);
      } catch (error) {
        console.error(`خطأ في معالج الحدث ${event}:`, error);
      }
    });
  }, []);

  // Register event callback
  const registerCallback = useCallback((event: string, callback: Function) => {
    const callbacks = eventCallbacksRef.current.get(event) || [];
    callbacks.push(callback);
    eventCallbacksRef.current.set(event, callbacks);

    // Return unregister function
    return () => {
      const updatedCallbacks = eventCallbacksRef.current.get(event) || [];
      const index = updatedCallbacks.indexOf(callback);
      if (index > -1) {
        updatedCallbacks.splice(index, 1);
        eventCallbacksRef.current.set(event, updatedCallbacks);
      }
    };
  }, []);

  // Room management
  const joinFileRoom = useCallback((fileId: string) => {
    if (socketRef.current && state.isConnected) {
      console.log(`📁 الانضمام إلى غرفة الملف: ${fileId}`);
      socketRef.current.emit('joinFileRoom', fileId);
    }
  }, [state.isConnected]);

  const leaveFileRoom = useCallback((fileId: string) => {
    if (socketRef.current && state.isConnected) {
      console.log(`📁 مغادرة غرفة الملف: ${fileId}`);
      socketRef.current.emit('leaveFileRoom', fileId);
    }
  }, [state.isConnected]);

  // Send chat message
  const sendChatMessage = useCallback((fileId: string, message: string) => {
    if (socketRef.current && state.isConnected) {
      console.log(`💬 إرسال رسالة للملف ${fileId}: ${message}`);
      socketRef.current.emit('sendChatMessage', { fileId, message });
    }
  }, [state.isConnected]);

  // Connection management
  const disconnect = useCallback(() => {
    if (socketRef.current) {
      console.log('🔌 قطع اتصال WebSocket');
      socketRef.current.disconnect();
      socketRef.current = null;
      setState(prev => ({
        ...prev,
        isConnected: false,
        isConnecting: false,
        connectionId: null
      }));
    }
  }, []);

  const reconnect = useCallback(() => {
    disconnect();
    setTimeout(initializeSocket, 1000);
  }, [disconnect, initializeSocket]);

  // Get connection statistics
  const getConnectionStats = useCallback(async () => {
    try {
      const response = await fetch('/api/websocket/stats', {
        credentials: 'include'
      });
      if (response.ok) {
        const data = await response.json();
        return data.data;
      }
      throw new Error('فشل في جلب إحصائيات الاتصال');
    } catch (error) {
      console.error('خطأ في جلب إحصائيات WebSocket:', error);
      return null;
    }
  }, []);

  // Event listener hooks
  const onChatMessage = useCallback((callback: (message: ChatMessage) => void) => {
    return registerCallback('chatMessage', callback);
  }, [registerCallback]);

  const onAnalysisProgress = useCallback((callback: (progress: AnalysisProgress) => void) => {
    return registerCallback('analysisProgress', callback);
  }, [registerCallback]);

  const onAnalysisComplete = useCallback((callback: (result: any) => void) => {
    return registerCallback('analysisComplete', callback);
  }, [registerCallback]);

  const onNotification = useCallback((callback: (notification: any) => void) => {
    return registerCallback('notification', callback);
  }, [registerCallback]);

  const onUserJoinedRoom = useCallback((callback: (user: any) => void) => {
    return registerCallback('userJoinedRoom', callback);
  }, [registerCallback]);

  const onUserLeftRoom = useCallback((callback: (user: any) => void) => {
    return registerCallback('userLeftRoom', callback);
  }, [registerCallback]);

  // Initialize socket when user is available
  useEffect(() => {
    if (user && !socketRef.current) {
      initializeSocket();
    } else if (!user && socketRef.current) {
      disconnect();
    }
  }, [user, initializeSocket, disconnect]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, []);

  return {
    state,
    socket: socketRef.current,
    joinFileRoom,
    leaveFileRoom,
    sendChatMessage,
    onChatMessage,
    onAnalysisProgress,
    onAnalysisComplete,
    onNotification,
    onUserJoinedRoom,
    onUserLeftRoom,
    disconnect,
    reconnect,
    getConnectionStats
  };
}