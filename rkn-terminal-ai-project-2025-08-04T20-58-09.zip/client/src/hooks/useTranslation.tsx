import { useLanguage } from '@/lib/i18n';
import { useDirection } from '@/lib/direction';

/**
 * Enhanced translation hook with RTL direction support
 */
export function useTranslation() {
  const { language, setLanguage, t } = useLanguage();
  const { dir, toggleDirection, setDirection, setLanguage: setDirectionLanguage } = useDirection();
  
  const isRTL = dir === 'rtl';
  
  // Sync language and direction changes
  const handleLanguageChange = (newLanguage: 'ar' | 'en') => {
    setLanguage(newLanguage);
    setDirectionLanguage(newLanguage);
  };
  
  return {
    t,
    language,
    setLanguage: handleLanguageChange,
    changeLanguage: handleLanguageChange, // Alias for compatibility
    isRTL,
    dir,
    toggleDirection,
    setDirection,
    currentLanguage: language,
  };
}

/**
 * Helper function to format file size with translation
 */
export function useFileSize() {
  const { t, currentLanguage } = useTranslation();
  
  return (bytes: number): string => {
    if (bytes === 0) return `0 ${currentLanguage === 'ar' ? 'بايت' : 'bytes'}`;
    
    const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت'];
    const sizesEn = ['bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    
    const size = Math.round(bytes / Math.pow(1024, i) * 100) / 100;
    const unit = currentLanguage === 'ar' ? sizes[i] : sizesEn[i];
    
    return `${size} ${unit}`;
  };
}

/**
 * Helper function to format time ago with translation
 */
export function useTimeAgo() {
  const { t } = useTranslation();
  
  return (date: Date): string => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${t('ago')} ${days} ${t('days')}`;
    if (hours > 0) return `${t('ago')} ${hours} ${t('hours')}`;
    if (minutes > 0) return `${t('ago')} ${minutes} ${t('minutes')}`;
    return t('now');
  };
}