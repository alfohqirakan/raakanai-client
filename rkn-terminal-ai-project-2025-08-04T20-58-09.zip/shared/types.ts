// Additional types for API responses and statistics
export interface StatsResponse {
  totalFiles: number;
  analyzedFiles: number;
  processingFiles: number;
  fileTypes: Record<string, number>;
  todayOperations: number;
}

export interface SecurityConfig {
  encryptionEnabled: boolean;
  antiTamperProtection: boolean;
  anomalyDetection: boolean;
  rateLimiting: boolean;
  inputSanitization: boolean;
  accessControl: boolean;
}

export interface AICapabilities {
  selfLearning: boolean;
  adaptiveProcessing: boolean;
  contextAwareness: boolean;
  multiModalAnalysis: boolean;
  realTimeProcessing: boolean;
  advancedInsights: boolean;
}

export interface SystemHealth {
  status: 'healthy' | 'warning' | 'critical';
  uptime: number;
  processedFiles: number;
  activeConnections: number;
  memoryUsage: number;
  cpuUsage: number;
}