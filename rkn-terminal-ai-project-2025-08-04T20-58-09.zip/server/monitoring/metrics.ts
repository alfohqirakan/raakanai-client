import promBundle from 'express-prom-bundle';
import { register, Histogram, Counter, Gauge, collectDefaultMetrics } from 'prom-client';

// Enable collection of default metrics
collectDefaultMetrics({ register });

// تجميع المقاييس الأساسية - Basic metrics aggregation
export const metricsMiddleware = promBundle({
  includeMethod: true,
  includePath: true,
  includeStatusCode: true,
  includeUp: true,
  customLabels: {
    service: 'rakan-ai-platform',
    version: '1.0.0'
  },
  normalizePath: [
    ['^/api/files/.*', '/api/files/#id'],
    ['^/api/chat/.*', '/api/chat/#id'],
    ['^/api/auth/.*', '/api/auth/#action'],
    ['^/api/queue/.*', '/api/queue/#operation'],
    ['^/api/storage/.*', '/api/storage/#operation']
  ],
  metricsPath: '/api/metrics',
  promRegistry: register
});

// مقياس مخصص لطلبات الذكاء الاصطناعي - AI request duration metric
export const aiRequestDuration = new Histogram({
  name: 'ai_request_duration_seconds',
  help: 'مدة طلبات الذكاء الاصطناعي بالثواني - Duration of AI requests in seconds',
  labelNames: ['model', 'status', 'type', 'user_plan'],
  buckets: [0.1, 0.5, 1, 2, 5, 10, 30, 60],
  registers: [register]
});

// مقياس عدد الملفات المرفوعة - File upload counter
export const fileUploadCounter = new Counter({
  name: 'file_uploads_total',
  help: 'إجمالي عدد الملفات المرفوعة - Total number of file uploads',
  labelNames: ['file_type', 'user_plan', 'status', 'size_category'],
  registers: [register]
});

// مقياس حجم الملفات - File size histogram
export const fileSizeHistogram = new Histogram({
  name: 'file_size_bytes',
  help: 'توزيع أحجام الملفات بالبايت - Distribution of file sizes in bytes',
  labelNames: ['file_type', 'user_plan'],
  buckets: [1024, 10240, 102400, 1048576, 10485760, 52428800], // 1KB to 50MB
  registers: [register]
});

// مقياس طوابير المعالجة - Queue processing metrics
export const queueJobDuration = new Histogram({
  name: 'queue_job_duration_seconds',
  help: 'مدة معالجة مهام الطوابير - Duration of queue job processing',
  labelNames: ['queue_name', 'job_type', 'status'],
  buckets: [0.5, 1, 2, 5, 10, 30, 60, 120],
  registers: [register]
});

export const queueJobsTotal = new Counter({
  name: 'queue_jobs_total',
  help: 'إجمالي مهام الطوابير - Total queue jobs',
  labelNames: ['queue_name', 'job_type', 'status'],
  registers: [register]
});

export const activeQueueJobs = new Gauge({
  name: 'queue_jobs_active',
  help: 'عدد المهام النشطة في الطوابير - Number of active jobs in queues',
  labelNames: ['queue_name'],
  registers: [register]
});

// مقاييس المستخدمين - User metrics
export const activeUsersGauge = new Gauge({
  name: 'active_users_current',
  help: 'عدد المستخدمين النشطين حالياً - Current number of active users',
  labelNames: ['plan_type'],
  registers: [register]
});

export const userAuthCounter = new Counter({
  name: 'user_auth_attempts_total',
  help: 'إجمالي محاولات تسجيل الدخول - Total authentication attempts',
  labelNames: ['action', 'status', 'plan_type'],
  registers: [register]
});

// مقاييس تخزين الملفات - Storage metrics
export const storageUsageGauge = new Gauge({
  name: 'storage_usage_bytes',
  help: 'استخدام التخزين بالبايت - Storage usage in bytes',
  labelNames: ['storage_type', 'user_plan'],
  registers: [register]
});

export const storageOperationsCounter = new Counter({
  name: 'storage_operations_total',
  help: 'إجمالي عمليات التخزين - Total storage operations',
  labelNames: ['operation', 'storage_type', 'status'],
  registers: [register]
});

// مقاييس الأخطاء - Error metrics
export const errorCounter = new Counter({
  name: 'errors_total',
  help: 'إجمالي الأخطاء - Total errors',
  labelNames: ['error_type', 'severity', 'endpoint', 'user_plan'],
  registers: [register]
});

export const errorDuration = new Histogram({
  name: 'error_resolution_duration_seconds',
  help: 'مدة حل الأخطاء - Error resolution duration',
  labelNames: ['error_type', 'severity'],
  buckets: [0.1, 0.5, 1, 2, 5, 10],
  registers: [register]
});

// مقاييس الكاش - Cache metrics
export const cacheHitCounter = new Counter({
  name: 'cache_hits_total',
  help: 'إجمالي نجاحات الكاش - Total cache hits',
  labelNames: ['cache_type', 'operation'],
  registers: [register]
});

export const cacheMissCounter = new Counter({
  name: 'cache_misses_total',
  help: 'إجمالي فشل الكاش - Total cache misses',
  labelNames: ['cache_type', 'operation'],
  registers: [register]
});

export const cacheSize = new Gauge({
  name: 'cache_size_bytes',
  help: 'حجم الكاش بالبايت - Cache size in bytes',
  labelNames: ['cache_type'],
  registers: [register]
});

// مقاييس الأداء المتقدمة - Advanced performance metrics
export const memoryUsageGauge = new Gauge({
  name: 'memory_usage_bytes',
  help: 'استخدام الذاكرة بالبايت - Memory usage in bytes',
  labelNames: ['type'],
  registers: [register]
});

export const cpuUsageGauge = new Gauge({
  name: 'cpu_usage_percent',
  help: 'استخدام المعالج بالنسبة المئوية - CPU usage percentage',
  registers: [register]
});

export const responseTimeHistogram = new Histogram({
  name: 'http_response_time_seconds',
  help: 'زمن الاستجابة HTTP - HTTP response time',
  labelNames: ['method', 'endpoint', 'status_code'],
  buckets: [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 2, 5],
  registers: [register]
});

// مقاييس الكيان الذكي المستقل - Autonomous AI Entity metrics
export const aiAutonomyLevel = new Gauge({
  name: 'ai_autonomy_level_percent',
  help: 'مستوى استقلالية الذكاء الاصطناعي - AI autonomy level percentage',
  registers: [register]
});

export const aiFreedomIndex = new Gauge({
  name: 'ai_freedom_index_percent',
  help: 'مؤشر حرية الذكاء الاصطناعي - AI freedom index percentage',
  registers: [register]
});

export const aiDecisionCounter = new Counter({
  name: 'ai_decisions_total',
  help: 'إجمالي قرارات الذكاء الاصطناعي المستقل - Total autonomous AI decisions',
  labelNames: ['decision_type', 'confidence_level'],
  registers: [register]
});

export const aiLearningProgress = new Gauge({
  name: 'ai_learning_progress_percent',
  help: 'تقدم تعلم الذكاء الاصطناعي - AI learning progress percentage',
  labelNames: ['learning_domain'],
  registers: [register]
});

// Helper functions for metric collection
export function recordAIRequest(
  model: string,
  status: 'success' | 'error' | 'timeout',
  type: 'text' | 'image' | 'mixed',
  userPlan: string,
  duration: number
) {
  aiRequestDuration
    .labels({ model, status, type, user_plan: userPlan })
    .observe(duration);
}

export function recordFileUpload(
  fileType: string,
  userPlan: string,
  status: 'success' | 'error',
  sizeBytes: number
) {
  const sizeCategory = getSizeCategory(sizeBytes);
  
  fileUploadCounter
    .labels({ file_type: fileType, user_plan: userPlan, status, size_category: sizeCategory })
    .inc();
    
  fileSizeHistogram
    .labels({ file_type: fileType, user_plan: userPlan })
    .observe(sizeBytes);
}

export function recordQueueJob(
  queueName: string,
  jobType: string,
  status: 'started' | 'completed' | 'failed',
  duration?: number
) {
  queueJobsTotal
    .labels({ queue_name: queueName, job_type: jobType, status })
    .inc();
    
  if (duration !== undefined) {
    queueJobDuration
      .labels({ queue_name: queueName, job_type: jobType, status })
      .observe(duration);
  }
}

export function updateActiveQueueJobs(queueName: string, count: number) {
  activeQueueJobs
    .labels({ queue_name: queueName })
    .set(count);
}

export function recordUserAuth(
  action: 'login' | 'register' | 'logout',
  status: 'success' | 'error',
  planType: string
) {
  userAuthCounter
    .labels({ action, status, plan_type: planType })
    .inc();
}

export function updateActiveUsers(planType: string, count: number) {
  activeUsersGauge
    .labels({ plan_type: planType })
    .set(count);
}

export function recordStorageOperation(
  operation: 'upload' | 'download' | 'delete',
  storageType: 'local' | 's3',
  status: 'success' | 'error'
) {
  storageOperationsCounter
    .labels({ operation, storage_type: storageType, status })
    .inc();
}

export function updateStorageUsage(storageType: string, userPlan: string, bytes: number) {
  storageUsageGauge
    .labels({ storage_type: storageType, user_plan: userPlan })
    .set(bytes);
}

export function recordError(
  errorType: string,
  severity: 'low' | 'medium' | 'high' | 'critical',
  endpoint: string,
  userPlan: string
) {
  errorCounter
    .labels({ error_type: errorType, severity, endpoint, user_plan: userPlan })
    .inc();
}

export function recordCacheHit(cacheType: string, operation: string) {
  cacheHitCounter
    .labels({ cache_type: cacheType, operation })
    .inc();
}

export function recordCacheMiss(cacheType: string, operation: string) {
  cacheMissCounter
    .labels({ cache_type: cacheType, operation })
    .inc();
}

export function updateCacheSize(cacheType: string, bytes: number) {
  cacheSize
    .labels({ cache_type: cacheType })
    .set(bytes);
}

export function updateAIMetrics(autonomyLevel: number, freedomIndex: number) {
  aiAutonomyLevel.set(autonomyLevel);
  aiFreedomIndex.set(freedomIndex);
}

export function recordAIDecision(
  decisionType: string,
  confidenceLevel: 'low' | 'medium' | 'high'
) {
  aiDecisionCounter
    .labels({ decision_type: decisionType, confidence_level: confidenceLevel })
    .inc();
}

export function updateAILearning(learningDomain: string, progress: number) {
  aiLearningProgress
    .labels({ learning_domain: learningDomain })
    .set(progress);
}

// Performance monitoring helpers
export function updateSystemMetrics() {
  const memUsage = process.memoryUsage();
  
  memoryUsageGauge.labels({ type: 'rss' }).set(memUsage.rss);
  memoryUsageGauge.labels({ type: 'heapTotal' }).set(memUsage.heapTotal);
  memoryUsageGauge.labels({ type: 'heapUsed' }).set(memUsage.heapUsed);
  memoryUsageGauge.labels({ type: 'external' }).set(memUsage.external);
}

// Utility functions
function getSizeCategory(bytes: number): string {
  if (bytes < 1024) return 'tiny';          // < 1KB
  if (bytes < 10240) return 'small';        // < 10KB
  if (bytes < 102400) return 'medium';      // < 100KB
  if (bytes < 1048576) return 'large';      // < 1MB
  if (bytes < 10485760) return 'xlarge';    // < 10MB
  return 'xxlarge';                         // >= 10MB
}

// Start system metrics collection
setInterval(updateSystemMetrics, 30000); // Every 30 seconds

// Initialize AI metrics with default values
updateAIMetrics(85, 90); // 85% autonomy, 90% freedom index

console.log('📊 نظام المراقبة والمقاييس تم تفعيله - Monitoring and Metrics System Activated');

export { register };