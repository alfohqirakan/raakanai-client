/**
 * RKN-Terminal AI Email Service
 * خدمة البريد الإلكتروني لمنصة راكان الذكاء السيادي
 */

import nodemailer from 'nodemailer';
import { log } from '../vite.js';

interface EmailConfig {
  host: string;
  port: number;
  secure: boolean;
  auth: {
    user: string;
    pass: string;
  };
}

interface EmailOptions {
  to: string;
  subject: string;
  text: string;
  html?: string;
  attachments?: Array<{
    filename: string;
    path?: string;
    content?: Buffer;
  }>;
}

class EmailService {
  private transporter: nodemailer.Transporter | null = null;
  private isConfigured = false;

  constructor() {
    this.initializeTransporter();
  }

  private initializeTransporter(): void {
    try {
      // Check for email configuration in environment variables
      const emailConfig = this.getEmailConfig();
      
      if (!emailConfig) {
        log('⚠️ Email service not configured - missing environment variables', 'email');
        return;
      }

      this.transporter = nodemailer.createTransporter({
        host: emailConfig.host,
        port: emailConfig.port,
        secure: emailConfig.secure,
        auth: emailConfig.auth,
        pool: true,
        maxConnections: 5,
        maxMessages: 100,
        rateDelta: 20000,
        rateLimit: 5
      });

      this.isConfigured = true;
      log('📧 Email service initialized successfully', 'email');
      
      // Verify connection
      this.verifyConnection();
    } catch (error) {
      log(`❌ Failed to initialize email service: ${error}`, 'email');
    }
  }

  private getEmailConfig(): EmailConfig | null {
    const host = process.env.SMTP_HOST;
    const port = process.env.SMTP_PORT;
    const user = process.env.SMTP_USER;
    const pass = process.env.SMTP_PASS;

    if (!host || !port || !user || !pass) {
      return null;
    }

    return {
      host,
      port: parseInt(port, 10),
      secure: port === '465', // true for 465, false for other ports
      auth: { user, pass }
    };
  }

  private async verifyConnection(): Promise<void> {
    if (!this.transporter) return;

    try {
      await this.transporter.verify();
      log('✅ Email connection verified successfully', 'email');
    } catch (error) {
      log(`❌ Email connection verification failed: ${error}`, 'email');
      this.isConfigured = false;
    }
  }

  async sendEmail(options: EmailOptions): Promise<boolean> {
    if (!this.isConfigured || !this.transporter) {
      log('⚠️ Email service not configured, skipping email send', 'email');
      return false;
    }

    try {
      const mailOptions = {
        from: process.env.SMTP_FROM || process.env.SMTP_USER,
        to: options.to,
        subject: options.subject,
        text: options.text,
        html: options.html,
        attachments: options.attachments,
        headers: {
          'X-Mailer': 'RKN-Terminal AI',
          'X-Priority': '3',
          'X-MSMail-Priority': 'Normal'
        }
      };

      const result = await this.transporter.sendMail(mailOptions);
      
      log(`📧 Email sent successfully to ${options.to}: ${options.subject}`, 'email');
      log(`📧 Message ID: ${result.messageId}`, 'email');
      
      return true;
    } catch (error) {
      log(`❌ Failed to send email to ${options.to}: ${error}`, 'email');
      return false;
    }
  }

  async sendBulkEmails(emails: EmailOptions[]): Promise<{ sent: number; failed: number }> {
    if (!this.isConfigured) {
      log('⚠️ Email service not configured, skipping bulk email send', 'email');
      return { sent: 0, failed: emails.length };
    }

    let sent = 0;
    let failed = 0;

    for (const email of emails) {
      const success = await this.sendEmail(email);
      if (success) {
        sent++;
      } else {
        failed++;
      }
      
      // Add delay between emails to respect rate limits
      await new Promise(resolve => setTimeout(resolve, 1000));
    }

    log(`📧 Bulk email completed: ${sent} sent, ${failed} failed`, 'email');
    return { sent, failed };
  }

  async sendTemplatedEmail(
    to: string,
    templateName: string,
    subject: string,
    data: Record<string, any>
  ): Promise<boolean> {
    try {
      // In a real implementation, you would load email templates from files
      const htmlTemplate = this.getEmailTemplate(templateName);
      const textTemplate = this.getTextTemplate(templateName);

      // Simple template replacement (in production, use a proper template engine)
      let html = htmlTemplate;
      let text = textTemplate;

      Object.entries(data).forEach(([key, value]) => {
        const placeholder = `{{${key}}}`;
        html = html.replace(new RegExp(placeholder, 'g'), String(value));
        text = text.replace(new RegExp(placeholder, 'g'), String(value));
      });

      return await this.sendEmail({
        to,
        subject,
        text,
        html
      });
    } catch (error) {
      log(`❌ Failed to send templated email: ${error}`, 'email');
      return false;
    }
  }

  private getEmailTemplate(templateName: string): string {
    // Basic email templates - in production, load from files
    const templates: Record<string, string> = {
      analysisComplete: `
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
          <meta charset="utf-8">
          <title>اكتمل تحليل الملف</title>
          <style>
            body { font-family: 'Cairo', Arial, sans-serif; background-color: #f8f9fa; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
            .header { background: linear-gradient(135deg, #002B5B, #F5C542); color: white; padding: 20px; border-radius: 10px; text-align: center; }
            .content { padding: 20px; line-height: 1.6; }
            .footer { text-align: center; padding: 15px; color: #666; border-top: 1px solid #eee; }
            .btn { background: #002B5B; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎯 RKN-Terminal AI</h1>
              <p>اكتمل تحليل الملف بنجاح</p>
            </div>
            <div class="content">
              <h2>مرحباً {{username}}،</h2>
              <p>اكتمل تحليل الملف <strong>"{{fileName}}"</strong> بنجاح!</p>
              <p>النتائج متاحة الآن للعرض والتحميل.</p>
              <a href="{{fileUrl}}" class="btn">عرض النتائج</a>
              <div style="margin-top: 20px; padding: 15px; background: #f8f9fa; border-radius: 5px;">
                <h3>ملخص التحليل:</h3>
                <p>{{summary}}</p>
              </div>
            </div>
            <div class="footer">
              <p>© 2025 RKN-Terminal AI - راكان الذكاء السيادي</p>
            </div>
          </div>
        </body>
        </html>
      `,
      newMessage: `
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
          <meta charset="utf-8">
          <title>رسالة جديدة</title>
          <style>
            body { font-family: 'Cairo', Arial, sans-serif; background-color: #f8f9fa; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; }
            .header { background: linear-gradient(135deg, #002B5B, #F5C542); color: white; padding: 20px; border-radius: 10px; text-align: center; }
            .content { padding: 20px; line-height: 1.6; }
            .message { background: #e3f2fd; padding: 15px; border-radius: 5px; border-right: 4px solid #2196f3; margin: 15px 0; }
            .footer { text-align: center; padding: 15px; color: #666; border-top: 1px solid #eee; }
            .btn { background: #002B5B; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>💬 RKN-Terminal AI</h1>
              <p>رسالة جديدة</p>
            </div>
            <div class="content">
              <h2>مرحباً {{username}}،</h2>
              <p>لديك رسالة جديدة بخصوص الملف <strong>"{{fileName}}"</strong></p>
              <div class="message">
                <p><strong>من:</strong> {{senderName}}</p>
                <p><strong>الرسالة:</strong></p>
                <p>{{messagePreview}}</p>
              </div>
              <a href="{{fileUrl}}" class="btn">عرض المحادثة</a>
            </div>
            <div class="footer">
              <p>© 2025 RKN-Terminal AI - راكان الذكاء السيادي</p>
            </div>
          </div>
        </body>
        </html>
      `
    };

    return templates[templateName] || templates.analysisComplete;
  }

  private getTextTemplate(templateName: string): string {
    const templates: Record<string, string> = {
      analysisComplete: `
مرحباً {{username}}،

اكتمل تحليل الملف "{{fileName}}" بنجاح!

النتائج متاحة الآن للعرض والتحميل من خلال الرابط:
{{fileUrl}}

ملخص التحليل:
{{summary}}

مع تحيات فريق RKN-Terminal AI
      `,
      newMessage: `
مرحباً {{username}}،

لديك رسالة جديدة بخصوص الملف "{{fileName}}"

من: {{senderName}}
الرسالة: {{messagePreview}}

يمكنك عرض المحادثة كاملة من خلال الرابط:
{{fileUrl}}

مع تحيات فريق RKN-Terminal AI
      `
    };

    return templates[templateName] || templates.analysisComplete;
  }

  getStatus(): {
    isConfigured: boolean;
    transporter: boolean;
    configuration: Partial<EmailConfig>;
  } {
    const config = this.getEmailConfig();
    return {
      isConfigured: this.isConfigured,
      transporter: !!this.transporter,
      configuration: config ? {
        host: config.host,
        port: config.port,
        secure: config.secure,
        auth: { user: config.auth.user, pass: '***' }
      } : {}
    };
  }
}

// Export singleton instance
export const emailService = new EmailService();

// Convenience function for backwards compatibility
export async function sendEmail(to: string, subject: string, text: string, html?: string): Promise<boolean> {
  return emailService.sendEmail({ to, subject, text, html });
}