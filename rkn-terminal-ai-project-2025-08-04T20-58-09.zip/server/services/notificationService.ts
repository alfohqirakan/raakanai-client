/**
 * RKN-Terminal AI Notification Service
 * خدمة الإشعارات لمنصة راكان الذكاء السيادي
 */

import { render } from 'mustache';
import { emailService } from './emailService.js';
import { emitToUser, broadcastNotification } from './socketService.js';
import { log } from '../vite.js';

interface User {
  id: number;
  username: string;
  email?: string;
  plan: string;
}

interface NotificationContext {
  fileName?: string;
  fileUrl?: string;
  fileId?: string;
  summary?: string;
  messagePreview?: string;
  senderName?: string;
  progress?: number;
  stage?: string;
  analysisResults?: any;
  [key: string]: any;
}

interface NotificationTemplate {
  subject: string;
  text: string;
  html?: string;
  websocketEvent?: string;
  priority?: 'low' | 'normal' | 'high' | 'urgent';
}

const templates: Record<string, NotificationTemplate> = {
  analysisComplete: {
    subject: 'اكتمل تحليل الملف - {{fileName}}',
    text: `مرحباً {{username}}،
اكتمل تحليل الملف "{{fileName}}" بنجاح.

ملخص النتائج:
{{summary}}

يمكنك عرض النتائج كاملة من خلال الرابط: {{fileUrl}}

مع تحيات فريق RKN-Terminal AI`,
    websocketEvent: 'analysisComplete',
    priority: 'high'
  },

  analysisStarted: {
    subject: 'بدء تحليل الملف - {{fileName}}',
    text: `مرحباً {{username}}،
بدأ تحليل الملف "{{fileName}}" بنجاح.

سيتم إشعارك فور اكتمال التحليل.

مع تحيات فريق RKN-Terminal AI`,
    websocketEvent: 'analysisStarted',
    priority: 'normal'
  },

  analysisProgress: {
    subject: 'تقدم تحليل الملف - {{fileName}}',
    text: `مرحباً {{username}}،
تقدم تحليل الملف "{{fileName}}": {{progress}}%

المرحلة الحالية: {{stage}}

مع تحيات فريق RKN-Terminal AI`,
    websocketEvent: 'analysisProgress',
    priority: 'low'
  },

  analysisError: {
    subject: 'خطأ في تحليل الملف - {{fileName}}',
    text: `مرحباً {{username}}،
حدث خطأ أثناء تحليل الملف "{{fileName}}".

تفاصيل الخطأ: {{errorMessage}}

يرجى المحاولة مرة أخرى أو التواصل مع الدعم الفني.

مع تحيات فريق RKN-Terminal AI`,
    websocketEvent: 'analysisError',
    priority: 'urgent'
  },

  newMessage: {
    subject: 'رسالة جديدة بخصوص {{fileName}}',
    text: `مرحباً {{username}}،
لديك رسالة جديدة بخصوص الملف "{{fileName}}":

من: {{senderName}}
الرسالة: "{{messagePreview}}..."

يمكنك عرض المحادثة كاملة من خلال الرابط: {{fileUrl}}

مع تحيات فريق RKN-Terminal AI`,
    websocketEvent: 'newMessage',
    priority: 'normal'
  },

  welcomeMessage: {
    subject: 'مرحباً بك في RKN-Terminal AI',
    text: `مرحباً {{username}}،

نرحب بك في منصة راكان الذكاء السيادي - RKN-Terminal AI

خطتك الحالية: {{planName}}
حد الرفع: {{uploadLimit}} ملف

يمكنك الآن:
• رفع وتحليل الملفات بالذكاء الاصطناعي
• التواصل الفوري مع النظام
• تحميل تقارير التحليل المفصلة
• مراقبة تقدم التحليل في الوقت الفعلي

مع تحيات فريق RKN-Terminal AI`,
    websocketEvent: 'welcome',
    priority: 'normal'
  },

  systemMaintenance: {
    subject: 'إشعار صيانة النظام - RKN-Terminal AI',
    text: `مرحباً {{username}}،

سيتم إجراء صيانة دورية للنظام:

وقت الصيانة: {{maintenanceTime}}
المدة المتوقعة: {{duration}}

خلال هذه الفترة قد تواجه انقطاع مؤقت في الخدمة.

نعتذر عن أي إزعاج وشكراً لتفهمكم.

مع تحيات فريق RKN-Terminal AI`,
    websocketEvent: 'systemMaintenance',
    priority: 'high'
  },

  uploadLimitReached: {
    subject: 'تم الوصول لحد الرفع - RKN-Terminal AI',
    text: `مرحباً {{username}}،

لقد وصلت إلى الحد الأقصى للرفع في خطتك الحالية ({{uploadLimit}} ملف).

للاستمرار في رفع المزيد من الملفات، يمكنك:
• ترقية الخطة إلى Professional
• انتظار بداية الشهر القادم لتجديد الحد

مع تحيات فريق RKN-Terminal AI`,
    websocketEvent: 'uploadLimitReached',
    priority: 'high'
  }
};

class NotificationService {
  async sendNotification(
    type: keyof typeof templates,
    user: User,
    context: NotificationContext,
    options: {
      sendEmail?: boolean;
      sendWebSocket?: boolean;
      sendBrowser?: boolean;
    } = {}
  ): Promise<{
    email: boolean;
    websocket: boolean;
    browser: boolean;
  }> {
    const template = templates[type];
    if (!template) {
      log(`⚠️ Unknown notification template: ${type}`, 'notification');
      return { email: false, websocket: false, browser: false };
    }

    // Prepare context with user data
    const fullContext = {
      username: user.username,
      userId: user.id,
      userPlan: user.plan,
      ...context
    };

    const results = {
      email: false,
      websocket: false,
      browser: false
    };

    // Send email notification
    if (options.sendEmail !== false && user.email) {
      try {
        const subject = render(template.subject, fullContext);
        const text = render(template.text, fullContext);
        
        results.email = await emailService.sendEmail({
          to: user.email,
          subject,
          text
        });

        if (results.email) {
          log(`📧 Email notification sent to ${user.username}: ${type}`, 'notification');
        }
      } catch (error) {
        log(`❌ Failed to send email notification: ${error}`, 'notification');
      }
    }

    // Send WebSocket notification
    if (options.sendWebSocket !== false && template.websocketEvent) {
      try {
        const notificationData = {
          type: template.websocketEvent,
          title: render(template.subject, fullContext),
          message: render(template.text, fullContext).substring(0, 200) + '...',
          context: fullContext,
          priority: template.priority || 'normal',
          timestamp: new Date()
        };

        emitToUser(user.id, 'notification', notificationData);
        results.websocket = true;
        
        log(`📡 WebSocket notification sent to ${user.username}: ${type}`, 'notification');
      } catch (error) {
        log(`❌ Failed to send WebSocket notification: ${error}`, 'notification');
      }
    }

    return results;
  }

  async sendBulkNotification(
    type: keyof typeof templates,
    users: User[],
    context: NotificationContext,
    options: {
      sendEmail?: boolean;
      sendWebSocket?: boolean;
    } = {}
  ): Promise<{
    total: number;
    successful: number;
    failed: number;
  }> {
    const results = {
      total: users.length,
      successful: 0,
      failed: 0
    };

    for (const user of users) {
      try {
        const result = await this.sendNotification(type, user, context, options);
        
        if (result.email || result.websocket) {
          results.successful++;
        } else {
          results.failed++;
        }
      } catch (error) {
        results.failed++;
        log(`❌ Failed to send notification to ${user.username}: ${error}`, 'notification');
      }

      // Add small delay to prevent overwhelming the system
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    log(`📢 Bulk notification completed: ${results.successful}/${results.total} successful`, 'notification');
    return results;
  }

  async sendSystemNotification(
    message: string,
    type: 'info' | 'warning' | 'error' | 'success' = 'info',
    targetUsers?: number[]
  ): Promise<void> {
    try {
      const notification = {
        type,
        title: 'إشعار النظام',
        message,
        timestamp: new Date(),
        system: true
      };

      if (targetUsers && targetUsers.length > 0) {
        // Send to specific users
        for (const userId of targetUsers) {
          emitToUser(userId, 'systemNotification', notification);
        }
        log(`📢 System notification sent to ${targetUsers.length} specific users`, 'notification');
      } else {
        // Broadcast to all connected users
        broadcastNotification(notification);
        log('📢 System notification broadcasted to all users', 'notification');
      }
    } catch (error) {
      log(`❌ Failed to send system notification: ${error}`, 'notification');
    }
  }

  async sendAnalysisProgressUpdate(
    user: User,
    fileId: string,
    fileName: string,
    progress: number,
    stage: string,
    message?: string
  ): Promise<void> {
    try {
      // Send real-time WebSocket update
      emitToUser(user.id, 'analysisProgress', {
        fileId,
        fileName,
        progress,
        stage,
        message: message || `جارٍ ${stage}...`,
        timestamp: new Date()
      });

      // Send email notification only at certain milestones or completion
      if (progress === 100) {
        await this.sendNotification('analysisComplete', user, {
          fileName,
          fileId,
          fileUrl: `/files/${fileId}`,
          summary: message || 'اكتمل التحليل بنجاح'
        }, {
          sendEmail: true,
          sendWebSocket: false // Already sent above
        });
      }

      log(`📊 Analysis progress update sent to ${user.username}: ${progress}%`, 'notification');
    } catch (error) {
      log(`❌ Failed to send analysis progress update: ${error}`, 'notification');
    }
  }

  async sendChatNotification(
    user: User,
    fileName: string,
    senderName: string,
    messagePreview: string,
    fileUrl: string
  ): Promise<void> {
    try {
      await this.sendNotification('newMessage', user, {
        fileName,
        senderName,
        messagePreview: messagePreview.substring(0, 100),
        fileUrl
      }, {
        sendEmail: true,
        sendWebSocket: true
      });

      log(`💬 Chat notification sent to ${user.username}`, 'notification');
    } catch (error) {
      log(`❌ Failed to send chat notification: ${error}`, 'notification');
    }
  }

  getAvailableTemplates(): string[] {
    return Object.keys(templates);
  }

  getTemplateInfo(type: string): NotificationTemplate | null {
    return templates[type] || null;
  }

  async getNotificationHistory(userId: number, limit: number = 50): Promise<any[]> {
    // In a real implementation, this would fetch from a database
    // For now, return empty array
    log(`📋 Notification history requested for user ${userId}`, 'notification');
    return [];
  }

  async markNotificationAsRead(userId: number, notificationId: string): Promise<boolean> {
    // In a real implementation, this would update the database
    log(`✅ Notification ${notificationId} marked as read for user ${userId}`, 'notification');
    return true;
  }
}

// Export singleton instance
export const notificationService = new NotificationService();

// Convenience functions for common notifications
export async function notifyAnalysisComplete(
  user: User,
  fileName: string,
  fileId: string,
  summary: string
): Promise<void> {
  await notificationService.sendNotification('analysisComplete', user, {
    fileName,
    fileId,
    fileUrl: `/files/${fileId}`,
    summary
  });
}

export async function notifyAnalysisProgress(
  user: User,
  fileId: string,
  fileName: string,
  progress: number,
  stage: string,
  message?: string
): Promise<void> {
  await notificationService.sendAnalysisProgressUpdate(
    user,
    fileId,
    fileName,
    progress,
    stage,
    message
  );
}

export async function notifyNewMessage(
  user: User,
  fileName: string,
  senderName: string,
  messagePreview: string,
  fileUrl: string
): Promise<void> {
  await notificationService.sendChatNotification(
    user,
    fileName,
    senderName,
    messagePreview,
    fileUrl
  );
}

export async function notifySystemMaintenance(
  maintenanceTime: string,
  duration: string,
  targetUsers?: number[]
): Promise<void> {
  await notificationService.sendSystemNotification(
    `صيانة النظام مجدولة في ${maintenanceTime} لمدة ${duration}`,
    'warning',
    targetUsers
  );
}