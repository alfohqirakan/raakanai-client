import OpenAI from "openai";
import { retryWithBackoff, sleep, getFileCategory, formatFileSize, detectLanguage } from '../utils/helpers.js';
import { robustAIRequest, smartAIRetry, aiCircuitBreaker } from './aiRetry.js';

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_KEY || "sk-default-key"
});

/**
 * Enhanced content analysis with retry logic and Arabic focus
 */
export async function analyzeContent(
  content: string,
  fileType: string,
  maxRetries: number = 3
): Promise<string> {
  return retryWithBackoff(async () => {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o', // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: 'system',
          content: `أنت راكان، مساعد ذكاء اصطناعي متقدم ومتخصص في تحليل ${fileType}. 
          قدم تحليلاً مفصلاً وشاملاً باللغة العربية يشمل:
          - ملخص واضح ومفيد
          - النقاط الرئيسية والمهمة
          - التصنيف والموضوعات
          - التقييم والتوصيات
          
          اجعل التحليل عملياً ومفيداً للمستخدم.`,
        },
        { 
          role: 'user', 
          content: `يرجى تحليل هذا المحتوى بشكل شامل ومفصل:\n\n${content}` 
        },
      ],
      max_tokens: 2000,
      temperature: 0.7,
    });

    return response.choices[0].message.content || 'فشل في إنتاج التحليل';
  }, maxRetries);
}

export interface FileAnalysis {
  summary: string;
  keyPoints: string[];
  categories: string[];
  sentiment?: number;
  confidence: number;
  language: string;
  wordCount?: number;
}

export async function analyzeText(text: string): Promise<FileAnalysis> {
  try {
    const fileCategory = getFileCategory('text/plain');
    const enhancedAnalysis = await analyzeContent(text, fileCategory);

    // Parse enhanced analysis or fallback to structured format
    const response = await retryWithBackoff(async () => {
      return await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "أنت راكان، محلل مستندات خبير. حلل النص المقدم وأرجع تحليلاً شاملاً بصيغة JSON باللغة العربية. يجب أن يشمل: ملخص، نقاط رئيسية، تصنيفات، تقييم المشاعر (1-5)، مستوى الثقة (0-1)، اللغة المكتشفة، وعدد الكلمات."
          },
          {
            role: "user",
            content: `يرجى تحليل هذا النص وتقديم تحليل مفصل:\n\n${text.substring(0, 4000)}`
          }
        ],
        response_format: { type: "json_object" },
      });
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      summary: result.summary || enhancedAnalysis || "تم تحليل النص بنجاح",
      keyPoints: result.keyPoints || result.النقاط_الرئيسية || ['نص تم تحليله'],
      categories: result.categories || result.التصنيفات || ['محتوى نصي'],
      sentiment: Math.max(1, Math.min(5, result.sentiment || result.المشاعر || 3)),
      confidence: Math.max(0, Math.min(1, result.confidence || result.الثقة || 0.8)),
      language: result.language || result.اللغة || detectLanguage(text),
      wordCount: result.wordCount || result.عدد_الكلمات || text.split(/\s+/).length,
    };
  } catch (error) {
    console.error("Error analyzing text:", error);
    throw new Error("فشل في تحليل النص بواسطة راكان: " + (error as Error).message);
  }
}

export async function analyzeImage(base64Image: string): Promise<FileAnalysis> {
  try {
    const fileCategory = getFileCategory('image/jpeg');
    
    const response = await retryWithBackoff(async () => {
      return await openai.chat.completions.create({
        model: "gpt-4o", 
        messages: [
          {
            role: "system",
            content: "أنت راكان، خبير تحليل الصور بالذكاء الاصطناعي. حلل الصورة وأرجع تحليلاً شاملاً بصيغة JSON باللغة العربية."
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: `حلل هذه الصورة بشكل مفصل وقدم تحليلاً شاملاً يشمل: الوصف، العناصر الرئيسية، الألوان، التصنيفات، أي نصوص مرئية، والسياق. أرجع النتيجة بصيغة JSON.`
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/jpeg;base64,${base64Image}`
                }
              }
            ],
          },
        ],
        response_format: { type: "json_object" },
        max_tokens: 1000,
      });
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      summary: result.description || result.summary || result.الوصف || "تم تحليل الصورة بنجاح",
      keyPoints: result.keyElements || result.keyPoints || result.العناصر_الرئيسية || ['صورة تم تحليلها'],
      categories: result.categories || result.التصنيفات || ["صورة"],
      confidence: Math.max(0, Math.min(1, result.confidence || result.الثقة || 0.9)),
      language: result.language || result.اللغة || "بصري",
    };
  } catch (error) {
    console.error("Error analyzing image:", error);
    throw new Error("فشل في تحليل الصورة بواسطة راكان: " + (error as Error).message);
  }
}

export async function chatWithAI(message: string, context?: string): Promise<string> {
  try {
    const systemMessage = context 
      ? `أنت راكان، مساعد ذكاء اصطناعي متقدم وذكي يتحدث العربية. لديك إمكانية الوصول لسياق تحليل الملفات: ${context}. أجب بطريقة مفيدة ومفصلة باللغة العربية.`
      : "أنت راكان، مساعد ذكاء اصطناعي متقدم وذكي يتحدث العربية. أجب بطريقة مفيدة ومفصلة باللغة العربية.";

    const response = await retryWithBackoff(async () => {
      return await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: systemMessage
          },
          {
            role: "user",
            content: message
          }
        ],
        max_tokens: 800,
        temperature: 0.7,
      });
    });

    return response.choices[0].message.content || "عذراً، لا أستطيع الإجابة في الوقت الحالي. يرجى إعادة المحاولة.";
  } catch (error) {
    console.error("Error in AI chat:", error);
    throw new Error("فشل في التواصل مع راكان AI: " + (error as Error).message);
  }
}
