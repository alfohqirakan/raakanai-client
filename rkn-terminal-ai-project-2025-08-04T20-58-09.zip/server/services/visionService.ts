import OpenAI from 'openai';
import sharp from 'sharp';
import { success, error } from '../utils/apiResponse.js';
import { recordAIRequest, recordError } from '../monitoring/metrics.js';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

interface VisionAnalysisResult {
  objects: string[];
  text: string;
  scene: string;
  description: string;
  confidence: number;
  metadata: {
    imageSize: { width: number; height: number };
    format: string;
    quality: string;
  };
}

interface ImageProcessingMetadata {
  originalSize: { width: number; height: number };
  processedSize: { width: number; height: number };
  format: string;
  quality: number;
  compressionRatio: number;
}

export async function enhancedImageAnalysis(imageBuffer: Buffer, fileName: string): Promise<VisionAnalysisResult> {
  const startTime = Date.now();
  
  try {
    console.log(`🖼️ RKN Vision: Starting enhanced analysis for ${fileName}`);
    
    // Get original image metadata
    const originalMetadata = await sharp(imageBuffer).metadata();
    
    // تحسين الصورة للتحليل الأمثل
    const processedImage = await sharp(imageBuffer)
      .resize(1024, 1024, { 
        fit: 'inside',
        withoutEnlargement: true 
      })
      .jpeg({ 
        quality: 90,
        progressive: true 
      })
      .toBuffer();

    const processedMetadata = await sharp(processedImage).metadata();
    
    // تحويل إلى base64 للإرسال لـ OpenAI
    const base64Image = processedImage.toString('base64');
    
    // تحليل متعدد المستويات باستخدام GPT-4o Vision
    const [objectDetection, textExtraction, sceneAnalysis] = await Promise.all([
      detectObjects(base64Image, fileName),
      extractText(base64Image, fileName),
      analyzeScene(base64Image, fileName)
    ]);

    const processingTime = Date.now() - startTime;
    
    // حساب معدل الضغط
    const compressionRatio = originalMetadata.size ? 
      Math.round((originalMetadata.size / processedImage.length) * 100) / 100 : 1;

    const result: VisionAnalysisResult = {
      objects: objectDetection.objects,
      text: textExtraction.text,
      scene: sceneAnalysis.scene,
      description: sceneAnalysis.description,
      confidence: Math.min(objectDetection.confidence, textExtraction.confidence, sceneAnalysis.confidence),
      metadata: {
        imageSize: {
          width: processedMetadata.width || 0,
          height: processedMetadata.height || 0
        },
        format: processedMetadata.format || 'unknown',
        quality: 'optimized'
      }
    };

    // تسجيل المقاييس
    recordAIRequest('vision_analysis', 'success', processingTime);
    
    console.log(`✅ RKN Vision: Analysis completed for ${fileName} in ${processingTime}ms`);
    console.log(`📊 Compression: ${originalMetadata.size} → ${processedImage.length} bytes (${compressionRatio}x)`);
    
    return result;

  } catch (err: any) {
    const processingTime = Date.now() - startTime;
    recordAIRequest('vision_analysis', 'error', processingTime);
    recordError('vision_analysis', err.message);
    
    console.error(`❌ RKN Vision: Analysis failed for ${fileName}:`, err);
    throw new Error(`فشل في تحليل الصورة: ${err.message}`);
  }
}

async function detectObjects(base64Image: string, fileName: string): Promise<{ objects: string[]; confidence: number }> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `أنت خبير في كشف الأشياء في الصور. قم بتحليل الصورة وحدد جميع الأشياء الموجودة.
          أجب بصيغة JSON التالية: {"objects": ["شيء1", "شيء2"], "confidence": 0.95}
          استخدم الأسماء العربية للأشياء مع ذكر النسخة الإنجليزية بين قوسين إذا لزم الأمر.`
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `حلل هذه الصورة وحدد جميع الأشياء الموجودة فيها. اسم الملف: ${fileName}`
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ]
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000
    });

    const result = JSON.parse(response.choices[0].message.content || '{"objects": [], "confidence": 0}');
    return {
      objects: result.objects || [],
      confidence: result.confidence || 0.7
    };

  } catch (err: any) {
    console.error('❌ Object detection failed:', err);
    return { objects: ['فشل في كشف الأشياء'], confidence: 0 };
  }
}

async function extractText(base64Image: string, fileName: string): Promise<{ text: string; confidence: number }> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `أنت خبير في استخراج النصوص من الصور (OCR). قم بقراءة وتحليل جميع النصوص الموجودة.
          أجب بصيغة JSON التالية: {"text": "النص المستخرج", "confidence": 0.95}
          إذا لم تجد نصوص، أجب بـ "لا توجد نصوص مقروءة".`
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `استخرج جميع النصوص الموجودة في هذه الصورة. اسم الملف: ${fileName}`
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ]
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1500
    });

    const result = JSON.parse(response.choices[0].message.content || '{"text": "", "confidence": 0}');
    return {
      text: result.text || 'لا توجد نصوص مقروءة',
      confidence: result.confidence || 0.7
    };

  } catch (err: any) {
    console.error('❌ Text extraction failed:', err);
    return { text: 'فشل في استخراج النص', confidence: 0 };
  }
}

async function analyzeScene(base64Image: string, fileName: string): Promise<{ scene: string; description: string; confidence: number }> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: `أنت خبير في تحليل المشاهد والصور. قم بوصف المشهد والسياق العام للصورة.
          أجب بصيغة JSON التالية: {"scene": "نوع المشهد", "description": "وصف مفصل", "confidence": 0.95}
          اجعل الوصف شاملاً ومفيداً باللغة العربية.`
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `حلل هذا المشهد واعطِ وصفاً شاملاً للصورة ومحتواها. اسم الملف: ${fileName}`
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ]
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 2000
    });

    const result = JSON.parse(response.choices[0].message.content || '{"scene": "", "description": "", "confidence": 0}');
    return {
      scene: result.scene || 'مشهد غير محدد',
      description: result.description || 'فشل في تحليل المشهد',
      confidence: result.confidence || 0.7
    };

  } catch (err: any) {
    console.error('❌ Scene analysis failed:', err);
    return { 
      scene: 'فشل في تحليل المشهد', 
      description: 'حدث خطأ أثناء تحليل المشهد',
      confidence: 0 
    };
  }
}

// دالة لمعالجة الصور المتعددة دفعة واحدة
export async function batchImageAnalysis(images: { buffer: Buffer; fileName: string }[]): Promise<VisionAnalysisResult[]> {
  console.log(`🎯 RKN Vision: Starting batch analysis for ${images.length} images`);
  
  const results = await Promise.allSettled(
    images.map(img => enhancedImageAnalysis(img.buffer, img.fileName))
  );

  const successfulResults: VisionAnalysisResult[] = [];
  const errors: string[] = [];

  results.forEach((result, index) => {
    if (result.status === 'fulfilled') {
      successfulResults.push(result.value);
    } else {
      errors.push(`${images[index].fileName}: ${result.reason.message}`);
    }
  });

  if (errors.length > 0) {
    console.warn(`⚠️ RKN Vision: ${errors.length} images failed analysis:`, errors);
  }

  console.log(`✅ RKN Vision: Batch analysis completed - ${successfulResults.length}/${images.length} successful`);
  return successfulResults;
}

// دالة لتحسين الصورة فقط بدون تحليل
export async function optimizeImage(imageBuffer: Buffer, options: {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  format?: 'jpeg' | 'png' | 'webp';
} = {}): Promise<{ buffer: Buffer; metadata: ImageProcessingMetadata }> {
  const {
    maxWidth = 1920,
    maxHeight = 1080,
    quality = 85,
    format = 'jpeg'
  } = options;

  try {
    const originalMetadata = await sharp(imageBuffer).metadata();
    
    let pipeline = sharp(imageBuffer)
      .resize(maxWidth, maxHeight, { 
        fit: 'inside',
        withoutEnlargement: true 
      });

    // تطبيق التنسيق المطلوب
    switch (format) {
      case 'jpeg':
        pipeline = pipeline.jpeg({ quality, progressive: true });
        break;
      case 'png':
        pipeline = pipeline.png({ quality, progressive: true });
        break;
      case 'webp':
        pipeline = pipeline.webp({ quality });
        break;
    }

    const optimizedBuffer = await pipeline.toBuffer();
    const processedMetadata = await sharp(optimizedBuffer).metadata();
    
    const compressionRatio = originalMetadata.size ? 
      Math.round((originalMetadata.size / optimizedBuffer.length) * 100) / 100 : 1;

    return {
      buffer: optimizedBuffer,
      metadata: {
        originalSize: {
          width: originalMetadata.width || 0,
          height: originalMetadata.height || 0
        },
        processedSize: {
          width: processedMetadata.width || 0,
          height: processedMetadata.height || 0
        },
        format: format,
        quality: quality,
        compressionRatio: compressionRatio
      }
    };

  } catch (err: any) {
    console.error('❌ Image optimization failed:', err);
    throw new Error(`فشل في تحسين الصورة: ${err.message}`);
  }
}

console.log('🎯 RKN-Terminal AI Enhanced Vision Service initialized with GPT-4o');

export default { enhancedImageAnalysis, batchImageAnalysis, optimizeImage };