import type { Express } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs/promises';
import { storage } from '../storage.js';
import { insertFileSchema } from '@shared/schema.js';
import { success, error } from '../utils/apiResponse.js';
import { addFileProcessingJob } from './simpleQueue.js';
import { recordFileUpload, recordStorageOperation, recordError } from '../monitoring/metrics.js';

// Upload directory configuration
const uploadDir = path.join(process.cwd(), "uploads");

// Store chunks temporarily in memory with TTL
const chunkedUploads = new Map<string, {
  chunks: Buffer[];
  fileName: string;
  totalChunks: number;
  fileSize: number;
  receivedChunks: number;
  userId: number;
  timestamp: number;
}>();

// Cleanup old upload sessions (older than 1 hour)
setInterval(() => {
  const now = Date.now();
  const oneHour = 60 * 60 * 1000;
  
  for (const [fileId, upload] of chunkedUploads.entries()) {
    if (now - upload.timestamp > oneHour) {
      chunkedUploads.delete(fileId);
      console.log(`🧹 Cleaned up expired upload session: ${fileId}`);
    }
  }
}, 15 * 60 * 1000); // Run every 15 minutes

// Helper function to get MIME type from extension
function getMimeType(extension: string): string {
  const mimeTypes: Record<string, string> = {
    '.pdf': 'application/pdf',
    '.txt': 'text/plain',
    '.md': 'text/markdown',
    '.json': 'application/json',
    '.csv': 'text/csv',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.mp4': 'video/mp4',
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav',
    '.zip': 'application/zip',
    '.rar': 'application/x-rar-compressed',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.doc': 'application/msword',
    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
  };
  
  return mimeTypes[extension] || 'application/octet-stream';
}

export function setupChunkedUploadRoutes(router: Express) {
  // Multer configuration for chunks
  const chunkStorage = multer.memoryStorage();
  const chunkUpload = multer({ 
    storage: chunkStorage,
    limits: { 
      fileSize: 10 * 1024 * 1024, // 10MB per chunk
      fieldSize: 10 * 1024 * 1024 // 10MB field size
    }
  });

  // Chunk upload endpoint
  router.post("/api/upload/chunk", chunkUpload.single('chunk'), async (req: any, res: any) => {
    try {
      // Check authentication
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لرفع الملفات", "NOT_AUTHENTICATED"));
      }

      const { fileId, chunkIndex, totalChunks, fileName, fileSize } = req.body;
      const chunkBuffer = req.file?.buffer;

      if (!chunkBuffer || !fileId || chunkIndex === undefined || !totalChunks || !fileName) {
        return res.status(400).json(error('بيانات الجزء مفقودة', 'MISSING_CHUNK_DATA'));
      }

      const chunkIdx = parseInt(chunkIndex);
      const totalChunksNum = parseInt(totalChunks);
      const fileSizeNum = parseInt(fileSize);

      // Initialize upload tracking
      if (!chunkedUploads.has(fileId)) {
        chunkedUploads.set(fileId, {
          chunks: new Array(totalChunksNum),
          fileName,
          totalChunks: totalChunksNum,
          fileSize: fileSizeNum,
          receivedChunks: 0,
          userId: req.session.userId,
          timestamp: Date.now()
        });
      }

      const uploadData = chunkedUploads.get(fileId)!;
      uploadData.chunks[chunkIdx] = chunkBuffer;
      uploadData.receivedChunks++;

      console.log(`📦 RKN Chunk ${chunkIdx + 1}/${totalChunksNum} received for ${fileName}`);

      res.json(success('تم رفع الجزء بنجاح', {
        fileId,
        chunkIndex: chunkIdx,
        received: uploadData.receivedChunks,
        total: totalChunksNum,
        progress: Math.round((uploadData.receivedChunks / totalChunksNum) * 100)
      }));

      recordFileUpload('chunk', uploadData.userId, chunkBuffer.length);

    } catch (err: any) {
      console.error('❌ RKN Chunk upload error:', err);
      recordError('chunk_upload', err.message);
      res.status(500).json(error('فشل في رفع الجزء', 'CHUNK_UPLOAD_ERROR'));
    }
  });

  // Complete upload endpoint
  router.post("/api/upload/complete", async (req: any, res: any) => {
    try {
      // Check authentication
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لرفع الملفات", "NOT_AUTHENTICATED"));
      }

      const { fileId, fileName, totalChunks, fileSize } = req.body;

      if (!fileId || !fileName || !totalChunks || !fileSize) {
        return res.status(400).json(error('بيانات اكتمال الرفع مفقودة', 'MISSING_COMPLETION_DATA'));
      }

      const uploadData = chunkedUploads.get(fileId);
      if (!uploadData) {
        return res.status(404).json(error('جلسة الرفع غير موجودة', 'UPLOAD_SESSION_NOT_FOUND'));
      }

      // Verify all chunks received
      if (uploadData.receivedChunks !== uploadData.totalChunks) {
        return res.status(400).json(error(
          `رفع غير مكتمل - تم استلام ${uploadData.receivedChunks} من ${uploadData.totalChunks} أجزاء`, 
          'INCOMPLETE_UPLOAD'
        ));
      }

      // Get user and check limits
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        chunkedUploads.delete(fileId);
        return res.status(404).json(error("المستخدم غير موجود", "USER_NOT_FOUND"));
      }

      // Check plan limits
      const uploadLimit = user.plan === 'pro' ? 100 : 5;
      if (user.uploadCount >= uploadLimit) {
        chunkedUploads.delete(fileId);
        return res.status(403).json(error(
          `تجاوز حد الرفع المسموح. الحد الأقصى: ${uploadLimit} ملف`,
          "UPLOAD_LIMIT_EXCEEDED"
        ));
      }

      // Combine chunks into complete file
      const completeBuffer = Buffer.concat(uploadData.chunks.filter(chunk => chunk !== undefined));
      
      // Clean up chunks from memory
      chunkedUploads.delete(fileId);

      // Determine file type and extension
      const fileExtension = path.extname(fileName).toLowerCase();
      const mimeType = getMimeType(fileExtension);
      
      // Create unique filename
      const timestamp = Date.now();
      const uniqueFileName = `${timestamp}_${fileName}`;
      const filePath = path.join(uploadDir, uniqueFileName);

      // Ensure upload directory exists
      await fs.mkdir(uploadDir, { recursive: true });

      // Save file to disk
      await fs.writeFile(filePath, completeBuffer);

      // Create file record
      const fileData = insertFileSchema.parse({
        name: uniqueFileName,
        originalName: fileName,
        size: fileSize,
        mimeType: mimeType,
        path: filePath,
        userId: user.id,
        status: "uploaded",
      });

      const savedFile = await storage.createFile(fileData);

      // Update user upload count
      await storage.updateUser(user.id, {
        uploadCount: user.uploadCount + 1
      });

      // Queue for AI analysis
      addFileProcessingJob({
        fileId: savedFile.id,
        fileName: savedFile.name,
        filePath: filePath,
        mimeType: mimeType
      });

      console.log(`✅ RKN Chunked upload completed: ${fileName} (${fileSize} bytes)`);

      recordFileUpload('complete', user.id, fileSize);
      recordStorageOperation('write', fileSize);

      res.json(success('تم رفع الملف بنجاح ووضعه في قائمة التحليل بالذكاء الاصطناعي', {
        fileId: savedFile.id,
        fileName: savedFile.name,
        originalName: savedFile.originalName,
        size: savedFile.size,
        status: 'uploaded',
        message: 'الملف جاهز للتحليل بواسطة نظام RKN-Terminal AI'
      }));

    } catch (err: any) {
      console.error('❌ RKN Chunked upload completion error:', err);
      recordError('chunked_upload_complete', err.message);
      res.status(500).json(error('فشل في إكمال الرفع المتقطع', 'CHUNKED_UPLOAD_COMPLETION_ERROR'));
    }
  });

  // Get upload status endpoint
  router.get("/api/upload/status/:fileId", async (req: any, res: any) => {
    try {
      const { fileId } = req.params;
      const uploadData = chunkedUploads.get(fileId);
      
      if (!uploadData) {
        return res.status(404).json(error('جلسة الرفع غير موجودة', 'UPLOAD_SESSION_NOT_FOUND'));
      }

      res.json(success('حالة الرفع', {
        fileId,
        fileName: uploadData.fileName,
        totalChunks: uploadData.totalChunks,
        receivedChunks: uploadData.receivedChunks,
        progress: Math.round((uploadData.receivedChunks / uploadData.totalChunks) * 100),
        isComplete: uploadData.receivedChunks === uploadData.totalChunks
      }));

    } catch (err: any) {
      console.error('❌ Upload status error:', err);
      res.status(500).json(error('فشل في جلب حالة الرفع', 'UPLOAD_STATUS_ERROR'));
    }
  });

  console.log('🚀 RKN-Terminal AI Chunked Upload service initialized');
}

export { chunkedUploads };