import { analyzeContent } from './openai.js';

// Enhanced retry configuration
const MAX_RETRIES = 5; // Increased for better reliability
const BASE_RETRY_DELAY = 1000; // 1 second base delay
const MAX_RETRY_DELAY = 30000; // 30 seconds max delay
const BACKOFF_MULTIPLIER = 2; // Exponential backoff

interface RetryOptions {
  maxRetries?: number;
  baseDelay?: number;
  maxDelay?: number;
  backoffMultiplier?: number;
  onRetry?: (attempt: number, error: Error) => void;
}

/**
 * Enhanced robust AI request with exponential backoff and comprehensive error handling
 */
export async function robustAIRequest(
  content: string, 
  fileType: string, 
  options: RetryOptions = {}
): Promise<any> {
  const {
    maxRetries = MAX_RETRIES,
    baseDelay = BASE_RETRY_DELAY,
    maxDelay = MAX_RETRY_DELAY,
    backoffMultiplier = BACKOFF_MULTIPLIER,
    onRetry
  } = options;

  let attempt = 0;
  let lastError: Error | undefined;
  
  while (attempt < maxRetries) {
    try {
      console.log(`🤖 محاولة تحليل AI - المحاولة ${attempt + 1}/${maxRetries}`);
      
      const startTime = Date.now();
      const result = await analyzeContent(content, fileType);
      const duration = Date.now() - startTime;
      
      console.log(`✅ نجح التحليل في ${duration}ms بعد ${attempt + 1} محاولة`);
      return result;
      
    } catch (error) {
      attempt++;
      lastError = error as Error;
      
      console.error(`❌ فشل التحليل - المحاولة ${attempt}/${maxRetries}: ${lastError.message}`);
      
      // Check if error is retryable
      if (!isRetryableError(lastError) || attempt >= maxRetries) {
        console.error(`💥 فشل نهائي في التحليل بعد ${attempt} محاولة`);
        break;
      }
      
      // Calculate delay with exponential backoff and jitter
      const delay = Math.min(
        baseDelay * Math.pow(backoffMultiplier, attempt - 1) + Math.random() * 1000,
        maxDelay
      );
      
      console.log(`⏳ انتظار ${Math.round(delay)}ms قبل المحاولة التالية...`);
      
      // Call retry callback if provided
      if (onRetry) {
        onRetry(attempt, lastError);
      }
      
      // Wait before next attempt
      await sleep(delay);
    }
  }
  
  // All retries failed
  throw new AIRetryError(
    `فشل التحليل بعد ${maxRetries} محاولة. آخر خطأ: ${lastError?.message || 'خطأ غير معروف'}`,
    attempt,
    lastError
  );
}

/**
 * Batch AI processing with retry for multiple files
 */
export async function robustBatchAIRequest(
  files: Array<{ content: string; fileType: string; id: string }>,
  options: RetryOptions & { concurrency?: number } = {}
): Promise<Array<{ id: string; result?: any; error?: string }>> {
  const { concurrency = 3 } = options;
  const results: Array<{ id: string; result?: any; error?: string }> = [];
  
  console.log(`📦 بدء معالجة دفعة من ${files.length} ملف مع تزامن ${concurrency}`);
  
  // Process files in batches to avoid overwhelming the API
  for (let i = 0; i < files.length; i += concurrency) {
    const batch = files.slice(i, i + concurrency);
    
    const batchPromises = batch.map(async (file) => {
      try {
        const result = await robustAIRequest(file.content, file.fileType, {
          ...options,
          onRetry: (attempt, error) => {
            console.log(`🔄 إعادة محاولة للملف ${file.id}: المحاولة ${attempt}`);
          }
        });
        
        return { id: file.id, result };
      } catch (error) {
        console.error(`❌ فشل نهائي في معالجة الملف ${file.id}:`, error);
        return { id: file.id, error: (error as Error).message };
      }
    });
    
    const batchResults = await Promise.all(batchPromises);
    results.push(...batchResults);
    
    // Add delay between batches to respect rate limits
    if (i + concurrency < files.length) {
      await sleep(1000);
    }
  }
  
  const successful = results.filter(r => r.result).length;
  const failed = results.filter(r => r.error).length;
  
  console.log(`📊 انتهت المعالجة: ${successful} نجح، ${failed} فشل من ${files.length} ملف`);
  
  return results;
}

/**
 * Smart retry with adaptive delays based on error type
 */
export async function smartAIRetry(
  content: string,
  fileType: string,
  context: { fileSize: number; complexity: 'low' | 'medium' | 'high' } = { fileSize: 0, complexity: 'medium' }
): Promise<any> {
  // Adaptive configuration based on file characteristics
  const config = getAdaptiveConfig(context);
  
  return robustAIRequest(content, fileType, {
    maxRetries: config.maxRetries,
    baseDelay: config.baseDelay,
    maxDelay: config.maxDelay,
    onRetry: (attempt, error) => {
      console.log(`🧠 إعادة محاولة ذكية: ${attempt}/${config.maxRetries} - ${error.message}`);
    }
  });
}

/**
 * Check if an error is retryable
 */
function isRetryableError(error: Error): boolean {
  const retryablePatterns = [
    'rate limit',
    'timeout',
    'network',
    'temporary',
    'overloaded',
    'service unavailable',
    'internal server error',
    '429',
    '500',
    '502',
    '503',
    '504'
  ];
  
  const message = error.message.toLowerCase();
  return retryablePatterns.some(pattern => message.includes(pattern));
}

/**
 * Get adaptive configuration based on file context
 */
function getAdaptiveConfig(context: { fileSize: number; complexity: 'low' | 'medium' | 'high' }) {
  const baseConfig = {
    maxRetries: 3,
    baseDelay: 1000,
    maxDelay: 15000
  };
  
  // Adjust for file size
  if (context.fileSize > 1024 * 1024) { // > 1MB
    baseConfig.maxRetries = 5;
    baseConfig.baseDelay = 2000;
    baseConfig.maxDelay = 30000;
  }
  
  // Adjust for complexity
  switch (context.complexity) {
    case 'high':
      baseConfig.maxRetries = 6;
      baseConfig.baseDelay = 3000;
      baseConfig.maxDelay = 45000;
      break;
    case 'low':
      baseConfig.maxRetries = 2;
      baseConfig.baseDelay = 500;
      baseConfig.maxDelay = 5000;
      break;
  }
  
  return baseConfig;
}

/**
 * Sleep utility function
 */
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Custom error class for AI retry failures
 */
export class AIRetryError extends Error {
  constructor(
    message: string,
    public attempts: number,
    public lastError?: Error
  ) {
    super(message);
    this.name = 'AIRetryError';
  }
}

/**
 * Circuit breaker pattern for AI requests
 */
export class AICircuitBreaker {
  private failures = 0;
  private lastFailureTime = 0;
  private state: 'closed' | 'open' | 'half-open' = 'closed';
  
  constructor(
    private failureThreshold = 5,
    private recoveryTimeout = 60000 // 1 minute
  ) {}
  
  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailureTime > this.recoveryTimeout) {
        this.state = 'half-open';
        console.log('🔄 محاولة استعادة دائرة AI - حالة نصف مفتوحة');
      } else {
        throw new Error('دائرة AI مفتوحة - الخدمة غير متاحة مؤقتاً');
      }
    }
    
    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }
  
  private onSuccess() {
    this.failures = 0;
    this.state = 'closed';
    console.log('✅ دائرة AI مغلقة - الخدمة تعمل بشكل طبيعي');
  }
  
  private onFailure() {
    this.failures++;
    this.lastFailureTime = Date.now();
    
    if (this.failures >= this.failureThreshold) {
      this.state = 'open';
      console.log(`🚨 دائرة AI مفتوحة بعد ${this.failures} فشل متتالي`);
    }
  }
  
  getState() {
    return {
      state: this.state,
      failures: this.failures,
      lastFailureTime: this.lastFailureTime
    };
  }
}

// Global circuit breaker instance
export const aiCircuitBreaker = new AICircuitBreaker();