import { storage } from '../storage.js';
import { FileProcessingError, DatabaseError, NetworkError } from '../middleware/errorHandler.js';

// Simple in-memory job queue system
interface JobData {
  id: string;
  name: string;
  data: any;
  status: 'waiting' | 'active' | 'completed' | 'failed';
  progress: number;
  createdAt: Date;
  processedOn?: number;
  finishedOn?: number;
  failedOn?: number;
  failedReason?: string;
  attemptsMade: number;
  maxAttempts: number;
  returnvalue?: any;
}

class SimpleQueue {
  private jobs: Map<string, JobData> = new Map();
  private pendingJobs: JobData[] = [];
  private processingJobs: Set<string> = new Set();
  private completedJobs: Map<string, JobData> = new Map();
  private failedJobs: Map<string, JobData> = new Map();
  private nextJobId = 1;
  private isProcessing = false;

  constructor(private name: string) {
    // Start processing loop
    this.startProcessing();
  }

  async add(jobName: string, data: any, options: any = {}): Promise<JobData> {
    const jobId = `${this.name}-${this.nextJobId++}`;
    const job: JobData = {
      id: jobId,
      name: jobName,
      data,
      status: 'waiting',
      progress: 0,
      createdAt: new Date(),
      attemptsMade: 0,
      maxAttempts: options.attempts || 3
    };

    this.jobs.set(jobId, job);
    this.pendingJobs.push(job);

    console.log(`📋 تم إضافة مهمة: ${jobId} إلى طابور ${this.name}`);
    return job;
  }

  async getJob(jobId: string): Promise<JobData | null> {
    return this.jobs.get(jobId) || null;
  }

  async getJobCounts() {
    return {
      waiting: this.pendingJobs.length,
      active: this.processingJobs.size,
      completed: this.completedJobs.size,
      failed: this.failedJobs.size,
      delayed: 0,
      paused: 0
    };
  }

  async clean(age: number, limit: number, type: string): Promise<number> {
    let cleaned = 0;
    const cutoff = Date.now() - age;

    if (type === 'completed') {
      for (const [id, job] of this.completedJobs) {
        if (job.finishedOn && job.finishedOn < cutoff) {
          this.completedJobs.delete(id);
          this.jobs.delete(id);
          cleaned++;
          if (cleaned >= limit) break;
        }
      }
    } else if (type === 'failed') {
      for (const [id, job] of this.failedJobs) {
        if (job.failedOn && job.failedOn < cutoff) {
          this.failedJobs.delete(id);
          this.jobs.delete(id);
          cleaned++;
          if (cleaned >= limit) break;
        }
      }
    }

    return cleaned;
  }

  async close(): Promise<void> {
    console.log(`🔒 إغلاق طابور ${this.name}`);
    this.isProcessing = false;
  }

  private async startProcessing() {
    this.isProcessing = true;
    this.processLoop();
  }

  private async processLoop() {
    while (this.isProcessing) {
      if (this.pendingJobs.length > 0 && this.processingJobs.size < 3) {
        const job = this.pendingJobs.shift();
        if (job) {
          this.processJob(job);
        }
      }
      // Wait a bit before checking again
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }

  private async processJob(job: JobData) {
    this.processingJobs.add(job.id);
    job.status = 'active';
    job.processedOn = Date.now();

    try {
      if (this.name === 'file-processing') {
        await this.processFileJob(job);
      } else if (this.name === 'batch-processing') {
        await this.processBatchJob(job);
      } else if (this.name === 'ai-analysis') {
        await this.processAIJob(job);
      }

      // Mark as completed
      job.status = 'completed';
      job.finishedOn = Date.now();
      job.progress = 100;
      this.processingJobs.delete(job.id);
      this.completedJobs.set(job.id, job);

      console.log(`✅ مهمة مكتملة: ${job.id}`);

    } catch (error: any) {
      // Mark as failed
      job.status = 'failed';
      job.failedOn = Date.now();
      job.failedReason = error.message;
      job.attemptsMade++;

      this.processingJobs.delete(job.id);

      if (job.attemptsMade < job.maxAttempts) {
        // Retry after delay
        setTimeout(() => {
          this.pendingJobs.push(job);
        }, 5000 * Math.pow(2, job.attemptsMade));
      } else {
        this.failedJobs.set(job.id, job);
        console.error(`❌ مهمة فشلت نهائياً: ${job.id}`, error);
      }
    }
  }

  private async processFileJob(job: JobData) {
    const { fileId, filePath, mimeType, userId } = job.data;

    job.progress = 10;

    // Get file from storage
    const file = await storage.getFile(fileId);
    if (!file) {
      throw new Error(`File not found: ${fileId}`);
    }

    job.progress = 25;

    // Update file status to processing
    await storage.updateFile(fileId, { status: 'processing' });

    job.progress = 40;

    // Simulate analysis delay
    await new Promise(resolve => setTimeout(resolve, 1000));

    const analysisResult = {
      summary: `تم تحليل الملف ${file.name}`,
      keyPoints: ['معلومات مهمة من الملف'],
      categories: ['عام'],
      confidence: 0.9,
      language: 'ar',
      processingTime: 1000
    };

    job.progress = 70;

    // Update file with analysis results
    await storage.updateFile(fileId, {
      status: 'analyzed',
      analysis: analysisResult
    });

    job.progress = 100;
    job.returnvalue = { success: true, fileId, analysis: analysisResult };
  }

  private async processBatchJob(job: JobData) {
    const { fileIds, userId, batchId } = job.data;

    const results = [];
    const totalFiles = fileIds.length;

    for (let i = 0; i < totalFiles; i++) {
      const fileId = fileIds[i];

      // Add individual file processing job
      const fileJob = await fileQueue.add('process-file', {
        fileId,
        userId,
        filePath: '',
        mimeType: '',
        priority: 'normal'
      });

      results.push({
        fileId,
        jobId: fileJob.id
      });

      job.progress = Math.round(((i + 1) / totalFiles) * 100);
    }

    job.returnvalue = { success: true, batchId, fileJobs: results };
  }

  private async processAIJob(job: JobData) {
    const { fileId, analysisType, userId } = job.data;

    job.progress = 20;

    const file = await storage.getFile(fileId);
    if (!file) {
      throw new Error(`File not found: ${fileId}`);
    }

    job.progress = 50;

    // Simulate advanced AI analysis
    await new Promise(resolve => setTimeout(resolve, 2000));

    const analysisResult = {
      summary: `تحليل متقدم للملف ${file.name}`,
      keyPoints: ['نقاط رئيسية متقدمة'],
      categories: ['متقدم'],
      confidence: 0.95,
      language: 'ar',
      enhanced: true,
      analysisType
    };

    job.progress = 80;

    await storage.updateFile(fileId, {
      status: 'analyzed',
      analysis: analysisResult
    });

    job.progress = 100;
    job.returnvalue = { success: true, fileId, analysisType, result: analysisResult };
  }
}

// Create queue instances
const fileQueue = new SimpleQueue('file-processing');
const batchQueue = new SimpleQueue('batch-processing');
const aiAnalysisQueue = new SimpleQueue('ai-analysis');

console.log('📦 نظام الطوابير البسيط جاهز - Simple Queue System Ready');

// Job data interfaces
interface FileProcessingJobData {
  fileId: string;
  filePath: string;
  mimeType: string;
  userId: string;
  priority?: 'low' | 'normal' | 'high';
  metadata?: Record<string, any>;
}

interface BatchProcessingJobData {
  fileIds: string[];
  userId: string;
  batchId: string;
  priority?: 'low' | 'normal' | 'high';
}

interface AIAnalysisJobData {
  fileId: string;
  analysisType: 'text' | 'image' | 'document' | 'advanced';
  options?: Record<string, any>;
  userId: string;
}

// Job management functions
export async function addFileProcessingJob(
  fileId: string,
  filePath: string,
  mimeType: string,
  userId: string,
  options: {
    priority?: 'low' | 'normal' | 'high';
    delay?: number;
    metadata?: Record<string, any>;
  } = {}
): Promise<JobData> {
  try {
    const jobData: FileProcessingJobData = {
      fileId,
      filePath,
      mimeType,
      userId,
      priority: options.priority || 'normal',
      metadata: options.metadata
    };

    const job = await fileQueue.add('process-file', jobData, {
      priority: options.priority === 'high' ? 1 : options.priority === 'low' ? 10 : 5,
      delay: options.delay || 0
    });

    console.log(`📋 تم إضافة مهمة معالجة الملف: ${fileId} (Job ID: ${job.id})`);
    return job;

  } catch (err: any) {
    console.error('Failed to add file processing job:', err);
    throw new FileProcessingError(`Failed to queue file processing: ${err.message}`);
  }
}

export async function addBatchProcessingJob(
  fileIds: string[],
  userId: string,
  options: {
    priority?: 'low' | 'normal' | 'high';
    batchId?: string;
  } = {}
): Promise<JobData> {
  try {
    const batchId = options.batchId || `batch-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    const jobData: BatchProcessingJobData = {
      fileIds,
      userId,
      batchId,
      priority: options.priority || 'normal'
    };

    const job = await batchQueue.add('process-batch', jobData, {
      priority: options.priority === 'high' ? 1 : options.priority === 'low' ? 10 : 5
    });

    console.log(`📦 تم إضافة مهمة معالجة الدفعة: ${batchId} (${fileIds.length} ملفات)`);
    return job;

  } catch (err: any) {
    console.error('Failed to add batch processing job:', err);
    throw new FileProcessingError(`Failed to queue batch processing: ${err.message}`);
  }
}

export async function addAIAnalysisJob(
  fileId: string,
  analysisType: 'text' | 'image' | 'document' | 'advanced',
  userId: string,
  options: Record<string, any> = {}
): Promise<JobData> {
  try {
    const jobData: AIAnalysisJobData = {
      fileId,
      analysisType,
      userId,
      options
    };

    const job = await aiAnalysisQueue.add('ai-analysis', jobData, {
      priority: analysisType === 'advanced' ? 1 : 5
    });

    console.log(`🤖 تم إضافة مهمة التحليل الذكي: ${fileId} (نوع: ${analysisType})`);
    return job;

  } catch (err: any) {
    console.error('Failed to add AI analysis job:', err);
    throw new FileProcessingError(`Failed to queue AI analysis: ${err.message}`);
  }
}

// Queue status and monitoring functions
export async function getQueueStats() {
  try {
    const [fileStats, batchStats, aiStats] = await Promise.all([
      fileQueue.getJobCounts(),
      batchQueue.getJobCounts(),
      aiAnalysisQueue.getJobCounts()
    ]);

    return {
      fileProcessing: fileStats,
      batchProcessing: batchStats,
      aiAnalysis: aiStats,
      timestamp: new Date().toISOString()
    };
  } catch (err: any) {
    console.error('Failed to get queue stats:', err);
    throw new DatabaseError(`Failed to retrieve queue statistics: ${err.message}`);
  }
}

export async function getJobStatus(jobId: string, queueName: 'file-processing' | 'batch-processing' | 'ai-analysis') {
  try {
    let queue;
    switch (queueName) {
      case 'file-processing':
        queue = fileQueue;
        break;
      case 'batch-processing':
        queue = batchQueue;
        break;
      case 'ai-analysis':
        queue = aiAnalysisQueue;
        break;
    }

    const job = await queue.getJob(jobId);
    if (!job) {
      return null;
    }

    return {
      id: job.id,
      name: job.name,
      data: job.data,
      progress: job.progress,
      attemptsMade: job.attemptsMade,
      finishedOn: job.finishedOn,
      processedOn: job.processedOn,
      returnvalue: job.returnvalue,
      failedReason: job.failedReason,
      status: job.status
    };
  } catch (err: any) {
    console.error('Failed to get job status:', err);
    throw new DatabaseError(`Failed to retrieve job status: ${err.message}`);
  }
}

// Queue cleanup and maintenance
export async function cleanupQueues() {
  try {
    const results = await Promise.all([
      fileQueue.clean(24 * 60 * 60 * 1000, 100, 'completed'), // Clean completed jobs older than 24h
      fileQueue.clean(7 * 24 * 60 * 60 * 1000, 50, 'failed'), // Clean failed jobs older than 7 days
      batchQueue.clean(24 * 60 * 60 * 1000, 100, 'completed'),
      batchQueue.clean(7 * 24 * 60 * 60 * 1000, 50, 'failed'),
      aiAnalysisQueue.clean(24 * 60 * 60 * 1000, 100, 'completed'),
      aiAnalysisQueue.clean(7 * 24 * 60 * 60 * 1000, 50, 'failed')
    ]);

    console.log(`🧹 تم تنظيف الطوابير: ${results.reduce((a, b) => a + b, 0)} مهمة محذوفة`);
    return results;
  } catch (err: any) {
    console.error('Failed to cleanup queues:', err);
    throw new DatabaseError(`Failed to cleanup queues: ${err.message}`);
  }
}

// Health check function
export async function getQueueHealth() {
  try {
    const health = {
      type: 'in-memory',
      queues: {
        fileProcessing: true,
        batchProcessing: true,
        aiAnalysis: true
      },
      workers: {
        fileWorker: true,
        batchWorker: true,
        aiWorker: true
      }
    };

    return health;
  } catch (err: any) {
    console.error('Failed to check queue health:', err);
    throw new NetworkError(`Queue health check failed: ${err.message}`);
  }
}

export {
  fileQueue,
  batchQueue,
  aiAnalysisQueue
};