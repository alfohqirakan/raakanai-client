/**
 * RKN-Terminal AI WebSocket Service
 * خدمة التواصل الفوري لمنصة راكان الذكاء السيادي
 */

import { Server as SocketIOServer, Socket } from 'socket.io';
import { Server as HTTPServer } from 'http';
import { log } from '../vite.js';

let io: SocketIOServer | null = null;
let isInitialized = false;

interface SocketData {
  userId?: number;
  username?: string;
  connectedAt: Date;
}

interface RoomParticipant {
  socketId: string;
  userId: number;
  username: string;
  joinedAt: Date;
}

interface AnalysisProgress {
  fileId: string;
  progress: number;
  stage: string;
  message: string;
  timestamp: Date;
}

interface ChatMessage {
  id: string;
  fileId: string;
  userId: number;
  username: string;
  message: string;
  timestamp: Date;
  type: 'user' | 'assistant';
}

// تتبع المشاركين في كل غرفة
const roomParticipants = new Map<string, RoomParticipant[]>();
const userConnections = new Map<number, string[]>(); // userId -> socketIds

/**
 * تهيئة خدمة WebSocket مع خادم HTTP موجود
 * Initialize WebSocket service with existing HTTP server
 */
export function initializeSocketService(httpServer: HTTPServer): void {
  if (isInitialized) {
    log('⚠️ WebSocket service already initialized', 'socket');
    return;
  }

  io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
      credentials: true
    },
    path: '/socket.io',
    transports: ['websocket', 'polling'],
    allowEIO3: true,
    pingTimeout: 60000,
    pingInterval: 25000
  });

  setupSocketHandlers();
  isInitialized = true;
  
  log('🔌 RKN-Terminal AI WebSocket Service initialized', 'socket');
  log('📡 Real-time communication active on all supported transports', 'socket');
}

/**
 * إعداد معالجات أحداث Socket.IO
 * Setup Socket.IO event handlers
 */
function setupSocketHandlers(): void {
  if (!io) return;

  io.on('connection', (socket: Socket) => {
    const clientIP = socket.handshake.address;
    const userAgent = socket.handshake.headers['user-agent'];
    
    log(`🔗 عميل جديد متصل: ${socket.id} من ${clientIP}`, 'socket');

    // تخزين بيانات الاتصال
    const socketData: SocketData = {
      connectedAt: new Date()
    };
    socket.data = socketData;

    // معالج تسجيل المستخدم في الجلسة
    socket.on('authenticate', (userData: { userId: number; username: string }) => {
      socket.data.userId = userData.userId;
      socket.data.username = userData.username;
      
      // تتبع اتصالات المستخدم
      const existingConnections = userConnections.get(userData.userId) || [];
      existingConnections.push(socket.id);
      userConnections.set(userData.userId, existingConnections);

      log(`👤 المستخدم ${userData.username} (${userData.userId}) سجل دخوله`, 'socket');
      
      // إرسال حالة الترحيب
      socket.emit('authenticated', {
        message: 'تم تسجيل الدخول بنجاح في النظام الفوري',
        timestamp: new Date(),
        features: ['real-time-analysis', 'live-chat', 'progress-tracking']
      });
    });

    // معالج الانضمام إلى غرفة ملف
    socket.on('joinFileRoom', (fileId: string) => {
      const roomName = `file-${fileId}`;
      socket.join(roomName);
      
      if (socket.data.userId && socket.data.username) {
        const participant: RoomParticipant = {
          socketId: socket.id,
          userId: socket.data.userId,
          username: socket.data.username,
          joinedAt: new Date()
        };

        const participants = roomParticipants.get(roomName) || [];
        participants.push(participant);
        roomParticipants.set(roomName, participants);

        log(`📁 المستخدم ${socket.data.username} انضم إلى غرفة الملف ${fileId}`, 'socket');
        
        // إشعار المشاركين الآخرين
        socket.to(roomName).emit('userJoinedRoom', {
          userId: socket.data.userId,
          username: socket.data.username,
          fileId,
          timestamp: new Date()
        });

        // إرسال قائمة المشاركين الحاليين
        socket.emit('roomParticipants', {
          fileId,
          participants: participants.map(p => ({
            userId: p.userId,
            username: p.username,
            joinedAt: p.joinedAt
          }))
        });
      }
    });

    // معالج مغادرة غرفة الملف
    socket.on('leaveFileRoom', (fileId: string) => {
      const roomName = `file-${fileId}`;
      socket.leave(roomName);
      
      removeParticipantFromRoom(socket.id, roomName);
      
      if (socket.data.username) {
        log(`📁 المستخدم ${socket.data.username} غادر غرفة الملف ${fileId}`, 'socket');
        
        socket.to(roomName).emit('userLeftRoom', {
          userId: socket.data.userId,
          username: socket.data.username,
          fileId,
          timestamp: new Date()
        });
      }
    });

    // معالج رسائل المحادثة الفورية
    socket.on('sendChatMessage', (data: { fileId: string; message: string }) => {
      if (!socket.data.userId || !socket.data.username) {
        socket.emit('error', { message: 'يجب تسجيل الدخول أولاً' });
        return;
      }

      const chatMessage: ChatMessage = {
        id: `msg-${Date.now()}-${socket.id}`,
        fileId: data.fileId,
        userId: socket.data.userId,
        username: socket.data.username,
        message: data.message,
        timestamp: new Date(),
        type: 'user'
      };

      const roomName = `file-${data.fileId}`;
      
      // إرسال الرسالة لجميع المشاركين في الغرفة
      io?.to(roomName).emit('chatMessage', chatMessage);
      
      log(`💬 رسالة جديدة من ${socket.data.username} في الملف ${data.fileId}`, 'socket');
    });

    // معالج طلب حالة التحليل
    socket.on('requestAnalysisStatus', (fileId: string) => {
      // يمكن إضافة منطق للحصول على حالة التحليل الحالية
      socket.emit('analysisStatus', {
        fileId,
        status: 'قيد المعالجة',
        progress: 75,
        stage: 'تحليل المحتوى',
        timestamp: new Date()
      });
    });

    // معالج الانقطاع
    socket.on('disconnect', (reason: string) => {
      log(`🔌 العميل ${socket.id} انقطع: ${reason}`, 'socket');
      
      // تنظيف بيانات المستخدم
      if (socket.data.userId) {
        const connections = userConnections.get(socket.data.userId) || [];
        const filteredConnections = connections.filter(id => id !== socket.id);
        
        if (filteredConnections.length === 0) {
          userConnections.delete(socket.data.userId);
        } else {
          userConnections.set(socket.data.userId, filteredConnections);
        }
      }

      // إزالة من جميع الغرف
      Array.from(roomParticipants.keys()).forEach(roomName => {
        removeParticipantFromRoom(socket.id, roomName);
      });
    });

    // معالج الأخطاء
    socket.on('error', (error: Error) => {
      log(`❌ خطأ في الاتصال ${socket.id}: ${error}`, 'socket');
    });
  });
}

/**
 * إزالة مشارك من غرفة
 */
function removeParticipantFromRoom(socketId: string, roomName: string): void {
  const participants = roomParticipants.get(roomName) || [];
  const filteredParticipants = participants.filter(p => p.socketId !== socketId);
  
  if (filteredParticipants.length === 0) {
    roomParticipants.delete(roomName);
  } else {
    roomParticipants.set(roomName, filteredParticipants);
  }
}

/**
 * إرسال تحديث تقدم التحليل
 * Send analysis progress update to file room
 */
export function emitAnalysisProgress(fileId: string, progress: AnalysisProgress): void {
  if (!io) {
    console.warn('⚠️ WebSocket service not initialized');
    return;
  }

  const roomName = `file-${fileId}`;
  io.to(roomName).emit('analysisProgress', progress);
  
  log(`📊 تحديث تقدم التحليل للملف ${fileId}: ${progress.progress}%`, 'socket');
}

/**
 * إرسال نتيجة التحليل المكتملة
 * Send completed analysis result to file room
 */
export function emitAnalysisResult(fileId: string, result: any): void {
  if (!io) {
    console.warn('⚠️ WebSocket service not initialized');
    return;
  }

  const roomName = `file-${fileId}`;
  io.to(roomName).emit('analysisComplete', {
    fileId,
    result,
    timestamp: new Date()
  });
  
  log(`✅ تم إرسال نتيجة التحليل للملف ${fileId}`, 'socket');
}

/**
 * إرسال رسالة للمستخدمين المتصلين
 * Send message to connected users
 */
export function emitToUser(userId: number, event: string, data: any): void {
  if (!io) {
    console.warn('⚠️ WebSocket service not initialized');
    return;
  }

  const connections = userConnections.get(userId);
  if (connections) {
    connections.forEach(socketId => {
      io?.to(socketId).emit(event, data);
    });
    
    log(`📤 إرسال ${event} للمستخدم ${userId}`, 'socket');
  }
}

/**
 * إرسال رسالة لغرفة محددة
 * Send message to specific room
 */
export function emitToRoom(room: string, event: string, data: any): void {
  if (!io) {
    console.warn('⚠️ WebSocket service not initialized');
    return;
  }

  io.to(room).emit(event, data);
  log(`📡 إرسال ${event} للغرفة ${room}`, 'socket');
}

/**
 * إرسال إشعار عام لجميع المتصلين
 * Broadcast notification to all connected clients
 */
export function broadcastNotification(notification: {
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  data?: any;
}): void {
  if (!io) {
    console.warn('⚠️ WebSocket service not initialized');
    return;
  }

  io.emit('notification', {
    ...notification,
    timestamp: new Date()
  });
  
  log(`📢 إشعار عام: ${notification.title}`, 'socket');
}

/**
 * الحصول على إحصائيات الاتصالات
 * Get connection statistics
 */
export function getConnectionStats(): {
  totalConnections: number;
  authenticatedUsers: number;
  activeRooms: number;
  userConnections: number;
} {
  return {
    totalConnections: io?.sockets.sockets.size || 0,
    authenticatedUsers: userConnections.size,
    activeRooms: roomParticipants.size,
    userConnections: Array.from(userConnections.values()).flat().length
  };
}

/**
 * فحص حالة خدمة WebSocket
 * Check WebSocket service health
 */
export function getServiceHealth(): {
  status: 'healthy' | 'degraded' | 'down';
  initialized: boolean;
  connections: number;
  uptime: number;
} {
  const connections = io?.sockets.sockets.size || 0;
  
  return {
    status: isInitialized && io ? (connections > 0 ? 'healthy' : 'degraded') : 'down',
    initialized: isInitialized,
    connections,
    uptime: process.uptime()
  };
}