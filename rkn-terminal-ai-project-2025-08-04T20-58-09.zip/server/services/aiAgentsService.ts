/**
 * RKN-Terminal AI Agents Service
 * خدمة الوكلاء الذكيين لمنصة راكان الذكاء السيادي
 */

import { agentRegistry, type AIAgent, type AgentExecution } from '@shared/ai-agents.js';
import { chatWithAI } from './openai.js';
import { log } from '../vite.js';

interface AgentTask {
  id: string;
  agentId: string;
  userId: number;
  input: any;
  context?: any;
  status: 'pending' | 'running' | 'completed' | 'failed';
  result?: any;
  error?: string;
  startTime: Date;
  endTime?: Date;
}

class AIAgentsService {
  private tasks: Map<string, AgentTask> = new Map();

  async executeAgent(
    agentId: string,
    input: any,
    userId: number,
    context?: any
  ): Promise<AgentExecution> {
    try {
      log(`🤖 تنفيذ الوكيل الذكي: ${agentId}`, 'agents');
      
      const agent = agentRegistry.getAgent(agentId);
      if (!agent) {
        throw new Error(`الوكيل ${agentId} غير موجود`);
      }

      // إنشاء مهمة جديدة
      const taskId = `task-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
      const task: AgentTask = {
        id: taskId,
        agentId,
        userId,
        input,
        context,
        status: 'pending',
        startTime: new Date()
      };

      this.tasks.set(taskId, task);

      // تنفيذ الوكيل
      const execution = await this.processAgentTask(agent, task);
      
      // تحديث المهمة
      task.status = execution.status;
      task.result = execution.output;
      task.error = execution.error;
      task.endTime = new Date();

      log(`✅ اكتمل تنفيذ الوكيل ${agentId} - المهمة: ${taskId}`, 'agents');
      
      return execution;

    } catch (error) {
      log(`❌ خطأ في تنفيذ الوكيل ${agentId}: ${error}`, 'agents');
      throw error;
    }
  }

  private async processAgentTask(agent: AIAgent, task: AgentTask): Promise<AgentExecution> {
    const execution: AgentExecution = {
      agentId: agent.id,
      taskId: task.id,
      userId: task.userId,
      input: task.input,
      status: 'running',
      startTime: task.startTime,
      toolsUsed: []
    };

    try {
      // إعداد السياق للوكيل
      const agentContext = this.prepareAgentContext(agent, task);
      
      // تحديد الأداة المطلوبة
      const toolName = task.input.tool || this.selectBestTool(agent, task.input);
      const tool = agent.tools.find(t => t.name === toolName);

      if (tool) {
        log(`🔧 استخدام الأداة: ${tool.name}`, 'agents');
        
        // تنفيذ الأداة
        const toolResult = await tool.execute(task.input, task.context);
        execution.toolsUsed.push(tool.name);
        
        // معالجة النتيجة بواسطة الذكاء الاصطناعي
        const aiAnalysis = await this.enhanceResultWithAI(agent, toolResult, task.input);
        
        execution.output = {
          toolResult,
          aiAnalysis,
          summary: this.generateTaskSummary(agent, toolResult, aiAnalysis),
          recommendations: this.generateRecommendations(agent, toolResult),
          metadata: {
            toolUsed: tool.name,
            executionTime: Date.now() - execution.startTime.getTime(),
            agentVersion: agent.version
          }
        };
      } else {
        // تنفيذ مباشر بواسطة الذكاء الاصطناعي
        const aiResult = await this.processWithAI(agent, task.input, task.context);
        execution.output = aiResult;
      }

      execution.status = 'completed';
      execution.endTime = new Date();
      execution.duration = execution.endTime.getTime() - execution.startTime.getTime();

    } catch (error) {
      execution.status = 'failed';
      execution.error = error instanceof Error ? error.message : 'خطأ غير معروف';
      execution.endTime = new Date();
      
      log(`❌ فشل في تنفيذ المهمة ${task.id}: ${execution.error}`, 'agents');
    }

    return execution;
  }

  private prepareAgentContext(agent: AIAgent, task: AgentTask): string {
    return `
اسم الوكيل: ${agent.nameAr} (${agent.name})
الدور: ${agent.roleAr}
المهمة: ${JSON.stringify(task.input, null, 2)}
السياق: ${task.context ? JSON.stringify(task.context, null, 2) : 'لا يوجد'}
الأدوات المتاحة: ${agent.tools.map(t => t.name).join(', ')}
    `;
  }

  private selectBestTool(agent: AIAgent, input: any): string {
    // اختيار أفضل أداة بناءً على نوع المدخل
    if (input.code && agent.specialization === 'security') {
      return 'code-scanner';
    }
    if (input.code && agent.specialization === 'development') {
      return 'code-optimizer';
    }
    if (input.data && agent.specialization === 'analysis') {
      return 'data-analyzer';
    }
    
    return agent.tools[0]?.name || '';
  }

  private async enhanceResultWithAI(agent: AIAgent, toolResult: any, originalInput: any): Promise<any> {
    try {
      const prompt = `
${agent.systemPromptAr}

نتيجة الأداة: ${JSON.stringify(toolResult, null, 2)}
المدخل الأصلي: ${JSON.stringify(originalInput, null, 2)}

يرجى تحليل النتيجة وتقديم:
1. ملخص شامل
2. تفسير للنتائج  
3. توصيات عملية
4. خطوات التالية المقترحة

قدم الإجابة باللغة العربية بتنسيق JSON.
`;

      const aiResponse = await chatWithAI(prompt);
      return {
        analysis: aiResponse,
        timestamp: new Date().toISOString(),
        confidence: this.calculateConfidence(toolResult)
      };

    } catch (error) {
      log(`⚠️ فشل في تعزيز النتيجة بالذكاء الاصطناعي: ${error}`, 'agents');
      return {
        analysis: 'تم إنشاء النتيجة بواسطة الأداة فقط',
        error: 'فشل في التحليل بالذكاء الاصطناعي'
      };
    }
  }

  private async processWithAI(agent: AIAgent, input: any, context?: any): Promise<any> {
    const prompt = `
${agent.systemPromptAr}

المهمة: ${JSON.stringify(input, null, 2)}
السياق: ${context ? JSON.stringify(context, null, 2) : 'لا يوجد'}

يرجى معالجة هذه المهمة وتقديم نتيجة شاملة باللغة العربية.
`;

    const aiResponse = await chatWithAI(prompt);
    
    return {
      result: aiResponse,
      type: 'ai_direct',
      timestamp: new Date().toISOString(),
      agentId: agent.id,
      confidence: 0.8
    };
  }

  private generateTaskSummary(agent: AIAgent, toolResult: any, aiAnalysis: any): string {
    const resultType = agent.specialization;
    
    switch (resultType) {
      case 'security':
        return `تم فحص الشفرة بواسطة ${agent.nameAr}. ${this.getSecuritySummary(toolResult)}`;
      case 'development':
        return `تم تحسين الشفرة بواسطة ${agent.nameAr}. ${this.getDevelopmentSummary(toolResult)}`;
      case 'analysis':
        return `تم تحليل البيانات بواسطة ${agent.nameAr}. ${this.getAnalysisSummary(toolResult)}`;
      default:
        return `تم تنفيذ المهمة بواسطة ${agent.nameAr} بنجاح.`;
    }
  }

  private getSecuritySummary(result: any): string {
    if (result.vulnerabilities) {
      const count = result.vulnerabilities.length;
      const riskLevel = result.riskLevel;
      return `تم اكتشاف ${count} مشكلة أمنية. مستوى الخطر: ${riskLevel}`;
    }
    return 'تم الفحص بنجاح.';
  }

  private getDevelopmentSummary(result: any): string {
    if (result.improvements) {
      return `تم تحسين الشفرة مع ${result.improvements.improvements?.length || 0} تحسين.`;
    }
    return 'تم تحليل الشفرة بنجاح.';
  }

  private getAnalysisSummary(result: any): string {
    if (result.summary) {
      return `تم تحليل ${result.summary.totalRecords || 0} سجل وإنشاء الرؤى.`;
    }
    return 'تم تحليل البيانات بنجاح.';
  }

  private generateRecommendations(agent: AIAgent, result: any): string[] {
    const recommendations: string[] = [];
    
    if (agent.specialization === 'security' && result.recommendations) {
      recommendations.push(...result.recommendations);
    }
    
    if (agent.specialization === 'development' && result.suggestions) {
      recommendations.push(...result.suggestions);
    }
    
    recommendations.push(`تم التحليل بواسطة ${agent.nameAr} - RKN-Terminal AI`);
    
    return recommendations;
  }

  private calculateConfidence(result: any): number {
    // حساب مستوى الثقة بناءً على النتيجة
    if (result.vulnerabilities !== undefined) {
      return result.vulnerabilities.length > 0 ? 0.9 : 0.8;
    }
    if (result.improvements !== undefined) {
      return 0.85;
    }
    return 0.7;
  }

  // إدارة المهام
  getTask(taskId: string): AgentTask | undefined {
    return this.tasks.get(taskId);
  }

  getUserTasks(userId: number): AgentTask[] {
    return Array.from(this.tasks.values()).filter(task => task.userId === userId);
  }

  getAgentStats(): any {
    const tasks = Array.from(this.tasks.values());
    const agents = agentRegistry.getAllAgents();
    
    return {
      totalAgents: agents.length,
      activeAgents: agents.filter(a => a.isActive).length,
      totalTasks: tasks.length,
      completedTasks: tasks.filter(t => t.status === 'completed').length,
      failedTasks: tasks.filter(t => t.status === 'failed').length,
      agentUsage: this.calculateAgentUsage(tasks),
      averageExecutionTime: this.calculateAverageExecutionTime(tasks)
    };
  }

  private calculateAgentUsage(tasks: AgentTask[]): Record<string, number> {
    const usage: Record<string, number> = {};
    tasks.forEach(task => {
      usage[task.agentId] = (usage[task.agentId] || 0) + 1;
    });
    return usage;
  }

  private calculateAverageExecutionTime(tasks: AgentTask[]): number {
    const completedTasks = tasks.filter(t => t.status === 'completed' && t.endTime);
    if (completedTasks.length === 0) return 0;
    
    const totalTime = completedTasks.reduce((sum, task) => {
      return sum + (task.endTime!.getTime() - task.startTime.getTime());
    }, 0);
    
    return totalTime / completedTasks.length;
  }

  // تنظيف المهام القديمة
  cleanupOldTasks(maxAge: number = 24 * 60 * 60 * 1000): void {
    const cutoff = Date.now() - maxAge;
    
    for (const [taskId, task] of this.tasks.entries()) {
      if (task.startTime.getTime() < cutoff) {
        this.tasks.delete(taskId);
      }
    }
    
    log(`🧹 تم تنظيف المهام القديمة. المهام المتبقية: ${this.tasks.size}`, 'agents');
  }
}

// تصدير المثيل الوحيد
export const aiAgentsService = new AIAgentsService();

// دالة مساعدة لاختبار الوكيل
export async function testAgent(agentId: string, testInput: any): Promise<any> {
  try {
    const result = await aiAgentsService.executeAgent(agentId, testInput, 1);
    return {
      success: true,
      result,
      message: `تم اختبار الوكيل ${agentId} بنجاح`
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'خطأ غير معروف',
      message: `فشل في اختبار الوكيل ${agentId}`
    };
  }
}