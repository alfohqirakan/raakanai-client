import NodeCache from 'node-cache';
import crypto from 'crypto';

// Enhanced AI caching system with multiple cache levels
const shortTermCache = new NodeCache({ stdTTL: 1800 }); // 30 minutes for quick responses
const longTermCache = new NodeCache({ stdTTL: 86400 }); // 24 hours for stable content
const statsCache = new NodeCache({ stdTTL: 300 }); // 5 minutes for stats

interface CacheStats {
  hits: number;
  misses: number;
  totalRequests: number;
  hitRate: number;
  cacheSize: number;
  lastUpdated: string;
}

interface CachedAnalysis {
  result: any;
  timestamp: number;
  version: string;
  fileType: string;
  confidence: number;
  processingTime: number;
}

/**
 * Generate optimized cache key using content hash and metadata
 */
export function getCacheKey(content: string, fileType: string, version: string = '2.0'): string {
  // Use SHA-256 hash for consistent, shorter keys
  const contentHash = crypto
    .createHash('sha256')
    .update(content)
    .digest('hex')
    .substring(0, 16); // First 16 chars for efficiency
  
  return `ai-analysis:${version}:${fileType}:${contentHash}`;
}

/**
 * Enhanced cached analysis with smart cache selection
 */
export async function getCachedAnalysis<T>(
  content: string, 
  fileType: string, 
  fetchFn: () => Promise<T>,
  options: {
    forceRefresh?: boolean;
    cacheLevel?: 'short' | 'long';
    version?: string;
  } = {}
): Promise<T> {
  const { forceRefresh = false, cacheLevel = 'short', version = '2.0' } = options;
  const key = getCacheKey(content, fileType, version);
  
  // Select appropriate cache
  const cache = cacheLevel === 'long' ? longTermCache : shortTermCache;
  
  if (!forceRefresh) {
    const cachedData = cache.get<CachedAnalysis>(key);
    
    if (cachedData) {
      console.log(`✅ Cache hit for ${fileType} - saved ${Date.now() - cachedData.timestamp}ms`);
      updateCacheStats('hit');
      return cachedData.result as T;
    }
  }
  
  console.log(`🔄 Cache miss for ${fileType} - calling AI service`);
  updateCacheStats('miss');
  
  const startTime = Date.now();
  const result = await fetchFn();
  const processingTime = Date.now() - startTime;
  
  // Store with metadata for enhanced tracking
  const cachedAnalysis: CachedAnalysis = {
    result,
    timestamp: Date.now(),
    version,
    fileType,
    confidence: (result as any)?.confidence || 0.8,
    processingTime
  };
  
  cache.set(key, cachedAnalysis);
  console.log(`💾 Cached analysis for ${fileType} (${processingTime}ms)`);
  
  return result;
}

/**
 * Smart caching based on content characteristics
 */
export async function getSmartCachedAnalysis<T>(
  content: string,
  fileType: string,
  fetchFn: () => Promise<T>,
  contentSize: number = content.length
): Promise<T> {
  // Determine cache strategy based on content
  const isLargeFile = contentSize > 100000; // 100KB
  const isStableContent = fileType.includes('pdf') || fileType.includes('document');
  
  const cacheLevel = (isLargeFile || isStableContent) ? 'long' : 'short';
  
  return getCachedAnalysis(content, fileType, fetchFn, { cacheLevel });
}

/**
 * Batch cache operations for multiple files
 */
export async function getBatchCachedAnalysis<T>(
  items: Array<{ content: string; fileType: string; id: string }>,
  fetchFn: (content: string, fileType: string) => Promise<T>
): Promise<Array<{ id: string; result: T; fromCache: boolean }>> {
  const results: Array<{ id: string; result: T; fromCache: boolean }> = [];
  
  for (const item of items) {
    const key = getCacheKey(item.content, item.fileType);
    const cached = shortTermCache.get<CachedAnalysis>(key);
    
    if (cached) {
      results.push({
        id: item.id,
        result: cached.result as T,
        fromCache: true
      });
      updateCacheStats('hit');
    } else {
      const result = await fetchFn(item.content, item.fileType);
      const cachedAnalysis: CachedAnalysis = {
        result,
        timestamp: Date.now(),
        version: '2.0',
        fileType: item.fileType,
        confidence: (result as any)?.confidence || 0.8,
        processingTime: 0
      };
      
      shortTermCache.set(key, cachedAnalysis);
      results.push({
        id: item.id,
        result,
        fromCache: false
      });
      updateCacheStats('miss');
    }
  }
  
  const cacheHits = results.filter(r => r.fromCache).length;
  console.log(`📦 Batch operation: ${cacheHits}/${items.length} from cache`);
  
  return results;
}

/**
 * Cache statistics tracking
 */
function updateCacheStats(type: 'hit' | 'miss') {
  const currentStats = statsCache.get<CacheStats>('global-stats') || {
    hits: 0,
    misses: 0,
    totalRequests: 0,
    hitRate: 0,
    cacheSize: 0,
    lastUpdated: new Date().toISOString()
  };
  
  if (type === 'hit') {
    currentStats.hits++;
  } else {
    currentStats.misses++;
  }
  
  currentStats.totalRequests = currentStats.hits + currentStats.misses;
  currentStats.hitRate = currentStats.totalRequests > 0 
    ? (currentStats.hits / currentStats.totalRequests) * 100 
    : 0;
  currentStats.cacheSize = shortTermCache.keys().length + longTermCache.keys().length;
  currentStats.lastUpdated = new Date().toISOString();
  
  statsCache.set('global-stats', currentStats);
}

/**
 * Get comprehensive cache statistics
 */
export function getCacheStats(): CacheStats {
  const stats = statsCache.get<CacheStats>('global-stats') || {
    hits: 0,
    misses: 0,
    totalRequests: 0,
    hitRate: 0,
    cacheSize: 0,
    lastUpdated: new Date().toISOString()
  };
  
  // Update current cache size
  stats.cacheSize = shortTermCache.keys().length + longTermCache.keys().length;
  
  return stats;
}

/**
 * Clear all caches
 */
export function clearAllCaches(): { cleared: number } {
  const totalKeys = shortTermCache.keys().length + longTermCache.keys().length;
  
  shortTermCache.flushAll();
  longTermCache.flushAll();
  statsCache.flushAll();
  
  console.log(`🗑️ Cleared ${totalKeys} cached items`);
  
  return { cleared: totalKeys };
}

/**
 * Cache warming for common content types
 */
export async function warmCache(
  commonContents: Array<{ content: string; fileType: string }>,
  fetchFn: (content: string, fileType: string) => Promise<any>
) {
  console.log(`🔥 Warming cache with ${commonContents.length} items`);
  
  const promises = commonContents.map(async (item) => {
    try {
      await getCachedAnalysis(item.content, item.fileType, () => 
        fetchFn(item.content, item.fileType)
      );
    } catch (error) {
      console.error(`Cache warming failed for ${item.fileType}:`, error);
    }
  });
  
  await Promise.all(promises);
  console.log('✅ Cache warming completed');
}

/**
 * Get cache health information
 */
export function getCacheHealth() {
  const stats = getCacheStats();
  const shortTermKeys = shortTermCache.keys().length;
  const longTermKeys = longTermCache.keys().length;
  
  return {
    status: stats.hitRate > 50 ? 'healthy' : 'needs-optimization',
    hitRate: stats.hitRate,
    totalCached: stats.cacheSize,
    shortTermCache: shortTermKeys,
    longTermCache: longTermKeys,
    efficiency: stats.hitRate > 70 ? 'excellent' : stats.hitRate > 40 ? 'good' : 'poor',
    recommendation: stats.hitRate < 40 
      ? 'Consider increasing cache TTL or warming cache with common queries'
      : 'Cache performance is optimal'
  };
}

// Export cache instances for advanced usage
export { shortTermCache, longTermCache, statsCache };