import fs from 'fs/promises';
import path from 'path';
import { analyzeText, analyzeImage, type FileAnalysis } from './openai.js';

export async function processTextFile(filePath: string): Promise<FileAnalysis> {
  try {
    const content = await fs.readFile(filePath, 'utf-8');
    return await analyzeText(content);
  } catch (error) {
    console.error("Error processing text file:", error);
    throw new Error("فشل في معالجة الملف النصي");
  }
}

export async function processImageFile(filePath: string): Promise<FileAnalysis> {
  try {
    const buffer = await fs.readFile(filePath);
    const base64 = buffer.toString('base64');
    return await analyzeImage(base64);
  } catch (error) {
    console.error("Error processing image file:", error);
    throw new Error("فشل في معالجة ملف الصورة");
  }
}

export async function processPDFFile(filePath: string): Promise<FileAnalysis> {
  try {
    // For now, return a basic analysis
    // In production, you'd use a PDF parsing library like pdf-parse
    return {
      summary: "ملف PDF تم رفعه بنجاح",
      keyPoints: ["وثيقة PDF"],
      categories: ["مستند"],
      confidence: 0.8,
      language: "unknown"
    };
  } catch (error) {
    console.error("Error processing PDF file:", error);
    throw new Error("فشل في معالجة ملف PDF");
  }
}

export function getFileProcessor(mimeType: string) {
  if (mimeType.startsWith('text/') || mimeType === 'application/json') {
    return processTextFile;
  }
  
  if (mimeType.startsWith('image/')) {
    return processImageFile;
  }
  
  if (mimeType === 'application/pdf') {
    return processPDFFile;
  }
  
  // Default processor for unsupported files
  return async (filePath: string): Promise<FileAnalysis> => {
    return {
      summary: "ملف غير مدعوم للتحليل الآلي",
      keyPoints: ["ملف غير مدعوم"],
      categories: ["غير معروف"],
      confidence: 0.5,
      language: "unknown"
    };
  };
}
