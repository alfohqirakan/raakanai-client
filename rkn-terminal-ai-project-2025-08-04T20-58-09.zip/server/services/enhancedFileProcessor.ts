import { analyzeText, analyzeImage } from './openai.js';
import { robustAIRequest, smartAIRetry, robustBatchAIRequest, aiCircuitBreaker, AIRetryError } from './aiRetry.js';
import { getCachedAnalysis, getSmartCachedAnalysis, getBatchCachedAnalysis, getCacheStats } from './aiCache.js';
import { getFileCategory, formatFileSize, detectLanguage } from '../utils/helpers.js';
import { enhancedImageAnalysis, batchImageAnalysis, optimizeImage } from './visionService.js';
import fs from 'fs/promises';
import path from 'path';

export interface EnhancedFileAnalysis {
  id: string;
  summary: string;
  keyPoints: string[];
  categories: string[];
  sentiment?: number;
  confidence: number;
  language: string;
  wordCount?: number;
  fileSize: number;
  processingTime: number;
  retryAttempts: number;
  status: 'success' | 'partial' | 'failed';
  error?: string;
}

/**
 * Enhanced file processor with robust AI retry mechanism
 */
export class EnhancedFileProcessor {
  private static instance: EnhancedFileProcessor;
  
  static getInstance(): EnhancedFileProcessor {
    if (!EnhancedFileProcessor.instance) {
      EnhancedFileProcessor.instance = new EnhancedFileProcessor();
    }
    return EnhancedFileProcessor.instance;
  }

  /**
   * Process single file with enhanced retry logic
   */
  async processSingleFile(
    filePath: string,
    mimeType: string,
    fileId: string
  ): Promise<EnhancedFileAnalysis> {
    const startTime = Date.now();
    let retryAttempts = 0;
    
    try {
      console.log(`🔄 بدء معالجة الملف المحسنة: ${filePath}`);
      
      const stats = await fs.stat(filePath);
      const fileSize = stats.size;
      const category = getFileCategory(mimeType);
      
      // Determine processing complexity
      const complexity = this.getComplexity(fileSize, mimeType);
      
      let result: any;
      let content: string = '';

      if (mimeType.startsWith('image/')) {
        // Process image files
        const imageData = await fs.readFile(filePath);
        const base64Image = imageData.toString('base64');
        
        result = await analyzeImage(base64Image);
      } else {
        // Process text-based files
        content = await fs.readFile(filePath, 'utf-8');
        
        // Use enhanced retry with circuit breaker and caching
        result = await aiCircuitBreaker.execute(async () => {
          return await getSmartCachedAnalysis(
            content,
            category,
            () => smartAIRetry(content, category, { fileSize, complexity }),
            fileSize
          );
        });
        
        // Fallback to basic analysis with caching if smart retry fails
        if (!result) {
          result = await getCachedAnalysis(
            content,
            category,
            () => analyzeText(content)
          );
        }
      }

      const processingTime = Date.now() - startTime;
      
      const enhancedAnalysis: EnhancedFileAnalysis = {
        id: fileId,
        summary: result.summary || 'تم تحليل الملف بنجاح',
        keyPoints: result.keyPoints || ['محتوى تم تحليله'],
        categories: result.categories || [category],
        sentiment: result.sentiment,
        confidence: result.confidence || 0.8,
        language: result.language || detectLanguage(content || ''),
        wordCount: result.wordCount,
        fileSize,
        processingTime,
        retryAttempts,
        status: 'success'
      };

      console.log(`✅ تمت معالجة الملف بنجاح في ${processingTime}ms`);
      return enhancedAnalysis;

    } catch (error) {
      const processingTime = Date.now() - startTime;
      
      if (error instanceof AIRetryError) {
        retryAttempts = error.attempts;
      }
      
      console.error(`❌ فشل في معالجة الملف ${filePath}:`, error);
      
      return {
        id: fileId,
        summary: 'فشل في تحليل الملف',
        keyPoints: ['خطأ في المعالجة'],
        categories: ['خطأ'],
        confidence: 0,
        language: 'غير محدد',
        fileSize: 0,
        processingTime,
        retryAttempts,
        status: 'failed',
        error: (error as Error).message
      };
    }
  }

  /**
   * Process multiple files in batch with optimized concurrency
   */
  async processBatchFiles(
    files: Array<{ filePath: string; mimeType: string; fileId: string }>
  ): Promise<EnhancedFileAnalysis[]> {
    console.log(`📦 بدء معالجة دفعة من ${files.length} ملف`);
    
    const results: EnhancedFileAnalysis[] = [];
    const batchSize = 3; // Process 3 files concurrently
    
    for (let i = 0; i < files.length; i += batchSize) {
      const batch = files.slice(i, i + batchSize);
      
      const batchPromises = batch.map(file => 
        this.processSingleFile(file.filePath, file.mimeType, file.fileId)
      );
      
      const batchResults = await Promise.allSettled(batchPromises);
      
      batchResults.forEach((result, index) => {
        if (result.status === 'fulfilled') {
          results.push(result.value);
        } else {
          const file = batch[index];
          results.push({
            id: file.fileId,
            summary: 'فشل في معالجة الملف',
            keyPoints: ['خطأ في المعالجة'],
            categories: ['خطأ'],
            confidence: 0,
            language: 'غير محدد',
            fileSize: 0,
            processingTime: 0,
            retryAttempts: 0,
            status: 'failed',
            error: result.reason?.message || 'خطأ غير معروف'
          });
        }
      });
      
      // Add delay between batches to respect rate limits
      if (i + batchSize < files.length) {
        await this.sleep(1000);
      }
    }
    
    const successful = results.filter(r => r.status === 'success').length;
    const failed = results.filter(r => r.status === 'failed').length;
    
    console.log(`📊 انتهت المعالجة المجمعة: ${successful} نجح، ${failed} فشل`);
    
    return results;
  }

  /**
   * Get processing complexity based on file characteristics
   */
  private getComplexity(fileSize: number, mimeType: string): 'low' | 'medium' | 'high' {
    // Size-based complexity
    if (fileSize > 5 * 1024 * 1024) return 'high'; // > 5MB
    if (fileSize > 1024 * 1024) return 'medium'; // > 1MB
    
    // Type-based complexity
    if (mimeType.includes('image')) return 'medium';
    if (mimeType.includes('pdf')) return 'high';
    if (mimeType.includes('video') || mimeType.includes('audio')) return 'high';
    
    return 'low';
  }

  /**
   * Get processing statistics
   */
  getProcessingStats() {
    const circuitBreakerState = aiCircuitBreaker.getState();
    const cacheStats = getCacheStats();
    
    return {
      circuitBreaker: circuitBreakerState,
      cache: cacheStats,
      timestamp: new Date().toISOString(),
      version: '2.0.0-enhanced-cached'
    };
  }

  /**
   * Reset circuit breaker if needed
   */
  resetCircuitBreaker() {
    // Create new instance to reset state
    const newBreaker = aiCircuitBreaker;
    console.log('🔄 تم إعادة تعيين قاطع الدائرة لـ AI');
    return newBreaker.getState();
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Export singleton instance
export const enhancedFileProcessor = EnhancedFileProcessor.getInstance();