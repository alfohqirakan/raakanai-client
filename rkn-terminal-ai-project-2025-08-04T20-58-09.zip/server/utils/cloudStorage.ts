import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand, HeadObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import fs from 'fs/promises';
import path from 'path';

// Enhanced cloud storage with fallback to local storage
class CloudStorageManager {
  private s3Client: S3Client | null = null;
  private isS3Available = false;
  private bucket: string;
  private region: string;

  constructor() {
    this.bucket = process.env.S3_BUCKET || 'rakan-ai-storage';
    this.region = process.env.S3_REGION || 'us-east-1';
    
    this.initializeS3();
  }

  private initializeS3() {
    try {
      if (process.env.S3_ACCESS_KEY && process.env.S3_SECRET_KEY) {
        this.s3Client = new S3Client({
          region: this.region,
          credentials: {
            accessKeyId: process.env.S3_ACCESS_KEY,
            secretAccessKey: process.env.S3_SECRET_KEY,
          },
        });
        this.isS3Available = true;
        console.log('☁️ S3 cloud storage initialized successfully');
      } else {
        console.log('📁 Using local storage - S3 credentials not configured');
      }
    } catch (error) {
      console.error('❌ Failed to initialize S3:', error);
      this.isS3Available = false;
    }
  }

  /**
   * Generate secure upload URL with fallback
   */
  async generateUploadURL(filename: string, contentType: string, userId: string): Promise<{
    signedUrl?: string;
    fileKey: string;
    uploadMethod: 'cloud' | 'local';
    expiresIn?: number;
  }> {
    const sanitizedFilename = this.sanitizeFilename(filename);
    const fileKey = `uploads/${userId}/${Date.now()}-${sanitizedFilename}`;

    if (this.isS3Available && this.s3Client) {
      try {
        const command = new PutObjectCommand({
          Bucket: this.bucket,
          Key: fileKey,
          ContentType: contentType,
          Metadata: {
            'user-id': userId,
            'original-name': filename,
            'upload-time': new Date().toISOString()
          }
        });

        const signedUrl = await getSignedUrl(this.s3Client, command, { 
          expiresIn: 3600 // 1 hour
        });

        console.log(`☁️ Generated S3 upload URL for ${filename}`);
        return { 
          signedUrl, 
          fileKey, 
          uploadMethod: 'cloud',
          expiresIn: 3600
        };
      } catch (error) {
        console.error('❌ Failed to generate S3 upload URL:', error);
        // Fallback to local storage
      }
    }

    // Local storage fallback
    const localPath = path.join('uploads', userId);
    await fs.mkdir(localPath, { recursive: true });
    
    console.log(`📁 Using local storage for ${filename}`);
    return {
      fileKey: path.join(localPath, `${Date.now()}-${sanitizedFilename}`),
      uploadMethod: 'local'
    };
  }

  /**
   * Get public URL for file access
   */
  getPublicURL(fileKey: string, uploadMethod: 'cloud' | 'local' = 'cloud'): string {
    if (uploadMethod === 'cloud' && this.isS3Available) {
      return `https://${this.bucket}.s3.${this.region}.amazonaws.com/${fileKey}`;
    }
    
    // Local storage URL
    const baseUrl = process.env.BASE_URL || 'http://localhost:5000';
    return `${baseUrl}/${fileKey}`;
  }

  /**
   * Generate signed download URL for secure access
   */
  async generateDownloadURL(fileKey: string, expiresIn: number = 3600): Promise<string | null> {
    if (!this.isS3Available || !this.s3Client) {
      return null;
    }

    try {
      const command = new GetObjectCommand({
        Bucket: this.bucket,
        Key: fileKey,
      });

      const signedUrl = await getSignedUrl(this.s3Client, command, { expiresIn });
      console.log(`🔗 Generated download URL for ${fileKey}`);
      return signedUrl;
    } catch (error) {
      console.error('❌ Failed to generate download URL:', error);
      return null;
    }
  }

  /**
   * Delete file from storage
   */
  async deleteFile(fileKey: string, uploadMethod: 'cloud' | 'local'): Promise<boolean> {
    if (uploadMethod === 'cloud' && this.isS3Available && this.s3Client) {
      try {
        const command = new DeleteObjectCommand({
          Bucket: this.bucket,
          Key: fileKey,
        });

        await this.s3Client.send(command);
        console.log(`🗑️ Deleted file from S3: ${fileKey}`);
        return true;
      } catch (error) {
        console.error('❌ Failed to delete from S3:', error);
        return false;
      }
    }

    // Local storage deletion
    try {
      await fs.unlink(fileKey);
      console.log(`🗑️ Deleted local file: ${fileKey}`);
      return true;
    } catch (error) {
      console.error('❌ Failed to delete local file:', error);
      return false;
    }
  }

  /**
   * Check if file exists
   */
  async fileExists(fileKey: string, uploadMethod: 'cloud' | 'local'): Promise<boolean> {
    if (uploadMethod === 'cloud' && this.isS3Available && this.s3Client) {
      try {
        const command = new HeadObjectCommand({
          Bucket: this.bucket,
          Key: fileKey,
        });

        await this.s3Client.send(command);
        return true;
      } catch {
        return false;
      }
    }

    // Local storage check
    try {
      await fs.access(fileKey);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Get file metadata
   */
  async getFileMetadata(fileKey: string, uploadMethod: 'cloud' | 'local'): Promise<{
    size?: number;
    lastModified?: Date;
    contentType?: string;
    metadata?: Record<string, string>;
  } | null> {
    if (uploadMethod === 'cloud' && this.isS3Available && this.s3Client) {
      try {
        const command = new HeadObjectCommand({
          Bucket: this.bucket,
          Key: fileKey,
        });

        const response = await this.s3Client.send(command);
        return {
          size: response.ContentLength,
          lastModified: response.LastModified,
          contentType: response.ContentType,
          metadata: response.Metadata
        };
      } catch (error) {
        console.error('❌ Failed to get S3 metadata:', error);
        return null;
      }
    }

    // Local storage metadata
    try {
      const stats = await fs.stat(fileKey);
      return {
        size: stats.size,
        lastModified: stats.mtime
      };
    } catch (error) {
      console.error('❌ Failed to get local file metadata:', error);
      return null;
    }
  }

  /**
   * Get storage statistics
   */
  getStorageInfo() {
    return {
      provider: this.isS3Available ? 'AWS S3' : 'Local Storage',
      bucket: this.bucket,
      region: this.region,
      isCloudAvailable: this.isS3Available,
      features: {
        signedUrls: this.isS3Available,
        publicUrls: true,
        metadata: this.isS3Available,
        scalability: this.isS3Available ? 'unlimited' : 'limited'
      }
    };
  }

  /**
   * Migrate file from local to cloud storage
   */
  async migrateToCloud(localPath: string, cloudKey: string, contentType: string): Promise<boolean> {
    if (!this.isS3Available || !this.s3Client) {
      console.log('❌ Cloud storage not available for migration');
      return false;
    }

    try {
      const fileData = await fs.readFile(localPath);
      
      const command = new PutObjectCommand({
        Bucket: this.bucket,
        Key: cloudKey,
        Body: fileData,
        ContentType: contentType,
      });

      await this.s3Client.send(command);
      console.log(`☁️ Successfully migrated ${localPath} to ${cloudKey}`);
      
      // Optionally delete local file after successful migration
      await fs.unlink(localPath);
      return true;
    } catch (error) {
      console.error('❌ Failed to migrate file to cloud:', error);
      return false;
    }
  }

  /**
   * Sanitize filename for safe storage
   */
  private sanitizeFilename(filename: string): string {
    return filename
      .replace(/[^a-zA-Z0-9._-]/g, '_')
      .replace(/_{2,}/g, '_')
      .slice(0, 255);
  }

  /**
   * Health check for storage system
   */
  async healthCheck(): Promise<{
    status: 'healthy' | 'degraded' | 'unhealthy';
    cloudStorage: boolean;
    localStorage: boolean;
    details: string[];
  }> {
    const details: string[] = [];
    let cloudStorage = false;
    let localStorage = false;

    // Check cloud storage
    if (this.isS3Available && this.s3Client) {
      try {
        // Try to list bucket (minimal operation)
        const command = new HeadObjectCommand({
          Bucket: this.bucket,
          Key: 'health-check-dummy'
        });
        
        await this.s3Client.send(command);
        cloudStorage = true;
        details.push('Cloud storage accessible');
      } catch (error) {
        if ((error as any).name === 'NotFound') {
          cloudStorage = true; // Bucket exists, file doesn't (expected)
          details.push('Cloud storage accessible');
        } else {
          details.push(`Cloud storage error: ${(error as Error).message}`);
        }
      }
    } else {
      details.push('Cloud storage not configured');
    }

    // Check local storage
    try {
      await fs.access('uploads');
      localStorage = true;
      details.push('Local storage accessible');
    } catch {
      try {
        await fs.mkdir('uploads', { recursive: true });
        localStorage = true;
        details.push('Local storage created and accessible');
      } catch (error) {
        details.push(`Local storage error: ${(error as Error).message}`);
      }
    }

    let status: 'healthy' | 'degraded' | 'unhealthy';
    if (cloudStorage && localStorage) {
      status = 'healthy';
    } else if (cloudStorage || localStorage) {
      status = 'degraded';
    } else {
      status = 'unhealthy';
    }

    return {
      status,
      cloudStorage,
      localStorage,
      details
    };
  }
}

// Export singleton instance
export const cloudStorage = new CloudStorageManager();

// Legacy exports for compatibility
export async function generateUploadURL(filename: string, contentType: string) {
  return cloudStorage.generateUploadURL(filename, contentType, 'default');
}

export function getPublicURL(fileKey: string) {
  return cloudStorage.getPublicURL(fileKey);
}