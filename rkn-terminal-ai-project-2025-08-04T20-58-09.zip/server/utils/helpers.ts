/**
 * Utility helper functions for the Rakan AI system
 */

/**
 * Sleep function for delays and retry logic
 * @param ms - milliseconds to sleep
 */
export const sleep = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * Retry function with exponential backoff
 * @param fn - Function to retry
 * @param maxRetries - Maximum number of retries
 * @param baseDelay - Base delay in milliseconds
 */
export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  baseDelay: number = 1000
): Promise<T> {
  let lastError: Error;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;
      
      if (attempt === maxRetries) {
        throw lastError;
      }
      
      // Exponential backoff: 1s, 2s, 4s, 8s...
      const delay = baseDelay * Math.pow(2, attempt);
      console.log(`المحاولة ${attempt + 1} فشلت، إعادة المحاولة خلال ${delay}ms:`, error);
      await sleep(delay);
    }
  }
  
  throw lastError!;
}

/**
 * Format file size in human readable format
 * @param bytes - Size in bytes
 * @returns Formatted string
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 بايت';
  
  const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  
  return `${Math.round(bytes / Math.pow(1024, i) * 100) / 100} ${sizes[i]}`;
}

/**
 * Generate a safe filename
 * @param originalName - Original filename
 * @returns Safe filename
 */
export function sanitizeFilename(originalName: string): string {
  return originalName
    .replace(/[^\w\s.-]/g, '') // Remove special characters
    .replace(/\s+/g, '_') // Replace spaces with underscores
    .toLowerCase();
}

/**
 * Check if a string is valid JSON
 * @param str - String to check
 * @returns boolean
 */
export function isValidJSON(str: string): boolean {
  try {
    JSON.parse(str);
    return true;
  } catch {
    return false;
  }
}

/**
 * Truncate text to specified length
 * @param text - Text to truncate
 * @param maxLength - Maximum length
 * @returns Truncated text
 */
export function truncateText(text: string, maxLength: number = 100): string {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength - 3) + '...';
}

/**
 * Get file type category from mime type
 * @param mimeType - MIME type
 * @returns Category string
 */
export function getFileCategory(mimeType: string): string {
  if (mimeType.startsWith('image/')) return 'صورة';
  if (mimeType.startsWith('video/')) return 'فيديو';
  if (mimeType.startsWith('audio/')) return 'صوت';
  if (mimeType.includes('pdf')) return 'مستند PDF';
  if (mimeType.includes('word') || mimeType.includes('document')) return 'مستند Word';
  if (mimeType.includes('sheet') || mimeType.includes('excel')) return 'جدول بيانات';
  if (mimeType.includes('presentation') || mimeType.includes('powerpoint')) return 'عرض تقديمي';
  if (mimeType.includes('text')) return 'ملف نصي';
  if (mimeType.includes('json')) return 'بيانات JSON';
  if (mimeType.includes('javascript')) return 'كود JavaScript';
  if (mimeType.includes('zip') || mimeType.includes('rar') || mimeType.includes('7z')) return 'ملف مضغوط';
  
  return 'ملف';
}

/**
 * Validate email format
 * @param email - Email to validate
 * @returns boolean
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Generate random string
 * @param length - Length of string
 * @returns Random string
 */
export function generateRandomString(length: number = 10): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

/**
 * Detect content language
 * @param content - Content to analyze
 * @returns Detected language
 */
export function detectLanguage(content: string): string {
  const arabicRegex = /[\u0600-\u06FF]/;
  const englishRegex = /[a-zA-Z]/;
  
  const arabicMatches = content.match(arabicRegex);
  const englishMatches = content.match(englishRegex);
  
  if (arabicMatches && englishMatches) return 'مختلط (عربي/إنجليزي)';
  if (arabicMatches) return 'عربي';
  if (englishMatches) return 'إنجليزي';
  return 'غير محدد';
}

/**
 * Calculate content complexity
 * @param content - Content to analyze
 * @returns Complexity level
 */
export function calculateComplexity(content: string): string {
  const words = content.split(/\s+/).length;
  const sentences = content.split(/[.!?]+/).length;
  const avgWordsPerSentence = words / sentences;
  
  if (avgWordsPerSentence > 20) return 'معقد';
  if (avgWordsPerSentence > 15) return 'متوسط';
  return 'بسيط';
}

/**
 * Extract basic topics from content
 * @param content - Content to analyze
 * @returns Array of topics
 */
export function extractTopics(content: string): string[] {
  const topics = [];
  const lowerContent = content.toLowerCase();
  
  // Basic topic detection
  if (lowerContent.includes('code') || lowerContent.includes('function') || lowerContent.includes('class')) {
    topics.push('برمجة');
  }
  if (lowerContent.includes('data') || lowerContent.includes('analysis')) {
    topics.push('تحليل بيانات');
  }
  if (lowerContent.includes('business') || lowerContent.includes('market')) {
    topics.push('أعمال');
  }
  
  return topics.length > 0 ? topics : ['عام'];
}