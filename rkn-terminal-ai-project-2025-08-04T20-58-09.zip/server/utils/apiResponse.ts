export function success(data: any, message?: string) {
  return { 
    status: "✅ success", 
    data,
    message: message || "تمت العملية بنجاح",
    timestamp: new Date().toISOString()
  };
}

export function error(message: string, code?: string) {
  return { 
    status: "❌ error", 
    message,
    code: code || "GENERAL_ERROR",
    timestamp: new Date().toISOString()
  };
}

export function processing(message: string, progress?: number) {
  return {
    status: "⏳ processing",
    message,
    progress: progress || 0,
    timestamp: new Date().toISOString()
  };
}

export function warning(message: string, data?: any) {
  return {
    status: "⚠️ warning",
    message,
    data,
    timestamp: new Date().toISOString()
  };
}