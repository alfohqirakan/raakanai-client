import swaggerJSDoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';
import type { Express } from 'express';

const options: swaggerJSDoc.Options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'RKN-Terminal AI API - راكان الذكاء السيادي',
      version: '2.0.0',
      description: `
# توثيق API لمنصة RKN-Terminal AI

مرحباً بكم في التوثيق الشامل لواجهة برمجة التطبيقات الخاصة بمنصة **راكان الذكاء السيادي** (RKN-Terminal AI).

## نظرة عامة

RKN-Terminal AI هي منصة ذكاء اصطناعي متقدمة تقدم:

### 🎯 القدرات الأساسية
- **تحليل الملفات المتقدم**: معالجة ذكية للمستندات والصور
- **الرؤية الاصطناعية**: تحليل الصور باستخدام GPT-4o Vision
- **المعالجة المجمعة**: رفع ومعالجة متعددة للملفات
- **نظام المحادثة الذكي**: AI محادثة تفاعلية حول الملفات

### 🔐 الأمان والمصادقة
- مصادقة قائمة على الجلسات
- حماية متعددة الطبقات
- تشفير البيانات الحساسة
- مراقبة الأداء والأمان

### 🌐 الدعم اللغوي
- عربي أولاً (RTL)
- دعم كامل للإنجليزية
- واجهة متعددة اللغات

### 📊 المراقبة والتحليلات
- مقاييس الأداء في الوقت الفعلي
- تتبع استخدام الموارد
- إحصائيات مفصلة

## استخدام API

جميع نقاط النهاية تستخدم تنسيق استجابة موحد:

\`\`\`json
{
  "status": "✅ success | ❌ error | ⏳ processing | ⚠️ warning",
  "data": {},
  "message": "رسالة وصفية",
  "timestamp": "2025-08-02T19:45:00.000Z"
}
\`\`\`

## المعدلات والحدود

### خطة المجانية
- 5 ملفات شهرياً
- حد أقصى 10MB للملف
- تحليل أساسي

### خطة Pro
- 100 ملف شهرياً  
- حد أقصى 50MB للملف
- تحليل متقدم ومعالجة مجمعة

---

**تطوير**: فريق RKN-Terminal AI  
**الدعم**: [support@rkn-terminal.ai](mailto:support@rkn-terminal.ai)
      `,
      contact: {
        name: 'RKN-Terminal AI Support',
        email: 'support@rkn-terminal.ai',
        url: 'https://rkn-terminal.ai'
      },
      license: {
        name: 'MIT',
        url: 'https://opensource.org/licenses/MIT'
      },
      termsOfService: 'https://rkn-terminal.ai/terms'
    },
    servers: [
      {
        url: 'http://localhost:5000/api',
        description: 'خادم التطوير المحلي'
      },
      {
        url: 'https://api.rkn-terminal.ai',
        description: 'خادم الإنتاج'
      }
    ],
    components: {
      securitySchemes: {
        SessionAuth: {
          type: 'apiKey',
          in: 'cookie',
          name: 'connect.sid',
          description: 'مصادقة قائمة على الجلسات'
        },
        BearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'مصادقة JWT (للاستخدام المستقبلي)'
        }
      },
      schemas: {
        ApiResponse: {
          type: 'object',
          properties: {
            status: {
              type: 'string',
              enum: ['✅ success', '❌ error', '⏳ processing', '⚠️ warning'],
              description: 'حالة الاستجابة'
            },
            data: {
              type: 'object',
              description: 'بيانات الاستجابة'
            },
            message: {
              type: 'string',
              description: 'رسالة وصفية'
            },
            timestamp: {
              type: 'string',
              format: 'date-time',
              description: 'طابع زمني ISO 8601'
            }
          },
          required: ['status', 'timestamp']
        },
        User: {
          type: 'object',
          properties: {
            id: {
              type: 'integer',
              description: 'معرف المستخدم الفريد'
            },
            username: {
              type: 'string',
              description: 'اسم المستخدم',
              minLength: 3,
              maxLength: 50
            },
            email: {
              type: 'string',
              format: 'email',
              description: 'عنوان البريد الإلكتروني'
            },
            plan: {
              type: 'string',
              enum: ['free', 'pro'],
              description: 'نوع الخطة'
            },
            uploadsUsed: {
              type: 'integer',
              description: 'عدد الملفات المرفوعة هذا الشهر'
            },
            uploadLimit: {
              type: 'integer',
              description: 'الحد الأقصى للملفات الشهرية'
            },
            createdAt: {
              type: 'string',
              format: 'date-time',
              description: 'تاريخ إنشاء الحساب'
            }
          },
          required: ['id', 'username', 'plan']
        },
        FileInfo: {
          type: 'object',
          properties: {
            id: {
              type: 'integer',
              description: 'معرف الملف الفريد'
            },
            filename: {
              type: 'string',
              description: 'اسم الملف'
            },
            originalName: {
              type: 'string',
              description: 'الاسم الأصلي للملف'
            },
            mimeType: {
              type: 'string',
              description: 'نوع MIME'
            },
            size: {
              type: 'integer',
              description: 'حجم الملف بالبايت'
            },
            status: {
              type: 'string',
              enum: ['uploaded', 'processing', 'analyzed', 'error'],
              description: 'حالة معالجة الملف'
            },
            analysis: {
              type: 'object',
              description: 'نتائج التحليل'
            },
            uploadedAt: {
              type: 'string',
              format: 'date-time',
              description: 'تاريخ الرفع'
            }
          },
          required: ['id', 'filename', 'mimeType', 'size', 'status']
        },
        VisionAnalysis: {
          type: 'object',
          properties: {
            objects: {
              type: 'array',
              items: {
                type: 'string'
              },
              description: 'الأشياء المكتشفة في الصورة'
            },
            text: {
              type: 'string',
              description: 'النصوص المستخرجة (OCR)'
            },
            scene: {
              type: 'string',
              description: 'وصف المشهد العام'
            },
            description: {
              type: 'string',
              description: 'وصف شامل للصورة'
            },
            confidence: {
              type: 'number',
              minimum: 0,
              maximum: 1,
              description: 'مستوى الثقة في التحليل'
            },
            metadata: {
              type: 'object',
              properties: {
                imageSize: {
                  type: 'object',
                  properties: {
                    width: { type: 'integer' },
                    height: { type: 'integer' }
                  }
                },
                format: { type: 'string' },
                quality: { type: 'string' }
              }
            }
          },
          required: ['objects', 'text', 'scene', 'description', 'confidence']
        },
        Error: {
          type: 'object',
          properties: {
            status: {
              type: 'string',
              enum: ['❌ error']
            },
            message: {
              type: 'string',
              description: 'رسالة الخطأ'
            },
            code: {
              type: 'string',
              description: 'رمز الخطأ'
            },
            timestamp: {
              type: 'string',
              format: 'date-time'
            }
          },
          required: ['status', 'message', 'timestamp']
        }
      },
      responses: {
        UnauthorizedError: {
          description: 'غير مصرح - يجب تسجيل الدخول',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' }
            }
          }
        },
        ForbiddenError: {
          description: 'ممنوع - ليس لديك صلاحية',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' }
            }
          }
        },
        NotFoundError: {
          description: 'غير موجود - لم يتم العثور على المورد',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' }
            }
          }
        },
        ValidationError: {
          description: 'خطأ في التحقق من صحة البيانات',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' }
            }
          }
        },
        ServerError: {
          description: 'خطأ في الخادم',
          content: {
            'application/json': {
              schema: { $ref: '#/components/schemas/Error' }
            }
          }
        }
      }
    },
    tags: [
      {
        name: 'Authentication',
        description: 'المصادقة وإدارة الجلسات'
      },
      {
        name: 'Files',
        description: 'إدارة ورفع الملفات'
      },
      {
        name: 'Vision AI',
        description: 'تحليل الصور بالذكاء الاصطناعي'
      },
      {
        name: 'Chat',
        description: 'نظام المحادثة مع AI'
      },
      {
        name: 'Analytics',
        description: 'التحليلات والإحصائيات'
      },
      {
        name: 'System',
        description: 'معلومات النظام والحالة'
      },
      {
        name: 'Notifications',
        description: 'نظام الإشعارات والبريد الإلكتروني'
      },
      {
        name: 'Email',
        description: 'خدمات البريد الإلكتروني'
      },
      {
        name: 'AI Agents',
        description: 'الوكلاء الذكيين المتخصصين'
      },
      {
        name: 'Self-Evolution',
        description: 'نظام التطور الذاتي والتعلم'
      }
    ]
  },
  apis: [
    './server/api/*.ts',
    './server/routes.ts',
    './server/index.ts'
  ]
};

const specs = swaggerJSDoc(options);

// تخصيص واجهة Swagger UI
const swaggerOptions = {
  customCss: `
    .swagger-ui .topbar { display: none; }
    .swagger-ui .info .title { color: #002B5B; font-family: 'Cairo', sans-serif; }
    .swagger-ui .info .description { text-align: right; direction: rtl; }
    .swagger-ui .opblock-tag { color: #002B5B; font-weight: bold; }
    .swagger-ui .opblock .opblock-summary { border-color: #F5C542; }
    .swagger-ui .btn.execute { background-color: #002B5B; border-color: #002B5B; }
    .swagger-ui .btn.execute:hover { background-color: #F5C542; border-color: #F5C542; color: #002B5B; }
  `,
  customSiteTitle: 'RKN-Terminal AI API Documentation',
  customfavIcon: '/favicon.ico',
  swaggerOptions: {
    persistAuthorization: true,
    displayRequestDuration: true,
    filter: true,
    tryItOutEnabled: true,
    requestInterceptor: (req: any) => {
      req.headers['Accept-Language'] = 'ar,en';
      return req;
    }
  }
};

export function setupSwagger(app: Express): void {
  // إعداد Swagger UI
  app.use('/api/docs', swaggerUi.serve);
  app.get('/api/docs', swaggerUi.setup(specs, swaggerOptions));

  // نقطة نهاية JSON الخام للمواصفات
  app.get('/api/docs/swagger.json', (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    res.send(specs);
  });

  console.log('📚 RKN-Terminal AI API Documentation initialized');
  console.log('📖 Swagger UI available at: /api/docs');
  console.log('📄 Raw JSON specs at: /api/docs/swagger.json');
}

export { specs };
export default setupSwagger;