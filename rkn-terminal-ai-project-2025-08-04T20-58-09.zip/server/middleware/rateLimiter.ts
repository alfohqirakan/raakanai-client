import rateLimit from 'express-rate-limit';
import { Request, Response } from 'express';

// Rate limiter للنظام السيادي
export const sovereignRateLimit = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 30, // limit each IP to 30 requests per windowMs
  message: {
    error: 'تم تجاوز الحد المسموح للطلبات',
    message: 'يرجى الانتظار قبل المحاولة مرة أخرى',
    retry_after: 60
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req: Request, res: Response) => {
    res.status(429).json({
      error: 'تم تجاوز الحد المسموح للطلبات',
      message: 'النظام السيادي يتطلب فترة استراحة',
      retry_after: 60,
      timestamp: new Date().toISOString()
    });
  }
});

// Rate limiter أكثر تساهلاً للتطبيقات الداخلية
export const internalRateLimit = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // أعلى للعمليات الداخلية
  skip: (req: Request) => {
    // تخطي التحديد للعمليات الداخلية المهمة
    return req.headers['x-internal-request'] === 'true';
  }
});

// Rate limiter خاص بـAPI
export const apiRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200, // limit each IP to 200 requests per 15 minutes
  message: {
    error: 'تم تجاوز حد الطلبات لواجهة البرمجة',
    retry_after: 900
  }
});