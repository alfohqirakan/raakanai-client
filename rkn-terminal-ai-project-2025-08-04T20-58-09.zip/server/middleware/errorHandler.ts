import { Request, Response, NextFunction } from 'express';
import { error as errorResponse } from '../utils/apiResponse.js';

// Enhanced error types for better categorization
export interface AppError extends Error {
  statusCode?: number;
  code?: string;
  isOperational?: boolean;
  details?: any;
}

// Error severity levels
export enum ErrorSeverity {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

// Error categories for analytics
export enum ErrorCategory {
  AUTHENTICATION = 'authentication',
  AUTHORIZATION = 'authorization',
  VALIDATION = 'validation',
  DATABASE = 'database',
  EXTERNAL_SERVICE = 'external_service',
  FILE_PROCESSING = 'file_processing',
  AI_SERVICE = 'ai_service',
  NETWORK = 'network',
  SYSTEM = 'system',
  UNKNOWN = 'unknown'
}

// Error classification utility
function classifyError(err: AppError): {
  category: ErrorCategory;
  severity: ErrorSeverity;
  isOperational: boolean;
} {
  // Authentication errors
  if (err.message.includes('unauthorized') || err.message.includes('غير مسجل الدخول')) {
    return {
      category: ErrorCategory.AUTHENTICATION,
      severity: ErrorSeverity.MEDIUM,
      isOperational: true
    };
  }

  // Database errors
  if (err.message.includes('database') || err.message.includes('query') || err.message.includes('connection')) {
    return {
      category: ErrorCategory.DATABASE,
      severity: ErrorSeverity.HIGH,
      isOperational: true
    };
  }

  // File processing errors
  if (err.message.includes('file') || err.message.includes('upload') || err.message.includes('ملف')) {
    return {
      category: ErrorCategory.FILE_PROCESSING,
      severity: ErrorSeverity.MEDIUM,
      isOperational: true
    };
  }

  // AI service errors
  if (err.message.includes('OpenAI') || err.message.includes('AI') || err.message.includes('ذكاء')) {
    return {
      category: ErrorCategory.AI_SERVICE,
      severity: ErrorSeverity.HIGH,
      isOperational: true
    };
  }

  // Validation errors
  if (err.message.includes('validation') || err.message.includes('invalid') || err.message.includes('required')) {
    return {
      category: ErrorCategory.VALIDATION,
      severity: ErrorSeverity.LOW,
      isOperational: true
    };
  }

  // Network errors
  if (err.message.includes('network') || err.message.includes('timeout') || err.message.includes('ECONNREFUSED')) {
    return {
      category: ErrorCategory.NETWORK,
      severity: ErrorSeverity.HIGH,
      isOperational: true
    };
  }

  // System errors
  if (err.statusCode && err.statusCode >= 500) {
    return {
      category: ErrorCategory.SYSTEM,
      severity: ErrorSeverity.CRITICAL,
      isOperational: false
    };
  }

  // Default classification
  return {
    category: ErrorCategory.UNKNOWN,
    severity: ErrorSeverity.MEDIUM,
    isOperational: err.isOperational ?? false
  };
}

// Error message translations
const errorMessages = {
  ar: {
    'Internal Server Error': 'خطأ داخلي في الخادم',
    'Not Found': 'غير موجود',
    'Unauthorized': 'غير مصرح',
    'Forbidden': 'محظور',
    'Bad Request': 'طلب غير صحيح',
    'Validation Error': 'خطأ في التحقق',
    'Database Error': 'خطأ في قاعدة البيانات',
    'File Processing Error': 'خطأ في معالجة الملف',
    'AI Service Error': 'خطأ في خدمة الذكاء الاصطناعي',
    'Network Error': 'خطأ في الشبكة',
    'Authentication Required': 'مطلوب تسجيل الدخول',
    'Access Denied': 'تم رفض الوصول',
    'Resource Not Found': 'المورد غير موجود',
    'Operation Failed': 'فشلت العملية'
  },
  en: {
    'Internal Server Error': 'Internal Server Error',
    'Not Found': 'Not Found',
    'Unauthorized': 'Unauthorized',
    'Forbidden': 'Forbidden',
    'Bad Request': 'Bad Request',
    'Validation Error': 'Validation Error',
    'Database Error': 'Database Error',
    'File Processing Error': 'File Processing Error',
    'AI Service Error': 'AI Service Error',
    'Network Error': 'Network Error',
    'Authentication Required': 'Authentication Required',
    'Access Denied': 'Access Denied',
    'Resource Not Found': 'Resource Not Found',
    'Operation Failed': 'Operation Failed'
  }
};

// Get localized error message
function getLocalizedMessage(message: string, language: 'ar' | 'en' = 'ar'): string {
  const messages = errorMessages[language];
  return (messages as Record<string, string>)[message] || message;
}

// Enhanced error logging
function logError(err: AppError, req: Request, classification: any) {
  const timestamp = new Date().toISOString();
  const userAgent = req.headers['user-agent'] || 'Unknown';
  const userId = (req.session as any)?.userId || 'Anonymous';
  const requestId = Math.random().toString(36).substring(7);

  // Create comprehensive error log
  const errorLog = {
    timestamp,
    requestId,
    error: {
      message: err.message,
      stack: err.stack,
      code: err.code,
      statusCode: err.statusCode
    },
    classification,
    request: {
      method: req.method,
      path: req.path,
      query: req.query,
      userId,
      userAgent,
      ip: req.ip
    },
    system: {
      nodeVersion: process.version,
      platform: process.platform,
      memory: process.memoryUsage(),
      uptime: process.uptime()
    }
  };

  // Log based on severity
  switch (classification.severity) {
    case ErrorSeverity.CRITICAL:
      console.error('🚨 CRITICAL ERROR:', JSON.stringify(errorLog, null, 2));
      break;
    case ErrorSeverity.HIGH:
      console.error('❌ HIGH SEVERITY ERROR:', JSON.stringify(errorLog, null, 2));
      break;
    case ErrorSeverity.MEDIUM:
      console.warn('⚠️ MEDIUM SEVERITY ERROR:', JSON.stringify(errorLog, null, 2));
      break;
    case ErrorSeverity.LOW:
      console.info('ℹ️ LOW SEVERITY ERROR:', JSON.stringify(errorLog, null, 2));
      break;
    default:
      console.log('📝 ERROR LOG:', JSON.stringify(errorLog, null, 2));
  }

  return requestId;
}

// Main error handler middleware
export function errorHandler(
  err: AppError,
  req: Request,
  res: Response,
  next: NextFunction
) {
  // Skip if response already sent
  if (res.headersSent) {
    return next(err);
  }

  // Classify the error
  const classification = classifyError(err);
  
  // Log the error with classification
  const requestId = logError(err, req, classification);

  // Determine status code
  const statusCode = err.statusCode || (classification.severity === ErrorSeverity.CRITICAL ? 500 : 400);

  // Determine language preference (default to Arabic)
  const acceptLanguage = req.headers['accept-language'] || 'ar';
  const language = acceptLanguage.includes('ar') ? 'ar' : 'en';

  // Get appropriate error message
  let errorMessage = err.message;
  if (statusCode === 500 && !classification.isOperational) {
    errorMessage = getLocalizedMessage('Internal Server Error', language);
  } else if (statusCode === 404) {
    errorMessage = getLocalizedMessage('Resource Not Found', language);
  } else if (statusCode === 401) {
    errorMessage = getLocalizedMessage('Authentication Required', language);
  } else if (statusCode === 403) {
    errorMessage = getLocalizedMessage('Access Denied', language);
  }

  // Prepare error response
  const errorData: Record<string, any> = {
    message: errorMessage,
    code: err.code || `ERR_${classification.category.toUpperCase()}`,
    category: classification.category,
    severity: classification.severity,
    timestamp: new Date().toISOString(),
    requestId,
    path: req.path,
    method: req.method
  };

  // Add debug information in development
  if (process.env.NODE_ENV === 'development') {
    errorData.stack = err.stack;
    errorData.details = err.details;
  }

  // Send standardized error response
  res.status(statusCode).json(errorResponse(errorMessage, errorData as any));
}

// Async error wrapper for route handlers
export function asyncHandler(fn: Function) {
  return (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

// Create custom error utility
export function createError(
  message: string,
  statusCode: number = 500,
  code?: string,
  details?: any
): AppError {
  const error = new Error(message) as AppError;
  error.statusCode = statusCode;
  error.code = code;
  error.details = details;
  error.isOperational = true;
  return error;
}

// Specific error creators
export const AuthenticationError = (message: string = 'Authentication required') =>
  createError(message, 401, 'AUTH_REQUIRED');

export const AuthorizationError = (message: string = 'Access denied') =>
  createError(message, 403, 'ACCESS_DENIED');

export const ValidationError = (message: string, details?: any) =>
  createError(message, 400, 'VALIDATION_ERROR', details);

export const DatabaseError = (message: string, details?: any) =>
  createError(message, 500, 'DATABASE_ERROR', details);

export const FileProcessingError = (message: string, details?: any) =>
  createError(message, 400, 'FILE_PROCESSING_ERROR', details);

export const AIServiceError = (message: string, details?: any) =>
  createError(message, 502, 'AI_SERVICE_ERROR', details);

export const NetworkError = (message: string, details?: any) =>
  createError(message, 503, 'NETWORK_ERROR', details);

// Rate limiting error
export const RateLimitError = (message: string = 'Too many requests') =>
  createError(message, 429, 'RATE_LIMIT_EXCEEDED');

// Not found error
export const NotFoundError = (resource: string = 'Resource') =>
  createError(`${resource} not found`, 404, 'NOT_FOUND');

// Global unhandled promise rejection handler
process.on('unhandledRejection', (reason: any, promise: Promise<any>) => {
  console.error('🚨 Unhandled Promise Rejection:', reason);
  console.error('Promise:', promise);
  
  // Create artificial error for logging
  const error = new Error(`Unhandled Promise Rejection: ${reason}`) as AppError;
  error.statusCode = 500;
  error.isOperational = false;
  
  const classification = {
    category: ErrorCategory.SYSTEM,
    severity: ErrorSeverity.CRITICAL,
    isOperational: false
  };
  
  // Log the error
  const errorLog = {
    timestamp: new Date().toISOString(),
    type: 'unhandledRejection',
    reason: reason?.toString(),
    stack: reason?.stack,
    classification
  };
  
  console.error('🚨 UNHANDLED REJECTION LOG:', JSON.stringify(errorLog, null, 2));
});

// Global uncaught exception handler
process.on('uncaughtException', (error: Error) => {
  console.error('🚨 Uncaught Exception:', error);
  
  const classification = {
    category: ErrorCategory.SYSTEM,
    severity: ErrorSeverity.CRITICAL,
    isOperational: false
  };
  
  const errorLog = {
    timestamp: new Date().toISOString(),
    type: 'uncaughtException',
    message: error.message,
    stack: error.stack,
    classification
  };
  
  console.error('🚨 UNCAUGHT EXCEPTION LOG:', JSON.stringify(errorLog, null, 2));
  
  // Graceful shutdown
  process.exit(1);
});