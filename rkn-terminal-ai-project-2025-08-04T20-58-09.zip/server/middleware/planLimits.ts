import { Request, Response, NextFunction } from 'express';
import { storage } from '../storage';

export interface UserPlanLimits {
  free: {
    maxUploads: number;
    maxFileSize: number; // in bytes
    features: string[];
  };
  pro: {
    maxUploads: number;
    maxFileSize: number;
    features: string[];
  };
}

export const PLAN_LIMITS: UserPlanLimits = {
  free: {
    maxUploads: 5,
    maxFileSize: 10 * 1024 * 1024, // 10MB
    features: ['basic_analysis', 'file_upload', 'chat']
  },
  pro: {
    maxUploads: 100,
    maxFileSize: 100 * 1024 * 1024, // 100MB
    features: ['advanced_analysis', 'autonomous_monitoring', 'bulk_upload', 'priority_support', 'custom_reports']
  }
};

export async function checkUploadLimits(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = (req as any).user?.id;
    if (!userId) {
      return res.status(401).json({ message: 'المستخدم غير مصرح له' });
    }

    // الحصول على معلومات المستخدم
    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }

    const userPlan = user.plan || 'free';
    const limits = PLAN_LIMITS[userPlan as keyof UserPlanLimits];

    // فحص عدد الملفات المرفوعة
    if (user.uploadCount >= limits.maxUploads) {
      return res.status(403).json({ 
        message: `تم الوصول لحد الخطة ${userPlan === 'free' ? 'المجانية' : 'المدفوعة'}`,
        currentUploads: user.uploadCount,
        maxUploads: limits.maxUploads,
        plan: userPlan
      });
    }

    // فحص حجم الملف
    const fileSize = req.file?.size || 0;
    if (fileSize > limits.maxFileSize) {
      return res.status(413).json({
        message: `حجم الملف كبير جداً للخطة ${userPlan === 'free' ? 'المجانية' : 'المدفوعة'}`,
        fileSize,
        maxSize: limits.maxFileSize,
        plan: userPlan
      });
    }

    next();
  } catch (error) {
    console.error('خطأ في فحص حدود الخطة:', error);
    res.status(500).json({ message: 'خطأ في النظام' });
  }
}

export async function checkFeatureAccess(feature: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const userId = (req as any).user?.id;
      if (!userId) {
        return res.status(401).json({ message: 'المستخدم غير مصرح له' });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'المستخدم غير موجود' });
      }

      const userPlan = user.plan || 'free';
      const limits = PLAN_LIMITS[userPlan as keyof UserPlanLimits];

      if (!limits.features.includes(feature)) {
        return res.status(403).json({
          message: `هذه الميزة متاحة فقط للخطة المدفوعة`,
          feature,
          userPlan,
          availableFeatures: limits.features
        });
      }

      next();
    } catch (error) {
      console.error('خطأ في فحص الميزة:', error);
      res.status(500).json({ message: 'خطأ في النظام' });
    }
  };
}

export async function incrementUploadCount(userId: string) {
  try {
    const user = await storage.getUser(userId);
    if (user) {
      await storage.updateUser(userId, {
        uploadCount: (user.uploadCount || 0) + 1
      });
    }
  } catch (error) {
    console.error('خطأ في تحديث عداد الرفع:', error);
  }
}