import multer from 'multer';
import path from 'path';
import { randomUUID } from 'crypto';
import fs from 'fs';

// Ensure upload directories exist
const uploadDir = 'uploads';
const imageDir = path.join(uploadDir, 'images');
const documentDir = path.join(uploadDir, 'documents');

[uploadDir, imageDir, documentDir].forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

// Configure multer storage with better organization
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Organize files by type
    const isImage = file.mimetype.startsWith('image/');
    const destination = isImage ? imageDir : documentDir;
    cb(null, destination);
  },
  filename: (req, file, cb) => {
    // Generate unique filename with timestamp and UUID
    const ext = path.extname(file.originalname);
    const uniqueName = `${Date.now()}_${randomUUID()}${ext}`;
    cb(null, uniqueName);
  },
});

// Enhanced file filter with comprehensive type checking
const fileFilter = (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  const allowedMimeTypes = [
    // Images
    'image/jpeg',
    'image/jpg', 
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml',
    
    // Documents
    'application/pdf',
    'text/plain',
    'text/csv',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    
    // Code files
    'text/javascript',
    'application/javascript',
    'text/typescript',
    'application/json',
    'text/html',
    'text/css',
    'application/xml',
    'text/xml',
    
    // Archive files
    'application/zip',
    'application/x-rar-compressed',
    'application/x-7z-compressed',
  ];

  const allowedExtensions = [
    '.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg',
    '.pdf', '.txt', '.csv', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
    '.js', '.ts', '.json', '.html', '.css', '.xml',
    '.zip', '.rar', '.7z'
  ];

  const fileExtension = path.extname(file.originalname).toLowerCase();
  
  if (allowedMimeTypes.includes(file.mimetype) && allowedExtensions.includes(fileExtension)) {
    cb(null, true);
  } else {
    const error = new Error(`نوع الملف غير مدعوم. الأنواع المدعومة: الصور (JPG, PNG, GIF, WebP, SVG)، المستندات (PDF, Word, Excel, PowerPoint)، النصوص (TXT, CSV)، الأكواد (JS, TS, JSON, HTML, CSS)، والأرشيف (ZIP, RAR, 7Z)`);
    error.name = 'INVALID_FILE_TYPE';
    cb(error);
  }
};

// Create multer instance with enhanced configuration
export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
    files: 10, // Maximum 10 files per request
    fieldSize: 1024 * 1024, // 1MB field size limit
  },
});

// Enhanced error handling middleware for multer
export const handleUploadError = (error: any, req: any, res: any, next: any) => {
  if (error instanceof multer.MulterError) {
    switch (error.code) {
      case 'LIMIT_FILE_SIZE':
        return res.status(400).json({
          status: '❌ error',
          message: 'حجم الملف كبير جداً. الحد الأقصى المسموح 50 ميجابايت',
          error: 'FILE_TOO_LARGE',
          timestamp: new Date().toISOString()
        });
      case 'LIMIT_FILE_COUNT':
        return res.status(400).json({
          status: '❌ error',
          message: 'عدد الملفات كبير جداً. الحد الأقصى 10 ملفات',
          error: 'TOO_MANY_FILES',
          timestamp: new Date().toISOString()
        });
      case 'LIMIT_UNEXPECTED_FILE':
        return res.status(400).json({
          status: '❌ error',
          message: 'حقل الملف غير متوقع',
          error: 'UNEXPECTED_FIELD',
          timestamp: new Date().toISOString()
        });
      default:
        return res.status(400).json({
          status: '❌ error',
          message: 'خطأ في رفع الملف',
          error: error.code,
          timestamp: new Date().toISOString()
        });
    }
  }

  if (error.name === 'INVALID_FILE_TYPE') {
    return res.status(400).json({
      status: '❌ error',
      message: error.message,
      error: 'INVALID_FILE_TYPE',
      timestamp: new Date().toISOString()
    });
  }

  // Pass other errors to default error handler
  next(error);
};

// Utility function to get file info
export const getFileInfo = (file: Express.Multer.File) => {
  return {
    originalName: file.originalname,
    filename: file.filename,
    mimetype: file.mimetype,
    size: file.size,
    path: file.path,
    destination: file.destination,
    isImage: file.mimetype.startsWith('image/'),
    extension: path.extname(file.originalname).toLowerCase(),
  };
};

// File validation utility
export const validateFile = (file: Express.Multer.File): { valid: boolean; error?: string } => {
  // Check file size
  if (file.size > 50 * 1024 * 1024) {
    return { valid: false, error: 'حجم الملف كبير جداً' };
  }

  // Check if file has content
  if (file.size === 0) {
    return { valid: false, error: 'الملف فارغ' };
  }

  // Additional security checks
  const filename = file.originalname.toLowerCase();
  const dangerousExtensions = ['.exe', '.bat', '.cmd', '.scr', '.pif', '.vbs', '.js', '.jar'];
  
  if (dangerousExtensions.some(ext => filename.endsWith(ext))) {
    return { valid: false, error: 'نوع الملف غير آمن' };
  }

  return { valid: true };
};