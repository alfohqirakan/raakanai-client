import { Request, Response, NextFunction } from 'express';
import { error } from '../utils/apiResponse.js';
import { canUserUpload } from '../lib/auth.js';

// Extend Express Request type to include session
declare module 'express-serve-static-core' {
  interface Request {
    session?: {
      user?: {
        id: string;
        username: string;
        plan: string;
      };
    };
  }
}

// Enhanced file type validation with comprehensive MIME types
const ALLOWED_MIME_TYPES = [
  // Images
  'image/jpeg',
  'image/jpg', 
  'image/png',
  'image/gif',
  'image/webp',
  'image/svg+xml',
  'image/bmp',
  'image/tiff',
  
  // Documents
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  
  // Text files
  'text/plain',
  'text/csv',
  'text/html',
  'text/css',
  'text/javascript',
  'text/xml',
  'application/json',
  'application/xml',
  
  // Code files
  'text/x-python',
  'text/x-java-source',
  'text/x-c',
  'text/x-c++',
  'text/x-csharp',
  'application/x-php',
  'text/x-sql',
  
  // Archives
  'application/zip',
  'application/x-rar-compressed',
  'application/x-7z-compressed',
  'application/x-tar',
  'application/gzip',
  
  // Audio
  'audio/mpeg',
  'audio/wav',
  'audio/ogg',
  'audio/mp4',
  'audio/flac',
  
  // Video
  'video/mp4',
  'video/mpeg',
  'video/quicktime',
  'video/x-msvideo',
  'video/webm'
];

// Enhanced file size limit - 50MB to match current system
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

/**
 * Enhanced file validation middleware with comprehensive checks
 */
export function validateFile(req: Request, res: Response, next: NextFunction) {
  try {
    console.log('🔍 بدء التحقق من صحة الملف');
    
    // Check if files exist
    if (!req.files || !Array.isArray(req.files) || req.files.length === 0) {
      console.log('❌ لم يتم توفير ملفات');
      return res.status(400).json(error('لم يتم توفير ملفات', 'NO_FILES_PROVIDED'));
    }

    const files = req.files as Express.Multer.File[];
    const validationErrors: string[] = [];

    // Validate each file
    for (const file of files) {
      console.log(`🔍 فحص الملف: ${file.originalname} (${file.mimetype}, ${file.size} bytes)`);
      
      // Check file type
      if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
        const fileType = file.mimetype.split('/')[1] || file.mimetype;
        validationErrors.push(`نوع الملف غير مدعوم: ${file.originalname} (${fileType})`);
        continue;
      }

      // Check file size
      if (file.size > MAX_FILE_SIZE) {
        const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
        validationErrors.push(`حجم الملف يتجاوز الحد المسموح: ${file.originalname} (${sizeMB} MB)`);
        continue;
      }

      // Check if file is empty
      if (file.size === 0) {
        validationErrors.push(`الملف فارغ: ${file.originalname}`);
        continue;
      }

      // Additional security checks
      if (file.originalname.includes('../') || file.originalname.includes('..\\')) {
        validationErrors.push(`اسم الملف غير آمن: ${file.originalname}`);
        continue;
      }
    }

    // If there are validation errors, return them
    if (validationErrors.length > 0) {
      console.log(`❌ فشل التحقق من ${validationErrors.length} ملف`);
      return res.status(400).json(error(
        `فشل التحقق من ${validationErrors.length} ملف`, 
        'FILE_VALIDATION_FAILED'
      ));
    }

    console.log(`✅ تم التحقق من ${files.length} ملف بنجاح`);
    next();
  } catch (err) {
    console.error('خطأ في التحقق من صحة الملف:', err);
    return res.status(500).json(error('خطأ في التحقق من صحة الملف', 'VALIDATION_ERROR'));
  }
}

/**
 * Enhanced user upload limits validation
 */
export async function validateUploadLimits(req: Request, res: Response, next: NextFunction) {
  try {
    const userId = req.session?.user?.id;
    
    if (!userId) {
      console.log('❌ محاولة رفع بدون تسجيل دخول');
      return res.status(401).json(error('يجب تسجيل الدخول أولاً', 'AUTHENTICATION_REQUIRED'));
    }

    const files = req.files as Express.Multer.File[];
    const fileCount = files?.length || 0;

    // Check user upload limits
    const { canUpload, remaining, limit } = await canUserUpload(userId);
    
    if (!canUpload) {
      console.log(`❌ تم الوصول لحد الرفع للمستخدم ${userId}`);
      return res.status(403).json(error(
        `تم الوصول للحد الأقصى للرفع (${limit} ملف)`, 
        'UPLOAD_LIMIT_EXCEEDED'
      ));
    }

    if (fileCount > remaining) {
      console.log(`❌ محاولة رفع ${fileCount} ملف لكن المتبقي ${remaining} فقط`);
      return res.status(403).json(error(
        `يمكنك رفع ${remaining} ملف فقط من ${fileCount} محاولة`, 
        'INSUFFICIENT_UPLOAD_QUOTA'
      ));
    }

    console.log(`✅ تحقق حدود الرفع: ${fileCount} ملف، متبقي ${remaining} من ${limit}`);
    next();
  } catch (err) {
    console.error('خطأ في فحص حدود الرفع:', err);
    return res.status(500).json(error('خطأ في فحص حدود الرفع', 'LIMIT_CHECK_ERROR'));
  }
}

/**
 * Get list of supported file types for client
 */
export function getSupportedFileTypes() {
  return {
    images: ['jpeg', 'jpg', 'png', 'gif', 'webp', 'svg', 'bmp', 'tiff'],
    documents: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx'],
    text: ['txt', 'csv', 'html', 'css', 'js', 'json', 'xml'],
    code: ['py', 'java', 'c', 'cpp', 'cs', 'php', 'sql'],
    archives: ['zip', 'rar', '7z', 'tar', 'gz'],
    audio: ['mp3', 'wav', 'ogg', 'm4a', 'flac'],
    video: ['mp4', 'mpeg', 'mov', 'avi', 'webm'],
    maxSize: '50 MB',
    maxFiles: 'حسب الخطة (5 مجاني، 100 احترافي)'
  };
}

/**
 * Security validation for file content
 */
export function validateFileContent(req: Request, res: Response, next: NextFunction) {
  try {
    const files = req.files as Express.Multer.File[];
    
    for (const file of files) {
      // Check for potential malicious file extensions in filename
      const dangerousExtensions = ['.exe', '.bat', '.cmd', '.scr', '.pif', '.com'];
      const filename = file.originalname.toLowerCase();
      
      if (dangerousExtensions.some(ext => filename.endsWith(ext))) {
        console.log(`🚨 ملف خطير محتمل: ${file.originalname}`);
        return res.status(400).json(error(
          `نوع الملف غير آمن: ${file.originalname}`, 
          'DANGEROUS_FILE_TYPE'
        ));
      }

      // Additional MIME type validation for security
      const fileExtension = filename.split('.').pop();
      if (fileExtension && !isValidMimeTypeForExtension(file.mimetype, fileExtension)) {
        console.log(`🚨 عدم تطابق نوع الملف: ${file.originalname}`);
        return res.status(400).json(error(
          `نوع الملف لا يتطابق مع الامتداد: ${file.originalname}`, 
          'MIME_TYPE_MISMATCH'
        ));
      }
    }

    next();
  } catch (err) {
    console.error('خطأ في التحقق من محتوى الملف:', err);
    return res.status(500).json(error('خطأ في التحقق من محتوى الملف', 'CONTENT_VALIDATION_ERROR'));
  }
}

/**
 * Validate MIME type matches file extension for security
 */
function isValidMimeTypeForExtension(mimeType: string, extension: string): boolean {
  const validMappings: Record<string, string[]> = {
    'jpg': ['image/jpeg'],
    'jpeg': ['image/jpeg'],
    'png': ['image/png'],
    'gif': ['image/gif'],
    'pdf': ['application/pdf'],
    'txt': ['text/plain'],
    'json': ['application/json'],
    'xml': ['application/xml', 'text/xml'],
    'zip': ['application/zip'],
    'mp3': ['audio/mpeg'],
    'mp4': ['video/mp4'],
    'doc': ['application/msword'],
    'docx': ['application/vnd.openxmlformats-officedocument.wordprocessingml.document']
  };

  const allowedMimeTypes = validMappings[extension.toLowerCase()];
  return allowedMimeTypes ? allowedMimeTypes.includes(mimeType) : true; // Allow unknown extensions
}