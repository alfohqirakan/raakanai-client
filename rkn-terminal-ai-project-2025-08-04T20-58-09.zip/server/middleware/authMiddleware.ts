import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

// Extend Request interface to include user
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        username: string;
        plan: string;
        role?: string;
        [key: string]: any;
      };
    }
  }
}

const JWT_SECRET = process.env.JWT_SECRET || 'rakan-ai-secret-key-2025';

export const authenticateJWT = (req: Request, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  
  if (authHeader) {
    const token = authHeader.split(' ')[1];
    
    jwt.verify(token, JWT_SECRET, (err, user) => {
      if (err) {
        return res.status(403).json({ error: 'رمز الدخول غير صالح' });
      }
      
      req.user = user;
      next();
    });
  } else {
    res.status(401).json({ error: 'مطلوب رمز دخول' });
  }
};

export const checkPermissions = (requiredRole: string) => {
  return (req: Request, res: Response, next: NextFunction) => {
    if (req.user && req.user.role && req.user.role === requiredRole) {
      next();
    } else {
      res.status(403).json({ error: 'غير مصرح' });
    }
  };
};

// Middleware للتحقق من الجلسة أو JWT
export const authenticateUser = (req: Request, res: Response, next: NextFunction) => {
  // التحقق من الجلسة أولاً (userId في الجلسة)
  if (req.session?.userId) {
    req.user = { 
      id: req.session.userId, 
      username: req.session.user?.username || '', 
      plan: req.session.user?.plan || 'free' 
    };
    return next();
  }
  
  // التحقق من JWT كبديل
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const token = authHeader.split(' ')[1];
    
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      req.user = decoded;
      return next();
    } catch (err) {
      return res.status(403).json({ error: 'رمز الدخول غير صالح' });
    }
  }
  
  return res.status(401).json({ error: 'غير مسجل الدخول' });
};