/**
 * @swagger
 * components:
 *   schemas:
 *     AIAgent:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           description: معرف الوكيل الفريد
 *         name:
 *           type: string
 *           description: اسم الوكيل بالإنجليزية
 *         nameAr:
 *           type: string
 *           description: اسم الوكيل بالعربية
 *         role:
 *           type: string
 *           description: دور الوكيل
 *         roleAr:
 *           type: string
 *           description: دور الوكيل بالعربية
 *         specialization:
 *           type: string
 *           enum: [security, development, analysis, optimization, testing]
 *           description: تخصص الوكيل
 *         capabilities:
 *           type: array
 *           items:
 *             type: string
 *           description: قدرات الوكيل
 *         tools:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/AITool'
 *         isActive:
 *           type: boolean
 *           description: هل الوكيل نشط
 *         version:
 *           type: string
 *           description: إصدار الوكيل
 *         metadata:
 *           type: object
 *           properties:
 *             created:
 *               type: string
 *               format: date
 *             lastUpdated:
 *               type: string
 *               format: date
 *             author:
 *               type: string
 *             tags:
 *               type: array
 *               items:
 *                 type: string
 *
 *     AITool:
 *       type: object
 *       properties:
 *         name:
 *           type: string
 *           description: اسم الأداة
 *         description:
 *           type: string
 *           description: وصف الأداة
 *         parameters:
 *           type: object
 *           description: معاملات الأداة
 *
 *     AgentExecution:
 *       type: object
 *       properties:
 *         agentId:
 *           type: string
 *           description: معرف الوكيل
 *         taskId:
 *           type: string
 *           description: معرف المهمة
 *         userId:
 *           type: integer
 *           description: معرف المستخدم
 *         input:
 *           type: object
 *           description: مدخل المهمة
 *         output:
 *           type: object
 *           description: مخرج المهمة
 *         status:
 *           type: string
 *           enum: [pending, running, completed, failed]
 *           description: حالة التنفيذ
 *         startTime:
 *           type: string
 *           format: date-time
 *           description: وقت البداية
 *         endTime:
 *           type: string
 *           format: date-time
 *           description: وقت الانتهاء
 *         duration:
 *           type: number
 *           description: مدة التنفيذ بالمللي ثانية
 *         toolsUsed:
 *           type: array
 *           items:
 *             type: string
 *           description: الأدوات المستخدمة
 *         error:
 *           type: string
 *           description: رسالة الخطأ إن وجدت
 *
 *     AgentStats:
 *       type: object
 *       properties:
 *         totalAgents:
 *           type: integer
 *           description: إجمالي الوكلاء
 *         activeAgents:
 *           type: integer
 *           description: الوكلاء النشطين
 *         totalTasks:
 *           type: integer
 *           description: إجمالي المهام
 *         completedTasks:
 *           type: integer
 *           description: المهام المكتملة
 *         failedTasks:
 *           type: integer
 *           description: المهام الفاشلة
 *         agentUsage:
 *           type: object
 *           description: إحصائيات استخدام الوكلاء
 *         averageExecutionTime:
 *           type: number
 *           description: متوسط وقت التنفيذ
 */

/**
 * @swagger
 * /api/agents:
 *   get:
 *     tags:
 *       - AI Agents
 *     summary: قائمة الوكلاء الذكيين
 *     description: الحصول على قائمة بجميع الوكلاء الذكيين المتاحين
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: active
 *         schema:
 *           type: boolean
 *         description: فلترة الوكلاء النشطين فقط
 *       - in: query
 *         name: specialization
 *         schema:
 *           type: string
 *           enum: [security, development, analysis, optimization, testing]
 *         description: فلترة حسب التخصص
 *     responses:
 *       200:
 *         description: قائمة الوكلاء الذكيين
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/AIAgent'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/agents/{agentId}:
 *   get:
 *     tags:
 *       - AI Agents
 *     summary: تفاصيل وكيل ذكي
 *     description: الحصول على تفاصيل وكيل ذكي محدد
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: agentId
 *         required: true
 *         schema:
 *           type: string
 *         description: معرف الوكيل
 *     responses:
 *       200:
 *         description: تفاصيل الوكيل
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/AIAgent'
 *       404:
 *         description: الوكيل غير موجود
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/agents/{agentId}/execute:
 *   post:
 *     tags:
 *       - AI Agents
 *     summary: تنفيذ وكيل ذكي
 *     description: تنفيذ مهمة باستخدام وكيل ذكي محدد
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: agentId
 *         required: true
 *         schema:
 *           type: string
 *         description: معرف الوكيل
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               input:
 *                 type: object
 *                 description: مدخل المهمة
 *                 example:
 *                   code: "function test() { return 'hello'; }"
 *                   tool: "code-scanner"
 *               context:
 *                 type: object
 *                 description: سياق إضافي (اختياري)
 *             required:
 *               - input
 *           examples:
 *             security-scan:
 *               summary: فحص أمني للشفرة
 *               value:
 *                 input:
 *                   code: "SELECT * FROM users WHERE id = $1"
 *                   tool: "code-scanner"
 *             code-optimization:
 *               summary: تحسين الشفرة
 *               value:
 *                 input:
 *                   code: "for(var i=0; i<arr.length; i++) { console.log(arr[i]); }"
 *                   tool: "code-optimizer"
 *     responses:
 *       200:
 *         description: نتيجة تنفيذ الوكيل
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/AgentExecution'
 *       400:
 *         description: خطأ في المدخلات
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         description: الوكيل غير موجود
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/agents/tasks:
 *   get:
 *     tags:
 *       - AI Agents
 *     summary: مهام المستخدم
 *     description: الحصول على قائمة مهام الوكلاء للمستخدم الحالي
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [pending, running, completed, failed]
 *         description: فلترة حسب الحالة
 *       - in: query
 *         name: agentId
 *         schema:
 *           type: string
 *         description: فلترة حسب الوكيل
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 50
 *         description: عدد النتائج
 *     responses:
 *       200:
 *         description: قائمة المهام
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/AgentExecution'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/agents/tasks/{taskId}:
 *   get:
 *     tags:
 *       - AI Agents
 *     summary: تفاصيل مهمة
 *     description: الحصول على تفاصيل مهمة محددة
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: taskId
 *         required: true
 *         schema:
 *           type: string
 *         description: معرف المهمة
 *     responses:
 *       200:
 *         description: تفاصيل المهمة
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/AgentExecution'
 *       404:
 *         description: المهمة غير موجودة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/agents/stats:
 *   get:
 *     tags:
 *       - AI Agents
 *     summary: إحصائيات الوكلاء
 *     description: الحصول على إحصائيات استخدام الوكلاء الذكيين
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: إحصائيات الوكلاء
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/AgentStats'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/agents/{agentId}/test:
 *   post:
 *     tags:
 *       - AI Agents
 *     summary: اختبار وكيل
 *     description: اختبار وكيل ذكي ببيانات تجريبية
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: agentId
 *         required: true
 *         schema:
 *           type: string
 *         description: معرف الوكيل
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               testInput:
 *                 type: object
 *                 description: بيانات الاختبار
 *                 example:
 *                   code: "console.log('test');"
 *                   tool: "code-scanner"
 *             required:
 *               - testInput
 *     responses:
 *       200:
 *         description: نتيجة الاختبار
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         success:
 *                           type: boolean
 *                         result:
 *                           type: object
 *                         message:
 *                           type: string
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       404:
 *         description: الوكيل غير موجود
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */