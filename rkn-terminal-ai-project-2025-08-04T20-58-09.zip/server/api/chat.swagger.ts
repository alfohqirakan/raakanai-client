/**
 * @swagger
 * components:
 *   schemas:
 *     ChatMessage:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *           description: معرف الرسالة الفريد
 *         fileId:
 *           type: integer
 *           description: معرف الملف المرتبط
 *         role:
 *           type: string
 *           enum: [user, assistant]
 *           description: دور مرسل الرسالة
 *         content:
 *           type: string
 *           description: محتوى الرسالة
 *         timestamp:
 *           type: string
 *           format: date-time
 *           description: وقت إرسال الرسالة
 *         metadata:
 *           type: object
 *           description: معلومات إضافية عن الرسالة
 *           properties:
 *             analysisType:
 *               type: string
 *               description: نوع التحليل المطلوب
 *             confidence:
 *               type: number
 *               description: مستوى الثقة في الاستجابة
 *             processingTime:
 *               type: integer
 *               description: وقت المعالجة بالميللي ثانية
 *       required: [id, fileId, role, content, timestamp]
 *     
 *     ChatRequest:
 *       type: object
 *       required:
 *         - fileId
 *         - message
 *       properties:
 *         fileId:
 *           type: integer
 *           description: معرف الملف للمحادثة حوله
 *         message:
 *           type: string
 *           minLength: 1
 *           maxLength: 2000
 *           description: رسالة المستخدم
 *           example: "ما هو الموضوع الرئيسي لهذا المستند؟"
 *         context:
 *           type: string
 *           description: سياق إضافي للمحادثة (اختياري)
 *         analysisType:
 *           type: string
 *           enum: [summary, detailed, creative, technical]
 *           default: detailed
 *           description: نوع التحليل المطلوب
 *     
 *     ChatHistory:
 *       type: object
 *       properties:
 *         fileId:
 *           type: integer
 *           description: معرف الملف
 *         fileName:
 *           type: string
 *           description: اسم الملف
 *         messages:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/ChatMessage'
 *           description: رسائل المحادثة
 *         totalMessages:
 *           type: integer
 *           description: العدد الإجمالي للرسائل
 *         lastActivity:
 *           type: string
 *           format: date-time
 *           description: آخر نشاط في المحادثة
 */

/**
 * @swagger
 * /api/chat/{fileId}/messages:
 *   get:
 *     tags:
 *       - Chat
 *     summary: الحصول على تاريخ المحادثة
 *     description: استرجاع جميع رسائل المحادثة المتعلقة بملف محدد
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: fileId
 *         required: true
 *         schema:
 *           type: integer
 *         description: معرف الملف
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: رقم الصفحة
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 50
 *         description: عدد الرسائل في الصفحة
 *     responses:
 *       200:
 *         description: تاريخ المحادثة
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         messages:
 *                           type: array
 *                           items:
 *                             $ref: '#/components/schemas/ChatMessage'
 *                         pagination:
 *                           type: object
 *                           properties:
 *                             page:
 *                               type: integer
 *                             limit:
 *                               type: integer
 *                             total:
 *                               type: integer
 *                             totalPages:
 *                               type: integer
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: ليس لديك صلاحية للوصول لهذا الملف
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         $ref: '#/components/responses/NotFoundError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 *   
 *   post:
 *     tags:
 *       - Chat
 *     summary: إرسال رسالة جديدة
 *     description: إرسال رسالة للذكاء الاصطناعي حول ملف محدد والحصول على استجابة
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: fileId
 *         required: true
 *         schema:
 *           type: integer
 *         description: معرف الملف
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - message
 *             properties:
 *               message:
 *                 type: string
 *                 minLength: 1
 *                 maxLength: 2000
 *                 description: رسالة المستخدم
 *                 example: "اشرح لي الفكرة الرئيسية في هذا المستند"
 *               context:
 *                 type: string
 *                 description: سياق إضافي (اختياري)
 *               analysisType:
 *                 type: string
 *                 enum: [summary, detailed, creative, technical]
 *                 default: detailed
 *                 description: نوع التحليل المطلوب
 *     responses:
 *       201:
 *         description: تم إرسال الرسالة واستلام الرد بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         userMessage:
 *                           $ref: '#/components/schemas/ChatMessage'
 *                         assistantMessage:
 *                           $ref: '#/components/schemas/ChatMessage'
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: ليس لديك صلاحية للوصول لهذا الملف
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         $ref: '#/components/responses/NotFoundError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/chat/conversations:
 *   get:
 *     tags:
 *       - Chat
 *     summary: الحصول على قائمة المحادثات
 *     description: استرجاع قائمة بجميع المحادثات النشطة للمستخدم
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: رقم الصفحة
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 50
 *           default: 20
 *         description: عدد المحادثات في الصفحة
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [lastActivity, fileName, messageCount]
 *           default: lastActivity
 *         description: ترتيب النتائج
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: اتجاه الترتيب
 *     responses:
 *       200:
 *         description: قائمة المحادثات
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         conversations:
 *                           type: array
 *                           items:
 *                             $ref: '#/components/schemas/ChatHistory'
 *                         pagination:
 *                           type: object
 *                           properties:
 *                             page:
 *                               type: integer
 *                             limit:
 *                               type: integer
 *                             total:
 *                               type: integer
 *                             totalPages:
 *                               type: integer
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/chat/{fileId}/clear:
 *   delete:
 *     tags:
 *       - Chat
 *     summary: مسح تاريخ المحادثة
 *     description: حذف جميع رسائل المحادثة المتعلقة بملف محدد
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: fileId
 *         required: true
 *         schema:
 *           type: integer
 *         description: معرف الملف
 *     responses:
 *       200:
 *         description: تم مسح تاريخ المحادثة بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: ليس لديك صلاحية لحذف هذه المحادثة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         $ref: '#/components/responses/NotFoundError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/chat/export/{fileId}:
 *   get:
 *     tags:
 *       - Chat
 *     summary: تصدير المحادثة
 *     description: تصدير تاريخ المحادثة بتنسيق JSON أو PDF
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: fileId
 *         required: true
 *         schema:
 *           type: integer
 *         description: معرف الملف
 *       - in: query
 *         name: format
 *         schema:
 *           type: string
 *           enum: [json, pdf, txt]
 *           default: json
 *         description: تنسيق التصدير
 *       - in: query
 *         name: includeMetadata
 *         schema:
 *           type: boolean
 *           default: true
 *         description: تضمين البيانات الوصفية
 *     responses:
 *       200:
 *         description: ملف المحادثة المصدرة
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               description: ملف JSON للمحادثة
 *           application/pdf:
 *             schema:
 *               type: string
 *               format: binary
 *               description: ملف PDF للمحادثة
 *           text/plain:
 *             schema:
 *               type: string
 *               description: ملف نصي للمحادثة
 *         headers:
 *           Content-Disposition:
 *             description: تحديد اسم الملف للتحميل
 *             schema:
 *               type: string
 *               example: 'attachment; filename="chat-export-filename.json"'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: ليس لديك صلاحية للوصول لهذا الملف
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         $ref: '#/components/responses/NotFoundError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */