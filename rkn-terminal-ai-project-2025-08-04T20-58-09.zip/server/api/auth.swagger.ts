/**
 * @swagger
 * components:
 *   schemas:
 *     LoginRequest:
 *       type: object
 *       required:
 *         - username
 *         - password
 *       properties:
 *         username:
 *           type: string
 *           minLength: 3
 *           maxLength: 50
 *           description: اسم المستخدم
 *           example: "ahmed_user"
 *         password:
 *           type: string
 *           minLength: 6
 *           description: كلمة المرور
 *           example: "password123"
 *     
 *     RegisterRequest:
 *       type: object
 *       required:
 *         - username
 *         - password
 *       properties:
 *         username:
 *           type: string
 *           minLength: 3
 *           maxLength: 50
 *           description: اسم المستخدم الفريد
 *           example: "new_user"
 *         password:
 *           type: string
 *           minLength: 6
 *           description: كلمة المرور (6 أحرف على الأقل)
 *           example: "securepass123"
 *
 *     UserSession:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *           description: معرف المستخدم
 *         username:
 *           type: string
 *           description: اسم المستخدم
 *         plan:
 *           type: string
 *           enum: [free, pro]
 *           description: نوع خطة المستخدم
 *         uploadsUsed:
 *           type: integer
 *           description: عدد الملفات المرفوعة هذا الشهر
 *         uploadLimit:
 *           type: integer
 *           description: الحد الأقصى للملفات الشهرية
 */

/**
 * @swagger
 * /api/auth/register:
 *   post:
 *     tags:
 *       - Authentication
 *     summary: تسجيل مستخدم جديد
 *     description: إنشاء حساب جديد في منصة RKN-Terminal AI
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/RegisterRequest'
 *     responses:
 *       201:
 *         description: تم إنشاء الحساب بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/UserSession'
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       409:
 *         description: اسم المستخدم موجود بالفعل
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/auth/login:
 *   post:
 *     tags:
 *       - Authentication
 *     summary: تسجيل الدخول
 *     description: تسجيل الدخول للحصول على جلسة مصادقة
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/LoginRequest'
 *     responses:
 *       200:
 *         description: تم تسجيل الدخول بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/UserSession'
 *         headers:
 *           Set-Cookie:
 *             schema:
 *               type: string
 *               example: connect.sid=s%3Asession_id; Path=/; HttpOnly
 *       401:
 *         description: بيانات دخول خاطئة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/auth/logout:
 *   post:
 *     tags:
 *       - Authentication
 *     summary: تسجيل الخروج
 *     description: إنهاء الجلسة الحالية وتسجيل الخروج
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: تم تسجيل الخروج بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/auth/me:
 *   get:
 *     tags:
 *       - Authentication
 *     summary: الحصول على معلومات المستخدم الحالي
 *     description: استرجاع معلومات المستخدم المسجل حالياً
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: معلومات المستخدم
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/UserSession'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */