import { Router } from "express";
import OpenAI from "openai";
import { success, error } from "../utils/apiResponse.js";

const router = Router();
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SUPPORTED_LANGUAGES = {
  "ar": "العربية",
  "en": "English", 
  "fr": "Français",
  "es": "Español",
  "de": "Deutsch",
  "ru": "Русский",
  "zh": "中文",
  "ja": "日本語",
  "ko": "한국어",
  "tr": "Türkçe",
  "pt": "Português",
  "hi": "हिन्दी",
  "it": "Italiano",
  "id": "Bahasa Indonesia",
  "fa": "فارسی"
};

// Test endpoint without rate limiting for demonstration
router.post("/test-speak", async (req, res) => {
  try {
    const { message, lang = "ar" } = req.body;
    
    if (!message?.trim()) {
      return res.status(400).json(error("يرجى توفير رسالة للرد عليها", "MISSING_MESSAGE"));
    }

    if (!SUPPORTED_LANGUAGES[lang as keyof typeof SUPPORTED_LANGUAGES]) {
      return res.status(400).json(error("اللغة المطلوبة غير مدعومة", "UNSUPPORTED_LANGUAGE"));
    }

    const languageName = SUPPORTED_LANGUAGES[lang as keyof typeof SUPPORTED_LANGUAGES];
    const systemPrompt = `أنت مساعد ذكي متعدد اللغات تابع لمنصة RKN-Terminal AI. 
    
قواعد مهمة:
- تحدث باللغة ${languageName} بطلاقة كاملة كناطق أصلي
- كن مفيداً ودقيقاً في إجاباتك
- احتفظ بشخصية مساعد ذكي محترف
- إذا كان السؤال تقنياً، قدم إجابة تقنية مفصلة
- إذا كان السؤال عاماً، كن ودوداً ومفيداً

معلومات عن النظام:
- اسم النظام: RKN-Terminal AI (راكان الذكاء السيادي) 
- المطور: المهندس راكان قاسم الفهيقي
- النسخة: 2025.1`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      temperature: 0.7,
      max_tokens: 1000
    });

    const reply = response.choices[0].message.content;
    
    res.json(success({
      reply,
      language: lang,
      languageName,
      originalMessage: message,
      testMode: true
    }, "تم الرد بنجاح (وضع الاختبار)"));

  } catch (err) {
    console.error("Test Multilingual AI error:", err);
    res.status(500).json(error("فشل في معالجة الطلب متعدد اللغات", "MULTILINGUAL_ERROR"));
  }
});

export default router;