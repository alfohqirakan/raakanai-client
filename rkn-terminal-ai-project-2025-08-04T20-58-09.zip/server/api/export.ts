import { Router } from 'express';
import archiver from 'archiver';
import fs from 'fs';
import path from 'path';
import { success, error } from '../utils/apiResponse.js';

const router = Router();

// Get project structure
router.get('/structure', async (req, res) => {
  try {
    const getDirectoryStructure = (dirPath: string, basePath = ''): any => {
      const items: any[] = [];
      const fullPath = path.join(process.cwd(), dirPath);
      
      if (!fs.existsSync(fullPath)) return items;
      
      const entries = fs.readdirSync(fullPath, { withFileTypes: true });
      
      for (const entry of entries) {
        // Skip hidden files, node_modules, and build files
        if (entry.name.startsWith('.') || 
            entry.name === 'node_modules' || 
            entry.name === 'dist' || 
            entry.name === 'build') {
          continue;
        }
        
        const relativePath = path.join(basePath, entry.name);
        
        if (entry.isDirectory()) {
          items.push({
            name: entry.name,
            type: 'directory',
            path: relativePath,
            children: getDirectoryStructure(path.join(dirPath, entry.name), relativePath)
          });
        } else {
          const stats = fs.statSync(path.join(fullPath, entry.name));
          items.push({
            name: entry.name,
            type: 'file',
            path: relativePath,
            size: stats.size,
            modified: stats.mtime.toISOString(),
            extension: path.extname(entry.name)
          });
        }
      }
      
      return items;
    };

    const structure = {
      name: 'rkn-terminal-ai',
      type: 'directory',
      children: [
        ...getDirectoryStructure('client'),
        ...getDirectoryStructure('server'),
        ...getDirectoryStructure('shared'),
        ...getDirectoryStructure('.', '').filter((item: any) => 
          item.type === 'file' && 
          !item.name.startsWith('.') && 
          item.name !== 'package-lock.json'
        )
      ]
    };

    return res.json(success('تم جلب هيكل المشروع بنجاح', structure));
  } catch (err) {
    console.error('Error getting project structure:', err);
    return res.status(500).json(error('فشل في جلب هيكل المشروع'));
  }
});

// Download project as ZIP
router.get('/download', async (req, res) => {
  try {
    const projectName = 'rkn-terminal-ai-project';
    const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
    const filename = `${projectName}-${timestamp}.zip`;
    
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    
    const archive = archiver('zip', {
      zlib: { level: 9 } // Maximum compression
    });
    
    archive.on('error', (err: any) => {
      console.error('Archive error:', err);
      res.status(500).end();
    });
    
    archive.pipe(res);
    
    // Add client files
    if (fs.existsSync('client')) {
      archive.directory('client/', 'client/');
    }
    
    // Add server files
    if (fs.existsSync('server')) {
      archive.directory('server/', 'server/');
    }
    
    // Add shared files
    if (fs.existsSync('shared')) {
      archive.directory('shared/', 'shared/');
    }
    
    // Add root configuration files
    const rootFiles = [
      'package.json',
      'tsconfig.json',
      'vite.config.ts',
      'tailwind.config.ts',
      'postcss.config.js',
      'components.json',
      'drizzle.config.ts',
      'replit.md',
      'README.md'
    ];
    
    for (const file of rootFiles) {
      if (fs.existsSync(file)) {
        archive.file(file, { name: file });
      }
    }
    
    // Add project metadata
    const metadata = {
      projectName: 'RKN-Terminal AI',
      description: 'Advanced Arabic-first AI platform with autonomous capabilities',
      version: '2.0.0',
      exportDate: new Date().toISOString(),
      architecture: {
        frontend: 'React + TypeScript + Vite',
        backend: 'Node.js + Express + TypeScript',
        database: 'PostgreSQL + Drizzle ORM',
        ai: 'OpenAI GPT-4o',
        styling: 'Tailwind CSS + shadcn/ui'
      },
      features: [
        'Arabic-first interface with RTL support',
        'Advanced AI creative hub',
        'Engineering command center',
        'Code playground with AI assistance',
        'Multilingual communication (15 languages)',
        'Self-evolving AI system',
        'Professional falcon theme design'
      ]
    };
    
    archive.append(JSON.stringify(metadata, null, 2), { name: 'project-metadata.json' });
    
    archive.finalize();
    
  } catch (err) {
    console.error('Export error:', err);
    return res.status(500).json(error('فشل في تصدير المشروع'));
  }
});

export default router;