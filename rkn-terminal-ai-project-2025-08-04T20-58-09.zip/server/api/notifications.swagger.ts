/**
 * @swagger
 * components:
 *   schemas:
 *     NotificationTemplate:
 *       type: object
 *       properties:
 *         subject:
 *           type: string
 *           description: قالب عنوان الإشعار
 *         text:
 *           type: string
 *           description: قالب نص الإشعار
 *         websocketEvent:
 *           type: string
 *           description: حدث WebSocket المرتبط
 *         priority:
 *           type: string
 *           enum: [low, normal, high, urgent]
 *           description: أولوية الإشعار
 *
 *     NotificationContext:
 *       type: object
 *       properties:
 *         fileName:
 *           type: string
 *           description: اسم الملف
 *         fileUrl:
 *           type: string
 *           description: رابط الملف
 *         fileId:
 *           type: string
 *           description: معرف الملف
 *         summary:
 *           type: string
 *           description: ملخص التحليل
 *         messagePreview:
 *           type: string
 *           description: معاينة الرسالة
 *         senderName:
 *           type: string
 *           description: اسم المرسل
 *         progress:
 *           type: number
 *           description: نسبة التقدم
 *         stage:
 *           type: string
 *           description: مرحلة المعالجة
 *
 *     NotificationOptions:
 *       type: object
 *       properties:
 *         sendEmail:
 *           type: boolean
 *           description: إرسال إشعار بريد إلكتروني
 *         sendWebSocket:
 *           type: boolean
 *           description: إرسال إشعار WebSocket
 *         sendBrowser:
 *           type: boolean
 *           description: إرسال إشعار المتصفح
 *
 *     NotificationResult:
 *       type: object
 *       properties:
 *         email:
 *           type: boolean
 *           description: حالة إرسال البريد الإلكتروني
 *         websocket:
 *           type: boolean
 *           description: حالة إرسال WebSocket
 *         browser:
 *           type: boolean
 *           description: حالة إرسال المتصفح
 *
 *     EmailStatus:
 *       type: object
 *       properties:
 *         isConfigured:
 *           type: boolean
 *           description: هل تم تكوين خدمة البريد
 *         transporter:
 *           type: boolean
 *           description: حالة ناقل البريد
 *         configuration:
 *           type: object
 *           properties:
 *             host:
 *               type: string
 *               description: خادم SMTP
 *             port:
 *               type: number
 *               description: منفذ SMTP
 *             secure:
 *               type: boolean
 *               description: اتصال آمن
 */

/**
 * @swagger
 * /api/notifications/send:
 *   post:
 *     tags:
 *       - Notifications
 *     summary: إرسال إشعار
 *     description: إرسال إشعار للمستخدم باستخدام قالب محدد
 *     security:
 *       - SessionAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - type
 *             properties:
 *               type:
 *                 type: string
 *                 description: نوع الإشعار (اسم القالب)
 *                 enum: [analysisComplete, analysisStarted, analysisProgress, analysisError, newMessage, welcomeMessage, systemMaintenance, uploadLimitReached]
 *                 example: "analysisComplete"
 *               targetUserId:
 *                 type: integer
 *                 description: معرف المستخدم المستهدف (اختياري - افتراضياً المستخدم الحالي)
 *               context:
 *                 $ref: '#/components/schemas/NotificationContext'
 *               options:
 *                 $ref: '#/components/schemas/NotificationOptions'
 *     responses:
 *       200:
 *         description: تم إرسال الإشعار بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/NotificationResult'
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       404:
 *         description: المستخدم المستهدف غير موجود
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/notifications/templates:
 *   get:
 *     tags:
 *       - Notifications
 *     summary: قوالب الإشعارات
 *     description: الحصول على قائمة بجميع قوالب الإشعارات المتاحة
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: قائمة قوالب الإشعارات
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           name:
 *                             type: string
 *                             description: اسم القالب
 *                           info:
 *                             $ref: '#/components/schemas/NotificationTemplate'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/notifications/history:
 *   get:
 *     tags:
 *       - Notifications
 *     summary: تاريخ الإشعارات
 *     description: الحصول على تاريخ الإشعارات للمستخدم الحالي
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 50
 *           minimum: 1
 *           maximum: 100
 *         description: عدد الإشعارات المطلوب جلبها
 *     responses:
 *       200:
 *         description: تاريخ الإشعارات
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           id:
 *                             type: string
 *                             description: معرف الإشعار
 *                           type:
 *                             type: string
 *                             description: نوع الإشعار
 *                           title:
 *                             type: string
 *                             description: عنوان الإشعار
 *                           message:
 *                             type: string
 *                             description: محتوى الإشعار
 *                           read:
 *                             type: boolean
 *                             description: هل تم قراءة الإشعار
 *                           timestamp:
 *                             type: string
 *                             format: date-time
 *                             description: وقت الإشعار
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/notifications/{id}/read:
 *   post:
 *     tags:
 *       - Notifications
 *     summary: تحديد إشعار كمقروء
 *     description: تحديد إشعار معين كمقروء للمستخدم الحالي
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: معرف الإشعار
 *     responses:
 *       200:
 *         description: تم تحديث حالة الإشعار بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       404:
 *         description: الإشعار غير موجود
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/email/status:
 *   get:
 *     tags:
 *       - Email
 *     summary: حالة خدمة البريد الإلكتروني
 *     description: فحص حالة وتكوين خدمة البريد الإلكتروني
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: حالة خدمة البريد الإلكتروني
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/EmailStatus'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */