import { Router } from "express";
import OpenAI from "openai";
import { authenticateUser } from "../middleware/authMiddleware.js";
import { success, error } from "../utils/apiResponse.js";

const router = Router();
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Generate code using AI
router.post("/generate-code", authenticateUser, async (req, res) => {
  try {
    const { prompt, language } = req.body;
    
    if (!prompt || !language) {
      return res.status(400).json(error("يرجى توفير الوصف ولغة البرمجة", "MISSING_PARAMS"));
    }

    const systemPrompt = `أنت مساعد برمجة ذكي متخصص في كتابة الأكواد باللغة العربية. قم بكتابة كود ${language} نظيف ومفهوم مع التعليقات باللغة العربية.

قواعد مهمة:
- اكتب كود عملي وقابل للتنفيذ
- أضف تعليقات توضيحية باللغة العربية
- استخدم أسماء متغيرات واضحة
- تأكد من أن الكود آمن وخالي من الثغرات
- اكتب مثال للاستخدام إذا كان ذلك مناسباً`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `اكتب كود ${language} لـ: ${prompt}` }
      ],
      max_tokens: 2000,
      temperature: 0.7
    });

    const generatedCode = response.choices[0].message.content;
    
    res.json(success({
      generatedCode,
      language,
      prompt
    }, "تم توليد الكود بنجاح"));

  } catch (err) {
    console.error("Code generation error:", err);
    res.status(500).json(error("فشل في توليد الكود", "GENERATION_ERROR"));
  }
});

// Execute code (simulation)
router.post("/execute-code", authenticateUser, async (req, res) => {
  try {
    const { code, language } = req.body;
    
    if (!code || !language) {
      return res.status(400).json(error("يرجى توفير الكود ولغة البرمجة", "MISSING_PARAMS"));
    }

    // For security reasons, we'll simulate code execution using AI analysis
    const systemPrompt = `أنت محاكي تنفيذ الأكواد. قم بتحليل الكود وتوقع النتيجة المحتملة للتنفيذ.

قواعد:
- لا تنفذ الكود فعلياً لأسباب أمنية
- قدم توقع واقعي للمخرجات
- أذكر أي أخطاء محتملة
- اكتب النتيجة بشكل واضح ومفهوم`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `قم بتحليل وتوقع نتيجة تنفيذ هذا الكود ${language}:\n\n${code}` }
      ],
      max_tokens: 1000,
      temperature: 0.3
    });

    const output = response.choices[0].message.content;
    
    res.json(success({
      output,
      language,
      executionNote: "هذه محاكاة للتنفيذ لأسباب أمنية"
    }, "تم تحليل الكود بنجاح"));

  } catch (err) {
    console.error("Code execution error:", err);
    res.status(500).json(error("فشل في تنفيذ الكود", "EXECUTION_ERROR"));
  }
});

// Evaluate code quality and provide suggestions
router.post("/evaluate-code", authenticateUser, async (req, res) => {
  try {
    const { code } = req.body;
    
    if (!code) {
      return res.status(400).json(error("يرجى توفير الكود للتقييم", "MISSING_CODE"));
    }

    const systemPrompt = `أنت خبير مراجعة الأكواد. قم بتقييم الكود المرسل وقدم تحليلاً شاملاً يشمل:

1. **جودة الكود**: نظافة وتنظيم الكود
2. **الأداء**: كفاءة التنفيذ والذاكرة  
3. **الأمان**: الثغرات المحتملة
4. **القابلية للقراءة**: وضوح المتغيرات والدوال
5. **التحسينات المقترحة**: اقتراحات للتحسين

اكتب التقييم باللغة العربية مع أمثلة عملية.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `قم بتقييم هذا الكود:\n\n${code}` }
      ],
      max_tokens: 1500,
      temperature: 0.5
    });

    const evaluation = response.choices[0].message.content;
    
    res.json(success({
      evaluation,
      timestamp: new Date().toISOString()
    }, "تم تقييم الكود بنجاح"));

  } catch (err) {
    console.error("Code evaluation error:", err);
    res.status(500).json(error("فشل في تقييم الكود", "EVALUATION_ERROR"));
  }
});

export default router;