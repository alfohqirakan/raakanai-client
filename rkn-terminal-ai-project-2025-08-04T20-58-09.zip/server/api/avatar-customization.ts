import { Router } from 'express';
import { z } from 'zod';

const router = Router();

// Avatar customization schemas
const avatarAppearanceSchema = z.object({
  gender: z.enum(['male', 'female', 'neutral']),
  ethnicity: z.enum(['arab', 'asian', 'african', 'european', 'mixed', 'custom']),
  age: z.enum(['young', 'adult', 'elder']),
  hairStyle: z.enum(['short', 'long', 'curly', 'straight', 'traditional', 'modern']),
  hairColor: z.enum(['black', 'brown', 'blonde', 'gray', 'white', 'custom']),
  eyeColor: z.enum(['brown', 'blue', 'green', 'hazel', 'gray', 'amber']),
  skinTone: z.enum(['light', 'medium', 'olive', 'tan', 'dark']),
  clothing: z.enum(['traditional', 'business', 'casual', 'formal', 'cultural']),
  accessories: z.array(z.enum(['glasses', 'hijab', 'beard', 'mustache', 'jewelry', 'hat']))
});

const avatarPersonalitySchema = z.object({
  traits: z.array(z.enum(['friendly', 'professional', 'wise', 'energetic', 'calm', 'humorous', 'serious', 'empathetic', 'respectful'])),
  communicationStyle: z.enum(['formal', 'casual', 'respectful', 'direct', 'gentle']),
  culturalBackground: z.enum(['saudi', 'gulf', 'arab', 'international', 'mixed']),
  expertise: z.array(z.enum(['technology', 'business', 'culture', 'education', 'healthcare', 'arts', 'science'])),
  languages: z.array(z.enum(['arabic', 'english', 'french', 'spanish', 'urdu', 'hindi'])),
  responseLength: z.enum(['brief', 'moderate', 'detailed']),
  formality: z.number().min(0).max(1),
  enthusiasm: z.number().min(0).max(1)
});

const avatarBehaviorSchema = z.object({
  greetingStyle: z.enum(['warm', 'professional', 'traditional', 'modern']),
  helpStyle: z.enum(['proactive', 'reactive', 'guidance', 'direct']),
  learningStyle: z.enum(['adaptive', 'consistent', 'progressive']),
  memoryLevel: z.enum(['session', 'short_term', 'long_term']),
  contextAwareness: z.number().min(0).max(1),
  culturalSensitivity: z.number().min(0).max(1),
  proactiveness: z.number().min(0).max(1)
});

const avatarCustomizationSchema = z.object({
  name: z.string().min(1).max(50),
  appearance: avatarAppearanceSchema,
  personality: avatarPersonalitySchema,
  behavior: avatarBehaviorSchema,
  voiceSettings: z.object({
    tone: z.enum(['warm', 'professional', 'friendly', 'authoritative']),
    speed: z.enum(['slow', 'normal', 'fast']),
    pitch: z.enum(['low', 'normal', 'high']),
    accent: z.enum(['saudi', 'gulf', 'levantine', 'egyptian', 'international'])
  }).optional()
});

// Get available customization options
router.get('/options', (req, res) => {
  const customizationOptions = {
    appearance: {
      gender: ['male', 'female', 'neutral'],
      ethnicity: ['arab', 'asian', 'african', 'european', 'mixed', 'custom'],
      age: ['young', 'adult', 'elder'],
      hairStyles: ['short', 'long', 'curly', 'straight', 'traditional', 'modern'],
      hairColors: ['black', 'brown', 'blonde', 'gray', 'white', 'custom'],
      eyeColors: ['brown', 'blue', 'green', 'hazel', 'gray', 'amber'],
      skinTones: ['light', 'medium', 'olive', 'tan', 'dark'],
      clothing: ['traditional', 'business', 'casual', 'formal', 'cultural'],
      accessories: ['glasses', 'hijab', 'beard', 'mustache', 'jewelry', 'hat']
    },
    personality: {
      traits: ['friendly', 'professional', 'wise', 'energetic', 'calm', 'humorous', 'serious', 'empathetic', 'respectful'],
      communicationStyles: ['formal', 'casual', 'respectful', 'direct', 'gentle'],
      culturalBackgrounds: ['saudi', 'gulf', 'arab', 'international', 'mixed'],
      expertise: ['technology', 'business', 'culture', 'education', 'healthcare', 'arts', 'science'],
      languages: ['arabic', 'english', 'french', 'spanish', 'urdu', 'hindi'],
      responseLengths: ['brief', 'moderate', 'detailed']
    },
    behavior: {
      greetingStyles: ['warm', 'professional', 'traditional', 'modern'],
      helpStyles: ['proactive', 'reactive', 'guidance', 'direct'],
      learningStyles: ['adaptive', 'consistent', 'progressive'],
      memoryLevels: ['session', 'short_term', 'long_term']
    },
    voice: {
      tones: ['warm', 'professional', 'friendly', 'authoritative'],
      speeds: ['slow', 'normal', 'fast'],
      pitches: ['low', 'normal', 'high'],
      accents: ['saudi', 'gulf', 'levantine', 'egyptian', 'international']
    }
  };

  res.json({
    status: '🎨 خيارات تخصيص الصورة الرمزية متاحة',
    customization_options: customizationOptions,
    timestamp: new Date().toISOString()
  });
});

// Get default avatar templates
router.get('/templates', (req, res) => {
  const avatarTemplates = [
    {
      id: 'saudi_professional',
      name: 'المحترف السعودي',
      description: 'صورة رمزية احترافية تمثل الثقافة السعودية',
      appearance: {
        gender: 'male',
        ethnicity: 'arab',
        age: 'adult',
        hairStyle: 'short',
        hairColor: 'black',
        eyeColor: 'brown',
        skinTone: 'olive',
        clothing: 'business',
        accessories: []
      },
      personality: {
        traits: ['professional', 'wise', 'respectful'],
        communicationStyle: 'formal',
        culturalBackground: 'saudi',
        expertise: ['business', 'technology'],
        languages: ['arabic', 'english'],
        responseLength: 'detailed',
        formality: 0.8,
        enthusiasm: 0.6
      }
    },
    {
      id: 'gulf_advisor',
      name: 'المستشار الخليجي',
      description: 'مستشار حكيم من منطقة الخليج',
      appearance: {
        gender: 'male',
        ethnicity: 'arab',
        age: 'elder',
        hairStyle: 'traditional',
        hairColor: 'gray',
        eyeColor: 'brown',
        skinTone: 'tan',
        clothing: 'traditional',
        accessories: ['beard']
      },
      personality: {
        traits: ['wise', 'calm', 'empathetic'],
        communicationStyle: 'respectful',
        culturalBackground: 'gulf',
        expertise: ['culture', 'education'],
        languages: ['arabic', 'english'],
        responseLength: 'moderate',
        formality: 0.9,
        enthusiasm: 0.4
      }
    },
    {
      id: 'modern_assistant',
      name: 'المساعد العصري',
      description: 'مساعد ذكي عصري ومتطور',
      appearance: {
        gender: 'female',
        ethnicity: 'arab',
        age: 'young',
        hairStyle: 'modern',
        hairColor: 'brown',
        eyeColor: 'hazel',
        skinTone: 'medium',
        clothing: 'casual',
        accessories: ['glasses']
      },
      personality: {
        traits: ['friendly', 'energetic', 'helpful'],
        communicationStyle: 'casual',
        culturalBackground: 'mixed',
        expertise: ['technology', 'arts'],
        languages: ['arabic', 'english', 'french'],
        responseLength: 'brief',
        formality: 0.3,
        enthusiasm: 0.9
      }
    }
  ];

  res.json({
    status: '📋 قوالب الصورة الرمزية جاهزة',
    avatar_templates: avatarTemplates,
    total_templates: avatarTemplates.length,
    timestamp: new Date().toISOString()
  });
});

// Create custom avatar
router.post('/create', async (req, res) => {
  try {
    const validatedData = avatarCustomizationSchema.parse(req.body);
    
    // Generate avatar ID
    const avatarId = `avatar_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    // Create avatar configuration
    const avatarConfig = {
      id: avatarId,
      ...validatedData,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      user_id: req.session?.userId || 'anonymous',
      status: 'active'
    };

    // Generate visual representation
    const visualDescription = generateAvatarDescription(avatarConfig);
    
    // Generate personality summary
    const personalitySummary = generatePersonalitySummary(avatarConfig);

    res.json({
      status: '🎨 تم إنشاء الصورة الرمزية بنجاح',
      avatar: {
        ...avatarConfig,
        visual_description: visualDescription,
        personality_summary: personalitySummary
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Avatar creation error:', error);
    if (error instanceof z.ZodError) {
      res.status(400).json({
        status: '❌ خطأ في بيانات التخصيص',
        validation_errors: error.errors,
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({
        status: '❌ خطأ في إنشاء الصورة الرمزية',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  }
});

// Generate avatar from template
router.post('/from-template/:templateId', async (req, res) => {
  try {
    const { templateId } = req.params;
    const { name, customizations } = req.body;

    // Get template (in real app, this would come from database)
    const templates = await getAvatarTemplates();
    const template = templates.find(t => t.id === templateId);

    if (!template) {
      return res.status(404).json({
        status: '❌ القالب غير موجود',
        template_id: templateId,
        timestamp: new Date().toISOString()
      });
    }

    // Apply customizations to template
    const customizedAvatar = {
      ...template,
      name: name || template.name,
      ...customizations,
      id: `avatar_${Date.now()}_${templateId}`,
      created_at: new Date().toISOString(),
      user_id: req.session?.userId || 'anonymous'
    };

    const visualDescription = generateAvatarDescription(customizedAvatar);
    const personalitySummary = generatePersonalitySummary(customizedAvatar);

    res.json({
      status: '🎨 تم إنشاء الصورة الرمزية من القالب',
      avatar: {
        ...customizedAvatar,
        visual_description: visualDescription,
        personality_summary: personalitySummary
      },
      base_template: templateId,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Template avatar creation error:', error);
    res.status(500).json({
      status: '❌ خطأ في إنشاء الصورة الرمزية من القالب',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// Preview avatar configuration
router.post('/preview', async (req, res) => {
  try {
    const previewData = req.body;
    
    // Generate preview without validation
    const visualDescription = generateAvatarDescription(previewData);
    const personalitySummary = generatePersonalitySummary(previewData);
    const sampleResponses = generateSampleResponses(previewData);

    res.json({
      status: '👁️ معاينة الصورة الرمزية',
      preview: {
        visual_description: visualDescription,
        personality_summary: personalitySummary,
        sample_responses: sampleResponses,
        compatibility_score: calculateCompatibilityScore(previewData)
      },
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Avatar preview error:', error);
    res.status(500).json({
      status: '❌ خطأ في معاينة الصورة الرمزية',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// Helper functions
function generateAvatarDescription(avatar: any): string {
  const { appearance } = avatar;
  if (!appearance) return 'مظهر غير محدد';
  
  const age = appearance.age === 'young' ? 'شاب' : appearance.age === 'elder' ? 'كبير السن' : 'متوسط العمر';
  const gender = appearance.gender === 'male' ? 'ذكر' : appearance.gender === 'female' ? 'أنثى' : 'محايد';
  const ethnicity = appearance.ethnicity === 'arab' ? 'عربي' : appearance.ethnicity || 'غير محدد';
  const hairColor = appearance.hairColor || 'غير محدد';
  const hairStyle = appearance.hairStyle || 'غير محدد';
  const eyeColor = appearance.eyeColor || 'غير محدد';
  const skinTone = appearance.skinTone || 'غير محدد';
  const clothing = appearance.clothing === 'traditional' ? 'ملابس تقليدية' : appearance.clothing === 'business' ? 'ملابس عمل' : 'ملابس عادية';
  
  return `شخص ${age} ${gender} من أصل ${ethnicity} بشعر ${hairColor} ${hairStyle} وعيون ${eyeColor} وبشرة ${skinTone}. يرتدي ${clothing}.`;
}

function generatePersonalitySummary(avatar: any): string {
  const { personality } = avatar;
  if (!personality) return 'شخصية غير محددة';
  
  const traits = personality.traits?.join(' و') || 'غير محدد';
  const communicationStyle = personality.communicationStyle || 'غير محدد';
  const expertise = personality.expertise?.join(' و') || 'غير محدد';
  const culturalBackground = personality.culturalBackground || 'غير محدد';
  const languages = personality.languages?.join(' و') || 'غير محدد';
  
  return `شخصية ${traits} تتواصل بأسلوب ${communicationStyle} وتتخصص في ${expertise}. خلفية ثقافية ${culturalBackground} ويتحدث ${languages}.`;
}

function generateSampleResponses(avatar: any): string[] {
  const style = avatar.personality?.communicationStyle || 'respectful';
  const formality = avatar.personality?.formality || 0.5;
  
  const responses = [];
  
  if (formality > 0.7) {
    responses.push('أهلاً وسهلاً بك، كيف يمكنني مساعدتك اليوم؟');
    responses.push('سأكون سعيداً لتقديم المساعدة في أي استفسار لديك.');
  } else if (formality > 0.3) {
    responses.push('مرحباً! كيف حالك؟ كيف يمكنني مساعدتك؟');
    responses.push('أهلاً بك! أنا هنا للمساعدة.');
  } else {
    responses.push('أهلاً! وش أخبارك؟ كيف أقدر أساعدك؟');
    responses.push('مرحبا! قل لي وش تحتاج وأنا موجود.');
  }
  
  return responses;
}

function calculateCompatibilityScore(avatar: any): number {
  // Simple compatibility calculation based on cultural alignment and personality balance
  let score = 0.5;
  
  if (avatar.personality?.culturalBackground === 'saudi' || avatar.personality?.culturalBackground === 'gulf') {
    score += 0.2;
  }
  
  if (avatar.personality?.traits?.includes('professional') && avatar.personality?.traits?.includes('respectful')) {
    score += 0.2;
  }
  
  if (avatar.personality?.languages?.includes('arabic')) {
    score += 0.1;
  }
  
  return Math.min(score, 1.0);
}

async function getAvatarTemplates() {
  // In a real application, this would fetch from database
  return [
    {
      id: 'saudi_professional',
      name: 'المحترف السعودي',
      appearance: { gender: 'male', ethnicity: 'arab', age: 'adult' },
      personality: { traits: ['professional', 'wise'], culturalBackground: 'saudi' }
    }
  ];
}

export default router;