/**
 * @swagger
 * components:
 *   schemas:
 *     FileUploadResponse:
 *       type: object
 *       properties:
 *         file:
 *           $ref: '#/components/schemas/FileInfo'
 *         analysis:
 *           type: object
 *           description: نتائج التحليل الأولي للملف
 *           properties:
 *             summary:
 *               type: string
 *               description: ملخص المحتوى
 *             keyPoints:
 *               type: array
 *               items:
 *                 type: string
 *               description: النقاط الرئيسية
 *             categories:
 *               type: array
 *               items:
 *                 type: string
 *               description: التصنيفات
 *             sentiment:
 *               type: number
 *               minimum: -1
 *               maximum: 1
 *               description: التحليل العاطفي
 *             confidence:
 *               type: number
 *               minimum: 0
 *               maximum: 1
 *               description: مستوى الثقة في التحليل
 *     
 *     ChunkedUploadInfo:
 *       type: object
 *       properties:
 *         uploadId:
 *           type: string
 *           description: معرف الرفع المتقطع
 *         fileName:
 *           type: string
 *           description: اسم الملف
 *         totalSize:
 *           type: integer
 *           description: الحجم الإجمالي بالبايت
 *         chunkSize:
 *           type: integer
 *           description: حجم القطعة الواحدة
 *         totalChunks:
 *           type: integer
 *           description: العدد الإجمالي للقطع
 *         uploadedChunks:
 *           type: array
 *           items:
 *             type: integer
 *           description: القطع المرفوعة بالفعل
 *         status:
 *           type: string
 *           enum: [pending, uploading, processing, completed, error]
 *           description: حالة الرفع
 *         expiresAt:
 *           type: string
 *           format: date-time
 *           description: وقت انتهاء صلاحية الرفع
 *     
 *     FileStats:
 *       type: object
 *       properties:
 *         totalFiles:
 *           type: integer
 *           description: العدد الإجمالي للملفات
 *         analyzedFiles:
 *           type: integer
 *           description: عدد الملفات المحللة
 *         processingFiles:
 *           type: integer
 *           description: عدد الملفات قيد المعالجة
 *         fileTypes:
 *           type: object
 *           additionalProperties:
 *             type: integer
 *           description: توزيع أنواع الملفات
 *           example:
 *             "application/pdf": 15
 *             "image/jpeg": 8
 *             "text/plain": 5
 *         todayOperations:
 *           type: integer
 *           description: عمليات اليوم
 */

/**
 * @swagger
 * /api/files/upload:
 *   post:
 *     tags:
 *       - Files
 *     summary: رفع ملف للتحليل
 *     description: رفع ملف واحد للمعالجة والتحليل بواسطة RKN-Terminal AI
 *     security:
 *       - SessionAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - file
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *                 description: الملف المراد رفعه ومعالجته
 *           encoding:
 *             file:
 *               contentType: application/octet-stream
 *     responses:
 *       201:
 *         description: تم رفع الملف بنجاح وبدء التحليل
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/FileUploadResponse'
 *       400:
 *         description: لم يتم رفع ملف أو تنسيق غير مدعوم
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: تجاوز حد الملفات المسموحة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       413:
 *         description: حجم الملف كبير جداً
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/files:
 *   get:
 *     tags:
 *       - Files
 *     summary: الحصول على قائمة الملفات
 *     description: استرجاع قائمة بملفات المستخدم مع خيارات التصفية والترتيب
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: رقم الصفحة
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *         description: عدد العناصر في الصفحة
 *       - in: query
 *         name: status
 *         schema:
 *           type: string
 *           enum: [uploaded, processing, analyzed, error]
 *         description: تصفية حسب حالة الملف
 *       - in: query
 *         name: mimeType
 *         schema:
 *           type: string
 *         description: تصفية حسب نوع الملف
 *         example: "image/"
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [uploadedAt, size, filename]
 *           default: uploadedAt
 *         description: ترتيب النتائج
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: اتجاه الترتيب
 *     responses:
 *       200:
 *         description: قائمة الملفات
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         files:
 *                           type: array
 *                           items:
 *                             $ref: '#/components/schemas/FileInfo'
 *                         pagination:
 *                           type: object
 *                           properties:
 *                             page:
 *                               type: integer
 *                             limit:
 *                               type: integer
 *                             total:
 *                               type: integer
 *                             totalPages:
 *                               type: integer
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/files/{fileId}:
 *   get:
 *     tags:
 *       - Files
 *     summary: الحصول على تفاصيل ملف
 *     description: استرجاع معلومات مفصلة عن ملف محدد مع نتائج التحليل
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: fileId
 *         required: true
 *         schema:
 *           type: integer
 *         description: معرف الملف
 *     responses:
 *       200:
 *         description: تفاصيل الملف
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/FileInfo'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: ليس لديك صلاحية للوصول لهذا الملف
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         $ref: '#/components/responses/NotFoundError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 *   
 *   delete:
 *     tags:
 *       - Files
 *     summary: حذف ملف
 *     description: حذف ملف نهائياً مع جميع بياناته المرتبطة
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: fileId
 *         required: true
 *         schema:
 *           type: integer
 *         description: معرف الملف
 *     responses:
 *       200:
 *         description: تم حذف الملف بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/ApiResponse'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: ليس لديك صلاحية لحذف هذا الملف
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       404:
 *         $ref: '#/components/responses/NotFoundError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/files/chunked/init:
 *   post:
 *     tags:
 *       - Files
 *     summary: بدء رفع متقطع للملفات الكبيرة
 *     description: تهيئة عملية رفع متقطع لملف كبير (أكثر من 5MB)
 *     security:
 *       - SessionAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - fileName
 *               - fileSize
 *               - mimeType
 *             properties:
 *               fileName:
 *                 type: string
 *                 description: اسم الملف
 *                 example: "large_document.pdf"
 *               fileSize:
 *                 type: integer
 *                 minimum: 1
 *                 description: حجم الملف بالبايت
 *                 example: 52428800
 *               mimeType:
 *                 type: string
 *                 description: نوع MIME للملف
 *                 example: "application/pdf"
 *               chunkSize:
 *                 type: integer
 *                 minimum: 1048576
 *                 maximum: 10485760
 *                 default: 5242880
 *                 description: حجم القطعة الواحدة (1MB - 10MB)
 *     responses:
 *       201:
 *         description: تم تهيئة الرفع المتقطع بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/ChunkedUploadInfo'
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       413:
 *         description: حجم الملف يتجاوز الحد المسموح
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/files/stats:
 *   get:
 *     tags:
 *       - Files
 *     summary: إحصائيات الملفات
 *     description: الحصول على إحصائيات شاملة عن ملفات المستخدم
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: إحصائيات الملفات
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/FileStats'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */