/**
 * @swagger
 * components:
 *   schemas:
 *     VisionAnalysisResponse:
 *       type: object
 *       properties:
 *         fileName:
 *           type: string
 *           description: اسم الملف المحلل
 *         analysis:
 *           $ref: '#/components/schemas/VisionAnalysis'
 *         processingInfo:
 *           type: object
 *           properties:
 *             userId:
 *               type: integer
 *               description: معرف المستخدم
 *             timestamp:
 *               type: string
 *               format: date-time
 *               description: وقت المعالجة
 *             service:
 *               type: string
 *               description: اسم الخدمة
 *               example: "RKN-Terminal AI Vision"
 *     
 *     BatchVisionResponse:
 *       type: object
 *       properties:
 *         totalImages:
 *           type: integer
 *           description: العدد الإجمالي للصور
 *         successfulAnalyses:
 *           type: integer
 *           description: عدد التحليلات الناجحة
 *         analyses:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/VisionAnalysis'
 *           description: نتائج التحليل لكل صورة
 *         processingInfo:
 *           type: object
 *           properties:
 *             userId:
 *               type: integer
 *             timestamp:
 *               type: string
 *               format: date-time
 *             service:
 *               type: string
 *               example: "RKN-Terminal AI Vision Batch"
 *     
 *     VisionServiceStatus:
 *       type: object
 *       properties:
 *         service:
 *           type: string
 *           description: اسم الخدمة
 *           example: "RKN-Terminal AI Enhanced Vision"
 *         status:
 *           type: string
 *           description: حالة الخدمة
 *           example: "active"
 *         capabilities:
 *           type: array
 *           items:
 *             type: string
 *           description: قدرات الخدمة
 *           example: ["تحليل الأشياء المتقدم", "استخراج النصوص (OCR)", "تحليل المشاهد والسياق"]
 *         models:
 *           type: object
 *           properties:
 *             vision:
 *               type: string
 *               example: "GPT-4o Vision"
 *             imageProcessing:
 *               type: string
 *               example: "Sharp"
 *             supportedFormats:
 *               type: array
 *               items:
 *                 type: string
 *               example: ["JPEG", "PNG", "WebP", "GIF", "TIFF"]
 *         limits:
 *           type: object
 *           properties:
 *             maxFileSize:
 *               type: string
 *               example: "10MB"
 *             maxBatchSize:
 *               type: integer
 *               example: 5
 *             supportedResolutions:
 *               type: string
 *               example: "up to 4K"
 */

/**
 * @swagger
 * /api/vision/analyze:
 *   post:
 *     tags:
 *       - Vision AI
 *     summary: تحليل صورة واحدة
 *     description: تحليل شامل لصورة واحدة باستخدام GPT-4o Vision مع Sharp image processing
 *     security:
 *       - SessionAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - image
 *             properties:
 *               image:
 *                 type: string
 *                 format: binary
 *                 description: ملف الصورة (PNG, JPG, WebP, GIF, TIFF)
 *           encoding:
 *             image:
 *               contentType: image/*
 *     responses:
 *       200:
 *         description: تم تحليل الصورة بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/VisionAnalysisResponse'
 *       400:
 *         description: لم يتم رفع صورة أو تنسيق غير مدعوم
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       413:
 *         description: حجم الملف كبير جداً (أكثر من 10MB)
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/vision/batch-analyze:
 *   post:
 *     tags:
 *       - Vision AI
 *     summary: تحليل متعدد للصور
 *     description: تحليل مجموعة من الصور (حد أقصى 5 صور) في طلب واحد
 *     security:
 *       - SessionAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - images
 *             properties:
 *               images:
 *                 type: array
 *                 items:
 *                   type: string
 *                   format: binary
 *                 maxItems: 5
 *                 description: مجموعة من ملفات الصور (حد أقصى 5)
 *           encoding:
 *             images:
 *               contentType: image/*
 *     responses:
 *       200:
 *         description: تم تحليل الصور بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/BatchVisionResponse'
 *       400:
 *         description: لم يتم رفع صور أو عدد الصور يتجاوز الحد المسموح
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/vision/optimize:
 *   post:
 *     tags:
 *       - Vision AI
 *     summary: تحسين وضغط الصور
 *     description: تحسين جودة الصور وضغطها باستخدام Sharp image processing
 *     security:
 *       - SessionAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - image
 *             properties:
 *               image:
 *                 type: string
 *                 format: binary
 *                 description: ملف الصورة للتحسين
 *               quality:
 *                 type: integer
 *                 minimum: 1
 *                 maximum: 100
 *                 default: 85
 *                 description: جودة الضغط (1-100)
 *               format:
 *                 type: string
 *                 enum: [jpeg, png, webp]
 *                 default: jpeg
 *                 description: تنسيق الإخراج
 *               width:
 *                 type: integer
 *                 minimum: 1
 *                 maximum: 4096
 *                 description: العرض المطلوب (اختياري)
 *               height:
 *                 type: integer
 *                 minimum: 1
 *                 maximum: 4096
 *                 description: الارتفاع المطلوب (اختياري)
 *     responses:
 *       200:
 *         description: تم تحسين الصورة بنجاح
 *         content:
 *           image/jpeg:
 *             schema:
 *               type: string
 *               format: binary
 *           image/png:
 *             schema:
 *               type: string
 *               format: binary
 *           image/webp:
 *             schema:
 *               type: string
 *               format: binary
 *         headers:
 *           Content-Type:
 *             description: نوع المحتوى للصورة المحسنة
 *             schema:
 *               type: string
 *               example: "image/jpeg"
 *           Content-Length:
 *             description: حجم الصورة المحسنة
 *             schema:
 *               type: integer
 *       400:
 *         description: لم يتم رفع صورة أو معاملات غير صحيحة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/vision/status:
 *   get:
 *     tags:
 *       - Vision AI
 *     summary: حالة خدمة الرؤية الاصطناعية
 *     description: الحصول على معلومات حول حالة وقدرات خدمة الرؤية الاصطناعية
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: معلومات حالة الخدمة
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/VisionServiceStatus'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */