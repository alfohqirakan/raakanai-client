import type { Express, Request, Response } from 'express';
import multer from 'multer';
import { enhancedImageAnalysis, batchImageAnalysis, optimizeImage } from '../services/visionService.js';
import { success, error } from '../utils/apiResponse.js';
import { recordAIRequest, recordError } from '../monitoring/metrics.js';

interface AuthenticatedRequest extends Request {
  session?: {
    userId?: number;
    username?: string;
  };
  file?: Express.Multer.File;
  files?: Express.Multer.File[];
}

// Configure multer for vision API endpoints
const visionUpload = multer({ 
  storage: multer.memoryStorage(),
  limits: { 
    fileSize: 10 * 1024 * 1024, // 10MB limit for vision processing
    files: 5 // Max 5 images for batch processing
  },
  fileFilter: (req, file, cb) => {
    // Accept only image files
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('ملف غير مدعوم - يجب أن يكون صورة'));
    }
  }
});

export function setupVisionRoutes(app: Express) {
  
  // Single image analysis endpoint
  app.post('/api/vision/analyze', visionUpload.single('image'), async (req: AuthenticatedRequest, res: Response) => {
    try {
      // Check authentication
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لاستخدام خدمة الرؤية", "NOT_AUTHENTICATED"));
      }

      if (!req.file) {
        return res.status(400).json(error('لم يتم رفع صورة', 'NO_IMAGE_PROVIDED'));
      }

      console.log(`🎯 RKN Vision API: Analyzing image ${req.file.originalname}`);

      const analysis = await enhancedImageAnalysis(req.file.buffer, req.file.originalname);

      res.json(success({
        fileName: req.file.originalname,
        analysis: analysis,
        processingInfo: {
          userId: req.session.userId,
          timestamp: new Date().toISOString(),
          service: 'RKN-Terminal AI Vision'
        }
      }, 'تم تحليل الصورة بنجاح'));

    } catch (err: any) {
      console.error('❌ Vision analysis error:', err);
      recordError('vision_api', err.message);
      res.status(500).json(error('VISION_ANALYSIS_ERROR', 'فشل في تحليل الصورة'));
    }
  });

  // Batch image analysis endpoint
  app.post('/api/vision/batch-analyze', visionUpload.array('images', 5), async (req: AuthenticatedRequest, res: Response) => {
    try {
      // Check authentication
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لاستخدام خدمة الرؤية", "NOT_AUTHENTICATED"));
      }

      if (!req.files || req.files.length === 0) {
        return res.status(400).json(error('لم يتم رفع صور', 'NO_IMAGES_PROVIDED'));
      }

      console.log(`🎯 RKN Vision API: Batch analyzing ${req.files.length} images`);

      const images = req.files.map((file: any) => ({
        buffer: file.buffer,
        fileName: file.originalname
      }));

      const analyses = await batchImageAnalysis(images);

      res.json(success({
        totalImages: req.files.length,
        successfulAnalyses: analyses.length,
        analyses: analyses,
        processingInfo: {
          userId: req.session.userId,
          timestamp: new Date().toISOString(),
          service: 'RKN-Terminal AI Vision Batch'
        }
      }, 'تم تحليل الصور بنجاح'));

    } catch (err: any) {
      console.error('❌ Batch vision analysis error:', err);
      recordError('vision_batch_api', err.message);
      res.status(500).json(error('BATCH_VISION_ANALYSIS_ERROR', 'فشل في تحليل الصور'));
    }
  });

  // Image optimization endpoint
  app.post('/api/vision/optimize', visionUpload.single('image'), async (req: AuthenticatedRequest, res: Response) => {
    try {
      // Check authentication
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لاستخدام خدمة الرؤية", "NOT_AUTHENTICATED"));
      }

      if (!req.file) {
        return res.status(400).json(error('لم يتم رفع صورة', 'NO_IMAGE_PROVIDED'));
      }

      const {
        maxWidth = 1920,
        maxHeight = 1080,
        quality = 85,
        format = 'jpeg'
      } = req.body;

      console.log(`🔧 RKN Vision API: Optimizing image ${req.file.originalname}`);

      const result = await optimizeImage(req.file.buffer, {
        maxWidth: parseInt(maxWidth),
        maxHeight: parseInt(maxHeight),
        quality: parseInt(quality),
        format: format as 'jpeg' | 'png' | 'webp'
      });

      // Send optimized image as response
      res.set({
        'Content-Type': `image/${format}`,
        'Content-Disposition': `attachment; filename="optimized_${req.file.originalname}"`,
        'X-Original-Size': `${result.metadata.originalSize.width}x${result.metadata.originalSize.height}`,
        'X-Optimized-Size': `${result.metadata.processedSize.width}x${result.metadata.processedSize.height}`,
        'X-Compression-Ratio': result.metadata.compressionRatio.toString()
      });

      res.send(result.buffer);

    } catch (err: any) {
      console.error('❌ Image optimization error:', err);
      recordError('vision_optimize_api', err.message);
      res.status(500).json(error('IMAGE_OPTIMIZATION_ERROR', 'فشل في تحسين الصورة'));
    }
  });

  // Vision service status endpoint
  app.get('/api/vision/status', async (req: AuthenticatedRequest, res: Response) => {
    try {
      // Check authentication
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لاستخدام خدمة الرؤية", "NOT_AUTHENTICATED"));
      }

      res.json(success({
        service: 'RKN-Terminal AI Enhanced Vision',
        status: 'active',
        capabilities: [
          'تحليل الأشياء المتقدم',
          'استخراج النصوص (OCR)',
          'تحليل المشاهد والسياق',
          'تحسين الصور',
          'المعالجة المجمعة للصور'
        ],
        models: {
          vision: 'GPT-4o Vision',
          imageProcessing: 'Sharp',
          supportedFormats: ['JPEG', 'PNG', 'WebP', 'GIF', 'TIFF']
        },
        limits: {
          maxFileSize: '10MB',
          maxBatchSize: 5,
          supportedResolutions: 'up to 4K'
        }
      }, 'حالة خدمة الرؤية'));

    } catch (err: any) {
      console.error('❌ Vision status error:', err);
      res.status(500).json(error('VISION_STATUS_ERROR', 'فشل في جلب حالة الخدمة'));
    }
  });

  console.log('🎯 RKN-Terminal AI Vision API endpoints initialized');
}

export default { setupVisionRoutes };