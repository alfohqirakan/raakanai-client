/**
 * @swagger
 * components:
 *   schemas:
 *     EvolutionMetrics:
 *       type: object
 *       properties:
 *         agentId:
 *           type: string
 *           description: معرف الوكيل
 *         successRate:
 *           type: number
 *           description: معدل النجاح (0-1)
 *         averageExecutionTime:
 *           type: number
 *           description: متوسط وقت التنفيذ بالمللي ثانية
 *         errorRate:
 *           type: number
 *           description: معدل الأخطاء (0-1)
 *         userSatisfaction:
 *           type: number
 *           description: مستوى رضا المستخدم (0-1)
 *         improvementAreas:
 *           type: array
 *           items:
 *             type: string
 *           description: مجالات التحسين المحددة
 *         strengths:
 *           type: array
 *           items:
 *             type: string
 *           description: نقاط القوة المحددة
 *         lastAnalyzed:
 *           type: string
 *           format: date-time
 *           description: تاريخ آخر تحليل
 *
 *     LearningPattern:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           description: معرف النمط
 *         pattern:
 *           type: string
 *           description: وصف النمط
 *         frequency:
 *           type: number
 *           description: تكرار ظهور النمط
 *         successRate:
 *           type: number
 *           description: معدل نجاح النمط
 *         context:
 *           type: string
 *           description: السياق المرتبط بالنمط
 *         recommendations:
 *           type: array
 *           items:
 *             type: string
 *           description: التوصيات المبنية على النمط
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: تاريخ اكتشاف النمط
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           description: تاريخ آخر تحديث
 *
 *     EvolutionSuggestion:
 *       type: object
 *       properties:
 *         agentId:
 *           type: string
 *           description: معرف الوكيل
 *         type:
 *           type: string
 *           enum: [capability, tool, prompt, parameter]
 *           description: نوع التحسين المقترح
 *         description:
 *           type: string
 *           description: وصف التحسين بالإنجليزية
 *         descriptionAr:
 *           type: string
 *           description: وصف التحسين بالعربية
 *         impact:
 *           type: string
 *           enum: [low, medium, high]
 *           description: مستوى تأثير التحسين
 *         implementation:
 *           type: string
 *           description: طريقة تطبيق التحسين
 *         reasoning:
 *           type: string
 *           description: التبرير وراء الاقتراح
 *         confidence:
 *           type: number
 *           description: مستوى الثقة في الاقتراح (0-1)
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: تاريخ إنشاء الاقتراح
 *
 *     KnowledgeBase:
 *       type: object
 *       properties:
 *         domain:
 *           type: string
 *           description: مجال المعرفة
 *         concepts:
 *           type: object
 *           description: المفاهيم المخزنة
 *         patterns:
 *           type: array
 *           items:
 *             $ref: '#/components/schemas/LearningPattern'
 *           description: الأنماط المرتبطة بالمجال
 *         improvements:
 *           type: array
 *           items:
 *             type: string
 *           description: التحسينات المطبقة
 *         lastUpdated:
 *           type: string
 *           format: date-time
 *           description: تاريخ آخر تحديث
 *
 *     EvolutionStats:
 *       type: object
 *       properties:
 *         totalAgentsAnalyzed:
 *           type: integer
 *           description: إجمالي الوكلاء المحللين
 *         averageSuccessRate:
 *           type: number
 *           description: متوسط معدل النجاح العام
 *         totalPatternsIdentified:
 *           type: integer
 *           description: إجمالي الأنماط المكتشفة
 *         totalSuggestionsGenerated:
 *           type: integer
 *           description: إجمالي الاقتراحات المُولدة
 *         knowledgeBaseDomains:
 *           type: array
 *           items:
 *             type: string
 *           description: مجالات قاعدة المعرفة
 *         lastEvolutionCycle:
 *           type: string
 *           format: date-time
 *           description: تاريخ آخر دورة تطور
 *         evolutionTrends:
 *           type: object
 *           properties:
 *             improvingAgents:
 *               type: integer
 *               description: عدد الوكلاء المتحسنين
 *             stableAgents:
 *               type: integer
 *               description: عدد الوكلاء المستقرين
 *             decliningAgents:
 *               type: integer
 *               description: عدد الوكلاء المتراجعين
 */

/**
 * @swagger
 * /api/evolution/metrics:
 *   get:
 *     tags:
 *       - Self-Evolution
 *     summary: مقاييس التطور الذاتي
 *     description: الحصول على مقاييس أداء الوكلاء وتطورهم
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: agentId
 *         schema:
 *           type: string
 *         description: معرف وكيل محدد (اختياري)
 *     responses:
 *       200:
 *         description: مقاييس التطور
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       oneOf:
 *                         - $ref: '#/components/schemas/EvolutionMetrics'
 *                         - type: object
 *                           additionalProperties:
 *                             $ref: '#/components/schemas/EvolutionMetrics'
 *       404:
 *         description: لا توجد مقاييس للوكيل المحدد
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/evolution/patterns:
 *   get:
 *     tags:
 *       - Self-Evolution
 *     summary: أنماط التعلم المكتشفة
 *     description: الحصول على الأنماط التي تم اكتشافها من سلوك الوكلاء
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: أنماط التعلم
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: array
 *                       items:
 *                         $ref: '#/components/schemas/LearningPattern'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/evolution/suggestions:
 *   get:
 *     tags:
 *       - Self-Evolution
 *     summary: اقتراحات التطوير
 *     description: الحصول على اقتراحات تحسين الوكلاء الذكيين
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: agentId
 *         schema:
 *           type: string
 *         description: معرف وكيل محدد (اختياري)
 *     responses:
 *       200:
 *         description: اقتراحات التطوير
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       oneOf:
 *                         - type: array
 *                           items:
 *                             $ref: '#/components/schemas/EvolutionSuggestion'
 *                         - type: object
 *                           additionalProperties:
 *                             type: array
 *                             items:
 *                               $ref: '#/components/schemas/EvolutionSuggestion'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/evolution/knowledge:
 *   get:
 *     tags:
 *       - Self-Evolution
 *     summary: قاعدة المعرفة
 *     description: الحصول على قاعدة المعرفة المتراكمة للنظام
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: domain
 *         schema:
 *           type: string
 *           enum: [security, development, analysis]
 *         description: مجال معرفة محدد (اختياري)
 *     responses:
 *       200:
 *         description: قاعدة المعرفة
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       oneOf:
 *                         - $ref: '#/components/schemas/KnowledgeBase'
 *                         - type: object
 *                           additionalProperties:
 *                             $ref: '#/components/schemas/KnowledgeBase'
 *       404:
 *         description: المجال غير موجود في قاعدة المعرفة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/evolution/stats:
 *   get:
 *     tags:
 *       - Self-Evolution
 *     summary: إحصائيات التطور الذاتي
 *     description: الحصول على إحصائيات شاملة لنظام التطور الذاتي
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: إحصائيات التطور
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/EvolutionStats'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/evolution/analyze/{agentId}:
 *   post:
 *     tags:
 *       - Self-Evolution
 *     summary: تحليل أداء وكيل محدد
 *     description: تحليل شامل لأداء وكيل ذكي وإنشاء اقتراحات التطوير
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: path
 *         name: agentId
 *         required: true
 *         schema:
 *           type: string
 *         description: معرف الوكيل المراد تحليله
 *     responses:
 *       200:
 *         description: نتائج التحليل الشامل
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         metrics:
 *                           $ref: '#/components/schemas/EvolutionMetrics'
 *                         patterns:
 *                           type: array
 *                           items:
 *                             $ref: '#/components/schemas/LearningPattern'
 *                         suggestions:
 *                           type: array
 *                           items:
 *                             $ref: '#/components/schemas/EvolutionSuggestion'
 *                         analysisDate:
 *                           type: string
 *                           format: date-time
 *       400:
 *         description: لا توجد بيانات تنفيذ للوكيل
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */