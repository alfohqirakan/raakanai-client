import { Router } from 'express';
import { spawn } from 'child_process';
import { z } from 'zod';
import path from 'path';

const router = Router();

// Schema for neural creative requests
const creativeRequestSchema = z.object({
  prompt: z.string().min(1).max(500),
  identity: z.enum(['Sadi-Infected', 'Advanced-Creative', 'Strategic-Genius', 'Cultural-Artist']).optional(),
  intensity: z.number().min(0).max(1).optional(),
  creative_type: z.enum(['ai_entity', 'visual_art', 'strategic_system', 'cultural_project']).optional()
});

// Get neural creative engine status
router.get('/status', (req, res) => {
  const engineStatus = {
    status: '🧠 المحرك الإبداعي العصبي نشط',
    available_identities: [
      {
        id: 'Sadi-Infected',
        name: 'السادي المصاب',
        description: 'كيان إبداعي عدائي متطور بقدرات تكتيكية',
        specialization: 'التفكير الاستراتيجي والتحليل العدائي'
      },
      {
        id: 'Advanced-Creative',
        name: 'المبدع المتقدم',
        description: 'محرك إبداعي شامل متعدد التخصصات',
        specialization: 'الإبداع التقني والفني المتكامل'
      },
      {
        id: 'Strategic-Genius',
        name: 'العبقري الاستراتيجي',
        description: 'عقل تكتيكي فائق للتخطيط المتقدم',
        specialization: 'التخطيط الاستراتيجي والتحليل المستقبلي'
      },
      {
        id: 'Cultural-Artist',
        name: 'الفنان الثقافي',
        description: 'مبدع ثقافي بهوية سعودية أصيلة',
        specialization: 'الفن والإبداع بالهوية الثقافية'
      }
    ],
    creative_domains: [
      'AI Entity Design',
      'Visual Intelligence',
      'Strategic Systems',
      'Cultural Innovation',
      'Technical Architecture',
      'Artistic Creation'
    ],
    brain_core_active: true,
    neural_pathways: 'fully_optimized',
    timestamp: new Date().toISOString()
  };

  res.json(engineStatus);
});

// Generate creative idea
router.post('/generate', async (req, res) => {
  try {
    const validatedData = creativeRequestSchema.parse(req.body);
    const { prompt, identity = 'Advanced-Creative', intensity = 0.9 } = validatedData;

    console.log(`🧠 تفعيل المحرك الإبداعي: ${identity}`);
    console.log(`💭 معالجة الطلب: ${prompt}`);

    // Execute neural creative engine
    const creativeResult = await executeNeuralCreativeEngine(prompt, identity, intensity);

    res.json({
      status: '🎨 تم توليد الفكرة الإبداعية بنجاح',
      request: {
        prompt: prompt,
        identity: identity,
        intensity: intensity
      },
      creative_output: creativeResult,
      generation_time: new Date().toISOString()
    });

  } catch (error) {
    console.error('خطأ في توليد الفكرة الإبداعية:', error);
    if (error instanceof z.ZodError) {
      res.status(400).json({
        status: '❌ خطأ في بيانات الطلب',
        validation_errors: error.errors,
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({
        status: '❌ خطأ في المحرك الإبداعي',
        error: error.message,
        timestamp: new Date().toISOString()
      });
    }
  }
});

// Get creative inspiration
router.get('/inspiration', (req, res) => {
  const inspirationSources = {
    status: '💡 مصادر الإلهام الإبداعي',
    cultural_inspiration: [
      'الفن الإسلامي التراثي والخط العربي',
      'العمارة السعودية الحديثة والتقليدية',
      'الشعر العربي الأصيل والنبطي',
      'التراث البدوي وحكمة الصحراء',
      'القيم الإسلامية والمبادئ السمحة'
    ],
    technical_inspiration: [
      'الذكاء الاصطناعي المتقدم',
      'الشبكات العصبية العميقة',
      'الحوسبة الكمية والمتوازية',
      'أنظمة الأمان السيبراني',
      'التقنيات الناشئة والمستقبلية'
    ],
    strategic_inspiration: [
      'التفكير التكتيكي العسكري',
      'الاستراتيجيات الاقتصادية المتقدمة',
      'التخطيط طويل المدى',
      'إدارة المخاطر والأزمات',
      'القيادة والتحليل السياسي'
    ],
    artistic_inspiration: [
      'فنون الخط والزخرفة الإسلامية',
      'التصميم المعاصر بروح التراث',
      'الألوان المستوحاة من البيئة السعودية',
      'التكوينات الهندسية المتقدمة',
      'الفن الرقمي والتفاعلي'
    ],
    recommended_prompts: [
      'كيان ذكي دفاعي بتقنيات متطورة',
      'نظام فني تفاعلي بهوية سعودية',
      'محرك تحليل استراتيجي متقدم',
      'مشروع إبداعي يجمع التراث والحداثة',
      'كيان ذكي للتعلم والتطوير المستمر'
    ],
    timestamp: new Date().toISOString()
  };

  res.json(inspirationSources);
});

// Analyze creative concept
router.post('/analyze', async (req, res) => {
  try {
    const { concept, analysis_depth = 'comprehensive' } = req.body;

    if (!concept || typeof concept !== 'string') {
      return res.status(400).json({
        status: '❌ مطلوب مفهوم للتحليل',
        timestamp: new Date().toISOString()
      });
    }

    const analysis = await analyzeCreativeConcept(concept, analysis_depth);

    res.json({
      status: '🔍 تم تحليل المفهوم الإبداعي',
      concept: concept,
      analysis: analysis,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('خطأ في تحليل المفهوم:', error);
    res.status(500).json({
      status: '❌ خطأ في التحليل',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// Get creative gallery
router.get('/gallery', (req, res) => {
  const creativeGallery = {
    status: '🎨 معرض الأعمال الإبداعية',
    featured_creations: [
      {
        id: 'sovereign_guardian',
        title: 'الحارس السيادي',
        description: 'كيان ذكي دفاعي متطور بقدرات حماية شاملة',
        category: 'AI Security Entity',
        creativity_score: 9.2,
        cultural_integration: 0.95,
        innovation_level: 'revolutionary'
      },
      {
        id: 'desert_vision',
        title: 'رؤية الصحراء',
        description: 'نظام بصري ذكي مستوحى من حكمة البداوة',
        category: 'Visual Intelligence',
        creativity_score: 8.8,
        cultural_integration: 0.98,
        innovation_level: 'advanced'
      },
      {
        id: 'tactical_analyst',
        title: 'المحلل التكتيكي',
        description: 'عقل استراتيجي للتحليل والتخطيط المتقدم',
        category: 'Strategic Intelligence',
        creativity_score: 9.0,
        cultural_integration: 0.92,
        innovation_level: 'cutting_edge'
      }
    ],
    creation_stats: {
      total_concepts: 156,
      success_rate: 0.94,
      average_creativity_score: 8.6,
      cultural_alignment: 0.96
    },
    popular_categories: [
      'AI Entity Design',
      'Strategic Systems',
      'Cultural Innovation',
      'Visual Intelligence'
    ],
    timestamp: new Date().toISOString()
  };

  res.json(creativeGallery);
});

// Helper functions
async function executeNeuralCreativeEngine(prompt: string, identity: string, intensity: number): Promise<any> {
  return new Promise((resolve, reject) => {
    // Create Python script content
    const pythonScript = `
import sys
sys.path.append('/home/runner/workspace')
from server.ai import sovereign_brain_injection as rakani_ethos

# Create neural creative engine
rakani_brain = rakani_ethos.NeuralCreativeEngine(identity="${identity}")

# Generate creative idea
result = rakani_brain.generate_creative_idea("${prompt}", intensity=${intensity})

# Output JSON result
import json
print(json.dumps(result, ensure_ascii=False, indent=2))
`;

    // Execute Python script
    const pythonProcess = spawn('python3', ['-c', pythonScript], {
      cwd: '/home/runner/workspace',
      stdio: ['pipe', 'pipe', 'pipe']
    });

    let outputData = '';
    let errorData = '';

    pythonProcess.stdout.on('data', (data) => {
      outputData += data.toString();
    });

    pythonProcess.stderr.on('data', (data) => {
      errorData += data.toString();
    });

    pythonProcess.on('close', (code) => {
      if (code === 0) {
        try {
          // Extract JSON from output (ignore print statements)
          const jsonStart = outputData.indexOf('{');
          const jsonEnd = outputData.lastIndexOf('}') + 1;
          const jsonOutput = outputData.substring(jsonStart, jsonEnd);
          
          const result = JSON.parse(jsonOutput);
          resolve(result);
        } catch (parseError) {
          console.error('JSON Parse Error:', parseError);
          console.log('Raw Output:', outputData);
          reject(new Error('فشل في تحليل نتيجة المحرك الإبداعي'));
        }
      } else {
        console.error('Python Error:', errorData);
        reject(new Error(`فشل في تنفيذ المحرك الإبداعي: ${errorData}`));
      }
    });

    // Set timeout
    setTimeout(() => {
      pythonProcess.kill();
      reject(new Error('انتهت مهلة تنفيذ المحرك الإبداعي'));
    }, 30000);
  });
}

async function analyzeCreativeConcept(concept: string, depth: string): Promise<any> {
  // Simulate creative concept analysis
  const analysisResult = {
    concept_classification: classifyConcept(concept),
    creativity_metrics: {
      originality: Math.random() * 0.3 + 0.7,
      innovation: Math.random() * 0.25 + 0.75,
      feasibility: Math.random() * 0.2 + 0.8,
      cultural_relevance: Math.random() * 0.1 + 0.9
    },
    improvement_suggestions: [
      'تعزيز التكامل الثقافي',
      'زيادة مستوى الابتكار التقني',
      'تحسين القابلية للتنفيذ',
      'دمج عناصر التراث السعودي'
    ],
    implementation_complexity: assessComplexity(concept),
    market_potential: 'high',
    technical_requirements: [
      'خبرة تقنية متقدمة',
      'موارد حاسوبية قوية',
      'فريق متعدد التخصصات',
      'دعم ثقافي ومؤسسي'
    ]
  };

  return analysisResult;
}

function classifyConcept(concept: string): string {
  if (concept.includes('ذكي') || concept.includes('AI')) return 'AI_System';
  if (concept.includes('فني') || concept.includes('art')) return 'Artistic_Creation';
  if (concept.includes('استراتيجي') || concept.includes('strategic')) return 'Strategic_System';
  if (concept.includes('ثقافي') || concept.includes('cultural')) return 'Cultural_Innovation';
  return 'General_Creative';
}

function assessComplexity(concept: string): string {
  const words = concept.split(' ').length;
  if (words > 10) return 'high';
  if (words > 5) return 'medium';
  return 'low';
}

export default router;