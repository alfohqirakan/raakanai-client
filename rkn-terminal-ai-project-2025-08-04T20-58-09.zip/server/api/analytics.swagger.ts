/**
 * @swagger
 * components:
 *   schemas:
 *     SystemMetrics:
 *       type: object
 *       properties:
 *         uptime:
 *           type: integer
 *           description: وقت تشغيل النظام بالثواني
 *         processedFiles:
 *           type: integer
 *           description: عدد الملفات المعالجة
 *         activeConnections:
 *           type: integer
 *           description: عدد الاتصالات النشطة
 *         memoryUsage:
 *           type: object
 *           properties:
 *             used:
 *               type: integer
 *               description: الذاكرة المستخدمة بالبايت
 *             total:
 *               type: integer
 *               description: إجمالي الذاكرة بالبايت
 *             percentage:
 *               type: number
 *               description: نسبة استخدام الذاكرة
 *         cpuUsage:
 *           type: number
 *           description: نسبة استخدام المعالج
 *         diskUsage:
 *           type: object
 *           properties:
 *             used:
 *               type: integer
 *               description: المساحة المستخدمة بالبايت
 *             available:
 *               type: integer
 *               description: المساحة المتاحة بالبايت
 *             percentage:
 *               type: number
 *               description: نسبة استخدام القرص
 *         aiMetrics:
 *           type: object
 *           properties:
 *             totalRequests:
 *               type: integer
 *               description: إجمالي طلبات الذكاء الاصطناعي
 *             successfulRequests:
 *               type: integer
 *               description: الطلبات الناجحة
 *             averageResponseTime:
 *               type: number
 *               description: متوسط وقت الاستجابة بالميللي ثانية
 *             errorRate:
 *               type: number
 *               description: معدل الأخطاء
 *     
 *     UserActivityMetrics:
 *       type: object
 *       properties:
 *         totalUsers:
 *           type: integer
 *           description: العدد الإجمالي للمستخدمين
 *         activeUsers:
 *           type: integer
 *           description: المستخدمون النشطون
 *         newUsers:
 *           type: integer
 *           description: المستخدمون الجدد
 *         usersByPlan:
 *           type: object
 *           properties:
 *             free:
 *               type: integer
 *               description: مستخدمو الخطة المجانية
 *             pro:
 *               type: integer
 *               description: مستخدمو خطة Pro
 *         activityByTimeRange:
 *           type: object
 *           additionalProperties:
 *             type: integer
 *           description: النشاط حسب الفترة الزمنية
 *           example:
 *             "00-06": 45
 *             "06-12": 120
 *             "12-18": 200
 *             "18-24": 85
 *     
 *     FileAnalyticsData:
 *       type: object
 *       properties:
 *         totalFiles:
 *           type: integer
 *           description: إجمالي الملفات
 *         filesByType:
 *           type: object
 *           additionalProperties:
 *             type: integer
 *           description: الملفات حسب النوع
 *           example:
 *             "application/pdf": 150
 *             "image/jpeg": 89
 *             "text/plain": 67
 *             "image/png": 45
 *         filesByStatus:
 *           type: object
 *           properties:
 *             uploaded:
 *               type: integer
 *             processing:
 *               type: integer
 *             analyzed:
 *               type: integer
 *             error:
 *               type: integer
 *         averageFileSize:
 *           type: integer
 *           description: متوسط حجم الملف بالبايت
 *         totalStorageUsed:
 *           type: integer
 *           description: إجمالي التخزين المستخدم بالبايت
 *         uploadTrends:
 *           type: array
 *           items:
 *             type: object
 *             properties:
 *               date:
 *                 type: string
 *                 format: date
 *               count:
 *                 type: integer
 *               size:
 *                 type: integer
 *           description: اتجاهات الرفع عبر الوقت
 *     
 *     PerformanceMetrics:
 *       type: object
 *       properties:
 *         apiEndpoints:
 *           type: object
 *           additionalProperties:
 *             type: object
 *             properties:
 *               totalRequests:
 *                 type: integer
 *               averageResponseTime:
 *                 type: number
 *               errorRate:
 *                 type: number
 *               slowestRequest:
 *                 type: number
 *               fastestRequest:
 *                 type: number
 *           description: مقاييس الأداء لكل نقطة نهاية
 *         databaseMetrics:
 *           type: object
 *           properties:
 *             totalQueries:
 *               type: integer
 *             averageQueryTime:
 *               type: number
 *             slowestQuery:
 *               type: number
 *             connectionPoolSize:
 *               type: integer
 *             activeConnections:
 *               type: integer
 *         errorAnalytics:
 *           type: object
 *           properties:
 *             totalErrors:
 *               type: integer
 *             errorsByType:
 *               type: object
 *               additionalProperties:
 *                 type: integer
 *             recentErrors:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   timestamp:
 *                     type: string
 *                     format: date-time
 *                   type:
 *                     type: string
 *                   message:
 *                     type: string
 *                   endpoint:
 *                     type: string
 */

/**
 * @swagger
 * /api/analytics/dashboard:
 *   get:
 *     tags:
 *       - Analytics
 *     summary: بيانات لوحة التحكم الرئيسية
 *     description: الحصول على المقاييس الأساسية للوحة التحكل الرئيسية
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: بيانات لوحة التحكم
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         userStats:
 *                           type: object
 *                           properties:
 *                             totalFiles:
 *                               type: integer
 *                             analyzedFiles:
 *                               type: integer
 *                             processingFiles:
 *                               type: integer
 *                             uploadsUsed:
 *                               type: integer
 *                             uploadLimit:
 *                               type: integer
 *                         recentActivity:
 *                           type: array
 *                           items:
 *                             type: object
 *                             properties:
 *                               type:
 *                                 type: string
 *                                 enum: [upload, analysis, chat]
 *                               description:
 *                                 type: string
 *                               timestamp:
 *                                 type: string
 *                                 format: date-time
 *                         quickInsights:
 *                           type: object
 *                           properties:
 *                             topFileTypes:
 *                               type: array
 *                               items:
 *                                 type: object
 *                                 properties:
 *                                   type:
 *                                     type: string
 *                                   count:
 *                                     type: integer
 *                             averageAnalysisTime:
 *                               type: number
 *                             successRate:
 *                               type: number
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/analytics/system:
 *   get:
 *     tags:
 *       - Analytics
 *     summary: مقاييس النظام
 *     description: الحصول على مقاييس أداء النظام والموارد (للإدارة فقط)
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: مقاييس النظام
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/SystemMetrics'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: ليس لديك صلاحية الوصول لمقاييس النظام
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/analytics/usage:
 *   get:
 *     tags:
 *       - Analytics
 *     summary: إحصائيات الاستخدام الشخصي
 *     description: الحصول على إحصائيات تفصيلية عن استخدام المستخدم للمنصة
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [day, week, month, quarter, year]
 *           default: month
 *         description: الفترة الزمنية للإحصائيات
 *       - in: query
 *         name: startDate
 *         schema:
 *           type: string
 *           format: date
 *         description: تاريخ البداية (اختياري)
 *       - in: query
 *         name: endDate
 *         schema:
 *           type: string
 *           format: date
 *         description: تاريخ النهاية (اختياري)
 *     responses:
 *       200:
 *         description: إحصائيات الاستخدام
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         period:
 *                           type: string
 *                           description: الفترة المحددة
 *                         fileAnalytics:
 *                           $ref: '#/components/schemas/FileAnalyticsData'
 *                         chatAnalytics:
 *                           type: object
 *                           properties:
 *                             totalMessages:
 *                               type: integer
 *                             conversationsStarted:
 *                               type: integer
 *                             averageMessagesPerConversation:
 *                               type: number
 *                             topQuestionTypes:
 *                               type: array
 *                               items:
 *                                 type: object
 *                                 properties:
 *                                   type:
 *                                     type: string
 *                                   count:
 *                                     type: integer
 *                         visionAnalytics:
 *                           type: object
 *                           properties:
 *                             totalImages:
 *                               type: integer
 *                             successfulAnalyses:
 *                               type: integer
 *                             averageConfidence:
 *                               type: number
 *                             topDetectedObjects:
 *                               type: array
 *                               items:
 *                                 type: object
 *                                 properties:
 *                                   object:
 *                                     type: string
 *                                   count:
 *                                     type: integer
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/analytics/export:
 *   get:
 *     tags:
 *       - Analytics
 *     summary: تصدير التحليلات
 *     description: تصدير بيانات التحليلات بتنسيقات مختلفة
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: type
 *         required: true
 *         schema:
 *           type: string
 *           enum: [usage, files, chat, vision, performance]
 *         description: نوع البيانات للتصدير
 *       - in: query
 *         name: format
 *         schema:
 *           type: string
 *           enum: [json, csv, xlsx, pdf]
 *           default: json
 *         description: تنسيق التصدير
 *       - in: query
 *         name: period
 *         schema:
 *           type: string
 *           enum: [day, week, month, quarter, year]
 *           default: month
 *         description: الفترة الزمنية
 *       - in: query
 *         name: includeCharts
 *         schema:
 *           type: boolean
 *           default: false
 *         description: تضمين الرسوم البيانية (للـ PDF)
 *     responses:
 *       200:
 *         description: ملف التحليلات المصدر
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               description: بيانات JSON
 *           text/csv:
 *             schema:
 *               type: string
 *               description: ملف CSV
 *           application/vnd.openxmlformats-officedocument.spreadsheetml.sheet:
 *             schema:
 *               type: string
 *               format: binary
 *               description: ملف Excel
 *           application/pdf:
 *             schema:
 *               type: string
 *               format: binary
 *               description: تقرير PDF
 *         headers:
 *           Content-Disposition:
 *             description: تحديد اسم الملف
 *             schema:
 *               type: string
 *               example: 'attachment; filename="analytics-export-2025-08.pdf"'
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/analytics/health:
 *   get:
 *     tags:
 *       - Analytics
 *     summary: صحة النظام
 *     description: فحص سريع لصحة النظام وحالة الخدمات
 *     responses:
 *       200:
 *         description: النظام يعمل بصحة جيدة
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         status:
 *                           type: string
 *                           enum: [healthy, warning, critical]
 *                         services:
 *                           type: object
 *                           properties:
 *                             database:
 *                               type: string
 *                               enum: [up, down, degraded]
 *                             storage:
 *                               type: string
 *                               enum: [up, down, degraded]
 *                             ai:
 *                               type: string
 *                               enum: [up, down, degraded]
 *                             vision:
 *                               type: string
 *                               enum: [up, down, degraded]
 *                         version:
 *                           type: string
 *                           description: إصدار النظام
 *                         uptime:
 *                           type: integer
 *                           description: وقت التشغيل بالثواني
 *                         lastCheck:
 *                           type: string
 *                           format: date-time
 *                           description: وقت آخر فحص
 *       503:
 *         description: النظام لا يعمل بصحة جيدة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */