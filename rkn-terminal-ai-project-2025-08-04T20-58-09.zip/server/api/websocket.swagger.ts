/**
 * @swagger
 * components:
 *   schemas:
 *     WebSocketConnection:
 *       type: object
 *       properties:
 *         socketId:
 *           type: string
 *           description: معرف الاتصال الفوري
 *         userId:
 *           type: integer
 *           description: معرف المستخدم
 *         username:
 *           type: string
 *           description: اسم المستخدم
 *         connectedAt:
 *           type: string
 *           format: date-time
 *           description: وقت الاتصال
 *         clientIP:
 *           type: string
 *           description: عنوان IP للعميل
 *         userAgent:
 *           type: string
 *           description: معلومات المتصفح
 *
 *     WebSocketMessage:
 *       type: object
 *       properties:
 *         event:
 *           type: string
 *           description: نوع الحدث
 *           example: "chatMessage"
 *         data:
 *           type: object
 *           description: بيانات الرسالة
 *         timestamp:
 *           type: string
 *           format: date-time
 *           description: وقت الإرسال
 *         room:
 *           type: string
 *           description: الغرفة المستهدفة (اختياري)
 *
 *     RoomParticipant:
 *       type: object
 *       properties:
 *         socketId:
 *           type: string
 *           description: معرف الاتصال
 *         userId:
 *           type: integer
 *           description: معرف المستخدم
 *         username:
 *           type: string
 *           description: اسم المستخدم
 *         joinedAt:
 *           type: string
 *           format: date-time
 *           description: وقت الانضمام
 *
 *     AnalysisProgress:
 *       type: object
 *       properties:
 *         fileId:
 *           type: string
 *           description: معرف الملف
 *         progress:
 *           type: number
 *           minimum: 0
 *           maximum: 100
 *           description: نسبة التقدم
 *         stage:
 *           type: string
 *           description: مرحلة التحليل الحالية
 *           example: "تحليل المحتوى"
 *         message:
 *           type: string
 *           description: رسالة وصفية
 *         timestamp:
 *           type: string
 *           format: date-time
 *           description: وقت التحديث
 *
 *     ChatMessage:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           description: معرف الرسالة
 *         fileId:
 *           type: string
 *           description: معرف الملف
 *         userId:
 *           type: integer
 *           description: معرف المرسل
 *         username:
 *           type: string
 *           description: اسم المرسل
 *         message:
 *           type: string
 *           description: محتوى الرسالة
 *         timestamp:
 *           type: string
 *           format: date-time
 *           description: وقت الإرسال
 *         type:
 *           type: string
 *           enum: [user, assistant]
 *           description: نوع المرسل
 *
 *     ConnectionStats:
 *       type: object
 *       properties:
 *         totalConnections:
 *           type: integer
 *           description: إجمالي الاتصالات النشطة
 *         authenticatedUsers:
 *           type: integer
 *           description: المستخدمون المسجلون
 *         activeRooms:
 *           type: integer
 *           description: الغرف النشطة
 *         userConnections:
 *           type: integer
 *           description: اتصالات المستخدمين
 *         averageLatency:
 *           type: number
 *           description: متوسط زمن الاستجابة بالميللي ثانية
 *
 *     WebSocketEvent:
 *       type: object
 *       properties:
 *         name:
 *           type: string
 *           description: اسم الحدث
 *         description:
 *           type: string
 *           description: وصف الحدث
 *         direction:
 *           type: string
 *           enum: [client-to-server, server-to-client, bidirectional]
 *           description: اتجاه الحدث
 *         dataSchema:
 *           type: object
 *           description: بنية البيانات المتوقعة
 *         example:
 *           type: object
 *           description: مثال على الاستخدام
 */

/**
 * @swagger
 * /api/websocket/stats:
 *   get:
 *     tags:
 *       - WebSocket
 *     summary: إحصائيات الاتصالات الفورية
 *     description: الحصول على إحصائيات مفصلة عن الاتصالات الفورية والغرف النشطة
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: إحصائيات الاتصالات
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       $ref: '#/components/schemas/ConnectionStats'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/websocket/health:
 *   get:
 *     tags:
 *       - WebSocket
 *     summary: صحة خدمة WebSocket
 *     description: فحص حالة وصحة خدمة التواصل الفوري
 *     responses:
 *       200:
 *         description: حالة خدمة WebSocket
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         status:
 *                           type: string
 *                           enum: [healthy, degraded, down]
 *                           description: حالة الخدمة
 *                         initialized:
 *                           type: boolean
 *                           description: هل تم تهيئة الخدمة
 *                         connections:
 *                           type: integer
 *                           description: عدد الاتصالات النشطة
 *                         uptime:
 *                           type: number
 *                           description: وقت التشغيل بالثواني
 *                         version:
 *                           type: string
 *                           description: إصدار Socket.IO
 *                         transport:
 *                           type: array
 *                           items:
 *                             type: string
 *                           description: وسائل النقل المدعومة
 *                           example: ["websocket", "polling"]
 *       503:
 *         description: خدمة WebSocket غير متاحة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */

/**
 * @swagger
 * /api/websocket/events:
 *   get:
 *     tags:
 *       - WebSocket
 *     summary: قائمة أحداث WebSocket
 *     description: الحصول على قائمة شاملة بجميع أحداث WebSocket المدعومة
 *     security:
 *       - SessionAuth: []
 *     responses:
 *       200:
 *         description: قائمة الأحداث المدعومة
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         clientEvents:
 *                           type: array
 *                           items:
 *                             $ref: '#/components/schemas/WebSocketEvent'
 *                           description: الأحداث التي يرسلها العميل
 *                         serverEvents:
 *                           type: array
 *                           items:
 *                             $ref: '#/components/schemas/WebSocketEvent'
 *                           description: الأحداث التي يرسلها الخادم
 *                         examples:
 *                           type: object
 *                           description: أمثلة على الاستخدام
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/websocket/rooms:
 *   get:
 *     tags:
 *       - WebSocket
 *     summary: الغرف النشطة
 *     description: الحصول على قائمة بالغرف النشطة والمشاركين فيها
 *     security:
 *       - SessionAuth: []
 *     parameters:
 *       - in: query
 *         name: includeParticipants
 *         schema:
 *           type: boolean
 *           default: true
 *         description: تضمين قائمة المشاركين
 *     responses:
 *       200:
 *         description: قائمة الغرف النشطة
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         totalRooms:
 *                           type: integer
 *                           description: العدد الإجمالي للغرف
 *                         rooms:
 *                           type: array
 *                           items:
 *                             type: object
 *                             properties:
 *                               roomName:
 *                                 type: string
 *                                 description: اسم الغرفة
 *                               participantCount:
 *                                 type: integer
 *                                 description: عدد المشاركين
 *                               createdAt:
 *                                 type: string
 *                                 format: date-time
 *                                 description: وقت إنشاء الغرفة
 *                               participants:
 *                                 type: array
 *                                 items:
 *                                   $ref: '#/components/schemas/RoomParticipant'
 *                                 description: قائمة المشاركين
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */

/**
 * @swagger
 * /api/websocket/broadcast:
 *   post:
 *     tags:
 *       - WebSocket
 *     summary: إرسال إشعار عام
 *     description: إرسال إشعار لجميع المستخدمين المتصلين (للإدارة فقط)
 *     security:
 *       - SessionAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - type
 *               - title
 *               - message
 *             properties:
 *               type:
 *                 type: string
 *                 enum: [info, warning, error, success]
 *                 description: نوع الإشعار
 *               title:
 *                 type: string
 *                 description: عنوان الإشعار
 *                 example: "تحديث النظام"
 *               message:
 *                 type: string
 *                 description: محتوى الإشعار
 *                 example: "سيتم تحديث النظام خلال 5 دقائق"
 *               data:
 *                 type: object
 *                 description: بيانات إضافية (اختياري)
 *               targetUsers:
 *                 type: array
 *                 items:
 *                   type: integer
 *                 description: معرفات المستخدمين المستهدفين (اختياري)
 *     responses:
 *       200:
 *         description: تم إرسال الإشعار بنجاح
 *         content:
 *           application/json:
 *             schema:
 *               allOf:
 *                 - $ref: '#/components/schemas/ApiResponse'
 *                 - type: object
 *                   properties:
 *                     data:
 *                       type: object
 *                       properties:
 *                         sentTo:
 *                           type: integer
 *                           description: عدد المستقبلين
 *                         timestamp:
 *                           type: string
 *                           format: date-time
 *                           description: وقت الإرسال
 *       400:
 *         $ref: '#/components/responses/ValidationError'
 *       401:
 *         $ref: '#/components/responses/UnauthorizedError'
 *       403:
 *         description: ليس لديك صلاحية إرسال الإشعارات العامة
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       500:
 *         $ref: '#/components/responses/ServerError'
 */