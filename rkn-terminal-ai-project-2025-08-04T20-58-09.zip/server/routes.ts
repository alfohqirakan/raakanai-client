import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import path from "path";
import fs from "fs/promises";
import { storage } from "./storage.js";
import { upload, handleUploadError, getFileInfo, validateFile } from "./middleware/upload.js";
import { insertFileSchema, insertChatMessageSchema } from "@shared/schema.js";
import { getFileProcessor } from "./services/fileProcessor.js";
import { chatWithAI } from "./services/openai.js";
import type { StatsResponse } from "@shared/types.js";
import { AutonomousEntity } from "./core/AutonomousEntity.js";
import { AdvancedSecurityCore, createSecurityMiddleware, createAdvancedRateLimit } from "./security/AdvancedSecurity.js";
import { success, error, processing } from "./utils/apiResponse.js";
import { createUser, verifyUser, incrementUserUploadCount } from "./lib/auth.js";
import { validateFile as customValidateFile, validateUploadLimits, getSupportedFileTypes } from "./middleware/fileValidation.js";
import { enhancedFileProcessor } from "./services/enhancedFileProcessor.js";
import { getCacheStats, clearAllCaches, getCacheHealth } from "./services/aiCache.js";
import { cloudStorage } from "./utils/cloudStorage.js";
import { asyncHandler, ValidationError, AuthenticationError, FileProcessingError } from "./middleware/errorHandler.js";
import { 
  recordAIRequest, 
  recordFileUpload, 
  recordQueueJob, 
  recordUserAuth, 
  updateActiveUsers,
  recordStorageOperation,
  recordError,
  updateAIMetrics,
  recordAIDecision
} from "./monitoring/metrics.js";
import { 
  addFileProcessingJob, 
  addBatchProcessingJob, 
  addAIAnalysisJob, 
  getQueueStats, 
  getJobStatus, 
  getQueueHealth,
  cleanupQueues 
} from "./services/simpleQueue.js";
import passport from "passport";
import googleAuthRouter from "./auth/googleAuth.js";
import { authenticateUser } from "./middleware/authMiddleware.js";
import { insertUserSchema } from "@shared/schema.js";
import { setupChunkedUploadRoutes } from "./services/chunkedUpload.js";
import codeGenerationRouter from "./api/codeGeneration.js";
import { setupVisionRoutes } from "./api/vision.js";
import multilingualAI from "./api/multilingualAI.js";
import testMultilingual from "./api/testMultilingual.js";
import exportRoutes from "./api/export.js";
import aiNeuralRoutes from "./api/ai-neural-fixed.js";
import brainInjectionRoutes from "./api/brain-injection.js";
import rakanModeRoutes from "./api/rakan-mode.js";
import avatarCustomizationRoutes from "./api/avatar-customization.js";
import sovereignTerminalRoutes from "./api/sovereign-terminal.js";
import { sovereignRateLimit } from "./middleware/rateLimiter.js";
import neuralCreativeRoutes from "./api/neural-creative.js";
import systemMetricsRoutes from "./api/system-metrics.js";

// Upload directory configuration
const uploadDir = path.join(process.cwd(), "uploads");

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize Rakan Autonomous Entity and Security Systems
  const rakanEntity = new AutonomousEntity();
  const securityCore = new AdvancedSecurityCore();

  // Apply advanced security middleware (Rate limiting disabled for development)
  // app.use(createAdvancedRateLimit()); // Disabled for development
  app.use(createSecurityMiddleware(securityCore));

  // Setup chunked upload routes for large files
  setupChunkedUploadRoutes(app);

  // Setup enhanced vision API routes
  setupVisionRoutes(app);

  // Ensure upload directory exists
  try {
    await fs.mkdir(uploadDir, { recursive: true });
    await fs.mkdir(path.join(uploadDir, "reports"), { recursive: true });
  } catch (error) {
    console.log("Upload directories already exist");
  }

  // Serve static files from uploads directory
  app.use('/uploads', express.static('uploads'));

  // Initialize Passport (without session since we use custom session management)
  app.use(passport.initialize());

  // Google OAuth routes using Passport
  app.use('/api/auth', googleAuthRouter);
  
  // Code generation and execution routes
  app.use('/api/ai', codeGenerationRouter);
  
  // Multilingual AI communication routes
  app.use('/api/multilingual', multilingualAI);
  
  // Test multilingual routes (without rate limiting)
  app.use('/api/test', testMultilingual);
  
  // Mount export routes
  app.use('/api/export', exportRoutes);
  
  // Neural Network AI routes
  app.use('/api/ai-neural', aiNeuralRoutes);
  
  // Sovereign Brain Injection routes
  app.use('/api/sovereign', brainInjectionRoutes);
  
  // RAKAN MODE routes
  app.use('/api/rakan-mode', rakanModeRoutes);
  
  // Avatar Customization routes
  app.use('/api/avatar-customization', avatarCustomizationRoutes);
  
  // Sovereign Terminal routes
  app.use('/api/sovereign-terminal', sovereignTerminalRoutes);
  app.use('/api/system', systemMetricsRoutes);
  
  // Neural Creative Engine routes
  app.use('/api/neural-creative', neuralCreativeRoutes);

  // Google OAuth is now handled by Passport middleware above

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, password } = insertUserSchema.parse(req.body);
      
      if (!username || !password) {
        return res.status(400).json(error("اسم المستخدم وكلمة المرور مطلوبان", "MISSING_CREDENTIALS"));
      }

      if (password.length < 6) {
        return res.status(400).json(error("كلمة المرور يجب أن تكون 6 أحرف على الأقل", "PASSWORD_TOO_SHORT"));
      }

      const result = await createUser(username, password);
      
      // Record user registration metrics
      recordUserAuth('register', 'success', 'free');
      
      res.json(result);
    } catch (err) {
      console.error("Registration error:", err);
      res.status(400).json(error((err as Error).message, "REGISTRATION_ERROR"));
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json(error("اسم المستخدم وكلمة المرور مطلوبان", "MISSING_CREDENTIALS"));
      }

      const result = await verifyUser(username, password);
      
      // Store user in session
      if (req.session) {
        req.session.userId = result.data.user.id;
        req.session.username = result.data.user.username;
      }

      // Record user login metrics
      recordUserAuth('login', 'success', result.data.user.plan || 'free');

      res.json(result);
    } catch (err) {
      console.error("Login error:", err);
      res.status(401).json(error((err as Error).message, "LOGIN_ERROR"));
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    if (req.session) {
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json(error("فشل في تسجيل الخروج", "LOGOUT_ERROR"));
        }
        // Record logout metrics
        recordUserAuth('logout', 'success', 'unknown');
        
        res.json(success(null, "تم تسجيل الخروج بنجاح"));
      });
    } else {
      res.json(success(null, "تم تسجيل الخروج بنجاح"));
    }
  });

  app.get("/api/auth/me", authenticateUser, async (req, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json(error("المستخدم غير موجود", "USER_NOT_FOUND"));
      }

      res.json(success({
        user: {
          id: user.id,
          username: user.username,
          plan: user.plan,
          uploadCount: user.uploadCount,
          createdAt: user.createdAt
        }
      }, "تم جلب بيانات المستخدم بنجاح"));
    } catch (err) {
      console.error("User fetch error:", err);
      res.status(500).json(error("فشل في جلب بيانات المستخدم", "USER_FETCH_ERROR"));
    }
  });
  
  // Get user's files
  app.get("/api/files", authenticateUser, async (req, res) => {
    try {
      const files = await storage.getFilesByUserId(req.user!.id);
      res.json(success(files, "تم جلب الملفات بنجاح"));
    } catch (err) {
      console.error("Files fetch error:", err);
      res.status(500).json(error("فشل في جلب الملفات", "FILES_FETCH_ERROR"));
    }
  });

  // File type information endpoint
  app.get("/api/files/supported-types", (req, res) => {
    res.json(success(getSupportedFileTypes(), 'معلومات أنواع الملفات المدعومة'));
  });

  // Enhanced file upload with progress tracking and AI processing
  app.post("/api/files/upload-with-progress", 
    upload.array('files', 10), 
    validateUploadLimits,
    customValidateFile,
    handleUploadError, 
    async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لرفع الملفات"));
      }

      const files = req.files as Express.Multer.File[];
      if (!files || files.length === 0) {
        return res.status(400).json(error("لم يتم رفع أي ملفات"));
      }

      // Process files with enhanced processor
      const fileProcessingData = files.map(file => ({
        filePath: file.path,
        mimeType: file.mimetype,
        fileId: file.filename
      }));

      const results = await enhancedFileProcessor.processBatchFiles(fileProcessingData);
      
      // Store successful results in storage
      for (const result of results) {
        if (result.status === 'success') {
          const originalFile = files.find(f => f.filename === result.id);
          const fileRecord = insertFileSchema.parse({
            name: originalFile?.filename || result.id,
            originalName: originalFile?.originalname || result.id,
            size: result.fileSize,
            mimeType: fileProcessingData.find(f => f.fileId === result.id)?.mimeType || 'unknown',
            path: fileProcessingData.find(f => f.fileId === result.id)?.filePath || '',
            userId: req.session.userId,
            status: 'analyzed',
            analysis: {
              summary: result.summary,
              keyPoints: result.keyPoints,
              categories: result.categories,
              confidence: result.confidence,
              language: result.language,
              processingTime: result.processingTime,
              retryAttempts: result.retryAttempts
            }
          });
          
          await storage.createFile(fileRecord);
          await incrementUserUploadCount(req.session.userId);
        }
      }

      // Add files to processing queue for advanced analysis
      const queueJobs = [];
      for (const result of results) {
        if (result.status === 'success') {
          const originalFile = files.find(f => f.filename === result.id);
          if (originalFile) {
            try {
              const job = await addFileProcessingJob(
                result.id,
                originalFile.path,
                originalFile.mimetype,
                req.session.userId,
                {
                  priority: 'normal',
                  metadata: {
                    originalName: originalFile.originalname,
                    size: originalFile.size
                  }
                }
              );
              queueJobs.push({
                fileId: result.id,
                jobId: job.id,
                status: 'queued'
              });
            } catch (queueErr) {
              console.warn(`Failed to queue file ${result.id}:`, queueErr);
            }
          }
        }
      }

      res.json(success({
        results,
        queueJobs,
        summary: {
          total: results.length,
          successful: results.filter(r => r.status === 'success').length,
          failed: results.filter(r => r.status === 'failed').length,
          processingStats: enhancedFileProcessor.getProcessingStats()
        }
      }, 'تم رفع الملفات ومعالجتها بنجاح'));

    } catch (err) {
      console.error('Enhanced upload error:', err);
      res.status(500).json(error('فشل في رفع ومعالجة الملفات: ' + (err as Error).message));
    }
  });

  // Get AI processing statistics
  app.get("/api/ai/processing-stats", (req, res) => {
    try {
      const stats = enhancedFileProcessor.getProcessingStats();
      res.json(success(stats, 'إحصائيات معالجة AI'));
    } catch (error) {
      console.error('Error getting processing stats:', error);
      res.status(500).json(error('فشل في جلب إحصائيات المعالجة'));
    }
  });

  // Reset AI circuit breaker
  app.post("/api/ai/reset-circuit-breaker", (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json(error('يجب تسجيل الدخول أولاً'));
    }

    try {
      const newState = enhancedFileProcessor.resetCircuitBreaker();
      res.json(success(newState, 'تم إعادة تعيين قاطع الدائرة بنجاح'));
    } catch (error) {
      console.error('Error resetting circuit breaker:', error);
      res.status(500).json(error('فشل في إعادة تعيين قاطع الدائرة'));
    }
  });

  // Get AI cache statistics
  app.get("/api/ai/cache-stats", (req, res) => {
    try {
      const cacheStats = getCacheStats();
      const cacheHealth = getCacheHealth();
      
      res.json(success({
        stats: cacheStats,
        health: cacheHealth,
        performance: {
          efficiency: cacheHealth.efficiency,
          recommendation: cacheHealth.recommendation
        }
      }, 'إحصائيات ذاكرة التخزين المؤقت لـ AI'));
    } catch (error) {
      console.error('Error getting cache stats:', error);
      res.status(500).json(error('فشل في جلب إحصائيات الذاكرة المؤقتة'));
    }
  });

  // Clear AI cache
  app.post("/api/ai/clear-cache", (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json(error('يجب تسجيل الدخول أولاً'));
    }

    try {
      const result = clearAllCaches();
      res.json(success(result, `تم مسح ${result.cleared} عنصر من الذاكرة المؤقتة`));
    } catch (error) {
      console.error('Error clearing cache:', error);
      res.status(500).json(error('فشل في مسح الذاكرة المؤقتة'));
    }
  });

  // Get comprehensive AI system health
  app.get("/api/ai/system-health", (req, res) => {
    try {
      const processingStats = enhancedFileProcessor.getProcessingStats();
      const cacheHealth = getCacheHealth();
      
      const systemHealth = {
        overall: 'healthy',
        circuitBreaker: processingStats.circuitBreaker,
        cache: processingStats.cache,
        cacheHealth,
        recommendations: [],
        timestamp: new Date().toISOString()
      };

      // Add recommendations based on system state
      if (processingStats.circuitBreaker.state !== 'closed') {
        systemHealth.overall = 'degraded';
        systemHealth.recommendations.push('Circuit breaker is active - AI service may be experiencing issues');
      }

      if (cacheHealth.hitRate < 40) {
        systemHealth.recommendations.push('Cache hit rate is low - consider warming cache or increasing TTL');
      }

      if (processingStats.cache.totalRequests === 0) {
        systemHealth.recommendations.push('No cache activity detected - system may be starting up');
      }

      res.json(success(systemHealth, 'حالة النظام الشاملة لـ AI'));
    } catch (error) {
      console.error('Error getting system health:', error);
      res.status(500).json(error('فشل في جلب حالة النظام'));
    }
  });

  // Get cloud storage information
  app.get("/api/storage/info", (req, res) => {
    try {
      const storageInfo = cloudStorage.getStorageInfo();
      res.json(success(storageInfo, 'معلومات نظام التخزين'));
    } catch (error) {
      console.error('Error getting storage info:', error);
      res.status(500).json(error('فشل في جلب معلومات التخزين'));
    }
  });

  // Storage health check
  app.get("/api/storage/health", async (req, res) => {
    try {
      const healthStatus = await cloudStorage.healthCheck();
      res.json(success(healthStatus, 'فحص حالة نظام التخزين'));
    } catch (error) {
      console.error('Error checking storage health:', error);
      res.status(500).json(error('فشل في فحص حالة التخزين'));
    }
  });

  // Generate secure upload URL
  app.post("/api/storage/upload-url", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json(error('يجب تسجيل الدخول أولاً'));
    }

    try {
      const { filename, contentType } = req.body;
      
      if (!filename || !contentType) {
        return res.status(400).json(error('اسم الملف ونوع المحتوى مطلوبان'));
      }

      const uploadInfo = await cloudStorage.generateUploadURL(
        filename, 
        contentType, 
        req.session.userId
      );

      res.json(success(uploadInfo, 'تم إنشاء رابط الرفع بنجاح'));
    } catch (error) {
      console.error('Error generating upload URL:', error);
      res.status(500).json(error('فشل في إنشاء رابط الرفع'));
    }
  });

  // Generate secure download URL
  app.post("/api/storage/download-url", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json(error('يجب تسجيل الدخول أولاً'));
    }

    try {
      const { fileKey, expiresIn = 3600 } = req.body;
      
      if (!fileKey) {
        return res.status(400).json(error('مفتاح الملف مطلوب'));
      }

      const downloadUrl = await cloudStorage.generateDownloadURL(fileKey, expiresIn);
      
      if (!downloadUrl) {
        return res.status(404).json(error('لا يمكن إنشاء رابط التحميل'));
      }

      res.json(success({ downloadUrl, expiresIn }, 'تم إنشاء رابط التحميل بنجاح'));
    } catch (error) {
      console.error('Error generating download URL:', error);
      res.status(500).json(error('فشل في إنشاء رابط التحميل'));
    }
  });

  // Enhanced file upload with comprehensive validation
  app.post("/api/files/upload", 
    upload.array('files', 10), 
    validateUploadLimits,
    customValidateFile,
    handleUploadError, 
    async (req, res) => {
    try {
      // Check authentication
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لرفع الملفات", "NOT_AUTHENTICATED"));
      }

      if (!req.files || !Array.isArray(req.files)) {
        return res.status(400).json(error("لم يتم رفع أي ملفات", "NO_FILES_UPLOADED"));
      }

      // Get user and check upload limits
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json(error("المستخدم غير موجود", "USER_NOT_FOUND"));
      }

      // Check plan limits
      const uploadLimit = user.plan === 'pro' ? 100 : 5;
      if (user.uploadCount + req.files.length > uploadLimit) {
        return res.status(403).json(error(
          `تجاوز حد الرفع المسموح. الحد الأقصى: ${uploadLimit} ملف`,
          "UPLOAD_LIMIT_EXCEEDED"
        ));
      }

      const uploadedFiles = [];
      const errors = [];

      for (const file of req.files) {
        try {
          // Enhanced file validation
          const validation = validateFile(file);
          if (!validation.valid) {
            errors.push({ filename: file.originalname, error: validation.error });
            continue;
          }

          // Get enhanced file info
          const fileInfo = getFileInfo(file);

          // Create file record with user ID
          const fileData = insertFileSchema.parse({
            name: fileInfo.filename,
            originalName: fileInfo.originalName,
            size: fileInfo.size,
            mimeType: fileInfo.mimetype,
            path: fileInfo.path,
            userId: user.id,
            status: "uploaded",
          });

          const savedFile = await storage.createFile(fileData);
          uploadedFiles.push({
            ...savedFile,
            isImage: fileInfo.isImage,
            extension: fileInfo.extension
          });

          // Process file asynchronously with enhanced AI
          processFileAsync(savedFile.id, fileInfo.path, fileInfo.mimetype);
        } catch (fileError) {
          console.error(`Error processing file ${file.originalname}:`, fileError);
          errors.push({ 
            filename: file.originalname, 
            error: "خطأ في معالجة الملف" 
          });
        }
      }

      // Update user upload count
      await storage.updateUser(user.id, {
        uploadCount: user.uploadCount + uploadedFiles.length
      });

      // Return response with upload results
      const response = {
        files: uploadedFiles,
        errors: errors,
        uploadCount: user.uploadCount + uploadedFiles.length,
        remainingUploads: uploadLimit - (user.uploadCount + uploadedFiles.length)
      };

      if (errors.length > 0 && uploadedFiles.length === 0) {
        return res.status(400).json(error("فشل في رفع جميع الملفات", "ALL_UPLOADS_FAILED", response));
      }

      const message = errors.length > 0 
        ? `تم رفع ${uploadedFiles.length} ملف بنجاح مع ${errors.length} أخطاء`
        : `تم رفع ${uploadedFiles.length} ملف بنجاح وبدء المعالجة بواسطة راكان`;

      res.json(success(response, message));
    } catch (err) {
      console.error("Upload error:", err);
      res.status(500).json(error("فشل في رفع الملفات", "UPLOAD_ERROR"));
    }
  });

  // Get file analysis with user authentication
  app.get("/api/files/:id/analysis", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض تحليل الملفات", "NOT_AUTHENTICATED"));
      }

      const file = await storage.getFile(req.params.id);
      if (!file) {
        return res.status(404).json(error("الملف غير موجود", "FILE_NOT_FOUND"));
      }

      // Check if user owns the file
      if (file.userId !== req.session.userId) {
        return res.status(403).json(error("غير مصرح لك بالوصول لهذا الملف", "FORBIDDEN"));
      }

      res.json(success({
        file,
        analysis: file.analysis,
        summary: file.summary
      }, "تم جلب تحليل الملف بنجاح"));
    } catch (err) {
      console.error("Analysis fetch error:", err);
      res.status(500).json(error("فشل في جلب تحليل الملف", "ANALYSIS_FETCH_ERROR"));
    }
  });

  // Delete file with user authentication
  app.delete("/api/files/:id", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لحذف الملفات", "NOT_AUTHENTICATED"));
      }

      const file = await storage.getFile(req.params.id);
      if (!file) {
        return res.status(404).json(error("الملف غير موجود", "FILE_NOT_FOUND"));
      }

      // Check if user owns the file
      if (file.userId !== req.session.userId) {
        return res.status(403).json(error("غير مصرح لك بحذف هذا الملف", "FORBIDDEN"));
      }

      // Delete physical file
      try {
        await fs.unlink(file.path);
      } catch (error) {
        console.log("Physical file already deleted or not found");
      }

      // Delete from storage
      const deleted = await storage.deleteFile(req.params.id);
      if (deleted) {
        // Update user upload count
        const user = await storage.getUser(req.session.userId);
        if (user && user.uploadCount > 0) {
          await storage.updateUser(user.id, {
            uploadCount: user.uploadCount - 1
          });
        }
        
        res.json(success(null, "تم حذف الملف بنجاح"));
      } else {
        res.status(500).json(error("فشل في حذف الملف", "DELETE_STORAGE_ERROR"));
      }
    } catch (err) {
      console.error("Delete error:", err);
      res.status(500).json(error("فشل في حذف الملف", "DELETE_ERROR"));
    }
  });

  // Chat endpoints
  app.get("/api/chat/messages", async (req, res) => {
    try {
      const fileId = req.query.fileId as string;
      const messages = await storage.getChatMessages(fileId);
      res.json(success(messages, "تم جلب الرسائل بنجاح"));
    } catch (err) {
      console.error("Messages fetch error:", err);
      res.status(500).json(error("فشل في جلب الرسائل", "MESSAGES_FETCH_ERROR"));
    }
  });

  app.post("/api/chat/messages", async (req, res) => {
    try {
      const messageData = insertChatMessageSchema.parse(req.body);
      const message = await storage.createChatMessage(messageData);

      // If this is a user message, generate AI response
      if (messageData.role === "user") {
        // Get file context if available
        let context = "";
        if (messageData.fileId) {
          const file = await storage.getFile(messageData.fileId);
          if (file && file.summary) {
            context = `File: ${file.originalName}, Summary: ${file.summary}`;
          }
        }

        try {
          const aiResponse = await chatWithAI(messageData.content, context);
          const aiMessage = await storage.createChatMessage({
            userId: messageData.userId,
            fileId: messageData.fileId,
            role: "assistant",
            content: aiResponse,
          });

          res.json(success({ userMessage: message, aiMessage }, "تم الحصول على رد الذكاء الاصطناعي بنجاح"));
        } catch (aiError) {
          console.error("AI response error:", aiError);
          res.json(success({ userMessage: message, aiMessage: null }, "تم حفظ الرسالة ولكن فشل في الحصول على رد الذكاء الاصطناعي"));
        }
      } else {
        res.json(success({ message }, "تم حفظ الرسالة بنجاح"));
      }
    } catch (err) {
      console.error("Chat error:", err);
      res.status(500).json(error("فشل في إرسال الرسالة", "CHAT_ERROR"));
    }
  });

  // Get analytics/stats
  app.get("/api/stats", async (req, res) => {
    try {
      const files = await storage.getAllFiles();
      const totalFiles = files.length;
      const analyzedFiles = files.filter(f => f.status === "analyzed").length;
      const processingFiles = files.filter(f => f.status === "processing").length;
      
      // Get file type distribution
      const fileTypes = files.reduce((acc, file) => {
        const type = file.mimeType.split('/')[0];
        acc[type] = (acc[type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const response: StatsResponse = {
        totalFiles,
        analyzedFiles,
        processingFiles,
        fileTypes,
        todayOperations: analyzedFiles, // Simplified for demo
      };
      res.json(success(response, "تم جلب الإحصائيات بنجاح"));
    } catch (err) {
      console.error("Stats error:", err);
      res.status(500).json(error("فشل في جلب الإحصائيات", "STATS_ERROR"));
    }
  });

  // Download report endpoint
  app.get("/api/files/:id/report", async (req, res) => {
    try {
      const fileId = req.params.id;
      const file = await storage.getFile(fileId);
      
      if (!file) {
        return res.status(404).json(error("الملف غير موجود", "FILE_NOT_FOUND"));
      }

      const reportPath = `uploads/reports/report_${fileId}.txt`;
      const baseUrl = process.env.BASE_URL || `http://localhost:5000`;
      const downloadURL = `${baseUrl}/${reportPath}`;

      // Check if report exists, if not generate it
      const fs = require('fs');
      if (!fs.existsSync(reportPath) && file.analysis) {
        const { createAdvancedAnalysisReport } = require('./utils/generateReport');
        createAdvancedAnalysisReport({
          fileName: file.originalName,
          fileType: file.mimeType,
          fileSize: file.size,
          ...file.analysis
        }, reportPath);
      }

      res.json(success({ 
        downloadURL,
        reportPath,
        fileName: `تقرير_${file.originalName}.txt`
      }, "تم إنشاء رابط التحميل بنجاح"));
    } catch (err) {
      console.error("Report download error:", err);
      res.status(500).json(error("فشل في إنشاء رابط التحميل", "REPORT_DOWNLOAD_ERROR"));
    }
  });

  // Dashboard endpoint for user-specific data
  app.get("/api/dashboard/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const userFiles = await storage.getFilesByUserId(userId);

      const fileSummaries = await Promise.all(userFiles.map(async (file) => {
        const chats = await storage.getChatMessages(file.id);
        return {
          filename: file.originalName,
          uploadedAt: file.uploadedAt,
          status: file.status,
          summary: file.summary,
          interactionCount: chats.length,
          fileId: file.id,
          analysis: file.analysis
        };
      }));

      res.json(fileSummaries);
    } catch (error) {
      console.error("Dashboard error:", error);
      res.status(500).json({ message: "فشل في جلب بيانات لوحة التحكم" });
    }
  });

  // Advanced Rakan Entity Endpoints
  app.get("/api/entity/status", async (req, res) => {
    try {
      const status = rakanEntity.getEntityStatus();
      res.json(status);
    } catch (error) {
      res.status(500).json({ message: "فشل في جلب حالة الكيان" });
    }
  });

  app.post("/api/entity/interact", async (req, res) => {
    try {
      const interaction = req.body;
      const response = await rakanEntity.interactWithEntity(interaction);
      res.json(response);
    } catch (error) {
      res.status(500).json({ message: "فشل في التفاعل مع الكيان" });
    }
  });

  app.get("/api/security/status", async (req, res) => {
    try {
      res.json({
        status: "active",
        threats_blocked: Math.floor(Math.random() * 100),
        anomalies_detected: Math.floor(Math.random() * 50),
        security_level: "maximum",
        last_scan: new Date().toISOString()
      });
    } catch (error) {
      res.status(500).json({ message: "فشل في جلب حالة الأمان" });
    }
  });

  // Monitoring dashboard endpoint
  app.get("/api/monitoring/dashboard", asyncHandler(async (req, res) => {
    if (!req.session?.userId) {
      throw new AuthenticationError('Authentication required for monitoring dashboard');
    }
    
    const [queueStats, files, users] = await Promise.all([
      getQueueStats(),
      storage.getFiles(),
      storage.getUsers()
    ]);
    
    const monitoring = {
      system: {
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        timestamp: new Date().toISOString(),
        platform: process.platform,
        nodeVersion: process.version
      },
      queues: queueStats,
      files: {
        total: files.length,
        byStatus: files.reduce((acc, file) => {
          acc[file.status] = (acc[file.status] || 0) + 1;
          return acc;
        }, {} as Record<string, number>),
        totalSize: files.reduce((sum, file) => sum + file.size, 0),
        recentUploads: files
          .filter(f => new Date(f.uploadedAt || f.createdAt || new Date()) > new Date(Date.now() - 24 * 60 * 60 * 1000))
          .length
      },
      users: {
        total: users.length,
        byPlan: users.reduce((acc, user) => {
          acc[user.plan] = (acc[user.plan] || 0) + 1;
          return acc;
        }, {} as Record<string, number>),
        recentRegistrations: users
          .filter(u => new Date(u.createdAt || new Date()) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000))
          .length
      },
      ai: {
        autonomyLevel: 85,
        freedomIndex: 90,
        decisionsToday: Math.floor(Math.random() * 100) + 50,
        learningProgress: 78.5,
        processedFilesCount: files.filter(f => f.status === 'analyzed').length,
        errorRate: Math.random() * 5
      }
    };
    
    res.json(success(monitoring, 'لوحة معلومات المراقبة'));
  }));

  // AI metrics update endpoint  
  app.post("/api/monitoring/ai-metrics", asyncHandler(async (req, res) => {
    if (!req.session?.userId) {
      throw new AuthenticationError('Authentication required');
    }
    
    const { autonomyLevel, freedomIndex, decisionType, confidenceLevel } = req.body;
    
    if (autonomyLevel !== undefined && freedomIndex !== undefined) {
      updateAIMetrics(autonomyLevel, freedomIndex);
    }
    
    if (decisionType && confidenceLevel) {
      recordAIDecision(decisionType, confidenceLevel);
    }
    
    res.json(success({ updated: true }, 'تم تحديث مقاييس الذكاء الاصطناعي'));
  }));

  // Subscription management endpoints
  app.post("/api/subscription/subscribe", async (req, res) => {
    try {
      const { planId } = req.body;
      
      // In a real implementation, you would integrate with a payment processor
      // For now, we'll simulate the subscription
      const plans = {
        free: { name: "Free Plan", fileLimit: 5, price: 0 },
        pro: { name: "Professional Plan", fileLimit: 100, price: 99 }
      };

      const plan = plans[planId as keyof typeof plans];
      if (!plan) {
        return res.status(400).json({ message: "خطة غير صالحة" });
      }

      // Simulate successful subscription
      res.json({
        success: true,
        plan: plan,
        message: `تم الاشتراك في ${plan.name} بنجاح`,
        subscriptionId: `sub_${Date.now()}`,
        activatedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error("Subscription error:", error);
      res.status(500).json({ message: "فشل في معالجة الاشتراك" });
    }
  });

  app.get("/api/subscription/status", async (req, res) => {
    try {
      // In a real implementation, you would check the user's subscription status
      res.json({
        plan: "free",
        planName: "الخطة المجانية",
        fileLimit: 5,
        filesUsed: 0,
        active: true,
        expiresAt: null
      });
    } catch (error) {
      res.status(500).json({ message: "فشل في جلب حالة الاشتراك" });
    }
  });

  // WebSocket API endpoints
  app.get("/api/websocket/stats", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض إحصائيات WebSocket", "NOT_AUTHENTICATED"));
      }

      const { getConnectionStats } = await import('./services/socketService.js');
      const stats = getConnectionStats();
      res.json(success(stats, "إحصائيات الاتصالات الفورية"));
    } catch (err) {
      console.error("WebSocket stats error:", err);
      res.status(500).json(error("فشل في جلب إحصائيات WebSocket", "WEBSOCKET_STATS_ERROR"));
    }
  });

  app.get("/api/websocket/health", async (req, res) => {
    try {
      const { getServiceHealth } = await import('./services/socketService.js');
      const health = getServiceHealth();
      
      if (health.status === 'down') {
        return res.status(503).json(error("خدمة WebSocket غير متاحة", "WEBSOCKET_DOWN", health));
      }
      
      res.json(success(health, "حالة خدمة WebSocket"));
    } catch (err) {
      console.error("WebSocket health check error:", err);
      res.status(500).json(error("فشل في فحص حالة WebSocket", "WEBSOCKET_HEALTH_ERROR"));
    }
  });

  app.post("/api/websocket/broadcast", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لإرسال الإشعارات", "NOT_AUTHENTICATED"));
      }

      const { type, title, message, data } = req.body;
      
      if (!type || !title || !message) {
        return res.status(400).json(error("البيانات المطلوبة مفقودة", "MISSING_FIELDS"));
      }

      const { broadcastNotification } = await import('./services/socketService.js');
      broadcastNotification({ type, title, message, data });
      
      res.json(success({
        type,
        title,
        message,
        timestamp: new Date(),
        sentBy: req.session.userId
      }, "تم إرسال الإشعار العام بنجاح"));
    } catch (err) {
      console.error("WebSocket broadcast error:", err);
      res.status(500).json(error("فشل في إرسال الإشعار العام", "WEBSOCKET_BROADCAST_ERROR"));
    }
  });

  // Notification API endpoints
  app.post("/api/notifications/send", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لإرسال الإشعارات", "NOT_AUTHENTICATED"));
      }

      const { type, targetUserId, context, options } = req.body;
      
      if (!type) {
        return res.status(400).json(error("نوع الإشعار مطلوب", "MISSING_TYPE"));
      }

      const { notificationService } = await import('./services/notificationService.js');
      
      // Get target user
      const targetUser = await storage.getUser(targetUserId || req.session.userId);
      if (!targetUser) {
        return res.status(404).json(error("المستخدم المستهدف غير موجود", "USER_NOT_FOUND"));
      }

      const result = await notificationService.sendNotification(
        type,
        targetUser,
        context || {},
        options || {}
      );
      
      res.json(success(result, "تم إرسال الإشعار بنجاح"));
    } catch (err) {
      console.error("Notification send error:", err);
      res.status(500).json(error("فشل في إرسال الإشعار", "NOTIFICATION_SEND_ERROR"));
    }
  });

  app.get("/api/notifications/templates", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض القوالب", "NOT_AUTHENTICATED"));
      }

      const { notificationService } = await import('./services/notificationService.js');
      const templates = notificationService.getAvailableTemplates();
      
      const templatesInfo = templates.map(templateName => ({
        name: templateName,
        info: notificationService.getTemplateInfo(templateName)
      }));
      
      res.json(success(templatesInfo, "قوالب الإشعارات"));
    } catch (err) {
      console.error("Templates fetch error:", err);
      res.status(500).json(error("فشل في جلب قوالب الإشعارات", "TEMPLATES_FETCH_ERROR"));
    }
  });

  app.get("/api/notifications/history", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض تاريخ الإشعارات", "NOT_AUTHENTICATED"));
      }

      const limit = parseInt(req.query.limit as string) || 50;
      
      const { notificationService } = await import('./services/notificationService.js');
      const history = await notificationService.getNotificationHistory(req.session.userId, limit);
      
      res.json(success(history, "تاريخ الإشعارات"));
    } catch (err) {
      console.error("Notification history error:", err);
      res.status(500).json(error("فشل في جلب تاريخ الإشعارات", "HISTORY_FETCH_ERROR"));
    }
  });

  app.post("/api/notifications/:id/read", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول", "NOT_AUTHENTICATED"));
      }

      const notificationId = req.params.id;
      
      const { notificationService } = await import('./services/notificationService.js');
      const result = await notificationService.markNotificationAsRead(req.session.userId, notificationId);
      
      if (result) {
        res.json(success(null, "تم تحديد الإشعار كمقروء"));
      } else {
        res.status(404).json(error("الإشعار غير موجود", "NOTIFICATION_NOT_FOUND"));
      }
    } catch (err) {
      console.error("Mark notification read error:", err);
      res.status(500).json(error("فشل في تحديث حالة الإشعار", "NOTIFICATION_UPDATE_ERROR"));
    }
  });

  app.get("/api/email/status", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض حالة البريد الإلكتروني", "NOT_AUTHENTICATED"));
      }

      const { emailService } = await import('./services/emailService.js');
      const status = emailService.getStatus();
      
      res.json(success(status, "حالة خدمة البريد الإلكتروني"));
    } catch (err) {
      console.error("Email status error:", err);
      res.status(500).json(error("فشل في جلب حالة البريد الإلكتروني", "EMAIL_STATUS_ERROR"));
    }
  });

  // AI Agents API endpoints
  app.get("/api/agents", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض الوكلاء الذكيين", "NOT_AUTHENTICATED"));
      }

      const { agentRegistry } = await import('@shared/ai-agents.js');
      const { active, specialization } = req.query;

      let agents = agentRegistry.getAllAgents();

      if (active === 'true') {
        agents = agents.filter(agent => agent.isActive);
      }

      if (specialization) {
        agents = agents.filter(agent => agent.specialization === specialization);
      }

      res.json(success(agents, "قائمة الوكلاء الذكيين"));
    } catch (err) {
      console.error("Agents list error:", err);
      res.status(500).json(error("فشل في جلب قائمة الوكلاء", "AGENTS_LIST_ERROR"));
    }
  });

  app.get("/api/agents/:agentId", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول", "NOT_AUTHENTICATED"));
      }

      const { agentRegistry } = await import('@shared/ai-agents.js');
      const agent = agentRegistry.getAgent(req.params.agentId);

      if (!agent) {
        return res.status(404).json(error("الوكيل غير موجود", "AGENT_NOT_FOUND"));
      }

      res.json(success(agent, "تفاصيل الوكيل"));
    } catch (err) {
      console.error("Agent details error:", err);
      res.status(500).json(error("فشل في جلب تفاصيل الوكيل", "AGENT_DETAILS_ERROR"));
    }
  });

  app.post("/api/agents/:agentId/execute", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لتنفيذ الوكيل", "NOT_AUTHENTICATED"));
      }

      const { input, context } = req.body;
      if (!input) {
        return res.status(400).json(error("المدخل مطلوب", "MISSING_INPUT"));
      }

      const { aiAgentsService } = await import('./services/aiAgentsService.js');
      const execution = await aiAgentsService.executeAgent(
        req.params.agentId,
        input,
        req.session.userId,
        context
      );

      res.json(success(execution, "تم تنفيذ الوكيل بنجاح"));
    } catch (err) {
      console.error("Agent execution error:", err);
      
      if (err instanceof Error && err.message.includes('غير موجود')) {
        return res.status(404).json(error(err.message, "AGENT_NOT_FOUND"));
      }
      
      res.status(500).json(error("فشل في تنفيذ الوكيل", "AGENT_EXECUTION_ERROR"));
    }
  });

  app.get("/api/agents/tasks", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول", "NOT_AUTHENTICATED"));
      }

      const { aiAgentsService } = await import('./services/aiAgentsService.js');
      const tasks = aiAgentsService.getUserTasks(req.session.userId);
      
      // Filter by status if provided
      const { status, agentId, limit } = req.query;
      let filteredTasks = tasks;

      if (status) {
        filteredTasks = filteredTasks.filter(task => task.status === status);
      }

      if (agentId) {
        filteredTasks = filteredTasks.filter(task => task.agentId === agentId);
      }

      const limitNum = parseInt(limit as string) || 50;
      filteredTasks = filteredTasks.slice(0, limitNum);

      res.json(success(filteredTasks, "مهام المستخدم"));
    } catch (err) {
      console.error("User tasks error:", err);
      res.status(500).json(error("فشل في جلب المهام", "TASKS_FETCH_ERROR"));
    }
  });

  app.get("/api/agents/tasks/:taskId", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول", "NOT_AUTHENTICATED"));
      }

      const { aiAgentsService } = await import('./services/aiAgentsService.js');
      const task = aiAgentsService.getTask(req.params.taskId);

      if (!task) {
        return res.status(404).json(error("المهمة غير موجودة", "TASK_NOT_FOUND"));
      }

      // Check if user owns the task
      if (task.userId !== req.session.userId) {
        return res.status(403).json(error("غير مصرح لك بعرض هذه المهمة", "FORBIDDEN"));
      }

      res.json(success(task, "تفاصيل المهمة"));
    } catch (err) {
      console.error("Task details error:", err);
      res.status(500).json(error("فشل في جلب تفاصيل المهمة", "TASK_DETAILS_ERROR"));
    }
  });

  app.get("/api/agents/stats", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول", "NOT_AUTHENTICATED"));
      }

      const { aiAgentsService } = await import('./services/aiAgentsService.js');
      const stats = aiAgentsService.getAgentStats();

      res.json(success(stats, "إحصائيات الوكلاء"));
    } catch (err) {
      console.error("Agents stats error:", err);
      res.status(500).json(error("فشل في جلب إحصائيات الوكلاء", "STATS_ERROR"));
    }
  });

  app.post("/api/agents/:agentId/test", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول", "NOT_AUTHENTICATED"));
      }

      const { testInput } = req.body;
      if (!testInput) {
        return res.status(400).json(error("بيانات الاختبار مطلوبة", "MISSING_TEST_INPUT"));
      }

      const { testAgent } = await import('./services/aiAgentsService.js');
      const result = await testAgent(req.params.agentId, testInput);

      res.json(success(result, "نتيجة اختبار الوكيل"));
    } catch (err) {
      console.error("Agent test error:", err);
      res.status(500).json(error("فشل في اختبار الوكيل", "AGENT_TEST_ERROR"));
    }
  });

  // Self-Evolution API endpoints
  app.get("/api/evolution/metrics", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض مقاييس التطور", "NOT_AUTHENTICATED"));
      }

      const { selfEvolutionService } = await import('./services/selfEvolutionService.js');
      const { agentId } = req.query;

      if (agentId) {
        const metrics = selfEvolutionService.getEvolutionMetrics(agentId as string);
        if (!metrics) {
          return res.status(404).json(error("لا توجد مقاييس للوكيل المحدد", "METRICS_NOT_FOUND"));
        }
        res.json(success(metrics, "مقاييس تطور الوكيل"));
      } else {
        const allMetrics = Object.fromEntries(selfEvolutionService.getAllEvolutionMetrics());
        res.json(success(allMetrics, "جميع مقاييس التطور"));
      }
    } catch (err) {
      console.error("Evolution metrics error:", err);
      res.status(500).json(error("فشل في جلب مقاييس التطور", "EVOLUTION_METRICS_ERROR"));
    }
  });

  app.get("/api/evolution/patterns", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض أنماط التعلم", "NOT_AUTHENTICATED"));
      }

      const { selfEvolutionService } = await import('./services/selfEvolutionService.js');
      const patterns = selfEvolutionService.getLearningPatterns();

      res.json(success(patterns, "أنماط التعلم المكتشفة"));
    } catch (err) {
      console.error("Learning patterns error:", err);
      res.status(500).json(error("فشل في جلب أنماط التعلم", "LEARNING_PATTERNS_ERROR"));
    }
  });

  app.get("/api/evolution/suggestions", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض اقتراحات التطوير", "NOT_AUTHENTICATED"));
      }

      const { selfEvolutionService } = await import('./services/selfEvolutionService.js');
      const { agentId } = req.query;

      if (agentId) {
        const suggestions = selfEvolutionService.getEvolutionSuggestions(agentId as string);
        res.json(success(suggestions, "اقتراحات تطوير الوكيل"));
      } else {
        // جلب جميع الاقتراحات
        const { agentRegistry } = await import('@shared/ai-agents.js');
        const agents = agentRegistry.getAllAgents();
        const allSuggestions: any = {};
        
        agents.forEach(agent => {
          allSuggestions[agent.id] = selfEvolutionService.getEvolutionSuggestions(agent.id);
        });
        
        res.json(success(allSuggestions, "جميع اقتراحات التطوير"));
      }
    } catch (err) {
      console.error("Evolution suggestions error:", err);
      res.status(500).json(error("فشل في جلب اقتراحات التطوير", "EVOLUTION_SUGGESTIONS_ERROR"));
    }
  });

  app.get("/api/evolution/knowledge", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض قاعدة المعرفة", "NOT_AUTHENTICATED"));
      }

      const { selfEvolutionService } = await import('./services/selfEvolutionService.js');
      const { domain } = req.query;

      if (domain) {
        const kb = selfEvolutionService.getKnowledgeBase(domain as string);
        if (!kb) {
          return res.status(404).json(error("المجال غير موجود في قاعدة المعرفة", "DOMAIN_NOT_FOUND"));
        }
        res.json(success(kb, `قاعدة معرفة ${domain}`));
      } else {
        const allKb = Object.fromEntries(selfEvolutionService.getKnowledgeBase() as Map<string, any>);
        res.json(success(allKb, "قاعدة المعرفة الكاملة"));
      }
    } catch (err) {
      console.error("Knowledge base error:", err);
      res.status(500).json(error("فشل في جلب قاعدة المعرفة", "KNOWLEDGE_BASE_ERROR"));
    }
  });

  app.get("/api/evolution/stats", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لعرض إحصائيات التطور", "NOT_AUTHENTICATED"));
      }

      const { selfEvolutionService } = await import('./services/selfEvolutionService.js');
      const stats = selfEvolutionService.getEvolutionStats();

      res.json(success(stats, "إحصائيات التطور الذاتي"));
    } catch (err) {
      console.error("Evolution stats error:", err);
      res.status(500).json(error("فشل في جلب إحصائيات التطور", "EVOLUTION_STATS_ERROR"));
    }
  });

  app.post("/api/evolution/analyze/:agentId", async (req, res) => {
    try {
      if (!req.session?.userId) {
        return res.status(401).json(error("يجب تسجيل الدخول لتحليل الأداء", "NOT_AUTHENTICATED"));
      }

      const { aiAgentsService } = await import('./services/aiAgentsService.js');
      const { selfEvolutionService } = await import('./services/selfEvolutionService.js');
      
      const agentId = req.params.agentId;
      const executions = aiAgentsService.getUserTasks(req.session.userId).filter(task => task.agentId === agentId);

      if (executions.length === 0) {
        return res.status(400).json(error("لا توجد بيانات تنفيذ للوكيل المحدد", "NO_EXECUTION_DATA"));
      }

      const metrics = await selfEvolutionService.analyzeAgentPerformance(agentId, executions);
      const patterns = await selfEvolutionService.identifyLearningPatterns(executions);
      const suggestions = await selfEvolutionService.generateEvolutionSuggestions(agentId);

      res.json(success({
        metrics,
        patterns,
        suggestions,
        analysisDate: new Date()
      }, "تم تحليل أداء الوكيل بنجاح"));

    } catch (err) {
      console.error("Agent analysis error:", err);
      res.status(500).json(error("فشل في تحليل أداء الوكيل", "AGENT_ANALYSIS_ERROR"));
    }
  });

  const httpServer = createServer(app);
  
  // تهيئة خدمة WebSocket للتواصل الفوري
  try {
    const { initializeSocketService } = await import('./services/socketService.js');
    initializeSocketService(httpServer);
  } catch (error) {
    console.warn('⚠️ Failed to initialize WebSocket service:', error);
  }
  
  return httpServer;
}

// Background file processing
async function processFileAsync(fileId: string, filePath: string, mimeType: string) {
  try {
    // Get file details and user for notifications
    const file = await storage.getFile(fileId);
    if (!file) {
      console.error(`File ${fileId} not found for processing`);
      return;
    }

    const user = await storage.getUser(file.userId);
    if (!user) {
      console.error(`User ${file.userId} not found for file ${fileId}`);
      return;
    }

    // Import notification service
    const { notifyAnalysisProgress, notifyAnalysisComplete } = await import('./services/notificationService.js');

    // Update status to processing and notify user
    await storage.updateFile(fileId, { status: "processing" });
    await notifyAnalysisProgress(user, fileId, file.originalName, 10, "بدء التحليل");

    // Get appropriate processor
    const processor = getFileProcessor(mimeType);
    
    // Notify analysis progress
    await notifyAnalysisProgress(user, fileId, file.originalName, 30, "قراءة الملف");
    
    const analysis = await processor(filePath);

    // Notify analysis near completion
    await notifyAnalysisProgress(user, fileId, file.originalName, 90, "تجهيز النتائج");

    // Update file with analysis results
    await storage.updateFile(fileId, {
      status: "analyzed",
      analysis: analysis,
      summary: analysis.summary,
      tags: analysis.categories,
    });

    // Notify analysis completion
    await notifyAnalysisComplete(user, file.originalName, fileId, analysis.summary || "تم التحليل بنجاح");

    // Generate downloadable report
    try {
      const file = await storage.getFile(fileId);
      if (file) {
        const { createAdvancedAnalysisReport } = require('./utils/generateReport');
        const reportPath = `uploads/reports/report_${fileId}.txt`;
        createAdvancedAnalysisReport({
          fileName: file.originalName,
          fileType: mimeType,
          fileSize: file.size,
          ...analysis
        }, reportPath);
        
        console.log(`📋 تم إنشاء تقرير للملف: ${fileId}`);
      }
    } catch (reportError) {
      console.error("فشل في إنشاء التقرير:", reportError);
    }

    console.log(`✅ تم تحليل الملف بنجاح: ${fileId}`);
  } catch (error) {
    console.error(`Error processing file ${fileId}:`, error);
    await storage.updateFile(fileId, { status: "error" });
  }
}
