import { Router } from 'express';
import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import jwt from 'jsonwebtoken';
import { storage } from '../storage';
import { success, error } from '../utils/apiResponse';

const router = Router();

// JWT Secret (في بيئة الإنتاج، يجب أن يكون من المتغيرات البيئية)
const JWT_SECRET = process.env.JWT_SECRET || 'rakan-ai-secret-key-2025';

// تكوين استراتيجية Google - فقط إذا كانت المتغيرات البيئية متوفرة
if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: '/api/auth/google/callback',
    scope: ['profile', 'email'],
    state: true
  }, async (accessToken, refreshToken, profile, done) => {
  try {
    // البحث عن مستخدم موجود بالبريد الإلكتروني
    const email = profile.emails?.[0].value || '';
    const existingUser = await storage.getUserByEmail(email) || null;

    if (existingUser) {
      // تحديث بيانات Google إذا لم تكن موجودة
      if (!existingUser.googleId) {
        const updatedUser = {
          ...existingUser,
          googleId: profile.id,
          avatar: profile.photos?.[0].value || existingUser.avatar || '',
          displayName: profile.displayName || existingUser.displayName || existingUser.username
        };
        // نحتاج إلى تحديث المستخدم في التخزين
        await storage.updateUser(existingUser.id, updatedUser);
        return done(null, updatedUser);
      }
      return done(null, existingUser);
    }

    // إنشاء مستخدم جديد
    const newUser = {
      googleId: profile.id,
      username: `google_${profile.id}`,
      email: profile.emails?.[0].value || '',
      displayName: profile.displayName || '',
      avatar: profile.photos?.[0].value || '',
      password: '', // لا نحتاج كلمة مرور للمستخدمين من Google
      plan: 'free' as const,
      isActive: 'true' as const,
      lastLogin: new Date(),
      uploadCount: 0
    };

    const user = await storage.createUser(newUser);
    done(null, user);
  } catch (err) {
    console.error('Google OAuth error:', err);
    done(err as Error);
  }
  }));
} else {
  console.log('⚠️ Google OAuth not configured - GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables required');
}

// إعداد Passport للتسلسل
passport.serializeUser((user: any, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id: string, done) => {
  try {
    const user = await storage.getUser(id);
    done(null, user);
  } catch (err) {
    done(err);
  }
});

// تسجيل الدخول مع Google
router.get('/google', (req, res, next) => {
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
    return res.status(503).json(error('خدمة Google OAuth غير متوفرة - يرجى التواصل مع المطور'));
  }
  
  const state = req.query.redirect_uri 
    ? Buffer.from(JSON.stringify({ redirect_uri: req.query.redirect_uri })).toString('base64')
    : undefined;
  
  passport.authenticate('google', {
    scope: ['profile', 'email'],
    state,
    session: false
  })(req, res, next);
});

// رد الاتصال من Google
router.get('/google/callback', (req, res, next) => {
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) {
    return res.redirect('/login?error=oauth_not_configured');
  }
  
  passport.authenticate('google', { 
    session: false, 
    failureRedirect: '/login?error=google_auth_failed' 
  }, (err: any, user: any) => {
    if (err) {
      console.error('Google auth error:', err);
      return res.redirect('/login?error=auth_error');
    }
    
    if (!user) {
      return res.redirect('/login?error=no_user');
    }

    // إنشاء جلسة تقليدية للتوافق مع النظام الحالي
    if (req.session) {
      req.session.user = { 
        id: user.id, 
        username: user.username, 
        plan: user.plan 
      };
    }

    // إنشاء رمز JWT للاستخدام المستقبلي
    const token = generateJWT(user);
    
    // استخراج معلومات إعادة التوجيه
    const state = req.query.state 
      ? JSON.parse(Buffer.from(req.query.state as string, 'base64').toString())
      : {};
    
    const redirectUri = state.redirect_uri || '/';
    
    // إعادة التوجيه مع معلومات النجاح
    res.redirect(`${redirectUri}?google_login=success&token=${token}`);
  })(req, res, next);
});
// Callback handling is now done in the custom callback above

// جلب بيانات المستخدم الحالي (دعم JWT)
router.get('/current', async (req, res) => {
  try {
    // التحقق من الجلسة أولاً (النظام الحالي)
    if (req.session?.user?.id) {
      const user = await storage.getUser(req.session.user.id);
      if (user) {
        return res.json(success('User data retrieved', { user }));
      }
    }

    // التحقق من رمز JWT كبديل
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json(error('غير مصرح'));
    }

    const decoded = verifyJWT(token);
    const user = await storage.getUser(decoded.id);

    if (!user) {
      return res.status(404).json(error('المستخدم غير موجود'));
    }

    res.json(success('تم جلب بيانات المستخدم', user));
  } catch (err) {
    console.error('Get current user error:', err);
    res.status(401).json(error('رمز غير صالح'));
  }
});

// تسجيل الخروج (دعم الجلسات و JWT)
router.post('/logout', (req, res) => {
  // مسح الجلسة
  if (req.session) {
    req.session.destroy((err: any) => {
      if (err) {
        console.error('Session destroy error:', err);
      }
    });
  }
  
  // مسح ملفات تعريف الارتباط
  res.clearCookie('connect.sid');
  res.clearCookie('session');
  
  res.json(success('تم تسجيل الخروج بنجاح'));
});

// إنشاء رمز JWT
function generateJWT(user: any): string {
  const payload = {
    id: user.id,
    username: user.username,
    email: user.email,
    plan: user.plan
  };
  
  return jwt.sign(payload, JWT_SECRET, { 
    expiresIn: '7d',
    issuer: 'rakan-ai',
    subject: user.id
  });
}

// التحقق من رمز JWT
function verifyJWT(token: string): any {
  try {
    return jwt.verify(token, JWT_SECRET, {
      issuer: 'rakan-ai'
    });
  } catch (err) {
    throw new Error('Invalid JWT token');
  }
}

export default router;