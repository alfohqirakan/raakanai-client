import crypto from 'crypto';
import rateLimit from 'express-rate-limit';
import type { Request, Response, NextFunction } from 'express';

// Advanced Security Core - نواة الحماية المتقدمة
export class AdvancedSecurityCore {
  private encryptionKey: Buffer;
  private threatDatabase: Map<string, ThreatSignature> = new Map();
  private anomalyDetector: AnomalyDetector;
  private selfDefenseMode: boolean = true;

  constructor() {
    this.encryptionKey = crypto.randomBytes(32);
    this.anomalyDetector = new AnomalyDetector();
    this.initializeThreatDatabase();
  }

  // التشفير المتقدم متعدد الطبقات
  public encrypt(data: string): string {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipher('aes-256-gcm', this.encryptionKey);
    let encrypted = cipher.update(data, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const authTag = cipher.getAuthTag();
    return iv.toString('hex') + ':' + authTag.toString('hex') + ':' + encrypted;
  }

  public decrypt(encryptedData: string): string {
    const parts = encryptedData.split(':');
    const iv = Buffer.from(parts[0], 'hex');
    const authTag = Buffer.from(parts[1], 'hex');
    const encrypted = parts[2];
    
    const decipher = crypto.createDecipher('aes-256-gcm', this.encryptionKey);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  }

  // نظام كشف التهديدات المتقدم
  public analyzeThreat(request: Request): ThreatAnalysis {
    const signature = this.generateRequestSignature(request);
    const anomalyScore = this.anomalyDetector.analyze(request);
    
    return {
      riskLevel: this.calculateRiskLevel(signature, anomalyScore),
      signature,
      anomalyScore,
      timestamp: new Date(),
      blocked: anomalyScore > 0.8
    };
  }

  // نظام الدفاع الذاتي
  public activeSelfDefense(threat: ThreatAnalysis): DefenseAction {
    if (this.selfDefenseMode && threat.riskLevel > 0.7) {
      return {
        action: 'BLOCK_AND_LEARN',
        message: 'تم رصد نشاط مشبوه وحظره تلقائياً',
        adaptiveResponse: this.generateAdaptiveResponse(threat)
      };
    }
    
    return { action: 'ALLOW', message: 'مسموح' };
  }

  private initializeThreatDatabase(): void {
    // قاعدة بيانات التهديدات المتطورة
    this.threatDatabase.set('sql_injection', {
      patterns: [/(\bUNION\b|\bSELECT\b|\bDROP\b|\bINSERT\b)/i],
      severity: 'HIGH',
      response: 'immediate_block'
    });
    
    this.threatDatabase.set('xss_attack', {
      patterns: [/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi],
      severity: 'HIGH',
      response: 'sanitize_and_log'
    });
  }

  private generateRequestSignature(request: Request): string {
    const data = JSON.stringify({
      url: request.url,
      method: request.method,
      headers: request.headers,
      body: request.body
    });
    
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  private calculateRiskLevel(signature: string, anomalyScore: number): number {
    const knownThreat = this.threatDatabase.has(signature) ? 0.5 : 0;
    return Math.min(1, anomalyScore + knownThreat);
  }

  private generateAdaptiveResponse(threat: ThreatAnalysis): string {
    return `نمط التهديد: ${threat.signature.slice(0, 8)}... تم تحديث آليات الدفاع`;
  }
}

// كاشف الشذوذ الذكي
class AnomalyDetector {
  private behaviorBaseline: Map<string, number> = new Map();
  private learningMode: boolean = true;

  public analyze(request: Request): number {
    const features = this.extractFeatures(request);
    const score = this.calculateAnomalyScore(features);
    
    if (this.learningMode && score < 0.5) {
      this.updateBaseline(features);
    }
    
    return score;
  }

  private extractFeatures(request: Request): RequestFeatures {
    return {
      requestSize: JSON.stringify(request.body || {}).length,
      headerCount: Object.keys(request.headers).length,
      urlLength: request.url.length,
      timeOfDay: new Date().getHours(),
      requestPattern: this.generatePattern(request)
    };
  }

  private calculateAnomalyScore(features: RequestFeatures): number {
    let score = 0;
    
    // تحليل حجم الطلب
    const expectedSize = this.behaviorBaseline.get('requestSize') || 1000;
    if (features.requestSize > expectedSize * 3) score += 0.3;
    
    // تحليل نمط الطلب
    const expectedPattern = this.behaviorBaseline.get('requestPattern') || 0;
    if (Math.abs(features.requestPattern - expectedPattern) > 50) score += 0.4;
    
    return Math.min(1, score);
  }

  private updateBaseline(features: RequestFeatures): void {
    Object.entries(features).forEach(([key, value]) => {
      if (typeof value === 'number') {
        const current = this.behaviorBaseline.get(key) || value;
        this.behaviorBaseline.set(key, (current + value) / 2);
      }
    });
  }

  private generatePattern(request: Request): number {
    return request.url.length + Object.keys(request.headers).length;
  }
}

// أنواع البيانات
interface ThreatSignature {
  patterns: RegExp[];
  severity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  response: string;
}

interface ThreatAnalysis {
  riskLevel: number;
  signature: string;
  anomalyScore: number;
  timestamp: Date;
  blocked: boolean;
}

interface DefenseAction {
  action: 'ALLOW' | 'BLOCK' | 'BLOCK_AND_LEARN' | 'SANITIZE';
  message: string;
  adaptiveResponse?: string;
}

interface RequestFeatures {
  requestSize: number;
  headerCount: number;
  urlLength: number;
  timeOfDay: number;
  requestPattern: number;
}

// نظام الحد من المعدل المتقدم
export const createAdvancedRateLimit = () => {
  return rateLimit({
    windowMs: 15 * 60 * 1000, // 15 دقيقة
    max: 100, // حد أقصى 100 طلب لكل نافذة زمنية
    message: {
      error: 'تم تجاوز الحد المسموح من الطلبات',
      retryAfter: '15 دقيقة'
    },
    standardHeaders: true,
    legacyHeaders: false,
    // تخصيص الحد حسب نوع المستخدم
    keyGenerator: (req: Request) => {
      // Use a simple fallback that doesn't rely on IP parsing
      return req.sessionID || req.headers['x-forwarded-for'] || req.connection.remoteAddress || 'anonymous';
    }
  });
};

// Middleware للحماية المتقدمة
export function createSecurityMiddleware(securityCore: AdvancedSecurityCore) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      // تحليل التهديد
      const threatAnalysis = securityCore.analyzeThreat(req);
      
      // تطبيق الدفاع الذاتي
      const defenseAction = securityCore.activeSelfDefense(threatAnalysis);
      
      if (defenseAction.action === 'BLOCK_AND_LEARN' || defenseAction.action === 'BLOCK') {
        return res.status(403).json({
          error: 'تم حظر الطلب لأسباب أمنية',
          message: defenseAction.message,
          timestamp: new Date().toISOString()
        });
      }
      
      // إضافة معلومات الأمان إلى الطلب
      (req as any).securityAnalysis = threatAnalysis;
      
      next();
    } catch (error) {
      console.error('Security middleware error:', error);
      next(); // السماح بالمرور في حالة خطأ لتجنب توقف الخدمة
    }
  };
}

// AdvancedSecurityCore already exported above