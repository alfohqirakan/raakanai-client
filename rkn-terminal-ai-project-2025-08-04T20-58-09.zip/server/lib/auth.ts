import bcrypt from 'bcrypt';
import { storage } from '../storage.js';
import { success, error } from '../utils/apiResponse.js';

const SALT_ROUNDS = 12; // Enhanced security

export async function createUser(username: string, password: string) {
  try {
    // Enhanced password validation
    if (password.length < 8) {
      throw new Error('كلمة المرور يجب أن تكون 8 أحرف على الأقل');
    }
    
    if (!/^[a-zA-Z0-9_]+$/.test(username)) {
      throw new Error('اسم المستخدم يجب أن يحتوي على أحرف وأرقام فقط');
    }
    
    if (username.length < 3) {
      throw new Error('اسم المستخدم يجب أن يكون 3 أحرف على الأقل');
    }
    
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
    
    // Check if user already exists
    const existingUser = await storage.getUserByUsername(username);
    if (existingUser) {
      throw new Error('اسم المستخدم موجود بالفعل');
    }

    const user = await storage.createUser({
      username,
      password: hashedPassword,
      plan: 'free',
      uploadCount: 0,
      isActive: true,
      lastLogin: new Date(),
    });

    console.log(`🔐 تم إنشاء مستخدم جديد: ${username}`);
    return success({ 
      user: { 
        id: user.id, 
        username: user.username,
        plan: user.plan,
        uploadCount: user.uploadCount
      } 
    }, 'تم إنشاء المستخدم بنجاح');
  } catch (err) {
    console.error('خطأ في إنشاء المستخدم:', err);
    throw new Error((err as Error).message || 'فشل في إنشاء المستخدم');
  }
}

export async function verifyUser(username: string, password: string) {
  try {
    const user = await storage.getUserByUsername(username);
    
    if (!user) {
      console.log(`❌ محاولة دخول فاشلة: مستخدم غير موجود - ${username}`);
      throw new Error('اسم المستخدم أو كلمة المرور غير صحيحة');
    }

    if (!user.isActive) {
      console.log(`❌ محاولة دخول فاشلة: حساب معطل - ${username}`);
      throw new Error('الحساب معطل. يرجى الاتصال بالدعم');
    }

    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) {
      console.log(`❌ محاولة دخول فاشلة: كلمة مرور خاطئة - ${username}`);
      throw new Error('اسم المستخدم أو كلمة المرور غير صحيحة');
    }

    // Update last login
    await storage.updateUser(user.id, {
      ...user,
      lastLogin: new Date(),
    });

    console.log(`✅ دخول ناجح: ${username}`);
    return success({ 
      user: { 
        id: user.id, 
        username: user.username,
        plan: user.plan,
        uploadCount: user.uploadCount,
        createdAt: user.createdAt,
        lastLogin: new Date()
      } 
    }, 'تم تسجيل الدخول بنجاح');
  } catch (err) {
    console.error('خطأ في التحقق من المستخدم:', err);
    throw new Error((err as Error).message || 'فشل في تسجيل الدخول');
  }
}

/**
 * Check if user can upload more files
 */
export async function canUserUpload(userId: string): Promise<{ canUpload: boolean; remaining: number; limit: number }> {
  try {
    const user = await storage.getUserById(userId);
    if (!user || !user.isActive) {
      return { canUpload: false, remaining: 0, limit: 0 };
    }
    
    const limit = user.plan === 'pro' ? 100 : 5;
    const remaining = limit - (user.uploadCount || 0);
    
    return {
      canUpload: remaining > 0,
      remaining: Math.max(0, remaining),
      limit
    };
  } catch (err) {
    console.error('خطأ في فحص حدود الرفع:', err);
    return { canUpload: false, remaining: 0, limit: 0 };
  }
}

/**
 * Increment user upload count
 */
export async function incrementUserUploadCount(userId: string) {
  try {
    const user = await storage.getUserById(userId);
    if (!user) {
      throw new Error('المستخدم غير موجود');
    }
    
    const { canUpload, limit } = await canUserUpload(userId);
    if (!canUpload) {
      throw new Error(`تم الوصول للحد الأقصى للرفع (${limit} ملف)`);
    }
    
    const updatedUser = {
      ...user,
      uploadCount: (user.uploadCount || 0) + 1,
    };
    
    await storage.updateUser(userId, updatedUser);
    return updatedUser;
  } catch (err) {
    console.error('خطأ في تحديث عداد الرفع:', err);
    throw err;
  }
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function comparePassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword);
}